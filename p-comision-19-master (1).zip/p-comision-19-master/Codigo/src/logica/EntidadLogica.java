package logica;

/**
 * Datos de una entidad que la vista necesita para dibujarla.
 */
public interface EntidadLogica {

    // Atributos de clase

    /** Capa del suelo: pasto, agua, caídas al vacío y suelo quebradizo. */
    int CAPA_SUELO = 0;

    /** Capa de lo que se agarra: objetos y power-ups. */
    int CAPA_OBJETOS = 1;

    /** Capa de los obstáculos altos, como las rocas. */
    int CAPA_OBSTACULOS = 2;

    /** Capa de los personajes: enemigos, jefes y proyectiles. */
    int CAPA_PERSONAJES = 3;

    /** Capa del jugador, la más alta. */
    int CAPA_JUGADOR = 4;

    // Consultas

    /**
     * Devuelve la coordenada x de la imagen.
     */
    int getX();

    /**
     * Devuelve la coordenada y de la imagen.
     */
    int getY();

    /**
     * Devuelve la x donde se dibuja la imagen (puede no coincidir con getX() si la imagen es más grande que la entidad: el margen lo define el dominio en su medidas.txt).
     */
    int getXImagen();

    /**
     * Devuelve la y donde se dibuja la imagen (puede no coincidir con getY() si la imagen es más grande que la entidad: el margen lo define el dominio en su medidas.txt).
     */
    int getYImagen();

    /**
     * Devuelve la ruta de la imagen actual.
     */
    String getRutaImagen();

    /**
     * Indica si la entidad fue eliminada.
     */
    boolean estaEliminada();

    /**
     * Devuelve la capa en la que se dibuja; las capas más altas tapan a las más bajas.
     */
    int getCapa();

    /**
     * Indica si la entidad se ve en este momento; es falso en los instantes apagados de un parpadeo.
     */
    boolean esVisible();
}
