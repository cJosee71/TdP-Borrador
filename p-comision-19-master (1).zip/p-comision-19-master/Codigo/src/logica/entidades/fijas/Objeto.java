package logica.entidades.fijas;

import logica.entidades.Colisionador;
import logica.entidades.Entidad;
import logica.entidades.Link;
import logica.fabricas.Sprite;
import logica.sonido.GestorDeSonido;
import logica.sonido.Sonido;

/**
 * Objeto que Link guarda en su inventario y puede equipar.
 */
public abstract class Objeto extends Entidad {

    // Constructores

    /**
     * Crea el objeto en (x, y).
     */
    protected Objeto(Sprite sprite, int x, int y) {
        super(sprite, x, y);
    }

    // Comandos

    /**
     * Recibe un choque (patrón Visitor).
     */
    public void aceptarColision(Colisionador c) {
        c.colisionarCon(this);
    }

    /**
     * Suena al ser recogido, pasa al inventario de Link y sale del sector.
     */
    public void serRecogidoPor(Link l) {
        GestorDeSonido.getInstancia().reproducir(Sonido.POWER_UP);
        l.agregarAlInventario(this);
        eliminar();
    }

    /**
     * Ataca con el objeto; no hace nada por defecto.
     */
    public void atacarCon(Link l) {
    }

    /**
     * Suelta el ataque; no hace nada por defecto.
     */
    public void soltarAtaqueCon(Link l) {
    }

    /**
     * Protege con el objeto; no hace nada por defecto.
     */
    public void protegerCon(Link l) {
    }

    /**
     * Suelta la protección; no hace nada por defecto.
     */
    public void soltarProteccionCon(Link l) {
    }

    // Consultas

    /**
     * Se dibuja en la capa de los objetos.
     */
    public int getCapa() {
        return CAPA_OBJETOS;
    }

    /**
     * Devuelve el nombre que muestra el HUD.
     */
    public abstract String getNombre();
}
