package logica.entidades.fijas;

import logica.entidades.EntidadAnimada;
import logica.entidades.Link;
import logica.fabricas.Sprite;

/**
 * Obstáculo que no se puede atravesar.
 */
public class Roca extends Obstaculo {

    // Constructores

    /**
     * Crea la roca en (x, y); su cuerpo lo trae el sprite (medidas.txt del dominio).
     */
    public Roca(Sprite sprite, int x, int y) {
        super(sprite, x, y);
    }

    // Comandos

    /**
     * No le hace nada a Link.
     */
    public void afectar(Link l) {
    }

    // Consultas

    /**
     * Se dibuja en la capa de los obstáculos altos.
     */
    public int getCapa() {
        return CAPA_OBSTACULOS;
    }

    /**
     * Le bloquea el paso a cualquiera.
     */
    public boolean bloqueaPasoA(EntidadAnimada quien) {
        return true;
    }

    /**
     * Impide que un enemigo se abalance o dispare a través de ella.
     */
    public boolean impideAbalanzarse() {
        return true;
    }
}
