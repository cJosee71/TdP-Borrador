package logica.entidades.fijas;

import logica.entidades.Link;
import logica.fabricas.Sprite;

/**
 * Power-up que suma un fragmento; cada FRAGMENTOS_POR_CORAZON (de Link) aumenta la vida máxima.
 */
public class FragmentoDeCorazon extends PowerUP {

    // Constructores

    /**
     * Crea el fragmento en (x, y); su cuerpo lo trae el sprite (medidas.txt del dominio).
     */
    public FragmentoDeCorazon(Sprite sprite, int x, int y) {
        super(sprite, x, y);
    }

    // Comandos

    /**
     * Le suma a Link un fragmento.
     */
    public void serRecogidoPor(Link l) {
        l.sumarFragmento();
        super.serRecogidoPor(l);
    }
}
