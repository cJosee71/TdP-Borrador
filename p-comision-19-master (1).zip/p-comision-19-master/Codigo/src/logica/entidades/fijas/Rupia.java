package logica.entidades.fijas;

import java.util.Random;

import logica.entidades.Link;
import logica.fabricas.Sprite;

/**
 * Power-up que suma una cantidad de rupias al azar.
 */
public class Rupia extends PowerUP {

    // Atributos de clase

    private static final int CANTIDAD_MINIMA = 1;
    private static final int CANTIDAD_MAXIMA = 5;
    private static final int PUNTOS_POR_RUPIA = 10;

    // Atributos de instancia

    protected int cantidad;

    // Constructores

    /**
     * Crea la rupia en (x, y) con una cantidad al azar; su cuerpo lo trae el sprite (medidas.txt del dominio).
     */
    public Rupia(Sprite sprite, int x, int y) {
        super(sprite, x, y);
        cantidad = CANTIDAD_MINIMA + new Random().nextInt(CANTIDAD_MAXIMA - CANTIDAD_MINIMA + 1);
    }

    // Comandos

    /**
     * Le suma las rupias a Link.
     */
    public void serRecogidoPor(Link l) {
        l.sumarRupias(cantidad);
        super.serRecogidoPor(l);
    }

    // Consultas

    /**
     * Devuelve los puntos por cada rupia.
     */
    public int getPuntos() {
        return PUNTOS_POR_RUPIA * cantidad;
    }

    /**
     * Devuelve la cantidad de rupias.
     */
    public int getCantidad() {
        return cantidad;
    }
}
