package logica.entidades.enemigos;

import logica.comportamientos.AtaquePorProyectil;
import logica.comportamientos.DefensaLimitada;
import logica.comportamientos.MovimientoInducido;
import logica.comportamientos.MovimientoTeletransporte;
import logica.entidades.Proyectil;
import logica.fabricas.Sprite;
import logica.util.Direccion;

/**
 * Enemigo que se teletransporta y dispara hacia Link cuando está enfrente sin obstáculos en el medio.
 * Al teletransportarse muestra un GIF de desaparecer antes del salto y uno de aparecer al llegar.
 */
public class Wizzrobe extends EnemigoConDrop implements GeneradorProyectil {

    // Atributos de clase

    private static final int VIDA = 2;
    private static final int PUNTOS = 500;
    private static final double PROBABILIDAD_DROP = 1.0;
    private static final long INTERVALO_TELETRANSPORTE = 3000;
    private static final int CANTIDAD_DISPAROS = 1;
    private static final int DANIO_DISPARO = 1;
    private static final long INTERVALO_DISPARO = 3000;
    private static final long DURACION_INVULNERABILIDAD = 1000;
    private static final long DURACION_APARECER = 500;
    private static final long DURACION_DESAPARECER = 500;

    // Atributos de instancia

    protected boolean apareciendo;
    protected boolean desapareciendo;
    protected int teletransportes;

    // Constructores

    /**
     * Crea el Wizzrobe en (x, y); su cuerpo lo trae el sprite (medidas.txt del dominio).
     */
    public Wizzrobe(Sprite sprite, int x, int y) {
        super(sprite, x, y, VIDA);
        setMovimiento(new MovimientoTeletransporte(INTERVALO_TELETRANSPORTE));
        setAtaque(new AtaquePorProyectil(this, CANTIDAD_DISPAROS, INTERVALO_DISPARO));
        setDefensa(new DefensaLimitada(DefensaLimitada.SIN_LIMITE, DefensaLimitada.SIEMPRE));
    }

    // Comandos

    /**
     * Al aparecer, vuelve a ser vulnerable, mira hacia Link y muestra el GIF de aparecer;
     * deja programado el GIF de desaparecer para antes del próximo salto.
     */
    public void teletransportarse() {
        setDefensa(new DefensaLimitada(DefensaLimitada.SIN_LIMITE, DefensaLimitada.SIEMPRE));
        setDireccion(direccionHaciaJugador());
        int numero = ++teletransportes;
        desapareciendo = false;
        apareciendo = true;
        notificarObservers();
        programar(DURACION_APARECER, () -> {
            if (numero == teletransportes) { apareciendo = false; notificarObservers(); }
        });
        programar(INTERVALO_TELETRANSPORTE - DURACION_DESAPARECER, () -> {
            if (numero == teletransportes) { desapareciendo = true; notificarObservers(); }
        });
    }

    /**
     * Queda quieto e invulnerable un tiempo, parpadeando; después se teletransporta y vuelve a ser vulnerable.
     * Corta las imágenes de aparecer y desaparecer que estuvieran programadas. Si el golpe lo mató, no hace nada.
     */
    protected void alSerGolpeado() {
        if (!muriendo) {
            teletransportes++;
            apareciendo = false;
            desapareciendo = false;
            setDefensa(new DefensaLimitada(0, DefensaLimitada.SIEMPRE));
            setMovimiento(new MovimientoInducido((Direccion) null, 0));
            parpadearDurante(DURACION_INVULNERABILIDAD);
            programar(DURACION_INVULNERABILIDAD, () -> setMovimiento(new MovimientoTeletransporte(INTERVALO_TELETRANSPORTE)));
        }
    }

    // Consultas

    /**
     * Devuelve el estado de la imagen: aparecer o desaparecer mientras se teletransporta, o el de muerte o el de su dirección.
     */
    @Override
    protected String getEstadoImagen() {
        String estado = super.getEstadoImagen();
        String direccion = getDireccion().name().toLowerCase();
        if (!muriendo && apareciendo)
            estado = "aparecer-" + direccion;
        else if (!muriendo && desapareciendo)
            estado = "desaparecer-" + direccion;
        return estado;
    }

    /**
     * Crea un disparo hacia Link.
     */
    public Proyectil generarProyectil() {
        return miJuego.getFabricaEntidades().crearProyectil(getX(), getY(), direccionHaciaJugador(), DANIO_DISPARO);
    }

    /**
     * Devuelve los puntos que da al morir.
     */
    public int getPuntos() {
        return PUNTOS;
    }

    /**
     * Devuelve la probabilidad de soltar un power-up.
     */
    protected double getProbabilidadDrop() {
        return PROBABILIDAD_DROP;
    }
}
