package logica.entidades.enemigos;

import logica.comportamientos.AtaquePorContacto;
import logica.comportamientos.DefensaLimitada;
import logica.comportamientos.MovimientoInducido;
import logica.fabricas.Sprite;
import logica.util.Direccion;
import logica.util.Posicion;

/**
 * Trampa invulnerable que sale hacia Link cuando queda en línea y vuelve al chocar.
 */
public class TrampaDeCuchillas extends Enemigo {

    // Atributos de clase

    private static final int VIDA = 1;
    private static final int PUNTOS = 0;
    private static final int DANIO_CONTACTO = 1;
    private static final int VELOCIDAD_SALIDA = 8;
    private static final int VELOCIDAD_VUELTA = 4;

    // Atributos de instancia

    protected Posicion posicionOriginal;
    protected Posicion destino;

    // Constructores

    /**
     * Crea la trampa en reposo en (x, y); su cuerpo lo trae el sprite (medidas.txt del dominio).
     */
    public TrampaDeCuchillas(Sprite sprite, int x, int y) {
        super(sprite, x, y, VIDA);
        posicionOriginal = new Posicion(x, y);
        setMovimiento(new MovimientoInducido((Direccion) null, VELOCIDAD_SALIDA));
        setAtaque(new AtaquePorContacto(DANIO_CONTACTO));
        setDefensa(new DefensaLimitada(0, DefensaLimitada.SIEMPRE));
    }

    // Comandos

    /**
     * Si está en reposo y Link queda en línea sin obstáculos en el medio, sale hacia el lugar que ocupaba Link; al llegar, vuelve.
     */
    protected void vigilarJugador() {
        boolean enReposo = getX() == posicionOriginal.getX() && getY() == posicionOriginal.getY();
        if (enReposo && getHitbox().estaEnLineaCon(miJuego.getJugador().getHitbox()) && !hayObstaculoHastaJugador()) {
            Direccion d = direccionHaciaJugador();
            Posicion posicionDeLink = miJuego.getJugador().getPosicion();
            int destinoX = d.getDx() != 0 ? posicionDeLink.getX() : getX();
            int destinoY = d.getDy() != 0 ? posicionDeLink.getY() : getY();
            destino = new Posicion(destinoX, destinoY);
            setDireccion(d);
            setMovimiento(new MovimientoInducido(d, VELOCIDAD_SALIDA));
        } else if (destino != null && llegoAlDestino()) {
            volver();
        }
    }

    /**
     * Vuelve a su lugar al chocar.
     */
    protected void alChocarConBloqueo() {
        volver();
    }

    /**
     * Vuelve despacio a su lugar; al llegar queda en reposo y puede volver a salir.
     */
    private void volver() {
        destino = null;
        setMovimiento(new MovimientoInducido(posicionOriginal, VELOCIDAD_VUELTA));
    }

    // Consultas

    /**
     * Indica si ya llegó (o pasó) al lugar que ocupaba Link cuando salió.
     */
    private boolean llegoAlDestino() {
        Direccion d = getDireccion();
        boolean llegoEnX = (getX() - destino.getX()) * d.getDx() >= 0;
        boolean llegoEnY = (getY() - destino.getY()) * d.getDy() >= 0;
        return llegoEnX && llegoEnY;
    }

    /**
     * Devuelve los puntos que da al morir.
     */
    public int getPuntos() {
        return PUNTOS;
    }
}
