package logica.entidades.enemigos;

import logica.fabricas.Sprite;
import logica.sonido.GestorDeSonido;
import logica.sonido.Sonido;

/**
 * Enemigo final de un nivel.
 */
public abstract class Jefe extends Enemigo {

    // Constructores

    /**
     * Crea el jefe en (x, y) con su vida.
     */
    protected Jefe(Sprite sprite, int x, int y, int vida) {
        super(sprite, x, y, vida);
    }

    // Comandos

    /**
     * Al terminar la animación de muerte: suena el jefe derrotado, se elimina y avisa al juego que se derrotó un jefe.
     */
    protected void desaparecer() {
        GestorDeSonido.getInstancia().reproducir(Sonido.JEFE_DERROTADO);
        eliminar();
        miJuego.jefeDerrotado(this);
    }
}
