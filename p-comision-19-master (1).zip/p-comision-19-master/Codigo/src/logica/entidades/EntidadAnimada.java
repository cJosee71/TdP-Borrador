package logica.entidades;

import java.util.ArrayList;
import java.util.List;

import logica.comportamientos.AtaquePorContacto;
import logica.comportamientos.ComportamientoAtaque;
import logica.comportamientos.ComportamientoDefensa;
import logica.comportamientos.ComportamientoMovimiento;
import logica.comportamientos.DefensaLimitada;
import logica.comportamientos.MovimientoInducido;
import logica.entidades.enemigos.Enemigo;
import logica.entidades.fijas.Objeto;
import logica.entidades.fijas.Obstaculo;
import logica.entidades.fijas.PowerUP;
import logica.fabricas.Sprite;
import logica.hilos.AccionProgramada;
import logica.sonido.GestorDeSonido;
import logica.sonido.Sonido;
import logica.util.Direccion;
import logica.util.Hitbox;
import logica.util.Posicion;

/**
 * Entidad que se mueve, ataca y recibe daño mediante estrategias (Strategy); resuelve choques con Visitor.
 */
public abstract class EntidadAnimada extends Entidad implements Colisionador {

    // Atributos de clase

    private static final long DURACION_PARPADEO = 600;
    private static final long PERIODO_PARPADEO = 100;

    // Atributos de instancia

    protected ComportamientoMovimiento movimiento;
    protected ComportamientoAtaque ataque;
    protected ComportamientoDefensa defensa;
    protected Direccion direccion;
    protected int vida;
    protected volatile long finParpadeo;
    protected List<AccionProgramada> pendientes;

    // Constructores

    /**
     * Crea la entidad mirando hacia abajo, quieta, sin daño al tocar y con defensa normal.
     */
    protected EntidadAnimada(Sprite sprite, int x, int y, int vida) {
        super(sprite, x, y);
        this.vida = vida;
        direccion = Direccion.ABAJO;
        pendientes = new ArrayList<>();
        movimiento = new MovimientoInducido((Direccion) null, 0);
        ataque = new AtaquePorContacto(0);
        defensa = new DefensaLimitada(DefensaLimitada.SIN_LIMITE, DefensaLimitada.SIEMPRE);
    }

    // Comandos

    /**
     * Cambia la estrategia de movimiento.
     */
    public void setMovimiento(ComportamientoMovimiento m) {
        movimiento = m;
    }

    /**
     * Cambia la estrategia de ataque.
     */
    public void setAtaque(ComportamientoAtaque a) {
        ataque = a;
    }

    /**
     * Cambia la estrategia de defensa.
     */
    public void setDefensa(ComportamientoDefensa d) {
        defensa = d;
    }

    /**
     * Cambia hacia dónde mira y actualiza la imagen.
     */
    public void setDireccion(Direccion d) {
        direccion = d;
        sprite.setEstado(d.name().toLowerCase());
        notificarObservers();
    }

    /**
     * Hace una vuelta: vigilar, moverse, atacar, verificar choques y ejecutar acciones vencidas.
     */
    public void actualizarEstado(AdministradorColisiones c) {
        if (!estaEliminada()) {
            vigilarJugador();
            movimiento.mover(this, c);
            ataque.atacar(this, c);
            if (!estaEliminada())
                c.verificarColisiones(this);
            ejecutarPendientes();
            avisarParpadeo();
        }
    }

    /**
     * Mientras parpadea avisa en cada vuelta para que la vista la prenda y apague; al terminar avisa una vez más.
     */
    private void avisarParpadeo() {
        if (finParpadeo != 0) {
            if (System.currentTimeMillis() >= finParpadeo)
                finParpadeo = 0;
            notificarObservers();
        }
    }

    /**
     * Hace su vuelta cuando la actualiza el hilo del mundo.
     */
    @Override
    public void actualizarPorMundo(AdministradorColisiones c) {
        actualizarEstado(c);
    }

    /**
     * Gancho al chocar con un bloqueo; vacío por defecto.
     */
    protected void alChocarConBloqueo() { }

    /**
     * Gancho al salir del sector; vacío por defecto.
     */
    protected void alSalirDelSector(Direccion d) { }

    /**
     * Gancho para mirar dónde está Link; vacío por defecto.
     */
    protected void vigilarJugador() { }

    /**
     * Avanza en una dirección sin controlar bloqueos.
     */
    public void avanzar(Direccion d, int pasos) {
        Posicion posicionNueva = getPosicion().desplazada(d, pasos);
        setPosicion(posicionNueva);
    }

    /**
     * Avanza hacia una posición sin pasarse ni controlar bloqueos.
     */
    public void avanzarHacia(Posicion destino, int pasos) {
        int desplazamientoX = Math.max(-pasos, Math.min(pasos, destino.getX() - getX()));
        int desplazamientoY = Math.max(-pasos, Math.min(pasos, destino.getY() - getY()));
        Posicion posicionNueva = new Posicion(getX() + desplazamientoX, getY() + desplazamientoY);
        setPosicion(posicionNueva);
    }

    /**
     * Recibe un golpe a través de su defensa; si le hace daño, suena el impacto.
     */
    public synchronized void recibirDanio(int danio, Direccion origen) {
        boolean recibioDanio = defensa.recibirDanio(this, danio, origen);
        if (recibioDanio) {
            GestorDeSonido.getInstancia().reproducir(Sonido.IMPACTO);
            alSerGolpeado();
        }
    }

    /**
     * Resta vida y muere si llega a 0.
     */
    public synchronized void aplicarDanio(int danio) {
        vida -= danio;
        if (vida > 0)
            finParpadeo = System.currentTimeMillis() + DURACION_PARPADEO;
        notificarObservers();
        if (vida <= 0)
            morir();
    }

    /**
     * Gancho al quedarse sin vida; vacío por defecto.
     */
    protected void morir() { }

    /**
     * Gancho al recibir daño; vacío por defecto.
     */
    protected void alSerGolpeado() { }

    /**
     * Parpadea al menos ms milisegundos desde ahora; si ya parpadeaba más, no lo acorta.
     */
    protected void parpadearDurante(long ms) {
        finParpadeo = Math.max(finParpadeo, System.currentTimeMillis() + ms);
        notificarObservers();
    }

    /**
     * Gancho después de atacar; vacío por defecto.
     */
    public void ataqueRealizado() { }

    /**
     * Gancho para volver a la defensa normal; vacío por defecto.
     */
    public void restaurarDefensa() { }

    /**
     * Gancho al teletransportarse; vacío por defecto.
     */
    public void teletransportarse() { }

    /**
     * Gancho al terminar un ataque largo; vacío por defecto.
     */
    public void ataqueTerminado() { }

    /**
     * Programa una acción para dentro de ms milisegundos, sin crear hilos.
     */
    protected synchronized void programar(long ms, Runnable accion) {
        long instanteDeVencimiento = System.currentTimeMillis() + ms;
        pendientes.add(new AccionProgramada(instanteDeVencimiento, accion));
    }

    /**
     * Descarta las acciones programadas que todavía no vencieron.
     */
    protected synchronized void cancelarProgramadas() {
        pendientes.clear();
    }

    /**
     * Ejecuta las acciones vencidas fuera de la llave.
     */
    private void ejecutarPendientes() {
        List<AccionProgramada> accionesVencidas = sacarVencidas(System.currentTimeMillis());
        for (AccionProgramada accion : accionesVencidas)
            accion.ejecutar();
    }

    /**
     * Saca de pendientes las acciones vencidas y las devuelve.
     */
    private synchronized List<AccionProgramada> sacarVencidas(long ahora) {
        List<AccionProgramada> vencidas = new ArrayList<>();
        for (AccionProgramada accion : pendientes)
            if (accion.estaVencida(ahora))
                vencidas.add(accion);
        pendientes.removeAll(vencidas);
        return vencidas;
    }

    /**
     * Choque con Link; vacío por defecto.
     */
    @Override
    public void colisionarCon(Link l) { }

    /**
     * Choque con un enemigo; vacío por defecto.
     */
    @Override
    public void colisionarCon(Enemigo e) { }

    /**
     * Choque con un proyectil; vacío por defecto.
     */
    @Override
    public void colisionarCon(Proyectil p) { }

    /**
     * Choque con un obstáculo; vacío por defecto.
     */
    @Override
    public void colisionarCon(Obstaculo o) { }

    /**
     * Choque con un power-up; vacío por defecto.
     */
    @Override
    public void colisionarCon(PowerUP p) { }

    /**
     * Choque con un objeto; vacío por defecto.
     */
    @Override
    public void colisionarCon(Objeto o) { }

    // Consultas

    /**
     * Indica si trata las caídas al vacío como una pared; false por defecto.
     */
    public boolean esquivaVacios() {
        return false;
    }

    /**
     * Indica si lo frenan Link y los enemigos; false por defecto.
     */
    public boolean esFrenadoPorPersonajes() {
        return false;
    }

    /**
     * Se dibuja en la capa de los personajes.
     */
    public int getCapa() {
        return CAPA_PERSONAJES;
    }

    /**
     * Devuelve hacia dónde mira.
     */
    public Direccion getDireccion() {
        return direccion;
    }

    /**
     * Indica si se ve: durante el parpadeo se prende y se apaga cada PERIODO_PARPADEO ms.
     */
    @Override
    public boolean esVisible() {
        long ahora = System.currentTimeMillis();
        return ahora >= finParpadeo || (ahora / PERIODO_PARPADEO) % 2 == 0;
    }

    /**
     * Devuelve la vida que le queda.
     */
    public int getVida() {
        return vida;
    }

    /**
     * Indica si quiere atacar en esta vuelta; false por defecto.
     */
    public boolean quiereAtacar() {
        return false;
    }

    /**
     * Indica si soltó el ataque; false por defecto.
     */
    public boolean soltoElAtaque() {
        return false;
    }

    /**
     * Indica si el ataque está cargado; false por defecto.
     */
    public boolean ataqueCargado() {
        return false;
    }

    /**
     * Indica si Link está en línea y en la dirección hacia la que mira.
     */
    public boolean linkEstaEnfrente() {
        Entidad link = miJuego.getJugador();
        boolean estaEnLinea = getHitbox().estaEnLineaCon(link.getHitbox());
        boolean estaEnfrente = estaEnLinea && direccionHaciaJugador() == direccion;
        return estaEnfrente;
    }

    /**
     * Indica si entre esta entidad y Link hay algo que impide abalanzarse o disparar (roca, agua o vacío).
     */
    public boolean hayObstaculoHastaJugador() {
        Entidad link = miJuego.getJugador();
        Hitbox camino = getHitbox().caminoHasta(link.getHitbox());
        boolean hayObstaculo = false;
        for (Entidad otra : miSector.getEntidades())
            if (otra != this && otra != link && !otra.estaEliminada()
                    && otra.impideAbalanzarse() && otra.getHitbox().intersecta(camino))
                hayObstaculo = true;
        return hayObstaculo;
    }

    /**
     * Devuelve la dirección hacia Link, comparando centros.
     */
    public Direccion direccionHaciaJugador() {
        Posicion centroDeLink = miJuego.getJugador().getCentro();
        Direccion direccionHaciaLink = getCentro().direccionHacia(centroDeLink);
        return direccionHaciaLink;
    }
}
