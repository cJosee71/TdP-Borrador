package logica.entidades;

import logica.comportamientos.DefensaLimitada;
import logica.comportamientos.MovimientoInducido;
import logica.fabricas.Sprite;
import logica.util.Direccion;
import logica.util.Posicion;

/**
 * Disparo o roca que avanza hasta chocar, salir del sector o llegar a su destino.
 */
public class Proyectil extends EntidadAnimada {

    // Atributos de clase

    private static final int VIDA = 1;
    private static final int VELOCIDAD = 6;
    private static final int PERMANENCIA_EN_PISO = 3000;

    // Atributos de instancia

    protected int danio;
    protected Posicion destino;
    protected boolean aterrizada;

    // Constructores

    /**
     * Crea el proyectil hacia una dirección; su cuerpo lo trae el sprite (medidas.txt del dominio: disparo o roca grande).
     */
    public Proyectil(Sprite sprite, int x, int y, Direccion d, int danio) {
        super(sprite, x, y, VIDA);
        this.danio = danio;
        setDireccion(d);
        setMovimiento(new MovimientoInducido(d, VELOCIDAD));
        setDefensa(new DefensaLimitada(0, DefensaLimitada.SIEMPRE));
    }

    // Comandos

    /**
     * Hace que avance hasta una posición fija.
     */
    public void setDestino(Posicion p) {
        destino = p;
        setMovimiento(new MovimientoInducido(p, VELOCIDAD));
    }

    /**
     * Hace su vuelta; al llegar a su destino queda unos segundos en el piso y después desaparece.
     */
    @Override
    public void actualizarEstado(AdministradorColisiones c) {
        super.actualizarEstado(c);
        if (destino != null && !aterrizada && !estaEliminada()
                && getX() == destino.getX() && getY() == destino.getY()) {
            aterrizada = true;
            programar(PERMANENCIA_EN_PISO, this::desaparecer);
        }
    }

    /**
     * Recibe un choque (patrón Visitor).
     */
    public void aceptarColision(Colisionador c) {
        c.colisionarCon(this);
    }

    /**
     * Desaparece al chocar con un bloqueo.
     */
    protected void alChocarConBloqueo() {
        desaparecer();
    }

    /**
     * Desaparece al salir del sector.
     */
    protected void alSalirDelSector(Direccion d) {
        desaparecer();
    }

    /**
     * Desaparece al morir.
     */
    protected void morir() {
        desaparecer();
    }

    /**
     * Se elimina del juego.
     */
    private void desaparecer() {
        eliminar();
    }

    // Consultas

    /**
     * Devuelve el daño que hace.
     */
    public int getDanio() {
        return danio;
    }
}
