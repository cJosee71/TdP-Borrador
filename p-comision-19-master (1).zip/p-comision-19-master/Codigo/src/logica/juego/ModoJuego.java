package logica.juego;

/**
 * Reglas de un modo de juego: cuándo termina la partida y en qué ranking se guarda.
 */
public abstract class ModoJuego {

    // Atributos de instancia

    protected int cantidadNiveles;

    // Constructores

    /**
     * Crea el modo con su cantidad de niveles.
     */
    protected ModoJuego(int cantidadNiveles) {
        this.cantidadNiveles = cantidadNiveles;
    }

    // Comandos

    /**
     * Guarda la entrada en el ranking del modo.
     */
    public abstract void registrarPuntaje(TablaRankings t, EntradaRanking e);

    /**
     * Reacciona al empezar un nivel. Por defecto no hace nada; los modos que lo necesitan lo redefinen.
     */
    public void alIniciarNivel() {
    }

    /**
     * Reacciona cuando Link recibe daño. Por defecto no hace nada; los modos que lo necesitan lo redefinen.
     */
    public void alRecibirDanio(ArbitroPartida a) {
    }

    /**
     * Reacciona a cada segundo de la partida. Por defecto no hace nada; los modos que lo necesitan lo redefinen.
     */
    public void alPasarTiempo(ArbitroPartida a, int segundos) {
    }

    // Consultas

    /**
     * Indica si el número es el del último nivel.
     */
    public boolean esUltimoNivel(int numero) {
        return numero == cantidadNiveles;
    }

    /**
     * Devuelve el nombre del modo.
     */
    public abstract String getNombre();

    /**
     * Devuelve el ranking del modo.
     */
    public abstract Ranking getRanking(TablaRankings t);

    /**
     * Devuelve el texto que explica las reglas del modo, para mostrarlo al elegirlo.
     */
    public abstract String getDescripcion();
}
