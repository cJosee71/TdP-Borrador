package logica.juego;

/**
 * Modo en el que la partida termina al recibir el primer daño (un golpe o una caída al vacío).
 */
public class NoHit extends ModoJuego {

    // Atributos de clase

    private static final int CANTIDAD_NIVELES = 2;

    // Constructores

    /**
     * Crea el modo con CANTIDAD_NIVELES niveles.
     */
    public NoHit() {
        super(CANTIDAD_NIVELES);
    }

    // Comandos

    /**
     * Agrega la entrada al ranking de este modo.
     */
    @Override
    public void registrarPuntaje(TablaRankings t, EntradaRanking e) {
        t.agregarAlRankingNoHit(e);
    }

    /**
     * Termina la partida al recibir daño, sea un golpe o una caída al vacío.
     */
    @Override
    public void alRecibirDanio(ArbitroPartida a) {
        a.terminarPartida();
    }

    // Consultas

    /**
     * Devuelve el nombre del modo.
     */
    @Override
    public String getNombre() {
        return "NoHit";
    }

    /**
     * Devuelve el ranking de este modo.
     */
    @Override
    public Ranking getRanking(TablaRankings t) {
        return t.getRankingNoHit();
    }

    /**
     * Devuelve la descripción del modo.
     */
    @Override
    public String getDescripcion() {
        return "Un solo golpe y la partida termina.";
    }
}
