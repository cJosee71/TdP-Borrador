package logica.fabricas;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

/**
 * Crea los sprites de cada entidad desde la carpeta de un dominio gráfico (patrón Abstract Factory): la ruta de cada
 * imagen, su margen y el cuerpo de la entidad. Los márgenes y los cuerpos los lee del archivo medidas.txt de la carpeta
 * del dominio, así un dominio con dibujos de otro tamaño solo cambia ese archivo; cada entidad tiene que tener ahí su
 * línea "cuerpo", y Link además su línea "alcance" (hasta dónde llega su golpe de espada). También arma la ruta de los
 * fondos de los sectores.
 */
public abstract class FabricaSprites {

    // Atributos de clase

    protected static final String ARCHIVO_MEDIDAS = "/medidas.txt";

    // Atributos de instancia

    protected Map<String, int[]> medidas;

    // Consultas

    /**
     * Crea el sprite de Link, con cada imagen en su versión normal y en la de la bellota (túnica roja). Las imágenes con
     * la espada afuera usan el margen "link-espada" (la x hacia la izquierda, la y hacia arriba) y el GIF del golpe, el
     * margen "link-golpe". El alcance de su espada es la línea "alcance link" de medidas.txt.
     */
    public Sprite crearSpritesLink() {
        Sprite s = conAlcance(conCuerpo(new Sprite(), "link"), "link");
        for (String prefijo : new String[] { "", "bellota-" }) {
            String base = carpeta() + "/link-" + prefijo;
            for (String estado : new String[] { "abajo", "arriba", "izquierda", "derecha",
                    "escudo-abajo", "escudo-arriba", "escudo-izquierda", "escudo-derecha" })
                s.agregar(prefijo + estado, base + estado + ".png");
            s.agregar(prefijo + "caida", base + "caida.gif");
            s.agregar(prefijo + "muerte", base + "muerte.gif");
            s.agregar(prefijo + "pierde-vida", base + "pierde-vida.gif");
            for (String direccion : new String[] { "abajo", "arriba", "izquierda", "derecha" }) {
                int espadaX = direccion.equals("izquierda") ? margenX("link-espada") : 0;
                int espadaY = direccion.equals("arriba") ? margenY("link-espada") : 0;
                s.agregar(prefijo + "ataque-recargado-" + direccion, base + "ataque-recargado-" + direccion + ".png", espadaX, espadaY);
                s.agregar(prefijo + "ataque-" + direccion, base + "ataque-" + direccion + ".gif", margenX("link-golpe"), margenY("link-golpe"));
                s.agregar(prefijo + "caminar-" + direccion, base + "caminar-" + direccion + ".gif");
                s.agregar(prefijo + "caminar-escudo-" + direccion, base + "caminar-escudo-" + direccion + ".gif");
                s.agregar(prefijo + "caminar-ataque-" + direccion, base + "caminar-ataque-" + direccion + ".gif", espadaX, espadaY);
                s.agregar(prefijo + "caminar-recargado-" + direccion, base + "caminar-recargado-" + direccion + ".gif", espadaX, espadaY);
            }
        }
        return s;
    }

    /**
     * Crea el sprite de el Moblin.
     */
    public Sprite crearSpritesMoblin() {
        Sprite s = conCuerpo(new Sprite(), "moblin");
        for (String direccion : new String[] { "abajo", "arriba", "izquierda", "derecha" })
            s.agregar(direccion, carpeta() + "/moblin-" + direccion + ".gif");
        s.agregar("muerte", carpeta() + "/moblin-muerte.gif");
        return s;
    }

    /**
     * Crea el sprite de el Moblin con espada y escudo.
     */
    public Sprite crearSpritesMoblinConEspadaYEscudo() {
        String nombre = "moblinconespadayescudo";
        Sprite s = conCuerpo(new Sprite(), nombre);
        for (String estado : new String[] { "abajo", "arriba", "izquierda", "derecha", "muerte" })
            s.agregar(estado, carpeta() + "/" + nombre + "-" + estado + ".gif", margenX(nombre), margenY(nombre));
        return s;
    }

    /**
     * Crea el sprite de el erizo de mar, con la nube de muerte.
     */
    public Sprite crearSpritesErizoDeMar() {
        Sprite s = armar("erizodemar", "normal");
        s.agregar("muerte", carpeta() + "/erizodemar-muerte.gif");
        return s;
    }

    /**
     * Crea el sprite de el Octorok, con la nube de muerte.
     */
    public Sprite crearSpritesOctorok() {
        Sprite s = armar("octorok", "abajo", "arriba", "izquierda", "derecha");
        s.agregar("muerte", carpeta() + "/octorok-muerte.gif");
        return s;
    }

    /**
     * Crea el sprite de la trampa de cuchillas.
     */
    public Sprite crearSpritesTrampaDeCuchillas() {
        return armar("trampadecuchillas", "normal");
    }

    /**
     * Crea el sprite de el Wizzrobe: una imagen por dirección, los GIFs de aparecer y desaparecer, y la nube de muerte.
     */
    public Sprite crearSpritesWizzrobe() {
        Sprite s = armar("wizzrobe", "abajo", "arriba", "izquierda", "derecha");
        for (String direccion : new String[] {"abajo", "arriba", "izquierda", "derecha"}) {
            s.agregar("aparecer-" + direccion, carpeta() + "/wizzrobe-aparecer-" + direccion + ".gif");
            s.agregar("desaparecer-" + direccion, carpeta() + "/wizzrobe-desaparecer-" + direccion + ".gif");
        }
        s.agregar("muerte", carpeta() + "/wizzrobe-muerte.gif");
        return s;
    }

    /**
     * Crea el sprite de MasterStalfos: un GIF para caminar, otro para el golpe de espada y otro para la muerte en cada dirección.
     */
    public Sprite crearSpritesMasterStalfos() {
        String nombre = "masterstalfos";
        Sprite s = conCuerpo(new Sprite(), nombre);
        for (String direccion : new String[] { "abajo", "arriba", "izquierda", "derecha" })
            for (String prefijo : new String[] { "", "ataque-", "muerte-" })
                s.agregar(prefijo + direccion, carpeta() + "/" + nombre + "-" + prefijo + direccion + ".gif", margenX(nombre),
                        margenY(nombre));
        return s;
    }

    /**
     * Crea el sprite de StoneHinox: todos sus estados son GIF animados (caminar, embestida,
     * vulnerable, avalancha y la nube de muerte agrandada). Si el dominio dibuja al jefe más grande
     * que su cuerpo, cada imagen usa el margen "stonehinox" de medidas.txt (0 si no está).
     */
    public Sprite crearSpritesStoneHinox() {
        String nombre = "stonehinox";
        Sprite s = conCuerpo(new Sprite(), nombre);
        for (String estado : new String[] {"normal", "embestida", "vulnerable", "avalancha", "muerte"}) {
            s.agregar(estado, carpeta() + "/" + nombre + "-" + estado + ".gif", margenX(nombre), margenY(nombre));
        }
        return s;
    }

    /**
     * Crea el sprite de la rupia.
     */
    public Sprite crearSpritesRupia() {
        return armar("rupia", "normal");
    }

    /**
     * Crea el sprite de la bellota.
     */
    public Sprite crearSpritesBellota() {
        return armar("bellota", "normal");
    }

    /**
     * Crea el sprite de el corazón.
     */
    public Sprite crearSpritesCorazon() {
        return armar("corazon", "normal");
    }

    /**
     * Crea el sprite de el fragmento de corazón.
     */
    public Sprite crearSpritesFragmentoDeCorazon() {
        return armar("fragmentodecorazon", "normal");
    }

    /**
     * Crea el sprite de la espada.
     */
    public Sprite crearSpritesEspada() {
        return armar("espada", "normal");
    }

    /**
     * Crea el sprite de el escudo.
     */
    public Sprite crearSpritesEscudo() {
        return armar("escudo", "normal");
    }

    /**
     * Crea el sprite de la roca.
     */
    public Sprite crearSpritesRoca() {
        return armar("roca", "normal");
    }

    /**
     * Crea el sprite de la pared invisible del borde del sector (imagen transparente).
     */
    public Sprite crearSpritesPared() {
        return armar("pared", "normal");
    }

    /**
     * Crea el sprite de el agua.
     */
    public Sprite crearSpritesAgua() {
        return armar("agua", "normal");
    }

    /**
     * Crea el sprite de el pasto.
     */
    public Sprite crearSpritesPasto() {
        return armar("pasto", "normal");
    }

    /**
     * Crea el sprite de la caída al vacío.
     */
    public Sprite crearSpritesCaidasAlVacio() {
        return armar("vacio", "normal");
    }

    /**
     * Crea el sprite de el suelo quebradizo.
     */
    public Sprite crearSpritesSuelosQuebradizo() {
        return armar("suelo-quebradizo", "normal");
    }

    /**
     * Crea el sprite de el disparo.
     */
    public Sprite crearSpritesProyectil() {
        return armar("proyectil", "normal");
    }

    /**
     * Crea el sprite de la roca grande.
     */
    public Sprite crearSpritesRocaGrande() {
        return armar("rocagrande", "normal");
    }

    /**
     * Devuelve la ruta de la imagen de fondo de un sector (según el número de nivel y la columna del sector), dentro de la carpeta del dominio.
     */
    public String getRutaFondo(int numeroNivel, int columna) {
        return carpeta() + "/fondos/nivel" + numeroNivel + "/fondo-sector-" + columna + ".png";
    }

    /**
     * Arma un sprite con una imagen por estado y el cuerpo de la entidad.
     */
    protected Sprite armar(String nombre, String... estados) {
        Sprite s = conCuerpo(new Sprite(), nombre);
        for (String estado : estados) {
            s.agregar(estado, carpeta() + "/" + nombre + "-" + estado + ".png");
        }
        return s;
    }

    /**
     * Devuelve la carpeta de imágenes del dominio.
     */
    protected abstract String carpeta();

    /**
     * Le asigna al sprite el cuerpo "cuerpo nombre" del archivo de medidas. Toda entidad tiene que tener su línea: si
     * falta (o no tiene 4 números), lanza IllegalStateException con el nombre de la línea y del archivo.
     */
    protected Sprite conCuerpo(Sprite s, String nombre) {
        int[] m = medidas().get("cuerpo " + nombre);
        if (m == null || m.length != 4) {
            throw new IllegalStateException("Falta la línea \"cuerpo " + nombre + "\" en " + carpeta() + ARCHIVO_MEDIDAS);
        }
        s.setCuerpo(new Cuerpo(m[0], m[1], m[2], m[3]));
        return s;
    }

    /**
     * Le asigna al sprite el alcance del golpe de espada, la línea "alcance nombre" del archivo de medidas. Si falta (o no
     * tiene 1 número), lanza IllegalStateException con el nombre de la línea y del archivo.
     */
    protected Sprite conAlcance(Sprite s, String nombre) {
        int[] m = medidas().get("alcance " + nombre);
        if (m == null || m.length != 1) {
            throw new IllegalStateException("Falta la línea \"alcance " + nombre + "\" en " + carpeta() + ARCHIVO_MEDIDAS);
        }
        s.setAlcanceAtaque(m[0]);
        return s;
    }

    /**
     * Devuelve el margen x de la imagen "imagen nombre" del archivo de medidas (0 si no está).
     */
    protected int margenX(String nombre) {
        int[] m = medidas().get("imagen " + nombre);
        return m != null && m.length == 2 ? m[0] : 0;
    }

    /**
     * Devuelve el margen y de la imagen "imagen nombre" del archivo de medidas (0 si no está).
     */
    protected int margenY(String nombre) {
        int[] m = medidas().get("imagen " + nombre);
        return m != null && m.length == 2 ? m[1] : 0;
    }

    /**
     * Devuelve las medidas del dominio; las lee la primera vez que se piden.
     */
    protected Map<String, int[]> medidas() {
        if (medidas == null) {
            medidas = leerMedidas(carpeta() + ARCHIVO_MEDIDAS);
        }
        return medidas;
    }

    /**
     * Lee un archivo de medidas: cada línea es "tipo nombre números..." (tipo cuerpo, imagen o alcance); se ignoran las líneas
     * vacías y las que empiezan con #. Si el archivo no existe, devuelve un mapa vacío (y el primer sprite que pida su
     * cuerpo avisa el error).
     */
    protected Map<String, int[]> leerMedidas(String ruta) {
        Map<String, int[]> leidas = new HashMap<>();
        InputStream entrada = getClass().getResourceAsStream(ruta);
        if (entrada == null) {
            return leidas;
        }
        try (BufferedReader lector = new BufferedReader(new InputStreamReader(entrada, StandardCharsets.UTF_8))) {
            String linea;
            while ((linea = lector.readLine()) != null) {
                linea = linea.trim();
                if (linea.isEmpty() || linea.startsWith("#")) {
                    continue;
                }
                String[] partes = linea.split("\\s+");
                int[] numeros = new int[partes.length - 2];
                for (int i = 0; i < numeros.length; i++) {
                    numeros[i] = Integer.parseInt(partes[i + 2]);
                }
                leidas.put(partes[0] + " " + partes[1], numeros);
            }
        } catch (IOException e) {
            leidas.clear();
        }
        return leidas;
    }
}
