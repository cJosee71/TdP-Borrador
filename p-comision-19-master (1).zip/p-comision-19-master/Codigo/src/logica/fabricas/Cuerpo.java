package logica.fabricas;

/**
 * Medidas del cuerpo (hitbox) de una entidad dentro de su imagen: margen desde la esquina, ancho y alto. Las define
 * cada dominio gráfico en su archivo de medidas, porque dependen de cómo está dibujada la entidad.
 */
public class Cuerpo {

    // Atributos de instancia

    protected final int margenX;
    protected final int margenY;
    protected final int ancho;
    protected final int alto;

    // Constructores

    /**
     * Crea un cuerpo corrido (margenX, margenY) desde la esquina de la entidad, de ancho x alto.
     */
    public Cuerpo(int margenX, int margenY, int ancho, int alto) {
        this.margenX = margenX;
        this.margenY = margenY;
        this.ancho = ancho;
        this.alto = alto;
    }

    // Consultas

    /**
     * Devuelve cuánto está corrido el cuerpo hacia la derecha desde la esquina de la entidad.
     */
    public int getMargenX() {
        return margenX;
    }

    /**
     * Devuelve cuánto está corrido el cuerpo hacia abajo desde la esquina de la entidad.
     */
    public int getMargenY() {
        return margenY;
    }

    /**
     * Devuelve el ancho del cuerpo.
     */
    public int getAncho() {
        return ancho;
    }

    /**
     * Devuelve el alto del cuerpo.
     */
    public int getAlto() {
        return alto;
    }
}
