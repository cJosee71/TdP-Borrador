package logica.fabricas;

/**
 * Fábrica de sprites del dominio gráfico alternativo: toma las imágenes y el archivo medidas.txt (cuerpos y márgenes de
 * imagen) de su carpeta.
 */
public class FabricaSpritesAlternativa extends FabricaSprites {

    // Constructores

    /**
     * Crea la fábrica del dominio alternativo.
     */
    public FabricaSpritesAlternativa() {
    }

    // Consultas

    /**
     * Devuelve la carpeta de imágenes y medidas alternativas.
     */
    protected String carpeta() {
        return "/Recursos/Imagenes/alternativa";
    }
}
