package logica.fabricas;

/**
 * Fábrica de sprites del dominio gráfico original: toma las imágenes y el archivo medidas.txt (cuerpos y márgenes de
 * imagen) de su carpeta.
 */
public class FabricaSpritesOriginal extends FabricaSprites {

    // Constructores

    /**
     * Crea la fábrica del dominio original.
     */
    public FabricaSpritesOriginal() {
    }

    // Consultas

    /**
     * Devuelve la carpeta de imágenes y medidas originales.
     */
    protected String carpeta() {
        return "/Recursos/Imagenes/original";
    }
}
