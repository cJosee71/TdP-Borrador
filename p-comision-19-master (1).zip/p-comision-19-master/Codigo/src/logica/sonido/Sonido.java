package logica.sonido;

/**
 * Los sonidos del juego, cada uno con su archivo en la carpeta de sonidos. Al ser un enumerado, solo se pueden pedir
 * sonidos que existen.
 */
public enum Sonido {
    ATAQUE("ataque.wav"),
    ATAQUE_RECARGADO("ataque-recargado.wav"),
    ESCUDO("escudo.wav"),
    IMPACTO("impacto.wav"),
    POWER_UP("power-up.wav"),
    ENEMIGO_DERROTADO("enemigo-derrotado.wav"),
    JEFE_DERROTADO("jefe-derrotado.wav"),
    CAIDA("caida.wav"),
    PERDER_VIDA("perder-vida.wav"),
    MUERTE("muerte.wav"),
    PROYECTIL("proyectil.wav"),
    CORTE_PASTO("corte-pasto.wav"),
    MUSICA_FONDO("musica-fondo.wav");

    // Atributos de instancia

    private final String archivo;

    // Constructores

    /**
     * Crea el sonido con el nombre de su archivo.
     */
    Sonido(String archivo) {
        this.archivo = archivo;
    }

    // Consultas

    /**
     * Devuelve el nombre del archivo del sonido, dentro de la carpeta de sonidos.
     */
    public String getArchivo() {
        return archivo;
    }
}
