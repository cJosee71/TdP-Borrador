package logica;

import logica.juego.ModoJuego;
import logica.fabricas.FabricaSprites;
import logica.juego.Ranking;

/**
 * Operaciones que la vista le pide a la lógica del juego.
 */
public interface ControladorJuego {

    // Comandos

    /**
     * Arma y arranca una partida nueva.
     */
    public void iniciar(ModoJuego modo, FabricaSprites dominio);

    /**
     * Registra el puntaje de la partida con el nombre del jugador; si es nulo o está vacío, el juego usa un nombre por defecto.
     */
    public void registrarNombre(String nombre);

    /**
     * Avisa que terminó la animación de cambio de sector.
     */
    public void transicionTerminada();

    /**
     * Carga el nivel siguiente y reanuda la partida después de la ventana de nivel superado.
     */
    public void continuarNivel();

    // Consultas

    /**
     * Devuelve el ranking del modo indicado.
     */
    public Ranking getRanking(ModoJuego m);

    /**
     * Devuelve el control del jugador, o null si no hay partida.
     */
    public ControlJugador getControlJugador();
}
