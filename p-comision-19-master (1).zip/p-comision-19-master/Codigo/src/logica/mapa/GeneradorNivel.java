package logica.mapa;

import logica.entidades.Entidad;
import logica.fabricas.FabricaEntidades;
import logica.entidades.enemigos.Jefe;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import logica.util.Posicion;

/**
 * Arma los niveles a partir de sus archivos de texto.
 */
public class GeneradorNivel {

    // Atributos de instancia

    protected String carpetaNiveles;

    // Constructores

    /**
     * Crea el generador con la carpeta de los archivos de niveles.
     */
    public GeneradorNivel(String carpetaNiveles) {
        this.carpetaNiveles = carpetaNiveles;
    }

    // Comandos

    /**
     * Reparte 4 fragmentos de corazón en sectores al azar: cada uno va a un lugar libre del tamaño de su cuerpo.
     */
    private void colocarFragmentosDeCorazon(Escena e, FabricaEntidades fabrica) {
        List<Sector> sectores = new ArrayList<>();
        for (int f = 0; f < e.getFilas(); f++)
            for (int c = 0; c < e.getColumnas(); c++)
                if (e.getSector(f, c) != null)
                    sectores.add(e.getSector(f, c));
        Collections.shuffle(sectores);
        for (int k = 0; k < 4 && k < sectores.size(); k++) {
            Entidad fragmento = fabrica.crearFragmentoDeCorazon(0, 0);
            Posicion p = sectores.get(k).posicionLibreAlAzar(fragmento.getAncho(), fragmento.getAlto());
            fragmento.ubicarCuerpoEn(p.getX(), p.getY());
            sectores.get(k).agregar(fragmento);
        }
    }

    // Consultas

    /**
     * Crea el nivel indicado con sus sectores, entidades y jefes.
     */
    public Nivel generar(int numero, FabricaEntidades fabrica) {
        List<String> lineas = leerArchivo(numero);
        String[] mapa = lineas.get(0).split(" ");
        String[] celdas = lineas.get(1).split(" ");
        String[] inicio = lineas.get(2).split(" ");
        int ancho = Integer.parseInt(celdas[1]);
        int alto = Integer.parseInt(celdas[2]);
        int celda = Integer.parseInt(celdas[3]);
        Escena escena = new Escena(Integer.parseInt(mapa[1]), Integer.parseInt(mapa[2]));
        List<Jefe> jefes = new ArrayList<>();
        int i = 3;
        while (i < lineas.size()) {
            String[] cabecera = lineas.get(i).split(" ");
            Sector sector = new Sector(Integer.parseInt(cabecera[1]), Integer.parseInt(cabecera[2]));
            escena.agregarSector(sector.getFila(), sector.getColumna(), sector);
            for (int r = 0; r < alto; r++) {
                String fila = lineas.get(i + 1 + r);
                for (int k = 0; k < ancho; k++) {
                    char s = fila.charAt(k);
                    int x = k * celda;
                    int y = r * celda;
                    if (s == 'S' || s == 'H') {
                        Jefe j = (s == 'S') ? fabrica.crearMasterStalfos(x, y) : fabrica.crearStoneHinox(x, y);
                        jefes.add(j);
                        sector.agregar(j);
                    } else {
                        Entidad e = crearEntidad(s, x, y, fabrica);
                        if (e != null)
                            sector.agregar(e);
                    }
                }
            }
            i += 1 + alto;
        }
        colocarFragmentosDeCorazon(escena, fabrica);
        Posicion posicion = new Posicion(Integer.parseInt(inicio[3]) * celda, Integer.parseInt(inicio[4]) * celda);
        return new Nivel(escena, jefes, Integer.parseInt(inicio[1]), Integer.parseInt(inicio[2]), posicion);
    }

    /**
     * Devuelve las líneas no vacías del archivo del nivel.
     */
    private List<String> leerArchivo(int numero) {
        String ruta = carpetaNiveles + "nivel" + numero + ".txt";
        List<String> lineas = new ArrayList<>();
        try (BufferedReader lector = new BufferedReader(
                new InputStreamReader(getClass().getResourceAsStream(ruta), StandardCharsets.UTF_8))) {
            String linea;
            while ((linea = lector.readLine()) != null)
                if (!linea.isBlank())
                    lineas.add(linea);
        } catch (IOException | NullPointerException ex) {
            throw new IllegalStateException("No se pudo leer " + ruta, ex);
        }
        return lineas;
    }

    /**
     * Crea la entidad que corresponde a un símbolo del archivo, o null si la celda está vacía. El '#' es la pared
     * invisible que frena a todos en el borde dibujado del fondo.
     */
    private Entidad crearEntidad(char simbolo, int x, int y, FabricaEntidades fabrica) {
        switch (simbolo) {
            case 'R': return fabrica.crearRoca(x, y);
            case '#': return fabrica.crearPared(x, y);
            case 'A': return fabrica.crearAgua(x, y);
            case 'P': return fabrica.crearPasto(x, y);
            case 'V': return fabrica.crearCaidasAlVacio(x, y);
            case 'Q': return fabrica.crearSuelosQuebradizo(x, y);
            case 'M': return fabrica.crearMoblin(x, y);
            case 'N': return fabrica.crearMoblinConEspadaYEscudo(x, y);
            case 'E': return fabrica.crearErizoDeMar(x, y);
            case 'O': return fabrica.crearOctorok(x, y);
            case 'T': return fabrica.crearTrampaDeCuchillas(x, y);
            case 'W': return fabrica.crearWizzrobe(x, y);
            case '$': return fabrica.crearRupia(x, y);
            case 'C': return fabrica.crearCorazon(x, y);
            case 'X': return fabrica.crearEspada(x, y);
            case '.': return null;
            default: throw new IllegalArgumentException("Símbolo desconocido: " + simbolo);
        }
    }
}
