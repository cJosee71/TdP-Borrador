package logica.comportamientos;

import logica.entidades.AdministradorColisiones;
import logica.entidades.EntidadAnimada;
import logica.util.Direccion;
import logica.util.Posicion;

/**
 * Movimiento indicado desde afuera: por dirección, con control de bloqueos, o hacia un objetivo fijo.
 */
public class MovimientoInducido implements ComportamientoMovimiento {

    // Atributos de instancia

    protected Direccion direccion;
    protected Posicion objetivo;
    protected int velocidad;

    // Constructores

    /**
     * Crea un movimiento por dirección; con null la entidad queda quieta.
     */
    public MovimientoInducido(Direccion d, int velocidad) {
        direccion = d;
        this.velocidad = velocidad;
    }

    /**
     * Crea un movimiento hacia una posición fija.
     */
    public MovimientoInducido(Posicion objetivo, int velocidad) {
        this.objetivo = objetivo;
        this.velocidad = velocidad;
    }

    // Comandos

    /**
     * Avanza hacia el objetivo o en la dirección actual.
     */
    @Override
    public void mover(EntidadAnimada e, AdministradorColisiones c) {
        if (objetivo != null)
            e.avanzarHacia(objetivo, velocidad);
        else if (direccion != null)
            c.mover(e, direccion, velocidad);
    }
}
