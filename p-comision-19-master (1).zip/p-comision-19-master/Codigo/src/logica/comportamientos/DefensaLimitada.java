package logica.comportamientos;

import logica.entidades.EntidadAnimada;
import logica.util.Direccion;

/**
 * Defensa que limita el daño por golpe: normal, invulnerable o bellota, según cómo se construya.
 */
public class DefensaLimitada implements ComportamientoDefensa {

    // Atributos de clase

    public static final int SIN_LIMITE = Integer.MAX_VALUE;
    public static final int SIEMPRE = -1;

    // Atributos de instancia

    protected int danioMaximo;
    protected int golpesRestantes;

    // Constructores

    /**
     * Crea la defensa con el daño máximo por golpe y los golpes que dura.
     */
    public DefensaLimitada(int danioMaximo, int golpes) {
        this.danioMaximo = danioMaximo;
        golpesRestantes = golpes;
    }

    // Comandos

    /**
     * Aplica el daño sin pasarse del máximo y descuenta un golpe si la defensa es limitada.
     */
    @Override
    public boolean recibirDanio(EntidadAnimada e, int danio, Direccion origen) {
        boolean recibioDanio = false;
        int real = Math.min(danio, danioMaximo);
        if (real > 0) {
            e.aplicarDanio(real);
            recibioDanio = true;
            if (golpesRestantes != SIEMPRE) {
                golpesRestantes--;
                if (golpesRestantes == 0) {
                    danioMaximo = SIN_LIMITE;
                    golpesRestantes = SIEMPRE;
                }
            }
        }
        return recibioDanio;
    }

    // Consultas

    /**
     * Devuelve los golpes que le quedan, o SIEMPRE.
     */
    public int getGolpesRestantes() {
        return golpesRestantes;
    }

    /**
     * Devuelve true si todavía le quedan golpes protegidos.
     */
    @Override
    public boolean tieneGolpesRestantes() {
        return golpesRestantes != SIEMPRE;
    }
}
