package logica.util;

/**
 * Rectángulo de colisión: el cuerpo de una entidad, corrido un margen desde la esquina de la entidad. Sus medidas las
 * define el dominio (ver Cuerpo).
 */
public class Hitbox {

    // Atributos de instancia

    protected Posicion posicion;
    protected int margenX;
    protected int margenY;
    protected int ancho;
    protected int alto;

    // Constructores

    /**
     * Crea una hitbox sin margen.
     */
    public Hitbox(int x, int y, int ancho, int alto) {
        this(x, y, 0, 0, ancho, alto);
    }

    /**
     * Crea una hitbox cuyo cuerpo está corrido un margen desde la esquina de la entidad.
     */
    public Hitbox(int x, int y, int margenX, int margenY, int ancho, int alto) {
        this.posicion = new Posicion(x, y);
        this.margenX = margenX;
        this.margenY = margenY;
        this.ancho = ancho;
        this.alto = alto;
    }

    // Comandos

    /**
     * Cambia la esquina de la entidad.
     */
    public void setPosicion(Posicion p) {
        posicion = p;
    }

    // Consultas

    /**
     * Devuelve la esquina de la entidad.
     */
    public Posicion getPosicion() {
        return posicion;
    }

    /**
     * Devuelve la x de la esquina del cuerpo.
     */
    public int getX() {
        return posicion.getX() + margenX;
    }

    /**
     * Devuelve la y de la esquina del cuerpo.
     */
    public int getY() {
        return posicion.getY() + margenY;
    }

    /**
     * Devuelve el ancho del cuerpo.
     */
    public int getAncho() {
        return ancho;
    }

    /**
     * Devuelve el alto del cuerpo.
     */
    public int getAlto() {
        return alto;
    }

    /**
     * Devuelve el centro del cuerpo.
     */
    public Posicion getCentro() {
        return new Posicion(getX() + ancho / 2, getY() + alto / 2);
    }

    /**
     * Indica si un punto está dentro del cuerpo.
     */
    public boolean contiene(Posicion p) {
        return getX() <= p.getX() && p.getX() < getX() + ancho
            && getY() <= p.getY() && p.getY() < getY() + alto;
    }

    /**
     * Indica si se superpone con otra hitbox.
     */
    public boolean intersecta(Hitbox otra) {
        return getX() < otra.getX() + otra.ancho && otra.getX() < getX() + ancho
            && getY() < otra.getY() + otra.alto && otra.getY() < getY() + alto;
    }

    /**
     * Devuelve una copia corrida unos pasos en una dirección.
     */
    public Hitbox desplazada(Direccion d, int pasos) {
        Posicion desplazada = posicion.desplazada(d, pasos);
        return new Hitbox(desplazada.getX(), desplazada.getY(), margenX, margenY, ancho, alto);
    }

    /**
     * Devuelve la posición de la entidad que deja la esquina del cuerpo en (x, y).
     */
    public Posicion posicionParaCuerpoEn(int x, int y) {
        return new Posicion(x - margenX, y - margenY);
    }

    /**
     * Devuelve la zona pegada al cuerpo en una dirección, con el alcance indicado.
     */
    public Hitbox adelante(Direccion d, int alcance) {
        switch (d) {
            case DERECHA:
                return new Hitbox(getX() + ancho, getY(), alcance, alto);
            case IZQUIERDA:
                return new Hitbox(getX() - alcance, getY(), alcance, alto);
            case ABAJO:
                return new Hitbox(getX(), getY() + alto, ancho, alcance);
            default:
                return new Hitbox(getX(), getY() - alcance, ancho, alcance);
        }
    }

    /**
     * Devuelve la zona que rodea al cuerpo, agrandada el alcance indicado hacia los cuatro lados.
     */
    public Hitbox alrededor(int alcance) {
        return new Hitbox(getX() - alcance, getY() - alcance, ancho + 2 * alcance, alto + 2 * alcance);
    }

    /**
     * Indica si el cuerpo está completo dentro de una zona.
     */
    public boolean estaDentroDe(int anchoZona, int altoZona) {
        return getX() >= 0 && getY() >= 0 && getX() + ancho <= anchoZona && getY() + alto <= altoZona;
    }

    /**
     * Indica si comparte fila o columna con otra hitbox.
     */
    public boolean estaEnLineaCon(Hitbox otra) {
        boolean mismaFila = getY() < otra.getY() + otra.alto && otra.getY() < getY() + alto;
        boolean mismaColumna = getX() < otra.getX() + otra.ancho && otra.getX() < getX() + ancho;
        return mismaFila || mismaColumna;
    }

    /**
     * Devuelve la franja que va desde este cuerpo hasta otro que está en su misma fila o columna.
     */
    public Hitbox caminoHasta(Hitbox otra) {
        boolean mismaFila = getY() < otra.getY() + otra.alto && otra.getY() < getY() + alto;
        Hitbox camino;
        if (mismaFila) {
            int izquierda = Math.min(getX(), otra.getX());
            int derecha = Math.max(getX() + ancho, otra.getX() + otra.ancho);
            camino = new Hitbox(izquierda, getY(), derecha - izquierda, alto);
        } else {
            int arriba = Math.min(getY(), otra.getY());
            int abajo = Math.max(getY() + alto, otra.getY() + otra.alto);
            camino = new Hitbox(getX(), arriba, ancho, abajo - arriba);
        }
        return camino;
    }
}
