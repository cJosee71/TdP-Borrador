package vista;

import java.awt.Cursor;
import java.awt.Font;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JFrame;

/**
 * Ventana emergente modal con el estilo de las pantallas. Es para las ventanas lo que PanelVista
 * es para las pantallas: el constructor arma los componentes y cerrar con la X avisa a alCerrar
 * (Template Method).
 */
public abstract class DialogoVista extends JDialog {

    // Atributos de instancia

    protected ControladorDeVistas controladorVistas;

    // Constructores

    /**
     * Crea la ventana modal sobre la ventana del juego, arma sus componentes, la ajusta a su contenido y la centra.
     */
    protected DialogoVista(JFrame duenio, String titulo, ControladorDeVistas c) {
        super(duenio, titulo, true);
        controladorVistas = c;
        setResizable(false);
        setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            /**
             * Cerrar con la X hace lo que decida cada ventana.
             */
            public void windowClosing(WindowEvent e) {
                alCerrar();
            }
        });
        JComponent contenido = (JComponent) getContentPane();
        contenido.setBackground(PanelVista.COLOR_FONDO);
        contenido.setBorder(BorderFactory.createLineBorder(PanelVista.COLOR_DORADO, 2));
        armarComponentes();
        pack();
        setLocationRelativeTo(duenio);
    }

    // Comandos

    /**
     * Crea y ubica los componentes de la ventana. Se llama desde el constructor:
     * las subclases inicializan sus atributos acá adentro.
     */
    protected abstract void armarComponentes();

    /**
     * Lo que hace la ventana cuando se la cierra con la X.
     */
    protected abstract void alCerrar();

    /**
     * Ajusta la ventana a su contenido y la vuelve a centrar, después de cambiar textos o esconder componentes.
     */
    protected void reacomodar() {
        pack();
        setLocationRelativeTo(getOwner());
    }

    // Consultas

    /**
     * Crea un botón con el estilo de las pantallas: dorado si es el principal, oscuro si no.
     */
    protected JButton crearBoton(String texto, boolean principal) {
        JButton boton = new JButton(texto);
        boton.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 15));
        boton.setFocusPainted(false);
        boton.setContentAreaFilled(false);
        boton.setOpaque(true);
        boton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        boton.setBackground(principal ? PanelVista.COLOR_DORADO : PanelVista.COLOR_SUPERFICIE);
        boton.setForeground(principal ? PanelVista.COLOR_FONDO : PanelVista.COLOR_TEXTO);
        boton.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(PanelVista.COLOR_DORADO),
                BorderFactory.createEmptyBorder(10, 28, 10, 28)));
        return boton;
    }
}
