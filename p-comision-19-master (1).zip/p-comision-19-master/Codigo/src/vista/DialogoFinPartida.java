package vista;

import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

/**
 * Ventana emergente de fin de partida, ganada o perdida: muestra el puntaje; si entra al ranking pide
 * el nombre para guardarlo, y si no, ofrece ver el ranking. Siempre se puede volver al menú.
 */
public class DialogoFinPartida extends DialogoVista {

    // Atributos de clase

    private static final Color COLOR_DERROTA = new Color(0xE0, 0x5A, 0x4C);

    // Atributos de instancia

    private JLabel titulo;
    private JLabel textoPuntaje;
    private JLabel textoRanking;
    private JTextField campoNombre;
    private JButton botonGuardar;
    private JButton botonVerRanking;

    // Constructores

    /**
     * Crea la ventana: "¡GANASTE!" en dorado o "GAME OVER" en rojo, con el puntaje; el campo del nombre
     * y GUARDAR solo se ven si entra al ranking, y VER RANKING solo si no entra. maximoRanking es cuántos puestos tiene el ranking ("¡Entraste al top N!").
     */
    public DialogoFinPartida(JFrame duenio, ControladorDeVistas c, boolean gano, int puntaje, boolean entraEnRanking, int maximoRanking) {
        super(duenio, gano ? "Partida ganada" : "Partida perdida", c);
        titulo.setText(gano ? "¡GANASTE!" : "GAME OVER");
        titulo.setForeground(gano ? PanelVista.COLOR_DORADO : COLOR_DERROTA);
        textoPuntaje.setText("Puntaje: " + puntaje);
        textoRanking.setText("¡Entraste al top " + maximoRanking + "! Escribí tu nombre:");
        textoRanking.setVisible(entraEnRanking);
        campoNombre.setVisible(entraEnRanking);
        botonGuardar.setVisible(entraEnRanking);
        botonVerRanking.setVisible(!entraEnRanking);
        reacomodar();
    }

    // Comandos

    /**
     * Cierra la ventana y guarda el puntaje con el nombre escrito (después se ve el ranking).
     */
    public void guardar() {
        dispose();
        controladorVistas.guardarPuntaje(campoNombre.getText());
    }

    /**
     * Cierra la ventana y muestra el ranking del modo jugado.
     */
    public void verRanking() {
        dispose();
        controladorVistas.verRankingPartida();
    }

    /**
     * Cierra la ventana y vuelve al menú principal sin guardar.
     */
    public void volver() {
        dispose();
        controladorVistas.mostrarPantallaPrincipal();
    }

    /**
     * Cerrar con la X vuelve al menú.
     */
    @Override
    protected void alCerrar() {
        volver();
    }

    /**
     * Crea el título, el puntaje, el aviso y el campo del nombre, y los botones GUARDAR, VER RANKING
     * y VOLVER AL MENÚ. Enter en el campo también guarda.
     */
    @Override
    protected void armarComponentes() {
        titulo = new JLabel("", SwingConstants.CENTER);
        titulo.setFont(new Font(Font.SERIF, Font.BOLD, 36));

        textoPuntaje = new JLabel("", SwingConstants.CENTER);
        textoPuntaje.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 18));
        textoPuntaje.setForeground(PanelVista.COLOR_TEXTO);

        textoRanking = new JLabel("", SwingConstants.CENTER);
        textoRanking.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 15));
        textoRanking.setForeground(PanelVista.COLOR_TEXTO);

        campoNombre = new JTextField(16);
        campoNombre.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 16));
        campoNombre.setBackground(PanelVista.COLOR_SUPERFICIE);
        campoNombre.setForeground(PanelVista.COLOR_TEXTO);
        campoNombre.setCaretColor(PanelVista.COLOR_TEXTO);
        campoNombre.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(PanelVista.COLOR_DORADO),
                BorderFactory.createEmptyBorder(6, 8, 6, 8)));
        campoNombre.addActionListener(e -> guardar());

        botonGuardar = crearBoton("GUARDAR", true);
        botonGuardar.addActionListener(e -> guardar());
        botonVerRanking = crearBoton("VER RANKING", true);
        botonVerRanking.addActionListener(e -> verRanking());
        JButton botonVolver = crearBoton("VOLVER AL MENÚ", false);
        botonVolver.addActionListener(e -> volver());

        JPanel botones = new JPanel();
        botones.setOpaque(false);
        botones.add(botonGuardar);
        botones.add(botonVerRanking);
        botones.add(botonVolver);

        setLayout(new GridBagLayout());
        GridBagConstraints ubicacion = new GridBagConstraints();
        ubicacion.gridx = 0;
        ubicacion.gridy = 0;
        ubicacion.insets = new Insets(30, 50, 6, 50);
        add(titulo, ubicacion);
        ubicacion.gridy = 1;
        ubicacion.insets = new Insets(6, 50, 14, 50);
        add(textoPuntaje, ubicacion);
        ubicacion.gridy = 2;
        ubicacion.insets = new Insets(4, 50, 6, 50);
        add(textoRanking, ubicacion);
        ubicacion.gridy = 3;
        add(campoNombre, ubicacion);
        ubicacion.gridy = 4;
        ubicacion.insets = new Insets(18, 40, 26, 40);
        add(botones, ubicacion);
    }
}
