package vista;

import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

/**
 * Ventana emergente de nivel superado: muestra el nivel, el puntaje y el nivel que sigue,
 * y al continuar pasa al nivel siguiente.
 */
public class DialogoPasajeNivel extends DialogoVista {

    // Atributos de instancia

    private JLabel titulo;
    private JLabel textoPuntaje;
    private JLabel textoSiguiente;

    // Constructores

    /**
     * Crea la ventana del nivel superado con su número y el puntaje.
     */
    public DialogoPasajeNivel(JFrame duenio, ControladorDeVistas c, int nivelSuperado, int puntaje) {
        super(duenio, "Nivel superado", c);
        titulo.setText("¡NIVEL " + nivelSuperado + " SUPERADO!");
        textoPuntaje.setText("Puntaje: " + puntaje);
        textoSiguiente.setText("Siguiente: nivel " + (nivelSuperado + 1));
        reacomodar();
    }

    // Comandos

    /**
     * Cierra la ventana y sigue con el nivel siguiente.
     */
    public void continuar() {
        dispose();
        controladorVistas.continuarNivel();
    }

    /**
     * Cerrar con la X también sigue con el nivel siguiente.
     */
    @Override
    protected void alCerrar() {
        continuar();
    }

    /**
     * Crea el título, el puntaje, el aviso del nivel siguiente y el botón CONTINUAR, uno debajo del otro.
     */
    @Override
    protected void armarComponentes() {
        titulo = new JLabel("", SwingConstants.CENTER);
        titulo.setFont(new Font(Font.SERIF, Font.BOLD, 32));
        titulo.setForeground(PanelVista.COLOR_DORADO);

        textoPuntaje = new JLabel("", SwingConstants.CENTER);
        textoPuntaje.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 18));
        textoPuntaje.setForeground(PanelVista.COLOR_TEXTO);

        textoSiguiente = new JLabel("", SwingConstants.CENTER);
        textoSiguiente.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 15));
        textoSiguiente.setForeground(PanelVista.COLOR_TEXTO);

        JButton botonContinuar = crearBoton("CONTINUAR", true);
        botonContinuar.addActionListener(e -> continuar());

        setLayout(new GridBagLayout());
        GridBagConstraints ubicacion = new GridBagConstraints();
        ubicacion.gridx = 0;
        ubicacion.gridy = 0;
        ubicacion.insets = new Insets(30, 50, 8, 50);
        add(titulo, ubicacion);
        ubicacion.gridy = 1;
        ubicacion.insets = new Insets(8, 50, 4, 50);
        add(textoPuntaje, ubicacion);
        ubicacion.gridy = 2;
        add(textoSiguiente, ubicacion);
        ubicacion.gridy = 3;
        ubicacion.insets = new Insets(22, 50, 30, 50);
        add(botonContinuar, ubicacion);
    }
}
