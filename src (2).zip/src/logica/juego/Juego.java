package logica.juego;

import logica.ControlJugador;
import logica.ControladorGrafico;
import logica.ControladorJuego;
import logica.entidades.AdministradorColisiones;
import logica.entidades.Entidad;
import logica.entidades.Link;
import logica.entidades.enemigos.Enemigo;
import logica.entidades.enemigos.Jefe;
import logica.entidades.fijas.PowerUP;
import logica.fabricas.FabricaEntidades;
import logica.fabricas.FabricaSprites;
import logica.entidades.EntornoJuego;
import logica.hilos.HiloJugador;
import logica.hilos.HiloMundo;
import logica.hilos.OyenteReloj;
import logica.hilos.Reloj;
import logica.mapa.GeneradorNivel;
import logica.mapa.Nivel;
import logica.mapa.Sector;
import logica.sonido.GestorDeSonido;
import logica.sonido.Sonido;
import logica.util.Direccion;

/**
 * Árbitro de la partida: arma el juego, maneja los hilos, los niveles (con la pausa, el GAME OVER y el reinicio del
 * nivel), el puntaje y los rankings.
 *
 * Interpretación del ranking (punto 15): la partida termina solo al ganar el último nivel, porque desde el GAME OVER
 * se puede reiniciar el nivel. Por eso guardar el puntaje en el ranking se ofrece solo al ganar (ver perderNivel y
 * ganarPartida); al reiniciar el nivel el puntaje vuelve a 0 (punto 9).
 */
public class Juego implements ControladorJuego, OyenteReloj, ArbitroPartida, TablaRankings, EntornoJuego {

    // Atributos de clase

    private static final int RACHA_PARA_BELLOTA = 4;
    private static final String NOMBRE_POR_DEFECTO = "Anónimo";
    private static final int RANKING_CLASICO = 0;
    private static final int RANKING_CONTRARRELOJ = 1;
    private static final int RANKING_NOHIT = 2;
    private static final int CANTIDAD_RANKINGS = 3;

    // Atributos de instancia

    protected ControladorGrafico controladorGrafico;
    protected Link jugador;
    protected Nivel nivel;
    protected int numeroNivel;
    protected ModoJuego modoJuego;
    protected Ranking[] rankings;
    protected Reloj reloj;
    protected HiloJugador hiloJugador;
    protected HiloMundo hiloMundo;
    protected AdministradorColisiones colisiones;
    protected GeneradorNivel generadorNivel;
    protected FabricaEntidades fabricaEntidades;
    protected FabricaSprites dominio;
    protected PersistenciaRanking persistencia;
    protected boolean partidaEnCurso;
    protected volatile boolean pausada;
    protected volatile boolean enTransicion;

    // Constructores

    /**
     * Crea el juego sin partida y carga los tres rankings.
     */
    public Juego(ControladorGrafico vista) {
        controladorGrafico = vista;
        colisiones = new AdministradorColisiones();
        generadorNivel = new GeneradorNivel("/Recursos/Niveles/");
        persistencia = new PersistenciaRanking();
        rankings = new Ranking[CANTIDAD_RANKINGS];
        for (int indiceRanking = 0; indiceRanking < rankings.length; indiceRanking++)
            rankings[indiceRanking] = persistencia.cargar(archivoDeRanking(indiceRanking));
    }

    // Comandos

    /**
     * Empieza una partida: guarda el dominio gráfico elegido (para los fondos), crea a Link (y guarda su inventario
     * inicial) y los hilos, carga el primer nivel, arranca los hilos y la música de fondo.
     */
    @Override
    public void iniciar(ModoJuego modo, FabricaSprites dominio) {
        modoJuego = modo;
        numeroNivel = 1;
        pausada = false;
        enTransicion = false;
        this.dominio = dominio;
        fabricaEntidades = new FabricaEntidades(this, dominio);
        jugador = fabricaEntidades.crearLink(0, 0);
        jugador.guardarInventarioDelNivel();
        crearHilos();
        cargarNivel();
        partidaEnCurso = true;
        arrancarHilos();
        GestorDeSonido.getInstancia().reproducirEnBucle(Sonido.MUSICA_FONDO);
    }

    /**
     * Termina la partida si seguía en curso, guarda el puntaje con el nombre del jugador (NOMBRE_POR_DEFECTO si es
     * nulo o está vacío) y muestra el ranking.
     */
    @Override
    public void registrarNombre(String nombre) {
        detenerPartida();
        String nombreFinal = nombre == null || nombre.isBlank() ? NOMBRE_POR_DEFECTO : nombre;
        EntradaRanking entradaNueva = new EntradaRanking(nombreFinal, jugador.getPuntaje());
        modoJuego.registrarPuntaje(this, entradaNueva);
        controladorGrafico.mostrarRanking(getRanking(modoJuego), modoJuego.getNombre());
    }

    /**
     * Muestra el sector nuevo y reanuda los hilos al terminar la transición.
     */
    @Override
    public synchronized void transicionTerminada() {
        activarSector(colisiones.getSector());
        enTransicion = false;
        if (!pausada) {
            reanudarHilos();
        }
    }

    /**
     * Pausa la partida en curso: detiene el reloj y los hilos, congela la acción de Link, suelta el control y muestra
     * el menú de pausa. Solo la marca de pausa va bajo la llave del juego, para no trabarse con la llave de Link.
     */
    @Override
    public void pausarPartida() {
        if (marcarPausa()) {
            jugador.pausarAccion();
            controladorGrafico.terminarControl();
            controladorGrafico.mostrarPausa(numeroNivel, jugador.getPuntaje());
        }
    }

    /**
     * Si la partida está en curso y no estaba en pausa, la marca en pausa, detiene el reloj, los hilos y la música
     * y devuelve true.
     */
    private synchronized boolean marcarPausa() {
        boolean sePauso = partidaEnCurso && !pausada;
        if (sePauso) {
            pausada = true;
            reloj.pausar();
            pausarHilos();
            GestorDeSonido.getInstancia().detener(Sonido.MUSICA_FONDO);
        }
        return sePauso;
    }

    /**
     * Sale de la pausa: retoma la acción de Link, reanuda el reloj, la música y, si no quedó una transición en curso,
     * los hilos.
     */
    @Override
    public synchronized void reanudarPartida() {
        if (pausada) {
            pausada = false;
            jugador.reanudarAccion();
            reloj.reanudar();
            GestorDeSonido.getInstancia().reanudarEnBucle(Sonido.MUSICA_FONDO);
            if (!enTransicion) {
                reanudarHilos();
            }
        }
    }

    /**
     * Suma los puntos del enemigo y la racha; al llegar a la racha necesaria aparece una bellota y devuelve true.
     */
    @Override
    public synchronized boolean enemigoDerrotado(Enemigo enemigo) {
        boolean aparecioBellota = false;
        jugador.sumarPuntos(enemigo.getPuntos());
        jugador.incrementarRacha();
        if (jugador.getRacha() == RACHA_PARA_BELLOTA) {
            jugador.reiniciarRacha();
            aparecerBellota(enemigo.getX(), enemigo.getY());
            aparecioBellota = true;
        }
        return aparecioBellota;
    }

    /**
     * Suma los puntos del jefe y, si no quedan jefes, muestra el nivel superado o gana la partida si era el último
     * nivel. Si Link está perdiendo su última vida no hace nada de eso: el GAME OVER tiene prioridad.
     */
    @Override
    public void jefeDerrotado(Jefe jefe) {
        jugador.sumarPuntos(jefe.getPuntos());
        if (nivelSuperado()) {
            if (modoJuego.esUltimoNivel(numeroNivel)) {
                ganarPartida();
            } else {
                mostrarPasajeDeNivel();
            }
        }
    }

    /**
     * Detiene el reloj, los hilos y la música, deja de enviarle teclas a Link y muestra la ventana de nivel superado.
     */
    private void mostrarPasajeDeNivel() {
        reloj.pausar();
        pausarHilos();
        GestorDeSonido.getInstancia().detener(Sonido.MUSICA_FONDO);
        controladorGrafico.terminarControl();
        controladorGrafico.mostrarPasajeNivel(numeroNivel, jugador.getPuntaje());
    }

    /**
     * Suma los puntos del power-up.
     */
    @Override
    public synchronized void powerUpRecogido(PowerUP powerUp) {
        jugador.sumarPuntos(powerUp.getPuntos());
    }

    /**
     * Avisa al modo que Link recibió daño (un golpe o una caída al vacío).
     */
    @Override
    public synchronized void jugadorDaniado() {
        modoJuego.alRecibirDanio(this);
    }

    /**
     * Pasa al nivel siguiente, con los fragmentos de corazón y la racha de Link en 0, guarda su inventario (para un
     * reinicio o una caída) y reanuda el reloj y los hilos.
     */
    @Override
    public void continuarNivel() {
        numeroNivel++;
        jugador.reiniciarFragmentosYRacha();
        jugador.guardarInventarioDelNivel();
        arrancarNivel();
    }

    /**
     * Link se quedó sin vidas: GAME OVER (la partida no termina: se reinicia el nivel o se vuelve al menú).
     */
    @Override
    public void jugadorSinVidas() {
        perderNivel();
    }

    /**
     * Vuelve a empezar el nivel actual: Link en su posición inicial, con el puntaje y lo acumulado en 0, las vidas y
     * corazones iniciales y el inventario con el que empezó el nivel; reanuda el reloj y los hilos.
     */
    @Override
    public void reiniciarNivel() {
        jugador.reiniciarPuntaje();
        jugador.reiniciarFragmentosYRacha();
        jugador.perderLoAcumulado();
        jugador.reiniciarVidas();
        jugador.restaurarInventarioDelNivel();
        arrancarNivel();
        pausada = false;
    }

    /**
     * Termina la partida sin ventana de fin y sin guardar en el ranking (para volver al menú).
     */
    @Override
    public synchronized void abandonarPartida() {
        detenerPartida();
    }

    /**
     * Vuelve a armar el nivel después de una caída al vacío, con Link en el inicio y el inventario con el que lo
     * empezó; el puntaje se conserva (interpretación del punto 9, ver Link).
     */
    @Override
    public void jugadorCayoAlVacio() {
        hiloMundo.pausar();
        jugador.restaurarInventarioDelNivel();
        cargarNivel();
        hiloMundo.reanudar();
    }

    /**
     * Pasa a Link al sector vecino y arranca la transición; si no hay vecino, lo devuelve al sector.
     */
    @Override
    public synchronized void cambiarDeSector(Direccion direccion) {
        Sector sectorActual = colisiones.getSector();
        Sector sectorVecino = nivel.getMapa().getVecino(sectorActual, direccion);
        if (sectorVecino == null) {
            jugador.entrarPorBordeOpuesto(direccion.opuesta());
        } else {
            pasarAlSector(sectorActual, sectorVecino, direccion);
        }
    }

    /**
     * Detiene los hilos, mueve a Link del sector actual al vecino (entrando por el borde opuesto) y arranca la
     * transición. Se llama desde cambiarDeSector, que tiene la llave del juego.
     */
    private void pasarAlSector(Sector sectorActual, Sector sectorVecino, Direccion direccion) {
        enTransicion = true;
        pausarHilos();
        sectorActual.quitar(jugador);
        jugador.entrarPorBordeOpuesto(direccion);
        sectorVecino.agregar(jugador);
        colisiones.setSector(sectorVecino);
        controladorGrafico.transicion(direccion);
    }

    /**
     * Agrega una entidad al sector visible y la muestra.
     */
    @Override
    public void agregarEntidad(Entidad entidad) {
        colisiones.getSector().agregar(entidad);
        entidad.registrarObserver(controladorGrafico.mostrarEntidad(entidad));
    }

    /**
     * Falló la condición del modo (tiempo agotado en Contrarreloj o golpe en NoHit): GAME OVER, igual que sin vidas.
     */
    @Override
    public void terminarPartida() {
        perderNivel();
    }

    /**
     * GAME OVER: pausa el reloj y los hilos (sin terminar la partida, para poder reiniciar el nivel), suelta el
     * control y muestra la ventana de partida perdida; no hace nada si ya estaba detenida.
     *
     * Interpretación del punto 15: al perder no se ofrece el ranking, porque la partida no terminó.
     */
    private void perderNivel() {
        if (marcarPausa()) {
            controladorGrafico.terminarControl();
            controladorGrafico.mostrarFinPartida(false, jugador.getPuntaje(), false);
        }
    }

    /**
     * Gana la partida: la termina y muestra la ventana de partida ganada, que pide el nombre si el puntaje entra al
     * ranking (único momento en que se ofrece); no hace nada si ya terminó.
     */
    private synchronized void ganarPartida() {
        if (partidaEnCurso) {
            detenerPartida();
            int puntajeFinal = jugador.getPuntaje();
            controladorGrafico.mostrarFinPartida(true, puntajeFinal, getRanking(modoJuego).entraEnTop5(puntajeFinal));
        }
    }

    /**
     * Arma el nivel actual (cargarNivel), vuelve el tiempo a 0 y reanuda el reloj, los hilos y la música.
     */
    private void arrancarNivel() {
        cargarNivel();
        reloj.reiniciar();
        controladorGrafico.actualizarTiempo(0);
        reloj.reanudar();
        reanudarHilos();
        GestorDeSonido.getInstancia().reanudarEnBucle(Sonido.MUSICA_FONDO);
    }

    /**
     * Detiene HiloJugador y HiloMundo (Link y el resto de las entidades quedan quietos).
     */
    private void pausarHilos() {
        hiloJugador.pausar();
        hiloMundo.pausar();
    }

    /**
     * Reanuda HiloJugador y HiloMundo.
     */
    private void reanudarHilos() {
        hiloJugador.reanudar();
        hiloMundo.reanudar();
    }

    /**
     * Si la partida está en curso, la marca como terminada, detiene el reloj, los hilos y la música de fondo
     * y le pide a la vista que deje de enviarle teclas a Link.
     */
    private void detenerPartida() {
        if (partidaEnCurso) {
            partidaEnCurso = false;
            reloj.detener();
            hiloJugador.detener();
            hiloMundo.detener();
            GestorDeSonido.getInstancia().detener(Sonido.MUSICA_FONDO);
            controladorGrafico.terminarControl();
        }
    }

    /**
     * Muestra el tiempo y avisa al modo que pasó un segundo.
     */
    @Override
    public synchronized void tic(int segundos) {
        controladorGrafico.actualizarTiempo(segundos);
        modoJuego.alPasarTiempo(this, segundos);
    }

    /**
     * Agrega una entrada al ranking Clásico.
     */
    @Override
    public void agregarAlRankingClasico(EntradaRanking entrada) {
        agregarAlRanking(RANKING_CLASICO, entrada);
    }

    /**
     * Agrega una entrada al ranking Contrarreloj.
     */
    @Override
    public void agregarAlRankingContrarreloj(EntradaRanking entrada) {
        agregarAlRanking(RANKING_CONTRARRELOJ, entrada);
    }

    /**
     * Agrega una entrada al ranking NoHit.
     */
    @Override
    public void agregarAlRankingNoHit(EntradaRanking entrada) {
        agregarAlRanking(RANKING_NOHIT, entrada);
    }

    /**
     * Inserta la entrada en un ranking y lo guarda si entró.
     */
    private void agregarAlRanking(int indiceRanking, EntradaRanking entrada) {
        Ranking ranking = rankings[indiceRanking];
        boolean entro = ranking.insertar(entrada);
        if (entro)
            persistencia.guardar(ranking, archivoDeRanking(indiceRanking));
    }

    /**
     * Genera el nivel actual, ubica a Link en el sector inicial (sin acción en curso) y lo activa.
     */
    private void cargarNivel() {
        jugador.reiniciarAccion();
        sacarJugadorDelSector();
        nivel = generadorNivel.generar(numeroNivel, fabricaEntidades);
        Sector sectorInicial = nivel.getSectorInicial();
        jugador.setPosicion(nivel.getPosicionInicial());
        sectorInicial.agregar(jugador);
        controladorGrafico.actualizarNivel(numeroNivel);
        activarSector(sectorInicial);
    }

    /**
     * Saca a Link del sector donde estaba, si estaba en alguno.
     */
    private void sacarJugadorDelSector() {
        Sector sectorAnterior = jugador.getSector();
        if (sectorAnterior != null)
            sectorAnterior.quitar(jugador);
    }

    /**
     * Crea el reloj, HiloJugador y HiloMundo de la partida.
     */
    private void crearHilos() {
        reloj = new Reloj(this);
        hiloJugador = new HiloJugador(jugador, colisiones);
        hiloMundo = new HiloMundo(colisiones);
    }

    /**
     * Inicia el reloj, HiloJugador y HiloMundo.
     */
    private void arrancarHilos() {
        reloj.iniciar();
        hiloJugador.iniciar();
        hiloMundo.iniciar();
    }

    /**
     * Hace visible un sector: muestra su fondo según el dominio y el nivel, y crea la vista de sus entidades, con Link
     * al final.
     */
    private void activarSector(Sector sector) {
        colisiones.setSector(sector);
        controladorGrafico.limpiarEscena();
        controladorGrafico.mostrarFondo(dominio.getRutaFondo(numeroNivel, sector.getColumna()));
        for (Entidad entidad : sector.getEntidades())
            if (entidad != jugador)
                entidad.registrarObserver(controladorGrafico.mostrarEntidad(entidad));
        jugador.registrarObserver(controladorGrafico.mostrarJugador(jugador));
    }

    /**
     * Hace aparecer una bellota en (x, y).
     */
    private void aparecerBellota(int x, int y) {
        Entidad bellota = fabricaEntidades.crearBellota(x, y);
        agregarEntidad(bellota);
    }

    // Consultas

    /**
     * Devuelve el ranking de un modo.
     */
    @Override
    public Ranking getRanking(ModoJuego modo) {
        return modo.getRanking(this);
    }

    /**
     * Devuelve a Link como control del jugador, o null si no hay partida.
     */
    @Override
    public ControlJugador getControlJugador() {
        return jugador;
    }

    /**
     * Devuelve el ranking Clásico.
     */
    @Override
    public Ranking getRankingClasico() {
        return rankings[RANKING_CLASICO];
    }

    /**
     * Devuelve el ranking Contrarreloj.
     */
    @Override
    public Ranking getRankingContrarreloj() {
        return rankings[RANKING_CONTRARRELOJ];
    }

    /**
     * Devuelve el ranking NoHit.
     */
    @Override
    public Ranking getRankingNoHit() {
        return rankings[RANKING_NOHIT];
    }

    /**
     * Indica si se superó el nivel: no quedan jefes y Link no está perdiendo su última vida (el GAME OVER tiene
     * prioridad).
     */
    private boolean nivelSuperado() {
        return nivel.jefesDerrotados() && !jugador.pierdeLaUltimaVida();
    }

    /**
     * Devuelve el nombre del archivo donde se guarda un ranking.
     */
    private String archivoDeRanking(int indiceRanking) {
        return "ranking" + indiceRanking + ".txt";
    }

    /**
     * Devuelve a Link como entidad, solo para saber dónde está.
     */
    @Override
    public Entidad getJugador() {
        return jugador;
    }

    /**
     * Devuelve la fábrica de entidades de la partida.
     */
    @Override
    public FabricaEntidades getFabricaEntidades() {
        return fabricaEntidades;
    }
}
