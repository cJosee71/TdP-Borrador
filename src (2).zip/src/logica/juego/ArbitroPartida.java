package logica.juego;

/**
 * Lo que un modo de juego puede pedirle a la partida.
 */
public interface ArbitroPartida {

    // Comandos

    /**
     * Pierde el nivel por la condición del modo (tiempo agotado o golpe): GAME OVER con reinicio del nivel o vuelta al
     * menú, sin ranking.
     */
    public void terminarPartida();
}
