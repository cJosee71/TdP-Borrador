package logica.juego;

/**
 * Modo en el que cada nivel tiene un tiempo límite; al agotarse es GAME OVER y, si se reinicia el nivel, vuelve el
 * tiempo completo.
 */
public class Contrarreloj extends ModoJuego {

    // Atributos de clase

    private static final int CANTIDAD_NIVELES = 2;
    private static final int TIEMPO_LIMITE = 120;

    // Constructores

    /**
     * Crea el modo con CANTIDAD_NIVELES niveles y TIEMPO_LIMITE segundos por nivel.
     */
    public Contrarreloj() {
        super(CANTIDAD_NIVELES);
    }

    // Comandos

    /**
     * Agrega la entrada al ranking de este modo.
     */
    @Override
    public void registrarPuntaje(TablaRankings tabla, EntradaRanking entrada) {
        tabla.agregarAlRankingContrarreloj(entrada);
    }

    /**
     * Si el tiempo del nivel llegó al límite, le pide a la partida el GAME OVER.
     */
    @Override
    public void alPasarTiempo(ArbitroPartida arbitro, int segundos) {
        if (segundos >= TIEMPO_LIMITE) {
            arbitro.terminarPartida();
        }
    }

    // Consultas

    /**
     * Devuelve el nombre del modo.
     */
    @Override
    public String getNombre() {
        return "Contrarreloj";
    }

    /**
     * Devuelve el ranking de este modo.
     */
    @Override
    public Ranking getRanking(TablaRankings tabla) {
        return tabla.getRankingContrarreloj();
    }

    /**
     * Devuelve la descripción del modo, con su tiempo límite por nivel.
     */
    @Override
    public String getDescripcion() {
        return "Tenés " + TIEMPO_LIMITE + " segundos por nivel.";
    }
}
