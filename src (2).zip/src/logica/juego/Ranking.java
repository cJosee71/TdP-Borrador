package logica.juego;

import java.util.ArrayList;
import java.util.List;

/**
 * Los MAXIMO mejores puntajes de un modo, de mayor a menor.
 */
public class Ranking {

    // Atributos de clase

    private static final int MAXIMO = 5;

    // Atributos de instancia

    protected List<EntradaRanking> entradas;

    // Constructores

    /**
     * Crea un ranking vacío.
     */
    public Ranking() {
        entradas = new ArrayList<>();
    }

    // Comandos

    /**
     * Inserta la entrada si entra entre los MAXIMO mejores; devuelve true si entró.
     * Un mismo nombre figura una sola vez, con su mayor puntaje (mayúsculas y minúsculas distinguen jugadores).
     */
    public boolean insertar(EntradaRanking nuevaEntrada) {
        EntradaRanking mismoJugador = buscarPorNombre(nuevaEntrada.getNombre());
        if (mismoJugador != null) {
            if (mismoJugador.getPuntaje() >= nuevaEntrada.getPuntaje())
                return false;
            entradas.remove(mismoJugador);
        }
        if (!entraEnTop5(nuevaEntrada.getPuntaje()))
            return false;
        entradas.add(calcularPosicionInsercion(nuevaEntrada.getPuntaje()), nuevaEntrada);
        limitarTamanioRanking();
        return true;
    }

    /**
     * Devuelve la entrada con ese nombre, o null si no está en el ranking.
     */
    private EntradaRanking buscarPorNombre(String nombre) {
        for (EntradaRanking existente : entradas)
            if (existente.getNombre().equals(nombre))
                return existente;
        return null;
    }

    /**
     * Devuelve la posición donde va un puntaje para que el ranking siga de mayor a menor.
     */
    private int calcularPosicionInsercion(int puntaje) {
        int posicion = 0;
        while (posicion < entradas.size() && entradas.get(posicion).getPuntaje() >= puntaje)
            posicion++;
        return posicion;
    }

    /**
     * Saca la última entrada si el ranking pasó de MAXIMO.
     */
    private void limitarTamanioRanking() {
        if (entradas.size() > MAXIMO)
            entradas.remove(MAXIMO);
    }

    // Consultas

    /**
     * Indica si un puntaje entra entre los MAXIMO mejores.
     */
    public boolean entraEnTop5(int puntaje) {
        return entradas.size() < MAXIMO || puntaje > entradas.get(entradas.size() - 1).getPuntaje();
    }

    /**
     * Devuelve una copia de las entradas.
     */
    public List<EntradaRanking> getEntradas() {
        return new ArrayList<>(entradas);
    }

    /**
     * Devuelve la cantidad de entradas.
     */
    public int cantidad() {
        return entradas.size();
    }

    /**
     * Devuelve cuántas entradas entran en el ranking (MAXIMO).
     */
    public int getMaximo() {
        return MAXIMO;
    }
}
