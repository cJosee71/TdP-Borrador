package logica.juego;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;

/**
 * Guarda y carga los rankings en archivos de texto.
 */
public class PersistenciaRanking {

    // Atributos de clase

    private static final String SEPARADOR_CAMPOS = ";";
    private static final int PARTES_ENTRADA_VALIDAS = 2;

    // Constructores

    /**
     * Crea la persistencia.
     */
    public PersistenciaRanking() { }

    // Comandos

    /**
     * Guarda el ranking en un archivo, una entrada por línea.
     */
    public void guardar(Ranking r, String archivo) {
        try (PrintWriter salida = new PrintWriter(new FileWriter(archivo, StandardCharsets.UTF_8))) {
            for (EntradaRanking e : r.getEntradas())
                salida.println(e.getNombre().replace(SEPARADOR_CAMPOS, " ") + SEPARADOR_CAMPOS + e.getPuntaje());
        } catch (IOException ex) {
            System.err.println("No se pudo guardar el ranking: " + ex.getMessage());
        }
    }

    // Consultas

    /**
     * Carga un ranking desde un archivo; si no existe o está dañado, lo devuelve vacío.
     */
    public Ranking cargar(String archivo) {
        Ranking ranking = new Ranking();
        File archivoRanking = new File(archivo);
        if (!archivoRanking.exists())
            return ranking;
        try (BufferedReader lector = new BufferedReader(new FileReader(archivoRanking, StandardCharsets.UTF_8))) {
            String linea;
            while ((linea = lector.readLine()) != null) {
                EntradaRanking entrada = leerEntrada(linea);
                if (entrada != null)
                    ranking.insertar(entrada);
            }
        } catch (IOException | NumberFormatException ex) {
            System.err.println("Ranking dañado, se empieza vacío: " + ex.getMessage());
        }
        return ranking;
    }

    /**
     * Arma la entrada de una línea "nombre;puntaje", o devuelve null si la línea no tiene ese formato.
     */
    private EntradaRanking leerEntrada(String linea) {
        String[] partes = linea.split(SEPARADOR_CAMPOS);
        if (partes.length != PARTES_ENTRADA_VALIDAS)
            return null;
        return new EntradaRanking(partes[0], Integer.parseInt(partes[1].trim()));
    }
}
