package logica.juego;

/**
 * Modo en el que el primer daño (un golpe o una caída al vacío) es GAME OVER: se reinicia el nivel o se vuelve al menú.
 */
public class NoHit extends ModoJuego {

    // Atributos de clase

    private static final int CANTIDAD_NIVELES = 2;

    // Constructores

    /**
     * Crea el modo con CANTIDAD_NIVELES niveles.
     */
    public NoHit() {
        super(CANTIDAD_NIVELES);
    }

    // Comandos

    /**
     * Agrega la entrada al ranking de este modo.
     */
    @Override
    public void registrarPuntaje(TablaRankings tabla, EntradaRanking entrada) {
        tabla.agregarAlRankingNoHit(entrada);
    }

    /**
     * Al recibir daño, sea un golpe o una caída al vacío, le pide a la partida el GAME OVER.
     */
    @Override
    public void alRecibirDanio(ArbitroPartida arbitro) {
        arbitro.terminarPartida();
    }

    // Consultas

    /**
     * Devuelve el nombre del modo.
     */
    @Override
    public String getNombre() {
        return "NoHit";
    }

    /**
     * Devuelve el ranking de este modo.
     */
    @Override
    public Ranking getRanking(TablaRankings tabla) {
        return tabla.getRankingNoHit();
    }

    /**
     * Devuelve la descripción del modo.
     */
    @Override
    public String getDescripcion() {
        return "Un solo golpe y la partida termina.";
    }
}
