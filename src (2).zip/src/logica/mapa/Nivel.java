package logica.mapa;

import logica.util.Posicion;
import logica.entidades.enemigos.Jefe;
import java.util.List;

/**
 * Nivel del juego: su escena, sus jefes y dónde empieza Link.
 */
public class Nivel {

    // Atributos de instancia

    protected Escena mapa;
    protected List<Jefe> jefes;
    protected int filaInicial;
    protected int columnaInicial;
    protected Posicion posicionInicial;

    // Constructores

    /**
     * Crea el nivel con su escena, sus jefes y el lugar de inicio.
     */
    public Nivel(Escena mapa, List<Jefe> jefes, int filaInicial, int columnaInicial, Posicion posicionInicial) {
        this.mapa = mapa;
        this.jefes = jefes;
        this.filaInicial = filaInicial;
        this.columnaInicial = columnaInicial;
        this.posicionInicial = posicionInicial;
    }

    // Consultas

    /**
     * Devuelve la escena.
     */
    public Escena getMapa() {
        return mapa;
    }

    /**
     * Devuelve el sector donde empieza Link.
     */
    public Sector getSectorInicial() {
        return mapa.getSector(filaInicial, columnaInicial);
    }

    /**
     * Devuelve la posición donde empieza Link.
     */
    public Posicion getPosicionInicial() {
        return posicionInicial;
    }

    /**
     * Indica si todos los jefes fueron derrotados; deja de recorrer en el primer jefe vivo.
     */
    public boolean jefesDerrotados() {
        int cantidadDerrotados = 0;
        while (cantidadDerrotados < jefes.size() && jefes.get(cantidadDerrotados).estaEliminada())
            cantidadDerrotados++;
        return cantidadDerrotados == jefes.size();
    }
}
