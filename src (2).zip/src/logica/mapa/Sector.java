package logica.mapa;

import logica.entidades.AdministradorColisiones;
import logica.util.Hitbox;
import java.util.Random;
import logica.util.Posicion;
import logica.entidades.Entidad;
import java.util.List;
import java.util.ArrayList;

/**
 * Pantalla del nivel con sus entidades.
 */
public class Sector {

    // Atributos de clase

    private static final int INTENTOS_LUGAR_LIBRE = 200;
    public static final int ANCHO = 768;
    public static final int ALTO = 528;

    // Atributos de instancia

    protected List<Entidad> entidades;
    protected int fila;
    protected int columna;

    // Constructores

    /**
     * Crea un sector vacío en una celda de la escena.
     */
    public Sector(int fila, int columna) {
        this.fila = fila;
        this.columna = columna;
        this.entidades = new ArrayList<>();
    }

    // Comandos

    /**
     * Agrega una entidad al sector.
     */
    public synchronized void agregar(Entidad entidad) {
        entidades.add(entidad);
        entidad.setSector(this);
    }

    /**
     * Quita una entidad del sector: porque fue eliminada o porque se va a otro sector.
     */
    public synchronized void quitar(Entidad entidad) {
        entidades.remove(entidad);
    }

    /**
     * Actualiza una vez cada entidad no eliminada.
     */
    public void actualizarEntidades(AdministradorColisiones colisiones) {
        for (Entidad entidad : getEntidades())
            if (!entidad.estaEliminada())
                entidad.actualizarPorMundo(colisiones);
    }

    // Consultas

    /**
     * Devuelve una copia de la lista de entidades.
     */
    public synchronized List<Entidad> getEntidades() {
        return new ArrayList<>(entidades);
    }

    /**
     * Devuelve un lugar libre al azar para un cuerpo de ese tamaño (prueba hasta INTENTOS_LUGAR_LIBRE veces), o el
     * centro si no encuentra.
     */
    public Posicion posicionLibreAlAzar(int ancho, int alto) {
        Random azar = new Random();
        List<Entidad> todas = getEntidades();
        Posicion posicion = getCentro();
        boolean encontrado = false;
        int intento = 0;
        while (!encontrado && intento < INTENTOS_LUGAR_LIBRE) {
            int x = azar.nextInt(ANCHO - ancho + 1);
            int y = azar.nextInt(ALTO - alto + 1);
            Hitbox lugar = new Hitbox(x, y, ancho, alto);
            encontrado = estaLibre(lugar, todas);
            if (encontrado)
                posicion = new Posicion(x, y);
            intento++;
        }
        return posicion;
    }

    /**
     * Indica si ninguna de las entidades no eliminadas ocupa el lugar.
     */
    private boolean estaLibre(Hitbox lugar, List<Entidad> todas) {
        boolean libre = true;
        int indiceEntidad = 0;
        while (libre && indiceEntidad < todas.size()) {
            Entidad entidad = todas.get(indiceEntidad);
            libre = entidad.estaEliminada() || !entidad.getHitbox().intersecta(lugar);
            indiceEntidad++;
        }
        return libre;
    }

    /**
     * Devuelve el centro de la pantalla.
     */
    public Posicion getCentro() {
        return new Posicion(ANCHO / 2, ALTO / 2);
    }

    /**
     * Devuelve la fila en la escena.
     */
    public int getFila() {
        return fila;
    }

    /**
     * Devuelve la columna en la escena.
     */
    public int getColumna() {
        return columna;
    }
}
