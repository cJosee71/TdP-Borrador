package logica.mapa;

import logica.entidades.Entidad;
import logica.fabricas.FabricaEntidades;
import logica.entidades.enemigos.Jefe;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import logica.util.Posicion;

/**
 * Arma los niveles a partir de sus archivos de texto.
 */
public class GeneradorNivel {

    // Atributos de clase

    private static final int PRIMERA_LINEA_DE_SECTORES = 3;
    private static final int FRAGMENTOS_POR_NIVEL = 4;

    // Atributos de instancia

    protected String carpetaNiveles;

    // Constructores

    /**
     * Crea el generador con la carpeta de los archivos de niveles.
     */
    public GeneradorNivel(String carpetaNiveles) {
        this.carpetaNiveles = carpetaNiveles;
    }

    // Comandos

    /**
     * Reparte FRAGMENTOS_POR_NIVEL fragmentos de corazón en sectores al azar, uno por sector.
     */
    private void colocarFragmentosDeCorazon(Escena escena, FabricaEntidades fabrica) {
        List<Sector> sectores = sectoresDeLaEscena(escena);
        Collections.shuffle(sectores);
        for (int fragmento = 0; fragmento < FRAGMENTOS_POR_NIVEL && fragmento < sectores.size(); fragmento++)
            colocarFragmentoEn(sectores.get(fragmento), fabrica);
    }

    /**
     * Agrega un fragmento de corazón al sector, en un lugar libre del tamaño de su cuerpo.
     */
    private void colocarFragmentoEn(Sector sector, FabricaEntidades fabrica) {
        Entidad fragmento = fabrica.crearFragmentoDeCorazon(0, 0);
        Posicion posicion = sector.posicionLibreAlAzar(fragmento.getAncho(), fragmento.getAlto());
        fragmento.ubicarCuerpoEn(posicion.getX(), posicion.getY());
        sector.agregar(fragmento);
    }

    /**
     * Crea el sector cuya cabecera está en lineaCabecera, lo ubica en la escena y le agrega las entidades de sus
     * filas.
     */
    private void cargarSector(List<String> lineas, int lineaCabecera, Escena escena, int columnasPorSector,
            int filasPorSector, int tamanioCelda, List<Jefe> jefes, FabricaEntidades fabrica) {
        String[] cabecera = lineas.get(lineaCabecera).split(" ");
        Sector sector = new Sector(Integer.parseInt(cabecera[1]), Integer.parseInt(cabecera[2]));
        escena.agregarSector(sector.getFila(), sector.getColumna(), sector);
        for (int filaDelSector = 0; filaDelSector < filasPorSector; filaDelSector++) {
            String renglon = lineas.get(lineaCabecera + 1 + filaDelSector);
            for (int columna = 0; columna < columnasPorSector; columna++)
                agregarSimbolo(sector, renglon.charAt(columna), columna * tamanioCelda, filaDelSector * tamanioCelda,
                        jefes, fabrica);
        }
    }

    /**
     * Agrega al sector la entidad de un símbolo del archivo; si es un jefe, también lo anota en la lista de jefes.
     */
    private void agregarSimbolo(Sector sector, char simbolo, int x, int y, List<Jefe> jefes, FabricaEntidades fabrica) {
        if (esJefe(simbolo)) {
            Jefe jefe = crearJefe(simbolo, x, y, fabrica);
            jefes.add(jefe);
            sector.agregar(jefe);
        } else if (!esCeldaVacia(simbolo)) {
            sector.agregar(crearEntidad(simbolo, x, y, fabrica));
        }
    }

    // Consultas

    /**
     * Crea el nivel indicado con sus sectores, entidades y jefes; si el sector de inicio no existe, lanza
     * IllegalStateException.
     */
    public Nivel generar(int numero, FabricaEntidades fabrica) {
        List<String> lineas = leerArchivo(numero);
        String[] cabeceraMapa = lineas.get(0).split(" ");
        String[] cabeceraCeldas = lineas.get(1).split(" ");
        String[] cabeceraInicio = lineas.get(2).split(" ");
        int columnasPorSector = Integer.parseInt(cabeceraCeldas[1]);
        int filasPorSector = Integer.parseInt(cabeceraCeldas[2]);
        int tamanioCelda = Integer.parseInt(cabeceraCeldas[3]);
        Escena escena = new Escena(Integer.parseInt(cabeceraMapa[1]), Integer.parseInt(cabeceraMapa[2]));
        List<Jefe> jefes = new ArrayList<>();
        int lineaCabecera = PRIMERA_LINEA_DE_SECTORES;
        while (lineaCabecera < lineas.size()) {
            cargarSector(lineas, lineaCabecera, escena, columnasPorSector, filasPorSector, tamanioCelda, jefes,
                    fabrica);
            lineaCabecera += 1 + filasPorSector;
        }
        colocarFragmentosDeCorazon(escena, fabrica);
        int filaInicial = Integer.parseInt(cabeceraInicio[1]);
        int columnaInicial = Integer.parseInt(cabeceraInicio[2]);
        if (escena.getSector(filaInicial, columnaInicial) == null)
            throw new IllegalStateException("El sector de inicio no existe en el nivel " + numero);
        int xInicial = Integer.parseInt(cabeceraInicio[3]) * tamanioCelda;
        int yInicial = Integer.parseInt(cabeceraInicio[4]) * tamanioCelda;
        Posicion posicion = new Posicion(xInicial, yInicial);
        return new Nivel(escena, jefes, filaInicial, columnaInicial, posicion);
    }

    /**
     * Devuelve las líneas no vacías del archivo del nivel.
     */
    private List<String> leerArchivo(int numero) {
        String ruta = carpetaNiveles + "nivel" + numero + ".txt";
        InputStream archivo = getClass().getResourceAsStream(ruta);
        if (archivo == null)
            throw new IllegalStateException("No se pudo leer " + ruta);
        List<String> lineas = new ArrayList<>();
        try (BufferedReader lector = new BufferedReader(new InputStreamReader(archivo, StandardCharsets.UTF_8))) {
            String linea;
            while ((linea = lector.readLine()) != null)
                if (!linea.isBlank())
                    lineas.add(linea);
        } catch (IOException ex) {
            throw new IllegalStateException("No se pudo leer " + ruta, ex);
        }
        return lineas;
    }

    /**
     * Crea la entidad que corresponde a un símbolo del archivo (que no es una celda vacía). El '#' es la pared
     * invisible que frena a todos en el borde dibujado del fondo.
     */
    private Entidad crearEntidad(char simbolo, int x, int y, FabricaEntidades fabrica) {
        Entidad entidad;
        switch (simbolo) {
            case 'R': entidad = fabrica.crearRoca(x, y); break;
            case '#': entidad = fabrica.crearPared(x, y); break;
            case 'A': entidad = fabrica.crearAgua(x, y); break;
            case 'P': entidad = fabrica.crearPasto(x, y); break;
            case 'V': entidad = fabrica.crearCaidasAlVacio(x, y); break;
            case 'Q': entidad = fabrica.crearSuelosQuebradizo(x, y); break;
            case 'M': entidad = fabrica.crearMoblin(x, y); break;
            case 'N': entidad = fabrica.crearMoblinConEspadaYEscudo(x, y); break;
            case 'E': entidad = fabrica.crearErizoDeMar(x, y); break;
            case 'O': entidad = fabrica.crearOctorok(x, y); break;
            case 'T': entidad = fabrica.crearTrampaDeCuchillas(x, y); break;
            case 'W': entidad = fabrica.crearWizzrobe(x, y); break;
            case '$': entidad = fabrica.crearRupia(x, y); break;
            case 'C': entidad = fabrica.crearCorazon(x, y); break;
            case 'X': entidad = fabrica.crearEspada(x, y); break;
            default: throw new IllegalArgumentException("Símbolo desconocido: " + simbolo);
        }
        return entidad;
    }

    /**
     * Indica si el símbolo es el de una celda vacía ('.').
     */
    private boolean esCeldaVacia(char simbolo) {
        return simbolo == '.';
    }

    /**
     * Indica si el símbolo es el de un jefe: 'S' (Master Stalfos) o 'H' (Stone Hinox).
     */
    private boolean esJefe(char simbolo) {
        return simbolo == 'S' || simbolo == 'H';
    }

    /**
     * Crea el jefe de un símbolo de jefe.
     */
    private Jefe crearJefe(char simbolo, int x, int y, FabricaEntidades fabrica) {
        return simbolo == 'S' ? fabrica.crearMasterStalfos(x, y) : fabrica.crearStoneHinox(x, y);
    }

    /**
     * Devuelve los sectores que existen en la escena, recorriéndola por filas.
     */
    private List<Sector> sectoresDeLaEscena(Escena escena) {
        List<Sector> sectores = new ArrayList<>();
        for (int fila = 0; fila < escena.getFilas(); fila++)
            for (int columna = 0; columna < escena.getColumnas(); columna++) {
                Sector sector = escena.getSector(fila, columna);
                if (sector != null)
                    sectores.add(sector);
            }
        return sectores;
    }
}
