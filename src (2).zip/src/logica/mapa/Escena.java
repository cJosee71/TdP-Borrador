package logica.mapa;

import logica.util.Direccion;

/**
 * Grilla de sectores de un nivel.
 */
public class Escena {

    // Atributos de instancia

    protected Sector[][] sectores;
    protected int filas;
    protected int columnas;

    // Constructores

    /**
     * Crea una escena vacía de filas por columnas.
     */
    public Escena(int filas, int columnas) {
        this.filas = filas;
        this.columnas = columnas;
        this.sectores = new Sector[filas][columnas];
    }

    // Comandos

    /**
     * Ubica un sector en la grilla si la celda existe.
     */
    public void agregarSector(int fila, int columna, Sector sector) {
        if (estaEnLaGrilla(fila, columna)) {
            sectores[fila][columna] = sector;
        }
    }

    // Consultas

    /**
     * Devuelve el sector de una celda, o null.
     */
    public Sector getSector(int fila, int columna) {
        return estaEnLaGrilla(fila, columna) ? sectores[fila][columna] : null;
    }

    /**
     * Devuelve el sector vecino en una dirección, o null.
     */
    public Sector getVecino(Sector sector, Direccion direccion) {
        int filaVecina = sector.getFila() + direccion.getDy();
        int columnaVecina = sector.getColumna() + direccion.getDx();
        return getSector(filaVecina, columnaVecina);
    }

    /**
     * Indica si la celda (fila, columna) está dentro de la grilla.
     */
    private boolean estaEnLaGrilla(int fila, int columna) {
        return fila >= 0 && fila < filas && columna >= 0 && columna < columnas;
    }

    /**
     * Devuelve la cantidad de filas.
     */
    public int getFilas() {
        return filas;
    }

    /**
     * Devuelve la cantidad de columnas.
     */
    public int getColumnas() {
        return columnas;
    }
}
