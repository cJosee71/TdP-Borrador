package logica.fabricas;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

/**
 * Crea los sprites de cada entidad desde la carpeta de un dominio gráfico (patrón Abstract Factory), con los cuerpos y
 * márgenes de su medidas.txt.
 */
public abstract class FabricaSprites {

    // Atributos de clase

    private static final String ARCHIVO_MEDIDAS = "/medidas.txt";
    private static final String[] DIRECCIONES = { "abajo", "arriba", "izquierda", "derecha" };
    private static final String[] PREFIJOS_LINK = { "", "bellota-" };
    private static final int[] SIN_MARGEN = { 0, 0 };

    // Atributos de instancia

    private Map<String, int[]> medidas;

    // Consultas

    /**
     * Crea el sprite de Link con cada imagen en su versión normal y en la de túnica roja (bellota). Los márgenes de
     * la espada y del golpe y el alcance de la espada salen de medidas.txt.
     */
    public Sprite crearSpritesLink() {
        Sprite sprite = conAlcance(conCuerpo(new Sprite(), "link"), "link");
        for (String prefijo : PREFIJOS_LINK) {
            agregarEstadosQuieto(sprite, prefijo);
            for (String direccion : DIRECCIONES)
                agregarEstadosPorDireccion(sprite, prefijo, direccion);
        }
        return sprite;
    }

    /**
     * Agrega a Link los estados que no dependen de caminar ni de atacar: quieto y con escudo en cada dirección, la
     * caída, la muerte y perder una vida.
     */
    private void agregarEstadosQuieto(Sprite sprite, String prefijo) {
        String base = rutaBaseLink(prefijo);
        for (String direccion : DIRECCIONES) {
            sprite.agregar(prefijo + direccion, base + direccion + ".png");
            sprite.agregar(prefijo + "escudo-" + direccion, base + "escudo-" + direccion + ".png");
        }
        sprite.agregar(prefijo + "caida", base + "caida.gif");
        sprite.agregar(prefijo + "muerte", base + "muerte.gif");
        sprite.agregar(prefijo + "pierde-vida", base + "pierde-vida.gif");
    }

    /**
     * Agrega a Link los estados de una dirección: ataque, ataque recargado y caminar. Las imágenes con la espada
     * afuera usan el margen "link-espada" y el golpe, el margen "link-golpe".
     */
    private void agregarEstadosPorDireccion(Sprite sprite, String prefijo, String direccion) {
        String base = rutaBaseLink(prefijo);
        int espadaX = direccion.equals("izquierda") ? margenX("link-espada") : 0;
        int espadaY = direccion.equals("arriba") ? margenY("link-espada") : 0;
        sprite.agregar(prefijo + "ataque-recargado-" + direccion, base + "ataque-recargado-" + direccion + ".png",
                espadaX, espadaY);
        sprite.agregar(prefijo + "ataque-" + direccion, base + "ataque-" + direccion + ".gif",
                margenX("link-golpe"), margenY("link-golpe"));
        sprite.agregar(prefijo + "caminar-" + direccion, base + "caminar-" + direccion + ".gif");
        sprite.agregar(prefijo + "caminar-escudo-" + direccion, base + "caminar-escudo-" + direccion + ".gif");
        sprite.agregar(prefijo + "caminar-ataque-" + direccion, base + "caminar-ataque-" + direccion + ".gif",
                espadaX, espadaY);
        sprite.agregar(prefijo + "caminar-recargado-" + direccion, base + "caminar-recargado-" + direccion + ".gif",
                espadaX, espadaY);
    }

    /**
     * Devuelve el comienzo de la ruta de las imágenes de Link con el prefijo dado.
     */
    private String rutaBaseLink(String prefijo) {
        return carpeta() + "/link-" + prefijo;
    }

    /**
     * Crea el sprite del Moblin.
     */
    public Sprite crearSpritesMoblin() {
        Sprite sprite = conCuerpo(new Sprite(), "moblin");
        for (String direccion : DIRECCIONES)
            sprite.agregar(direccion, carpeta() + "/moblin-" + direccion + ".gif");
        sprite.agregar("muerte", carpeta() + "/moblin-muerte.gif");
        return sprite;
    }

    /**
     * Crea el sprite del Moblin con espada y escudo.
     */
    public Sprite crearSpritesMoblinConEspadaYEscudo() {
        String nombre = "moblinconespadayescudo";
        Sprite sprite = conCuerpo(new Sprite(), nombre);
        for (String estado : new String[] { "abajo", "arriba", "izquierda", "derecha", "muerte" })
            sprite.agregar(estado, carpeta() + "/" + nombre + "-" + estado + ".gif", margenX(nombre), margenY(nombre));
        return sprite;
    }

    /**
     * Crea el sprite del erizo de mar, con la nube de muerte.
     */
    public Sprite crearSpritesErizoDeMar() {
        Sprite sprite = armar("erizodemar", "normal");
        sprite.agregar("muerte", carpeta() + "/erizodemar-muerte.gif");
        return sprite;
    }

    /**
     * Crea el sprite del Octorok, con la nube de muerte.
     */
    public Sprite crearSpritesOctorok() {
        Sprite sprite = armar("octorok", DIRECCIONES);
        sprite.agregar("muerte", carpeta() + "/octorok-muerte.gif");
        return sprite;
    }

    /**
     * Crea el sprite de la trampa de cuchillas.
     */
    public Sprite crearSpritesTrampaDeCuchillas() {
        return armar("trampadecuchillas", "normal");
    }

    /**
     * Crea el sprite del Wizzrobe: una imagen por dirección, los GIFs de aparecer y desaparecer, y la nube de muerte.
     */
    public Sprite crearSpritesWizzrobe() {
        Sprite sprite = armar("wizzrobe", DIRECCIONES);
        for (String direccion : DIRECCIONES) {
            sprite.agregar("aparecer-" + direccion, carpeta() + "/wizzrobe-aparecer-" + direccion + ".gif");
            sprite.agregar("desaparecer-" + direccion, carpeta() + "/wizzrobe-desaparecer-" + direccion + ".gif");
        }
        sprite.agregar("muerte", carpeta() + "/wizzrobe-muerte.gif");
        return sprite;
    }

    /**
     * Crea el sprite de MasterStalfos: un GIF para caminar, otro para el golpe de espada y otro para la muerte en
     * cada dirección.
     */
    public Sprite crearSpritesMasterStalfos() {
        String nombre = "masterstalfos";
        Sprite sprite = conCuerpo(new Sprite(), nombre);
        for (String direccion : DIRECCIONES)
            for (String prefijo : new String[] { "", "ataque-", "muerte-" })
                sprite.agregar(prefijo + direccion, carpeta() + "/" + nombre + "-" + prefijo + direccion + ".gif",
                        margenX(nombre), margenY(nombre));
        return sprite;
    }

    /**
     * Crea el sprite de StoneHinox con sus GIFs (caminar, embestida, vulnerable, avalancha y muerte), todos con el
     * margen "stonehinox" de medidas.txt (0 si no está).
     */
    public Sprite crearSpritesStoneHinox() {
        String nombre = "stonehinox";
        Sprite sprite = conCuerpo(new Sprite(), nombre);
        for (String estado : new String[] { "normal", "embestida", "vulnerable", "avalancha", "muerte" })
            sprite.agregar(estado, carpeta() + "/" + nombre + "-" + estado + ".gif", margenX(nombre), margenY(nombre));
        return sprite;
    }

    /**
     * Crea el sprite de la rupia.
     */
    public Sprite crearSpritesRupia() {
        return armar("rupia", "normal");
    }

    /**
     * Crea el sprite de la bellota.
     */
    public Sprite crearSpritesBellota() {
        return armar("bellota", "normal");
    }

    /**
     * Crea el sprite del corazón.
     */
    public Sprite crearSpritesCorazon() {
        return armar("corazon", "normal");
    }

    /**
     * Crea el sprite del fragmento de corazón.
     */
    public Sprite crearSpritesFragmentoDeCorazon() {
        return armar("fragmentodecorazon", "normal");
    }

    /**
     * Crea el sprite de la espada.
     */
    public Sprite crearSpritesEspada() {
        return armar("espada", "normal");
    }

    /**
     * Crea el sprite del escudo.
     */
    public Sprite crearSpritesEscudo() {
        return armar("escudo", "normal");
    }

    /**
     * Crea el sprite de la roca.
     */
    public Sprite crearSpritesRoca() {
        return armar("roca", "normal");
    }

    /**
     * Crea el sprite de la pared invisible del borde del sector (imagen transparente).
     */
    public Sprite crearSpritesPared() {
        return armar("pared", "normal");
    }

    /**
     * Crea el sprite del agua.
     */
    public Sprite crearSpritesAgua() {
        return armar("agua", "normal");
    }

    /**
     * Crea el sprite del pasto.
     */
    public Sprite crearSpritesPasto() {
        return armar("pasto", "normal");
    }

    /**
     * Crea el sprite de la caída al vacío.
     */
    public Sprite crearSpritesCaidasAlVacio() {
        return armar("vacio", "normal");
    }

    /**
     * Crea el sprite del suelo quebradizo.
     */
    public Sprite crearSpritesSuelosQuebradizo() {
        return armar("suelo-quebradizo", "normal");
    }

    /**
     * Crea el sprite del disparo.
     */
    public Sprite crearSpritesProyectil() {
        return armar("proyectil", "normal");
    }

    /**
     * Crea el sprite de la roca grande.
     */
    public Sprite crearSpritesRocaGrande() {
        return armar("rocagrande", "normal");
    }

    /**
     * Devuelve la ruta de la imagen de fondo de un sector (según el número de nivel y la columna del sector), dentro
     * de la carpeta del dominio.
     */
    public String getRutaFondo(int numeroNivel, int columna) {
        return carpeta() + "/fondos/nivel" + numeroNivel + "/fondo-sector-" + columna + ".png";
    }

    /**
     * Arma un sprite con una imagen por estado y el cuerpo de la entidad.
     */
    protected Sprite armar(String nombre, String... estados) {
        Sprite sprite = conCuerpo(new Sprite(), nombre);
        for (String estado : estados)
            sprite.agregar(estado, carpeta() + "/" + nombre + "-" + estado + ".png");
        return sprite;
    }

    /**
     * Devuelve la carpeta de imágenes del dominio.
     */
    protected abstract String carpeta();

    /**
     * Le asigna al sprite el cuerpo, la línea "cuerpo nombre" del archivo de medidas (obligatoria, con 4 números).
     */
    protected Sprite conCuerpo(Sprite sprite, String nombre) {
        int[] valores = medidaObligatoria("cuerpo " + nombre, 4);
        sprite.setCuerpo(new Cuerpo(valores[0], valores[1], valores[2], valores[3]));
        return sprite;
    }

    /**
     * Le asigna al sprite el alcance del golpe de espada, la línea "alcance nombre" del archivo de medidas
     * (obligatoria, con 1 número).
     */
    protected Sprite conAlcance(Sprite sprite, String nombre) {
        sprite.setAlcanceAtaque(medidaObligatoria("alcance " + nombre, 1)[0]);
        return sprite;
    }

    /**
     * Devuelve los números de la línea "clave" del archivo de medidas; si falta o no tiene la cantidad pedida, lanza
     * IllegalStateException con el nombre de la línea y del archivo.
     */
    private int[] medidaObligatoria(String clave, int cantidad) {
        int[] valores = medidas().get(clave);
        if (valores == null || valores.length != cantidad)
            throw new IllegalStateException("Falta la línea \"" + clave + "\" en " + carpeta() + ARCHIVO_MEDIDAS);
        return valores;
    }

    /**
     * Devuelve el margen x de la imagen "imagen nombre" del archivo de medidas (0 si no está).
     */
    protected int margenX(String nombre) {
        return margen(nombre)[0];
    }

    /**
     * Devuelve el margen y de la imagen "imagen nombre" del archivo de medidas (0 si no está).
     */
    protected int margenY(String nombre) {
        return margen(nombre)[1];
    }

    /**
     * Devuelve el margen {x, y} de la imagen "imagen nombre" del archivo de medidas, o SIN_MARGEN si no está.
     */
    private int[] margen(String nombre) {
        int[] valores = medidas().get("imagen " + nombre);
        return valores != null && valores.length == 2 ? valores : SIN_MARGEN;
    }

    /**
     * Devuelve las medidas del dominio; las lee la primera vez que se piden.
     */
    protected Map<String, int[]> medidas() {
        if (medidas == null)
            medidas = leerMedidas(carpeta() + ARCHIVO_MEDIDAS);
        return medidas;
    }

    /**
     * Lee un archivo de medidas con líneas "tipo nombre números..." (tipo cuerpo, imagen o alcance), ignorando las
     * vacías y las que empiezan con #. Si el archivo no existe, devuelve un mapa vacío.
     */
    protected Map<String, int[]> leerMedidas(String ruta) {
        Map<String, int[]> leidas = new HashMap<>();
        InputStream entrada = getClass().getResourceAsStream(ruta);
        if (entrada != null) {
            try (BufferedReader lector = new BufferedReader(new InputStreamReader(entrada, StandardCharsets.UTF_8))) {
                String linea;
                while ((linea = lector.readLine()) != null) {
                    linea = linea.trim();
                    if (esLineaDeDatos(linea)) {
                        String[] partes = linea.split("\\s+");
                        leidas.put(partes[0] + " " + partes[1], leerNumeros(partes));
                    }
                }
            } catch (IOException e) {
                leidas.clear();
            }
        }
        return leidas;
    }

    /**
     * Indica si la línea ya recortada tiene datos: no está vacía ni es un comentario (empieza con #).
     */
    private boolean esLineaDeDatos(String linea) {
        return !linea.isEmpty() && !linea.startsWith("#");
    }

    /**
     * Convierte a números las partes de una línea de medidas que vienen después del tipo y del nombre.
     */
    private int[] leerNumeros(String[] partes) {
        int[] numeros = new int[partes.length - 2];
        for (int i = 0; i < numeros.length; i++)
            numeros[i] = Integer.parseInt(partes[i + 2]);
        return numeros;
    }
}
