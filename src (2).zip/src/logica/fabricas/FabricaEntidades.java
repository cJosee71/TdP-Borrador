package logica.fabricas;

import logica.entidades.EntornoJuego;
import logica.entidades.Link;
import logica.entidades.Proyectil;
import logica.entidades.enemigos.ErizoDeMar;
import logica.entidades.enemigos.MasterStalfos;
import logica.entidades.enemigos.Moblin;
import logica.entidades.enemigos.MoblinConEspadaYEscudo;
import logica.entidades.enemigos.Octorok;
import logica.entidades.enemigos.StoneHinox;
import logica.entidades.enemigos.TrampaDeCuchillas;
import logica.entidades.enemigos.Wizzrobe;
import logica.entidades.fijas.Agua;
import logica.entidades.fijas.Bellota;
import logica.entidades.fijas.CaidasAlVacio;
import logica.entidades.fijas.Corazon;
import logica.entidades.fijas.Escudo;
import logica.entidades.fijas.Espada;
import logica.entidades.fijas.FragmentoDeCorazon;
import logica.entidades.fijas.Pasto;
import logica.entidades.fijas.Roca;
import logica.entidades.fijas.Rupia;
import logica.entidades.fijas.SuelosQuebradizo;
import logica.util.Direccion;

/**
 * Crea las entidades del juego con los sprites del dominio elegido.
 */
public class FabricaEntidades {

    // Atributos de instancia

    private FabricaSprites fabricaSprites;
    private EntornoJuego entorno;

    // Constructores

    /**
     * Crea la fábrica para el entorno de la partida y un dominio gráfico.
     */
    public FabricaEntidades(EntornoJuego entorno, FabricaSprites fabricaSprites) {
        this.entorno = entorno;
        this.fabricaSprites = fabricaSprites;
    }

    // Consultas

    /**
     * Crea Link con su escudo en (x, y).
     */
    public Link crearLink(int x, int y) {
        Link link = new Link(fabricaSprites.crearSpritesLink(), x, y);
        link.setJuego(entorno);
        link.agregarAlInventario(crearEscudo(x, y));
        return link;
    }

    /**
     * Crea un Moblin en (x, y).
     */
    public Moblin crearMoblin(int x, int y) {
        Moblin moblin = new Moblin(fabricaSprites.crearSpritesMoblin(), x, y);
        moblin.setJuego(entorno);
        return moblin;
    }

    /**
     * Crea un Moblin con espada y escudo en (x, y).
     */
    public MoblinConEspadaYEscudo crearMoblinConEspadaYEscudo(int x, int y) {
        MoblinConEspadaYEscudo moblin =
                new MoblinConEspadaYEscudo(fabricaSprites.crearSpritesMoblinConEspadaYEscudo(), x, y);
        moblin.setJuego(entorno);
        return moblin;
    }

    /**
     * Crea un erizo de mar en (x, y).
     */
    public ErizoDeMar crearErizoDeMar(int x, int y) {
        ErizoDeMar erizo = new ErizoDeMar(fabricaSprites.crearSpritesErizoDeMar(), x, y);
        erizo.setJuego(entorno);
        return erizo;
    }

    /**
     * Crea un Octorok en (x, y).
     */
    public Octorok crearOctorok(int x, int y) {
        Octorok octorok = new Octorok(fabricaSprites.crearSpritesOctorok(), x, y);
        octorok.setJuego(entorno);
        return octorok;
    }

    /**
     * Crea una trampa de cuchillas en (x, y).
     */
    public TrampaDeCuchillas crearTrampaDeCuchillas(int x, int y) {
        TrampaDeCuchillas trampa = new TrampaDeCuchillas(fabricaSprites.crearSpritesTrampaDeCuchillas(), x, y);
        trampa.setJuego(entorno);
        return trampa;
    }

    /**
     * Crea un Wizzrobe en (x, y).
     */
    public Wizzrobe crearWizzrobe(int x, int y) {
        Wizzrobe wizzrobe = new Wizzrobe(fabricaSprites.crearSpritesWizzrobe(), x, y);
        wizzrobe.setJuego(entorno);
        return wizzrobe;
    }

    /**
     * Crea a MasterStalfos en (x, y).
     */
    public MasterStalfos crearMasterStalfos(int x, int y) {
        MasterStalfos masterStalfos = new MasterStalfos(fabricaSprites.crearSpritesMasterStalfos(), x, y);
        masterStalfos.setJuego(entorno);
        return masterStalfos;
    }

    /**
     * Crea a StoneHinox en (x, y).
     */
    public StoneHinox crearStoneHinox(int x, int y) {
        StoneHinox stoneHinox = new StoneHinox(fabricaSprites.crearSpritesStoneHinox(), x, y);
        stoneHinox.setJuego(entorno);
        return stoneHinox;
    }

    /**
     * Crea una rupia en (x, y).
     */
    public Rupia crearRupia(int x, int y) {
        Rupia rupia = new Rupia(fabricaSprites.crearSpritesRupia(), x, y);
        rupia.setJuego(entorno);
        return rupia;
    }

    /**
     * Crea una bellota en (x, y).
     */
    public Bellota crearBellota(int x, int y) {
        Bellota bellota = new Bellota(fabricaSprites.crearSpritesBellota(), x, y);
        bellota.setJuego(entorno);
        return bellota;
    }

    /**
     * Crea un corazón en (x, y).
     */
    public Corazon crearCorazon(int x, int y) {
        Corazon corazon = new Corazon(fabricaSprites.crearSpritesCorazon(), x, y);
        corazon.setJuego(entorno);
        return corazon;
    }

    /**
     * Crea un fragmento de corazón en (x, y).
     */
    public FragmentoDeCorazon crearFragmentoDeCorazon(int x, int y) {
        FragmentoDeCorazon fragmento = new FragmentoDeCorazon(fabricaSprites.crearSpritesFragmentoDeCorazon(), x, y);
        fragmento.setJuego(entorno);
        return fragmento;
    }

    /**
     * Crea una espada en (x, y).
     */
    public Espada crearEspada(int x, int y) {
        Espada espada = new Espada(fabricaSprites.crearSpritesEspada(), x, y);
        espada.setJuego(entorno);
        return espada;
    }

    /**
     * Crea un escudo en (x, y).
     */
    public Escudo crearEscudo(int x, int y) {
        Escudo escudo = new Escudo(fabricaSprites.crearSpritesEscudo(), x, y);
        escudo.setJuego(entorno);
        return escudo;
    }

    /**
     * Crea una roca en (x, y).
     */
    public Roca crearRoca(int x, int y) {
        return new Roca(fabricaSprites.crearSpritesRoca(), x, y);
    }

    /**
     * Crea un tramo de pared invisible en (x, y): es una roca con imagen transparente, que frena a todos en el borde
     * dibujado del fondo.
     */
    public Roca crearPared(int x, int y) {
        return new Roca(fabricaSprites.crearSpritesPared(), x, y);
    }

    /**
     * Crea agua en (x, y).
     */
    public Agua crearAgua(int x, int y) {
        return new Agua(fabricaSprites.crearSpritesAgua(), x, y);
    }

    /**
     * Crea pasto en (x, y).
     */
    public Pasto crearPasto(int x, int y) {
        return new Pasto(fabricaSprites.crearSpritesPasto(), x, y);
    }

    /**
     * Crea una caída al vacío en (x, y).
     */
    public CaidasAlVacio crearCaidasAlVacio(int x, int y) {
        return new CaidasAlVacio(fabricaSprites.crearSpritesCaidasAlVacio(), x, y);
    }

    /**
     * Crea un suelo quebradizo en (x, y).
     */
    public SuelosQuebradizo crearSuelosQuebradizo(int x, int y) {
        return new SuelosQuebradizo(fabricaSprites.crearSpritesSuelosQuebradizo(), x, y);
    }

    /**
     * Crea un disparo en (x, y) hacia una dirección, con el daño que decide quien dispara.
     */
    public Proyectil crearProyectil(int x, int y, Direccion direccion, int danio) {
        Proyectil proyectil = new Proyectil(fabricaSprites.crearSpritesProyectil(), x, y, direccion, danio);
        proyectil.setJuego(entorno);
        return proyectil;
    }

    /**
     * Crea una roca grande en (x, y) hacia una dirección, con el daño que decide quien la lanza.
     */
    public Proyectil crearRocaGrande(int x, int y, Direccion direccion, int danio) {
        Proyectil rocaGrande = new Proyectil(fabricaSprites.crearSpritesRocaGrande(), x, y, direccion, danio);
        rocaGrande.setJuego(entorno);
        return rocaGrande;
    }
}
