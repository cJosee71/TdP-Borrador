package logica.fabricas;

import java.util.HashMap;
import java.util.Map;

import logica.util.Posicion;

/**
 * Lo que depende del dibujo de una entidad en un dominio: sus imágenes, una por estado, con el estado actual; el
 * margen de cada imagen (cuántos píxeles se dibuja más a la izquierda y más arriba que la posición de la entidad,
 * cuando es más grande que ella); el cuerpo (hitbox) que le corresponde a ese dibujo; y el alcance del golpe de
 * espada, que depende de cuánto se estira la espada en ese dibujo.
 */
public class Sprite {

    // Atributos de instancia

    protected final Map<String, String> rutas;
    protected final Map<String, Posicion> margenes;
    protected String estadoActual;
    protected Cuerpo cuerpo;
    protected int alcanceAtaque;

    // Constructores

    /**
     * Crea un sprite sin imágenes.
     */
    public Sprite() {
        rutas = new HashMap<>();
        margenes = new HashMap<>();
    }

    // Comandos

    /**
     * Agrega la imagen de un estado; el primero queda como actual.
     */
    public void agregar(String estado, String ruta) {
        rutas.put(estado, ruta);
        if (estadoActual == null) {
            estadoActual = estado;
        }
    }

    /**
     * Agrega la imagen de un estado con su margen: se dibuja margenX píxeles más a la izquierda y margenY más arriba
     * que la entidad.
     */
    public void agregar(String estado, String ruta, int margenX, int margenY) {
        agregar(estado, ruta);
        margenes.put(estado, new Posicion(margenX, margenY));
    }

    /**
     * Asigna el cuerpo (hitbox) que corresponde a este dibujo.
     */
    public void setCuerpo(Cuerpo c) {
        cuerpo = c;
    }

    /**
     * Asigna el alcance del golpe de espada: los píxeles que llega desde el borde del cuerpo.
     */
    public void setAlcanceAtaque(int alcance) {
        alcanceAtaque = alcance;
    }

    /**
     * Cambia el estado actual si existe.
     */
    public void setEstado(String estado) {
        if (tieneEstado(estado)) {
            estadoActual = estado;
        }
    }

    // Consultas

    /**
     * Devuelve la ruta de la imagen actual.
     */
    public String getRutaActual() {
        return rutas.get(estadoActual);
    }

    /**
     * Devuelve el cuerpo de este dibujo, o null si el dominio no definió uno (la entidad usa su cuerpo por defecto).
     */
    public Cuerpo getCuerpo() {
        return cuerpo;
    }

    /**
     * Devuelve el alcance del golpe de espada de este dibujo, en píxeles desde el borde del cuerpo (0 si el dominio
     * no definió uno).
     */
    public int getAlcanceAtaque() {
        return alcanceAtaque;
    }

    /**
     * Devuelve el estado actual.
     */
    public String getEstadoActual() {
        return estadoActual;
    }

    /**
     * Devuelve cuántos píxeles más a la izquierda se dibuja la imagen de un estado (0 si no tiene margen).
     */
    public int getMargenX(String estado) {
        Posicion margen = margenes.get(estado);
        return margen != null ? margen.getX() : 0;
    }

    /**
     * Devuelve cuántos píxeles más arriba se dibuja la imagen de un estado (0 si no tiene margen).
     */
    public int getMargenY(String estado) {
        Posicion margen = margenes.get(estado);
        return margen != null ? margen.getY() : 0;
    }

    /**
     * Devuelve la ruta de la imagen de un estado.
     */
    public String getRuta(String estado) {
        return rutas.get(estado);
    }

    /**
     * Indica si tiene imagen para un estado.
     */
    public boolean tieneEstado(String estado) {
        return rutas.containsKey(estado);
    }
}
