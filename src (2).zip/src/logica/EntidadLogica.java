package logica;

/**
 * Datos de una entidad que la vista necesita para dibujarla.
 */
public interface EntidadLogica {

    // Atributos de clase

    /** Capa del suelo: pasto, agua, caídas al vacío y suelo quebradizo. */
    public static final int CAPA_SUELO = 0;

    /** Capa de lo que se agarra: objetos y power-ups. */
    public static final int CAPA_OBJETOS = 1;

    /** Capa de los obstáculos altos, como las rocas. */
    public static final int CAPA_OBSTACULOS = 2;

    /** Capa de los personajes: enemigos, jefes y proyectiles. */
    public static final int CAPA_PERSONAJES = 3;

    /** Capa del jugador, la más alta. */
    public static final int CAPA_JUGADOR = 4;

    // Consultas

    /**
     * Devuelve la x de la esquina de la entidad.
     */
    public int getX();

    /**
     * Devuelve la y de la esquina de la entidad.
     */
    public int getY();

    /**
     * Devuelve la x donde se dibuja la imagen; difiere de getX() si la imagen es más grande que la entidad (el margen
     * lo define el dominio en su medidas.txt).
     */
    public int getXImagen();

    /**
     * Devuelve la y donde se dibuja la imagen; difiere de getY() si la imagen es más grande que la entidad (el margen
     * lo define el dominio en su medidas.txt).
     */
    public int getYImagen();

    /**
     * Devuelve la ruta de la imagen actual.
     */
    public String getRutaImagen();

    /**
     * Indica si la entidad fue eliminada.
     */
    public boolean estaEliminada();

    /**
     * Devuelve la capa en la que se dibuja; las capas más altas tapan a las más bajas.
     */
    public int getCapa();

    /**
     * Indica si la entidad se ve en este momento; es falso en los instantes apagados de un parpadeo.
     */
    public boolean esVisible();
}
