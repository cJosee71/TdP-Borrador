package logica.hilos;

/**
 * Ciclo común de los hilos del juego: hacer una vuelta y dormir un período (patrón Template Method).
 */
public abstract class HiloJuego implements Runnable {

    // Atributos de instancia

    protected Thread hilo;
    protected volatile boolean activo;
    protected volatile boolean pausado;
    protected long periodo;

    // Constructores

    /**
     * Crea el hilo sin arrancarlo, con el período en milisegundos.
     */
    protected HiloJuego(long periodo) {
        this.periodo = periodo;
    }

    // Comandos

    /**
     * Arranca el hilo.
     */
    public void iniciar() {
        activo = true;
        pausado = false;
        hilo = new Thread(this);
        hilo.start();
    }

    /**
     * Pide que el hilo termine al final de la vuelta.
     */
    public void detener() {
        activo = false;
    }

    /**
     * Pausa las vueltas sin terminar el hilo.
     */
    public void pausar() {
        pausado = true;
    }

    /**
     * Saca el hilo de la pausa.
     */
    public void reanudar() {
        pausado = false;
    }

    /**
     * Mientras esté activo, hace una vuelta si no está en pausa y duerme un período. Si una vuelta lanza una
     * RuntimeException, la informa por System.err y el hilo sigue con la siguiente.
     */
    @Override
    public final void run() {
        while (activo) {
            ejecutarCicloSiNoPausado();
            dormirHastaLaProximaVuelta();
        }
    }

    /**
     * Hace una vuelta si el hilo no está en pausa; si la vuelta lanza una RuntimeException, la informa por System.err.
     */
    private void ejecutarCicloSiNoPausado() {
        if (!pausado) {
            try {
                ciclo();
            } catch (RuntimeException error) {
                System.err.println("Error en una vuelta del hilo: " + error);
            }
        }
    }

    /**
     * Duerme un período; si interrumpen el hilo, lo da por terminado y conserva la marca de interrupción.
     */
    private void dormirHastaLaProximaVuelta() {
        try {
            Thread.sleep(periodo);
        } catch (InterruptedException interrupcion) {
            activo = false;
            Thread.currentThread().interrupt();
        }
    }

    /**
     * Hace una vuelta del hilo.
     */
    protected abstract void ciclo();

    // Consultas

    /**
     * Indica si el hilo está corriendo.
     */
    public boolean estaActivo() {
        return activo;
    }

    /**
     * Indica si el hilo está en pausa.
     */
    public boolean estaPausado() {
        return pausado;
    }
}
