package logica;

import logica.util.Direccion;
import logica.juego.Ranking;

/**
 * Operaciones que la lógica le pide a la vista.
 */
public interface ControladorGrafico {

    // Comandos

    /**
     * Crea la celda gráfica de una entidad y la devuelve como su observador.
     */
    public Observer mostrarEntidad(EntidadLogica e);

    /**
     * Crea la celda gráfica del jugador y la devuelve como su observador.
     */
    public Observer mostrarJugador(EntidadJugador j);

    /**
     * Borra todas las entidades dibujadas.
     */
    public void limpiarEscena();

    /**
     * Anima el cambio de sector en la dirección indicada.
     */
    public void transicion(Direccion d);

    /**
     * Muestra el tiempo de la partida.
     */
    public void actualizarTiempo(int segundos);

    /**
     * Muestra el número de nivel.
     */
    public void actualizarNivel(int numero);

    /**
     * Muestra la imagen de fondo del sector visible, a partir de su ruta.
     */
    public void mostrarFondo(String ruta);

    /**
     * Deja de enviarle las teclas al jugador (pausa, GAME OVER, nivel superado o fin de la partida).
     */
    public void terminarControl();

    /**
     * Muestra la ventana emergente de nivel superado con el puntaje.
     */
    public void mostrarPasajeNivel(int nivelSuperado, int puntaje);

    /**
     * Muestra el menú de pausa con el nivel y el puntaje.
     */
    public void mostrarPausa(int nivel, int puntaje);

    /**
     * Muestra la ventana emergente de fin de partida (ganada o perdida) con el puntaje;
     * si entra al ranking, pide el nombre.
     */
    public void mostrarFinPartida(boolean gano, int puntaje, boolean entraEnRanking);

    /**
     * Muestra el ranking de un modo de juego.
     */
    public void mostrarRanking(Ranking r, String nombreModo);
}
