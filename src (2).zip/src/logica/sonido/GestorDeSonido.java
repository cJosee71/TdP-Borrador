package logica.sonido;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Collections;
import java.util.EnumMap;
import java.util.Map;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;

/**
 * Carga los sonidos una única vez y los reproduce cuando se los pide. Hay una sola instancia (patrón Singleton), que
 * se crea al cargar la clase; Principal la pide al arrancar para que la carga no demore la primera partida.
 */
public final class GestorDeSonido {

    // Atributos de clase

    private static final String CARPETA = "/Recursos/Sonidos/";
    private static final GestorDeSonido INSTANCIA = new GestorDeSonido();

    // Atributos de instancia

    private final Map<Sonido, Clip> sonidos;

    // Constructores

    /**
     * Crea el gestor y carga todos los sonidos del enumerado; los que no se puedan cargar quedan en silencio.
     */
    private GestorDeSonido() {
        Map<Sonido, Clip> cargados = new EnumMap<>(Sonido.class);
        for (Sonido sonido : Sonido.values()) {
            cargar(cargados, sonido);
        }
        sonidos = Collections.unmodifiableMap(cargados);
    }

    // Comandos

    /**
     * Reproduce el sonido desde el principio; si ya estaba sonando, lo reinicia.
     */
    public void reproducir(Sonido sonido) {
        Clip clip = sonidos.get(sonido);
        if (clip != null) {
            synchronized (clip) {
                clip.stop();
                clip.setFramePosition(0);
                clip.start();
            }
        }
    }

    /**
     * Reproduce el sonido en bucle hasta que se lo detenga; si ya estaba sonando, no hace nada.
     */
    public void reproducirEnBucle(Sonido sonido) {
        Clip clip = sonidos.get(sonido);
        if (clip != null) {
            synchronized (clip) {
                if (!clip.isRunning()) {
                    clip.setFramePosition(0);
                    clip.loop(Clip.LOOP_CONTINUOUSLY);
                }
            }
        }
    }

    /**
     * Retoma en bucle el sonido desde donde se detuvo; si ya estaba sonando, no hace nada.
     */
    public void reanudarEnBucle(Sonido sonido) {
        Clip clip = sonidos.get(sonido);
        if (clip != null) {
            synchronized (clip) {
                if (!clip.isRunning()) {
                    clip.loop(Clip.LOOP_CONTINUOUSLY);
                }
            }
        }
    }

    /**
     * Detiene el sonido si está sonando; se puede retomar desde ahí con reanudarEnBucle.
     */
    public void detener(Sonido sonido) {
        Clip clip = sonidos.get(sonido);
        if (clip != null) {
            synchronized (clip) {
                clip.stop();
            }
        }
    }

    /**
     * Carga el archivo del sonido y lo guarda en el mapa; si no existe o no se puede abrir, lo avisa por consola y
     * el sonido queda en silencio.
     */
    private void cargar(Map<Sonido, Clip> destino, Sonido sonido) {
        String ruta = CARPETA + sonido.getArchivo();
        try (InputStream entrada = getClass().getResourceAsStream(ruta)) {
            if (entrada == null) {
                System.err.println("No se encontró el sonido " + ruta);
            } else {
                destino.put(sonido, prepararClip(entrada));
            }
        } catch (Exception error) {
            System.err.println("No se pudo cargar el sonido " + ruta + ": " + error.getMessage());
        }
    }

    /**
     * Abre el flujo de audio y devuelve el Clip listo para reproducirse.
     */
    private Clip prepararClip(InputStream entrada)
            throws IOException, UnsupportedAudioFileException, LineUnavailableException {
        try (AudioInputStream audio = AudioSystem.getAudioInputStream(new BufferedInputStream(entrada))) {
            Clip clip = AudioSystem.getClip();
            clip.open(audio);
            return clip;
        }
    }

    // Consultas

    /**
     * Devuelve la única instancia del gestor.
     */
    public static GestorDeSonido getInstancia() {
        return INSTANCIA;
    }
}
