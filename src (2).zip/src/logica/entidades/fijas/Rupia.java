package logica.entidades.fijas;

import java.util.Random;

import logica.entidades.Link;
import logica.fabricas.Sprite;

/**
 * Power-up que suma una cantidad de rupias al azar.
 */
public class Rupia extends PowerUP {

    // Atributos de clase

    private static final int CANTIDAD_MINIMA = 1;
    private static final int CANTIDAD_MAXIMA = 5;
    private static final int PUNTOS_POR_RUPIA = 10;

    // Atributos de instancia

    private int cantidad;

    // Constructores

    /**
     * Crea la rupia en (x, y) con una cantidad al azar.
     */
    public Rupia(Sprite sprite, int x, int y) {
        super(sprite, x, y);
        cantidad = cantidadAlAzar();
    }

    // Comandos

    /**
     * Le suma las rupias a Link.
     */
    @Override
    public void serRecogidoPor(Link link) {
        link.sumarRupias(cantidad);
        super.serRecogidoPor(link);
    }

    // Consultas

    /**
     * Devuelve los puntos por cada rupia.
     */
    @Override
    public int getPuntos() {
        return PUNTOS_POR_RUPIA * cantidad;
    }

    /**
     * Devuelve una cantidad al azar entre CANTIDAD_MINIMA y CANTIDAD_MAXIMA.
     */
    private int cantidadAlAzar() {
        return CANTIDAD_MINIMA + new Random().nextInt(CANTIDAD_MAXIMA - CANTIDAD_MINIMA + 1);
    }
}
