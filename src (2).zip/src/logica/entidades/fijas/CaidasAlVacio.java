package logica.entidades.fijas;

import logica.entidades.EntidadAnimada;
import logica.entidades.Link;
import logica.fabricas.Sprite;

/**
 * Obstáculo que hace caer a Link y perder una vida.
 */
public class CaidasAlVacio extends Obstaculo {

    // Constructores

    /**
     * Crea la caída en (x, y); su cuerpo lo trae el sprite.
     */
    public CaidasAlVacio(Sprite sprite, int x, int y) {
        super(sprite, x, y);
    }

    // Comandos

    /**
     * Hace caer a Link cuando el centro de su cuerpo está sobre el pozo; si solo pisa el borde, no cae.
     */
    @Override
    public void afectar(Link link) {
        if (elCentroDeLinkEstaSobreElPozo(link))
            link.caerAlVacio();
    }

    // Consultas

    /**
     * Indica si el centro del cuerpo de Link está dentro del pozo.
     */
    private boolean elCentroDeLinkEstaSobreElPozo(Link link) {
        return getHitbox().contiene(link.getCentro());
    }

    /**
     * Le bloquea el paso solo a quien esquiva los vacíos (los enemigos); Link la pisa y cae.
     */
    @Override
    public boolean bloqueaPasoA(EntidadAnimada quien) {
        return quien.esquivaVacios();
    }

    /**
     * Impide que un enemigo se abalance o dispare a través de ella.
     */
    @Override
    public boolean impideAbalanzarse() {
        return true;
    }
}
