package logica.entidades.fijas;

import logica.comportamientos.DefensaLimitada;
import logica.entidades.Link;
import logica.fabricas.Sprite;

/**
 * Power-up que limita el daño de los próximos golpes.
 */
public class Bellota extends PowerUP {

    // Atributos de clase

    private static final int DANIO_MAXIMO = 1;
    private static final int GOLPES_PROTEGIDOS = 3;

    // Constructores

    /**
     * Crea la bellota en (x, y).
     */
    public Bellota(Sprite sprite, int x, int y) {
        super(sprite, x, y);
    }

    // Comandos

    /**
     * Le da a Link la defensa de la bellota, que lo protege y lo viste con la túnica roja.
     */
    @Override
    public void serRecogidoPor(Link link) {
        link.recibirBellota(new DefensaLimitada(DANIO_MAXIMO, GOLPES_PROTEGIDOS));
        super.serRecogidoPor(link);
    }
}
