package logica.entidades.fijas;

import logica.entidades.Colisionador;
import logica.entidades.Entidad;
import logica.entidades.Link;
import logica.fabricas.Sprite;
import logica.sonido.GestorDeSonido;
import logica.sonido.Sonido;

/**
 * Objeto que Link guarda en su inventario y puede equipar.
 */
public abstract class Objeto extends Entidad {

    // Constructores

    /**
     * Crea el objeto en (x, y).
     */
    protected Objeto(Sprite sprite, int x, int y) {
        super(sprite, x, y);
    }

    // Comandos

    /**
     * Recibe un choque (patrón Visitor).
     */
    @Override
    public void aceptarColision(Colisionador colisionador) {
        colisionador.colisionarCon(this);
    }

    /**
     * Suena al ser recogido, pasa al inventario de Link y sale del sector.
     */
    public void serRecogidoPor(Link link) {
        GestorDeSonido.getInstancia().reproducir(Sonido.POWER_UP);
        link.agregarAlInventario(this);
        eliminar();
    }

    /**
     * Ataca con el objeto; no hace nada por defecto.
     */
    public void atacarCon(Link link) {
    }

    /**
     * Suelta el ataque; no hace nada por defecto.
     */
    public void soltarAtaqueCon(Link link) {
    }

    /**
     * Protege con el objeto; no hace nada por defecto.
     */
    public void protegerCon(Link link) {
    }

    /**
     * Suelta la protección; no hace nada por defecto.
     */
    public void soltarProteccionCon(Link link) {
    }

    // Consultas

    /**
     * Se dibuja en la capa de los objetos.
     */
    @Override
    public int getCapa() {
        return CAPA_OBJETOS;
    }

    /**
     * Devuelve el nombre que muestra el HUD.
     */
    public abstract String getNombre();
}
