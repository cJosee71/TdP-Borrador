package logica.entidades.fijas;

import logica.entidades.Link;
import logica.fabricas.Sprite;

/**
 * Power-up que cura a Link.
 */
public class Corazon extends PowerUP {

    // Atributos de clase

    private static final int MEDIOS_CURADOS = 2;

    // Constructores

    /**
     * Crea el corazón en (x, y).
     */
    public Corazon(Sprite sprite, int x, int y) {
        super(sprite, x, y);
    }

    // Comandos

    /**
     * Cura a Link.
     */
    @Override
    public void serRecogidoPor(Link link) {
        link.curar(MEDIOS_CURADOS);
        super.serRecogidoPor(link);
    }
}
