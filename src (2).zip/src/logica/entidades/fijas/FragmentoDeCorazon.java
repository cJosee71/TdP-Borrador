package logica.entidades.fijas;

import logica.entidades.Link;
import logica.fabricas.Sprite;

/**
 * Power-up que suma un fragmento de corazón; al juntar FRAGMENTOS_POR_CORAZON, Link aumenta su vida máxima.
 */
public class FragmentoDeCorazon extends PowerUP {

    // Constructores

    /**
     * Crea el fragmento en (x, y).
     */
    public FragmentoDeCorazon(Sprite sprite, int x, int y) {
        super(sprite, x, y);
    }

    // Comandos

    /**
     * Le suma a Link un fragmento.
     */
    @Override
    public void serRecogidoPor(Link link) {
        link.sumarFragmento();
        super.serRecogidoPor(link);
    }
}
