package logica.entidades.fijas;

import logica.entidades.Colisionador;
import logica.entidades.Entidad;
import logica.entidades.Link;
import logica.fabricas.Sprite;
import logica.sonido.GestorDeSonido;
import logica.sonido.Sonido;

/**
 * Elemento que Link recoge al tocarlo y le da un efecto y puntos.
 */
public abstract class PowerUP extends Entidad {

    // Atributos de clase

    private static final int PUNTOS = 300;

    // Constructores

    /**
     * Crea el power-up en (x, y).
     */
    protected PowerUP(Sprite sprite, int x, int y) {
        super(sprite, x, y);
    }

    // Comandos

    /**
     * Recibe un choque (patrón Visitor).
     */
    @Override
    public void aceptarColision(Colisionador colisionador) {
        colisionador.colisionarCon(this);
    }

    /**
     * Suena al ser recogido, avisa que fue recogido y sale del sector.
     */
    public void serRecogidoPor(Link link) {
        GestorDeSonido.getInstancia().reproducir(Sonido.POWER_UP);
        link.powerUpRecogido(this);
        eliminar();
    }

    // Consultas

    /**
     * Se dibuja en la capa de los objetos.
     */
    @Override
    public int getCapa() {
        return CAPA_OBJETOS;
    }

    /**
     * Devuelve los puntos que da al recogerlo.
     */
    public int getPuntos() {
        return PUNTOS;
    }
}
