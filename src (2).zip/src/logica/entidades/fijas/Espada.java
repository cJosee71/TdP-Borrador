package logica.entidades.fijas;

import logica.entidades.Link;
import logica.fabricas.Sprite;

/**
 * Objeto con el que Link ataca.
 */
public class Espada extends Objeto {

    // Constructores

    /**
     * Crea la espada en (x, y).
     */
    public Espada(Sprite sprite, int x, int y) {
        super(sprite, x, y);
    }

    // Comandos

    /**
     * Empieza a cargar el ataque de Link.
     */
    @Override
    public void atacarCon(Link link) {
        link.cargarAtaque();
    }

    /**
     * Suelta el ataque de Link.
     */
    @Override
    public void soltarAtaqueCon(Link link) {
        link.liberarAtaque();
    }

    // Consultas

    /**
     * Devuelve "Espada".
     */
    @Override
    public String getNombre() {
        return "Espada";
    }
}
