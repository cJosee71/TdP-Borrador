package logica.entidades.fijas;

import logica.entidades.Link;
import logica.fabricas.Sprite;

/**
 * Objeto que protege a Link mientras lo usa.
 */
public class Escudo extends Objeto {

    // Constructores

    /**
     * Crea el escudo en (x, y).
     */
    public Escudo(Sprite sprite, int x, int y) {
        super(sprite, x, y);
    }

    // Comandos

    /**
     * Levanta el escudo de Link.
     */
    @Override
    public void protegerCon(Link link) {
        link.activarEscudo();
    }

    /**
     * Baja el escudo de Link.
     */
    @Override
    public void soltarProteccionCon(Link link) {
        link.desactivarEscudo();
    }

    // Consultas

    /**
     * Devuelve "Escudo".
     */
    @Override
    public String getNombre() {
        return "Escudo";
    }
}
