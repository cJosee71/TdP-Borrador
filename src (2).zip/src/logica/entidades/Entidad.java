package logica.entidades;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import logica.EntidadLogica;
import logica.Observer;
import logica.fabricas.Cuerpo;
import logica.fabricas.Sprite;
import logica.mapa.Sector;
import logica.util.Hitbox;
import logica.util.Posicion;

/**
 * Elemento del juego con imagen, cuerpo y observadores. El cuerpo y los márgenes de imagen vienen en el sprite, que
 * arma la fábrica del dominio con las medidas de su archivo medidas.txt.
 */
public abstract class Entidad implements Colisionable, EntidadLogica {

    // Atributos de instancia

    protected Hitbox hitbox;
    protected Sprite sprite;
    protected List<Observer> observadores;
    protected EntornoJuego miJuego;
    protected Sector miSector;
    protected boolean eliminada;

    // Constructores

    /**
     * Crea la entidad en (x, y) con el cuerpo que trae su sprite: lo define el dominio en su medidas.txt y la fábrica
     * de sprites se lo pone a todos.
     */
    protected Entidad(Sprite sprite, int x, int y) {
        this.sprite = sprite;
        Cuerpo cuerpo = sprite.getCuerpo();
        this.hitbox = new Hitbox(x, y, cuerpo.getMargenX(), cuerpo.getMargenY(), cuerpo.getAncho(), cuerpo.getAlto());
        this.observadores = new CopyOnWriteArrayList<>();
    }

    // Comandos

    /**
     * Asigna el entorno de la partida.
     */
    public void setJuego(EntornoJuego juego) {
        miJuego = juego;
    }

    /**
     * Asigna el sector.
     */
    public void setSector(Sector sector) {
        miSector = sector;
    }

    /**
     * Mueve la entidad y avisa a la vista.
     */
    public void setPosicion(Posicion posicion) {
        hitbox.setPosicion(posicion);
        notificarObservers();
    }

    /**
     * Mueve la entidad para que la esquina de su cuerpo quede en (x, y).
     */
    public void ubicarCuerpoEn(int x, int y) {
        setPosicion(hitbox.posicionParaCuerpoEn(x, y));
    }

    /**
     * Agrega un observador.
     */
    public void registrarObserver(Observer observador) {
        observadores.add(observador);
    }

    /**
     * Saca la entidad del sector y avisa a la vista.
     */
    public void eliminar() {
        eliminada = true;
        if (miSector != null) {
            miSector.quitar(this);
        }
        notificarObservers();
    }

    /**
     * Recibe un golpe de espada; no hace nada por defecto.
     */
    public void recibirGolpeDeEspada(EntidadAnimada atacante, int danio) {
    }

    /**
     * Recibe un choque (patrón Visitor).
     */
    @Override
    public abstract void aceptarColision(Colisionador colisionador);

    /**
     * Se actualiza en la vuelta del mundo; no hace nada por defecto.
     */
    public void actualizarPorMundo(AdministradorColisiones colisiones) {
    }

    /**
     * Avisa a los observadores.
     */
    protected void notificarObservers() {
        for (Observer observador : observadores) {
            observador.actualizar();
        }
    }

    // Consultas

    /**
     * Devuelve la x de la esquina de la entidad.
     */
    @Override
    public int getX() {
        return hitbox.getPosicion().getX();
    }

    /**
     * Devuelve la y de la esquina de la entidad.
     */
    @Override
    public int getY() {
        return hitbox.getPosicion().getY();
    }

    /**
     * Devuelve la x donde se dibuja la imagen: getX() menos el margen que el sprite tiene para el estado mostrado.
     */
    @Override
    public int getXImagen() {
        return getX() - sprite.getMargenX(estadoMostrado());
    }

    /**
     * Devuelve la y donde se dibuja la imagen: getY() menos el margen que el sprite tiene para el estado mostrado.
     */
    @Override
    public int getYImagen() {
        return getY() - sprite.getMargenY(estadoMostrado());
    }

    /**
     * Devuelve el centro del cuerpo.
     */
    public Posicion getCentro() {
        return hitbox.getCentro();
    }

    /**
     * Devuelve la esquina de la entidad.
     */
    public Posicion getPosicion() {
        return hitbox.getPosicion();
    }

    /**
     * Devuelve el cuerpo.
     */
    public Hitbox getHitbox() {
        return hitbox;
    }

    /**
     * Devuelve el entorno de la partida.
     */
    public EntornoJuego getJuego() {
        return miJuego;
    }

    /**
     * Devuelve el sector.
     */
    public Sector getSector() {
        return miSector;
    }

    /**
     * Devuelve el ancho del cuerpo.
     */
    public int getAncho() {
        return hitbox.getAncho();
    }

    /**
     * Devuelve el alto del cuerpo.
     */
    public int getAlto() {
        return hitbox.getAlto();
    }

    /**
     * Indica si se ve; las entidades fijas siempre se ven.
     */
    @Override
    public boolean esVisible() {
        return true;
    }

    /**
     * Devuelve la ruta de la imagen del estado mostrado (patrón Template Method: el estado lo elige getEstadoImagen()).
     */
    @Override
    public String getRutaImagen() {
        return sprite.getRuta(estadoMostrado());
    }

    /**
     * Gancho que redefinen las subclases: devuelve el estado de la imagen que se quiere mostrar; por defecto, el estado
     * actual del sprite.
     */
    protected String getEstadoImagen() {
        return sprite.getEstadoActual();
    }

    /**
     * Devuelve el estado que se muestra: el que pide getEstadoImagen() si el sprite lo tiene; si no, el actual.
     */
    private String estadoMostrado() {
        String estado = getEstadoImagen();
        return sprite.tieneEstado(estado) ? estado : sprite.getEstadoActual();
    }

    /**
     * Indica si fue eliminada.
     */
    @Override
    public boolean estaEliminada() {
        return eliminada;
    }

    /**
     * Indica si le bloquea el paso a quien se mueve; false por defecto.
     */
    public boolean bloqueaPasoA(EntidadAnimada quien) {
        return false;
    }

    /**
     * Indica si impide que un enemigo se abalance o dispare a través de ella; false por defecto.
     */
    public boolean impideAbalanzarse() {
        return false;
    }
}
