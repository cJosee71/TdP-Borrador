package logica.entidades;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import logica.ControlJugador;
import logica.EntidadJugador;
import logica.comportamientos.AtaqueRecargado;
import logica.comportamientos.ComportamientoDefensa;
import logica.comportamientos.DefensaLimitada;
import logica.comportamientos.DefensaPorEscudo;
import logica.comportamientos.MovimientoInducido;
import logica.entidades.enemigos.Enemigo;
import logica.entidades.fijas.Objeto;
import logica.entidades.fijas.Obstaculo;
import logica.entidades.fijas.PowerUP;
import logica.entidades.fijas.SuelosQuebradizo;
import logica.fabricas.Sprite;
import logica.mapa.Sector;
import logica.sonido.GestorDeSonido;
import logica.sonido.Sonido;
import logica.util.Direccion;
import logica.util.Hitbox;

/**
 * Personaje del jugador: recibe las teclas, guarda el estado de la partida y reacciona a lo que toca.
 *
 * Interpretaciones del enunciado:
 * - Vidas (punto 9): el daño descuenta medios corazones; al quedarse sin corazones se pierde una vida y los corazones
 *   se recuperan. Perder la última vida es GAME OVER (ver morir y perderVida).
 * - Caída al vacío: la Tabla 3 dice que quita media vida y que Link vuelve a la entrada de la escena, y el punto 9
 *   que se pierde una vida y se reinicia el nivel. Se siguió el punto 9 (ver caerAlVacio).
 * - Teclas (punto 13): A y S actúan con el objeto equipado: A ataca solo con la espada equipada y S protege solo con
 *   el escudo equipado. D cambia de objeto (ver atacar, usarEscudo y cambiarObjeto).
 */
public class Link extends EntidadAnimada implements EntidadJugador, ControlJugador {

    // Atributos de clase

    private static final int VIDAS_INICIALES = 3;
    private static final int MEDIOS_CORAZONES_INICIALES = 6;
    private static final int VELOCIDAD_CAMINANDO = 4;
    private static final int FACTOR_RALENTIZACION = 2;
    private static final int DANIO_ESPADA = 1;
    private static final long DURACION_INVULNERABILIDAD = 1000;
    private static final long DEMORA_ROTURA_SUELO = 800;
    private static final int FRAGMENTOS_POR_CORAZON = 4;
    private static final int AUMENTO_VIDA_MAXIMA = 2;
    private static final int VUELTAS_IMAGEN_GOLPE = 8;
    private static final int VUELTAS_IMAGEN_GIRO = 16;
    private static final Direccion[] ORDEN_GIRO =
            { Direccion.ABAJO, Direccion.IZQUIERDA, Direccion.ARRIBA, Direccion.DERECHA };
    private static final long DURACION_CAIDA = 400;
    private static final long DURACION_MUERTE = 2100;
    private static final long DURACION_PERDER_VIDA = 1300;
    private static final long TIEMPO_CARGA = 3000;
    private static final int ALTO_PIES = 12;
    private static final String SIN_OBJETO = "Ninguno";

    // Atributos de instancia

    private int vidas;
    private int corazonesMaximos;
    private int puntaje;
    private int rupias;
    private int fragmentos;
    private int racha;
    private List<Objeto> inventario;
    private Objeto objetoEquipado;
    private List<Objeto> inventarioAlEmpezarNivel;
    private Objeto equipadoAlEmpezarNivel;
    private ComportamientoDefensa defensaBase;
    private volatile boolean escudoActivo;
    private volatile boolean atacando;
    private int vueltasMostrandoGolpe;
    private volatile boolean soltoAtaque;
    private boolean ralentizado;
    private volatile boolean cayendo;
    private volatile boolean muriendo;
    private volatile boolean caminando;
    private volatile long inicioCarga;
    private volatile long inicioPausa;
    private volatile boolean invulnerable;

    // Constructores

    /**
     * Crea a Link con sus vidas y corazones iniciales, sin objetos y quieto; el alcance de su espada lo trae el sprite.
     */
    public Link(Sprite sprite, int x, int y) {
        super(sprite, x, y, MEDIOS_CORAZONES_INICIALES);
        vidas = VIDAS_INICIALES;
        corazonesMaximos = vida;
        inventario = new ArrayList<>();
        inicioCarga = -1;
        inicioPausa = -1;
        defensaBase = DefensaLimitada.normal();
        movimiento = new MovimientoInducido((Direccion) null, VELOCIDAD_CAMINANDO);
        ataque = new AtaqueRecargado(DANIO_ESPADA, sprite.getAlcanceAtaque());
        defensa = defensaBase;
    }

    // Comandos

    /**
     * Hace una vuelta: si la espada ya está cargada avisa para mostrarla, durante el giro recargado avisa en cada
     * vuelta y, al terminar de mostrar el golpe, vuelve a la imagen de caminar.
     */
    @Override
    public void actualizarEstado(AdministradorColisiones colisiones) {
        super.actualizarEstado(colisiones);
        avisarSiEstaCargando();
        descontarVueltaDeGolpe();
    }

    /**
     * No hace nada: a Link lo actualiza solo su propio hilo.
     */
    @Override
    public void actualizarPorMundo(AdministradorColisiones colisiones) { }

    /**
     * Empieza a caminar en una dirección con un movimiento nuevo; mientras cae o muere solo recuerda que camina.
     */
    @Override
    public void mover(Direccion direccion) {
        caminando = true;
        setDireccion(direccion);
        if (!cayendo && !muriendo)
            setMovimiento(new MovimientoInducido(direccion, VELOCIDAD_CAMINANDO));
    }

    /**
     * Deja de caminar (movimiento quieto, salvo mientras cae o muere) y avisa a la vista para que muestre la imagen
     * quieta.
     */
    @Override
    public void detenerMovimiento() {
        caminando = false;
        if (!cayendo && !muriendo)
            quedarseQuieto();
        notificarObservers();
    }

    /**
     * Cambia el movimiento a uno quieto con la velocidad de caminar de Link.
     */
    private void quedarseQuieto() {
        setMovimiento(new MovimientoInducido((Direccion) null, VELOCIDAD_CAMINANDO));
    }

    /**
     * Avanza; si está ralentizado, menos pasos.
     */
    @Override
    public void avanzar(Direccion direccion, int pasos) {
        int pasosReales = ralentizado ? pasos / FACTOR_RALENTIZACION : pasos;
        ralentizado = false;
        super.avanzar(direccion, pasosReales);
    }

    /**
     * Hace que el próximo paso avance la mitad.
     */
    public void ralentizar() {
        ralentizado = true;
    }

    /**
     * Pide pasar al sector vecino.
     */
    @Override
    protected void alSalirDelSector(Direccion direccion) {
        miJuego.cambiarDeSector(direccion);
    }

    /**
     * Ubica el cuerpo en el borde opuesto al que salió.
     */
    public void entrarPorBordeOpuesto(Direccion direccion) {
        Hitbox cuerpo = getHitbox();
        switch (direccion) {
            case DERECHA:
                ubicarCuerpoEn(0, cuerpo.getY());
                break;
            case IZQUIERDA:
                ubicarCuerpoEn(Sector.ANCHO - getAncho(), cuerpo.getY());
                break;
            case ABAJO:
                ubicarCuerpoEn(cuerpo.getX(), 0);
                break;
            default:
                ubicarCuerpoEn(cuerpo.getX(), Sector.ALTO - getAlto());
                break;
        }
    }

    /**
     * Ataca con el objeto equipado (tecla A), salvo mientras cae o muere. Solo la espada ataca: con el escudo
     * equipado no hace nada (interpretación del punto 13).
     */
    @Override
    public void atacar() {
        if (objetoEquipado != null && !cayendo && !muriendo)
            objetoEquipado.atacarCon(this);
    }

    /**
     * Suelta el ataque del objeto equipado.
     */
    @Override
    public void soltarAtaque() {
        if (objetoEquipado != null)
            objetoEquipado.soltarAtaqueCon(this);
    }

    /**
     * Empieza a cargar el ataque de la espada: guarda la hora en inicioCarga.
     */
    public void cargarAtaque() {
        if (!atacando) {
            atacando = true;
            soltoAtaque = false;
            inicioCarga = System.currentTimeMillis();
            notificarObservers();
        }
    }

    /**
     * Marca que soltó la tecla de ataque, si estaba cargando el ataque y no está en pausa.
     */
    public void liberarAtaque() {
        if (atacando && inicioPausa < 0)
            soltoAtaque = true;
    }

    /**
     * Congela la acción en curso durante la pausa: soltar el ataque no cuenta y la carga deja de correr.
     */
    public void pausarAccion() {
        inicioPausa = System.currentTimeMillis();
    }

    /**
     * Retoma la acción congelada por la pausa: la carga de la espada sigue desde donde estaba.
     */
    public void reanudarAccion() {
        if (inicioPausa >= 0) {
            if (atacando)
                inicioCarga += System.currentTimeMillis() - inicioPausa;
            inicioPausa = -1;
        }
    }

    /**
     * Termina el ataque, suena la espada (o el ataque recargado) y deja la imagen del golpe; si fue recargado, la del
     * giro.
     */
    @Override
    public void ataqueRealizado() {
        boolean fueRecargado = ataqueCargado();
        atacando = false;
        soltoAtaque = false;
        if (fueRecargado) {
            vueltasMostrandoGolpe = VUELTAS_IMAGEN_GIRO;
            GestorDeSonido.getInstancia().reproducir(Sonido.ATAQUE_RECARGADO);
        } else {
            vueltasMostrandoGolpe = VUELTAS_IMAGEN_GOLPE;
            GestorDeSonido.getInstancia().reproducir(Sonido.ATAQUE);
        }
        notificarObservers();
    }

    /**
     * Si la espada ya está cargada avisa a la vista para que la muestre.
     */
    private void avisarSiEstaCargando() {
        if (atacando && ataqueCargado())
            notificarObservers();
    }

    /**
     * Descuenta una vuelta de la imagen del golpe; avisa en cada vuelta del giro y al terminar de mostrar el golpe.
     */
    private void descontarVueltaDeGolpe() {
        if (vueltasMostrandoGolpe > 0) {
            vueltasMostrandoGolpe--;
            boolean terminoElGolpe = vueltasMostrandoGolpe == 0;
            if (terminoElGolpe || girando())
                notificarObservers();
        }
    }

    /**
     * Se protege con el objeto equipado (tecla S), salvo mientras cae o muere. Solo el escudo protege: con la espada
     * equipada no hace nada (interpretación del punto 13).
     */
    @Override
    public void usarEscudo() {
        if (objetoEquipado != null && !cayendo && !muriendo)
            objetoEquipado.protegerCon(this);
    }

    /**
     * Suelta la protección del objeto equipado.
     */
    @Override
    public void soltarEscudo() {
        if (objetoEquipado != null)
            objetoEquipado.soltarProteccionCon(this);
    }

    /**
     * Levanta el escudo; si no estaba levantado, suena el escudo.
     */
    public void activarEscudo() {
        if (!escudoActivo)
            GestorDeSonido.getInstancia().reproducir(Sonido.ESCUDO);
        escudoActivo = true;
        setDefensa(new DefensaPorEscudo(false));
        notificarObservers();
    }

    /**
     * Baja el escudo y vuelve a la defensa base; si está invulnerable por un golpe, cayendo
     * o muriendo, sigue invulnerable. Si no estaba levantado no hace nada.
     */
    public void desactivarEscudo() {
        if (escudoActivo) {
            escudoActivo = false;
            if (invulnerable || cayendo || muriendo)
                setDefensa(DefensaLimitada.invulnerable());
            else
                setDefensa(defensaBase);
            notificarObservers();
        }
    }

    /**
     * Cambia la defensa base y la aplica solo si estaba usando la base; si está
     * invulnerable, con el escudo, cayendo o muriendo, la guarda y entra al terminar.
     */
    private void setDefensaBase(ComportamientoDefensa nuevaDefensa) {
        boolean usabaLaBase = defensa == defensaBase;
        defensaBase = nuevaDefensa;
        if (usabaLaBase)
            setDefensa(nuevaDefensa);
    }

    /**
     * Recibe la defensa de la bellota: la usa como defensa base (sin guardarla aparte) y cambia a la túnica roja.
     */
    public void recibirBellota(ComportamientoDefensa defensaBellota) {
        setDefensaBase(defensaBellota);
        notificarObservers();
    }

    /**
     * Termina la invulnerabilidad del golpe y vuelve a la defensa base si no usa el escudo
     * ni está cayendo al vacío o muriendo.
     */
    @Override
    public void restaurarDefensa() {
        invulnerable = false;
        if (!escudoActivo && !cayendo && !muriendo)
            setDefensa(defensaBase);
    }

    /**
     * Recibe el daño de un golpe de espada.
     */
    @Override
    public void recibirGolpeDeEspada(EntidadAnimada atacante, int danio) {
        recibirDanio(danio, atacante.getDireccion());
    }

    /**
     * Recibe un golpe; si le hace daño, suena el impacto, corta la racha y avisa al juego.
     */
    @Override
    public synchronized void recibirDanio(int danio, Direccion origen) {
        boolean recibioDanio = defensa.recibirDanio(this, danio, origen);
        if (recibioDanio) {
            GestorDeSonido.getInstancia().reproducir(Sonido.IMPACTO);
            reiniciarRacha();
            miJuego.jugadorDaniado();
            alSerGolpeado();
        }
    }

    /**
     * Queda invulnerable un tiempo (marcado en invulnerable) y parpadea mientras tanto, salvo si está muriendo.
     */
    @Override
    protected void alSerGolpeado() {
        if (!muriendo) {
            invulnerable = true;
            setDefensa(DefensaLimitada.invulnerable());
            parpadearDurante(DURACION_INVULNERABILIDAD);
            programar(DURACION_INVULNERABILIDAD, this::restaurarDefensa);
        }
    }

    /**
     * Recibe un choque (patrón Visitor).
     */
    @Override
    public void aceptarColision(Colisionador colisionador) {
        colisionador.colisionarCon(this);
    }

    /**
     * Le pide al enemigo que resuelva el choque (sirve cuando Link es el que se frena contra él).
     */
    @Override
    public void colisionarCon(Enemigo enemigo) {
        enemigo.colisionarCon(this);
    }

    /**
     * Recibe el daño del proyectil y lo elimina.
     */
    @Override
    public void colisionarCon(Proyectil proyectil) {
        recibirDanio(proyectil.getDanio(), proyectil.getDireccion());
        proyectil.eliminar();
    }

    /**
     * Recibe el efecto del obstáculo.
     */
    @Override
    public void colisionarCon(Obstaculo obstaculo) {
        obstaculo.afectar(this);
    }

    /**
     * Recoge el power-up.
     */
    @Override
    public void colisionarCon(PowerUP powerUp) {
        powerUp.serRecogidoPor(this);
    }

    /**
     * Recoge el objeto.
     */
    @Override
    public void colisionarCon(Objeto objeto) {
        objeto.serRecogidoPor(this);
    }

    /**
     * Rompe el suelo quebradizo tras una demora y deja una caída al vacío.
     */
    public void romperSuelo(SuelosQuebradizo suelo) {
        programar(DEMORA_ROTURA_SUELO, () -> {
            Sector sectorDelSuelo = suelo.getSector();
            Entidad caida = miJuego.getFabricaEntidades().crearCaidasAlVacio(suelo.getX(), suelo.getY());
            suelo.eliminar();
            if (sectorDelSuelo == getSector())
                miJuego.agregarEntidad(caida);
            else
                sectorDelSuelo.agregar(caida);
        });
    }

    /**
     * Se llama al quedarse sin corazones: corta la acción en curso, queda quieto e invulnerable y muestra la
     * animación (perder una vida, o la muerte si es la última); al terminar, pierde la vida.
     *
     * Interpretación del punto 9: un golpe no quita una vida entera sino medios corazones; la vida se pierde recién
     * al quedarse sin corazones.
     */
    @Override
    protected void morir() {
        if (!muriendo) {
            muriendo = true;
            reiniciarAccion();
            if (esLaUltimaVida()) {
                GestorDeSonido.getInstancia().reproducir(Sonido.MUERTE);
                programar(DURACION_MUERTE, this::terminarMuerte);
            } else {
                GestorDeSonido.getInstancia().reproducir(Sonido.PERDER_VIDA);
                programar(DURACION_PERDER_VIDA, this::terminarMuerte);
            }
            setMovimiento(MovimientoInducido.quieto());
            setDefensa(DefensaLimitada.invulnerable());
            notificarObservers();
        }
    }

    /**
     * Termina la animación: pierde una vida y, si le quedan, recupera los corazones y queda invulnerable un momento;
     * si no, queda la imagen de muerte detrás de la ventana de GAME OVER.
     */
    private void terminarMuerte() {
        if (perderVida()) {
            muriendo = false;
            volverACaminarConVidaLlena();
            alSerGolpeado();
            notificarObservers();
        }
    }

    /**
     * Cae al vacío: corta la acción en curso, suena la caída, corta la racha y queda quieto e invulnerable mientras
     * cae. Le avisa al juego que recibió daño, igual que un golpe (en NoHit es GAME OVER), y al terminar la caída
     * pierde una vida.
     *
     * Interpretación: se sigue el punto 9 del enunciado (pierde una vida entera y se reinicia el nivel) y no la Tabla
     * 3 (media vida y volver a la entrada de la escena).
     */
    public void caerAlVacio() {
        if (!cayendo) {
            cayendo = true;
            reiniciarAccion();
            GestorDeSonido.getInstancia().reproducir(Sonido.CAIDA);
            reiniciarRacha();
            setMovimiento(MovimientoInducido.quieto());
            setDefensa(DefensaLimitada.invulnerable());
            notificarObservers();
            miJuego.jugadorDaniado();
            programar(DURACION_CAIDA, this::terminarCaida);
        }
    }

    /**
     * Termina la caída: pierde una vida y le pide al juego reiniciar el nivel. Si era la última, queda sin corazones
     * y se ve la caída detrás de la ventana de GAME OVER.
     */
    private void terminarCaida() {
        if (esLaUltimaVida())
            vida = 0;
        if (perderVida()) {
            cayendo = false;
            volverACaminarConVidaLlena();
            setDefensa(defensaBase);
            miJuego.jugadorCayoAlVacio();
        }
    }

    /**
     * Descuenta una vida y devuelve true si le quedan; si no, avisa a la vista y al juego (GAME OVER) y devuelve
     * false.
     */
    private boolean perderVida() {
        vidas--;
        boolean quedanVidas = vidas > 0;
        if (!quedanVidas) {
            notificarObservers();
            miJuego.jugadorSinVidas();
        }
        return quedanVidas;
    }

    /**
     * Lo deja quieto, sin caminar y con los corazones llenos, después de perder una vida.
     */
    private void volverACaminarConVidaLlena() {
        quedarseQuieto();
        caminando = false;
        vida = corazonesMaximos;
    }

    /**
     * Pierde lo acumulado en la partida: las rupias vuelven a 0 y los corazones máximos a los iniciales.
     */
    public void perderLoAcumulado() {
        rupias = 0;
        corazonesMaximos = MEDIOS_CORAZONES_INICIALES;
    }

    /**
     * Recupera vida sin pasarse del máximo.
     */
    public void curar(int medios) {
        vida = Math.min(vida + medios, corazonesMaximos);
        notificarObservers();
    }

    /**
     * Deja a Link sin acción en curso (al empezar o reiniciar un nivel, morir o caer): corta el ataque y su carga,
     * sale de la pausa, deja de mostrar el golpe y baja el escudo.
     */
    public void reiniciarAccion() {
        atacando = false;
        soltoAtaque = false;
        inicioPausa = -1;
        vueltasMostrandoGolpe = 0;
        desactivarEscudo();
    }

    /**
     * Vuelve a las vidas iniciales con los corazones llenos: descarta lo programado (fin de la caída, de la muerte o
     * de la invulnerabilidad), deja de morir, de caer y de ser invulnerable y vuelve a caminar con su defensa base.
     */
    public void reiniciarVidas() {
        cancelarProgramadas();
        invulnerable = false;
        vidas = VIDAS_INICIALES;
        vida = corazonesMaximos;
        muriendo = false;
        cayendo = false;
        caminando = false;
        quedarseQuieto();
        setDefensa(defensaBase);
        notificarObservers();
    }

    /**
     * Equipa el siguiente objeto del inventario (tecla D), si no está atacando; si tenía el escudo levantado, lo
     * baja.
     */
    @Override
    public void cambiarObjeto() {
        if (!inventario.isEmpty() && !atacando) {
            desactivarEscudo();
            int indiceSiguiente = (inventario.indexOf(objetoEquipado) + 1) % inventario.size();
            objetoEquipado = inventario.get(indiceSiguiente);
            notificarObservers();
        }
    }

    /**
     * Agrega un objeto al inventario y lo equipa.
     */
    public void agregarAlInventario(Objeto objeto) {
        inventario.add(objeto);
        objetoEquipado = objeto;
        notificarObservers();
    }

    /**
     * Guarda una copia del inventario y del objeto equipado, para volver a ellos si se reinicia el nivel
     * o si cae al vacío.
     */
    public void guardarInventarioDelNivel() {
        inventarioAlEmpezarNivel = new ArrayList<>(inventario);
        equipadoAlEmpezarNivel = objetoEquipado;
    }

    /**
     * Vuelve al inventario y al objeto equipado que tenía al empezar el nivel.
     */
    public void restaurarInventarioDelNivel() {
        inventario = new ArrayList<>(inventarioAlEmpezarNivel);
        objetoEquipado = equipadoAlEmpezarNivel;
        notificarObservers();
    }

    /**
     * Suma puntos.
     */
    public void sumarPuntos(int puntos) {
        puntaje += puntos;
        notificarObservers();
    }

    /**
     * Vuelve el puntaje a 0.
     */
    public void reiniciarPuntaje() {
        puntaje = 0;
    }

    /**
     * Suma rupias.
     */
    public void sumarRupias(int cantidad) {
        rupias += cantidad;
        notificarObservers();
    }

    /**
     * Suma un fragmento; al juntar los necesarios suma un corazón máximo.
     */
    public void sumarFragmento() {
        fragmentos++;
        if (fragmentos % FRAGMENTOS_POR_CORAZON == 0) {
            corazonesMaximos += AUMENTO_VIDA_MAXIMA;
            vida = corazonesMaximos;
        }
        notificarObservers();
    }

    /**
     * Suma uno a la racha sin recibir daño.
     */
    public void incrementarRacha() {
        racha++;
    }

    /**
     * Vuelve la racha a 0.
     */
    public void reiniciarRacha() {
        racha = 0;
    }

    /**
     * Empieza un nivel nuevo sin fragmentos de corazón sueltos ni racha: los corazones máximos ya ganados se conservan.
     */
    public void reiniciarFragmentosYRacha() {
        fragmentos = 0;
        racha = 0;
    }

    /**
     * Avisa al juego que recogió un power-up.
     */
    public void powerUpRecogido(PowerUP powerUp) {
        miJuego.powerUpRecogido(powerUp);
    }

    // Consultas

    /**
     * Devuelve la franja de abajo del cuerpo, con la que Link pisa el terreno.
     */
    public Hitbox getPies() {
        Hitbox cuerpo = getHitbox();
        return new Hitbox(cuerpo.getX(), cuerpo.getY() + cuerpo.getAlto() - ALTO_PIES, cuerpo.getAncho(), ALTO_PIES);
    }

    /**
     * Les bloquea el paso a quienes frenan contra personajes.
     */
    @Override
    public boolean bloqueaPasoA(EntidadAnimada quien) {
        return quien.esFrenadoPorPersonajes();
    }

    /**
     * Lo frenan los enemigos.
     */
    @Override
    public boolean esFrenadoPorPersonajes() {
        return true;
    }

    /**
     * Indica si está cargando el ataque.
     */
    @Override
    public boolean quiereAtacar() {
        return atacando;
    }

    /**
     * Indica si soltó la tecla de ataque.
     */
    @Override
    public boolean soltoElAtaque() {
        return soltoAtaque;
    }

    /**
     * Indica si la espada lleva cargándose TIEMPO_CARGA milisegundos. Después de golpear sigue
     * respondiendo por el último golpe hasta la próxima carga, así se ve la imagen del giro.
     */
    @Override
    public boolean ataqueCargado() {
        return inicioCarga >= 0 && System.currentTimeMillis() - inicioCarga >= TIEMPO_CARGA;
    }

    /**
     * Indica si la bellota sigue activa: la defensa base todavía cuenta golpes y le queda alguno.
     */
    public boolean tieneBellota() {
        return defensaBase.tieneGolpesRestantes();
    }

    /**
     * Indica si le queda una sola vida: perderla es el GAME OVER.
     */
    private boolean esLaUltimaVida() {
        return vidas <= 1;
    }

    /**
     * Indica si está perdiendo su última vida: muriendo o cayendo al vacío con una sola vida. Mientras tanto la
     * partida no se puede ganar ni pasar de nivel, porque termina en GAME OVER.
     */
    public boolean pierdeLaUltimaVida() {
        return (muriendo || cayendo) && vidas == 1;
    }

    /**
     * Devuelve las vidas que le quedan.
     */
    @Override
    public int getVidas() {
        return vidas;
    }

    /**
     * Devuelve la vida actual en medios corazones.
     */
    @Override
    public int getCorazones() {
        return vida;
    }

    /**
     * Devuelve la vida máxima en medios corazones.
     */
    @Override
    public int getCorazonesMaximos() {
        return corazonesMaximos;
    }

    /**
     * Devuelve el nombre del objeto equipado, o SIN_OBJETO.
     */
    @Override
    public String getNombreObjetoEquipado() {
        String nombreObjeto = SIN_OBJETO;
        if (objetoEquipado != null)
            nombreObjeto = objetoEquipado.getNombre();
        return nombreObjeto;
    }

    /**
     * Devuelve el puntaje.
     */
    @Override
    public int getPuntaje() {
        return puntaje;
    }

    /**
     * Devuelve las rupias.
     */
    @Override
    public int getRupias() {
        return rupias;
    }

    /**
     * Devuelve la racha de enemigos derrotados sin recibir daño.
     */
    public int getRacha() {
        return racha;
    }

    /**
     * Devuelve el estado de la imagen según lo que hace (muriendo, cayendo, con escudo, atacando, caminando o quieto)
     * y hacia dónde mira; con la bellota usa la versión de túnica roja.
     */
    @Override
    protected String getEstadoImagen() {
        String dir = direccionImagen().name().toLowerCase();
        String estado = estadoBase(dir);
        if (muriendo)
            estado = esLaUltimaVida() ? "muerte" : "pierde-vida";
        else if (cayendo)
            estado = "caida";
        else if (escudoActivo)
            estado = prefijoCaminar() + "escudo-" + dir;
        else if (girando())
            estado = "ataque-recargado-" + dir;
        else if (mostrandoAtaque())
            estado = estadoDeAtaque(dir);
        if (tieneBellota() && sprite.tieneEstado("bellota-" + estado))
            estado = "bellota-" + estado;
        return estado;
    }

    /**
     * Devuelve el estado de la imagen cuando no hace nada especial: caminar o quieto, mirando hacia dir.
     */
    private String estadoBase(String dir) {
        return prefijoCaminar() + dir;
    }

    /**
     * Devuelve el estado de la imagen mientras ataca (normal o recargado, caminando o quieto), mirando hacia dir.
     */
    private String estadoDeAtaque(String dir) {
        String tipoDeAtaque = "ataque-";
        if (ataqueCargado())
            tipoDeAtaque = caminando ? "recargado-" : "ataque-recargado-";
        return prefijoCaminar() + tipoDeAtaque + dir;
    }

    /**
     * Devuelve "caminar-" si está caminando y "" si está quieto.
     */
    private String prefijoCaminar() {
        return caminando ? "caminar-" : "";
    }

    /**
     * Devuelve hacia dónde mira la imagen: durante el giro recorre las cuatro direcciones y termina en la suya.
     */
    private Direccion direccionImagen() {
        Direccion direccion = getDireccion();
        if (girando()) {
            int paso = (VUELTAS_IMAGEN_GIRO - vueltasMostrandoGolpe) * ORDEN_GIRO.length / VUELTAS_IMAGEN_GIRO;
            int inicio = Arrays.asList(ORDEN_GIRO).indexOf(getDireccion()) + 1;
            direccion = ORDEN_GIRO[(inicio + paso) % ORDEN_GIRO.length];
        }
        return direccion;
    }

    /**
     * Indica si está mostrando el giro del ataque recargado.
     */
    private boolean girando() {
        return !escudoActivo && !atacando && vueltasMostrandoGolpe > 0 && ataqueCargado();
    }

    /**
     * Indica si se está mostrando una imagen de ataque.
     */
    private boolean mostrandoAtaque() {
        return !escudoActivo && (atacando || vueltasMostrandoGolpe > 0);
    }

    /**
     * Se dibuja en la capa del jugador, arriba de todo.
     */
    @Override
    public int getCapa() {
        return CAPA_JUGADOR;
    }
}
