package logica.entidades.enemigos;

import logica.comportamientos.DefensaPorEscudo;
import logica.comportamientos.MovimientoAleatorio;
import logica.comportamientos.MovimientoInducido;
import logica.fabricas.Sprite;
import logica.util.Direccion;

/**
 * Moblin con escudo de frente que se abalanza cuando ve a Link.
 */
public class MoblinConEspadaYEscudo extends Moblin {

    // Atributos de clase

    private static final int PUNTOS = 300;
    private static final double PROBABILIDAD_DROP = 0.5;
    private static final int VELOCIDAD_ABALANZADA = 3;
    private static final long DURACION_ABALANZADA = 1600;
    private static final long PREPARACION_ABALANZADA = 500;
    private static final long DURACION_CAMBIO_VELOCIDAD = 100;
    private static final long DURACION_FRENADO = 500;

    // Atributos de instancia

    private boolean abalanzandose;

    // Constructores

    /**
     * Crea el Moblin en (x, y) con escudo de frente; el margen de su imagen, que es más grande que él, lo trae el
     * sprite.
     */
    public MoblinConEspadaYEscudo(Sprite sprite, int x, int y) {
        super(sprite, x, y);
        setDefensa(new DefensaPorEscudo(true));
    }

    // Comandos

    /**
     * Si puede abalanzarse, comienza la abalanzada en la dirección actual.
     */
    @Override
    protected void vigilarJugador() {
        if (puedeAbalanzarse()) {
            abalanzandose = true;
            abalanzarseHacia(getDireccion());
        }
    }

    /**
     * Se queda quieto un momento, acelera hasta VELOCIDAD_ABALANZADA en la dirección indicada y, al terminar, frena a
     * su velocidad de caminar y sigue derecho un rato antes de volver a caminar al azar.
     */
    private void abalanzarseHacia(Direccion direccion) {
        setMovimiento(MovimientoInducido.quieto());
        for (int v = 1; v <= VELOCIDAD_ABALANZADA; v++) {
            int velocidad = v;
            programar(PREPARACION_ABALANZADA + (v - 1) * DURACION_CAMBIO_VELOCIDAD,
                    () -> setMovimiento(new MovimientoInducido(direccion, velocidad)));
        }
        programar(PREPARACION_ABALANZADA + DURACION_ABALANZADA,
                () -> setMovimiento(new MovimientoInducido(direccion, VELOCIDAD)));
        programar(PREPARACION_ABALANZADA + DURACION_ABALANZADA + DURACION_FRENADO, this::terminarAbalanzada);
    }

    /**
     * Vuelve a caminar al azar al terminar la abalanzada.
     */
    private void terminarAbalanzada() {
        abalanzandose = false;
        setMovimiento(new MovimientoAleatorio(VELOCIDAD, INTERVALO_CAMBIO_DIRECCION));
    }

    // Consultas

    /**
     * Indica si puede abalanzarse: no está muriendo ni abalanzándose, Link está enfrente y no hay obstáculos en el
     * medio.
     */
    private boolean puedeAbalanzarse() {
        return !muriendo && !abalanzandose && linkEstaEnfrente() && !hayObstaculoHastaJugador();
    }

    /**
     * Devuelve los puntos que da al morir.
     */
    @Override
    public int getPuntos() {
        return PUNTOS;
    }

    /**
     * Devuelve la probabilidad de soltar un power-up.
     */
    @Override
    protected double getProbabilidadDrop() {
        return PROBABILIDAD_DROP;
    }
}
