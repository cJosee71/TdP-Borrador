package logica.entidades.enemigos;

import logica.entidades.fijas.PowerUP;

/**
 * Crea el power-up que suelta un enemigo (patrón Factory Method).
 */
public interface GeneradorDrop {

    // Consultas

    /**
     * Crea el power-up que se suelta.
     */
    public PowerUP generarDrop();
}
