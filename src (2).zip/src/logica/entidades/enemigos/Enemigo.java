package logica.entidades.enemigos;

import logica.comportamientos.AtaquePorContacto;
import logica.comportamientos.DefensaLimitada;
import logica.comportamientos.MovimientoInducido;
import logica.entidades.Colisionador;
import logica.entidades.EntidadAnimada;
import logica.entidades.Link;
import logica.fabricas.Sprite;
import logica.sonido.GestorDeSonido;
import logica.sonido.Sonido;
import logica.util.Direccion;

/**
 * Entidad animada que lastima a Link según su estrategia de ataque y da puntos al morir. Al morir muestra su
 * animación de muerte y recién después desaparece (patrón Template Method: el gancho desaparecer()).
 */
public abstract class Enemigo extends EntidadAnimada {

    // Atributos de clase

    private static final int DISTANCIA_RETROCESO = 8;
    private static final long DURACION_MUERTE = 300;

    // Atributos de instancia

    protected boolean muriendo;

    // Constructores

    /**
     * Crea el enemigo en (x, y) con su vida.
     */
    protected Enemigo(Sprite sprite, int x, int y, int vida) {
        super(sprite, x, y, vida);
    }

    // Comandos

    /**
     * Recibe un choque (patrón Visitor).
     */
    public void aceptarColision(Colisionador colisionador) {
        colisionador.colisionarCon(this);
    }

    /**
     * Al tocar a Link, le delega el daño a su estrategia de ataque, salvo mientras muere.
     */
    public void colisionarCon(Link link) {
        if (!muriendo)
            ataque.ataqueAlContactar(this, link);
    }

    /**
     * Recibe el daño de un golpe de espada.
     */
    public void recibirGolpeDeEspada(EntidadAnimada atacante, int danio) {
        recibirDanio(danio, atacante.getDireccion());
    }

    /**
     * Suena su derrota, se queda quieto, invulnerable y sin atacar mostrando su animación de muerte y, al terminar,
     * desaparece.
     */
    protected void morir() {
        if (!muriendo) {
            muriendo = true;
            GestorDeSonido.getInstancia().reproducir(getSonidoDerrota());
            cancelarProgramadas();
            setMovimiento(MovimientoInducido.quieto());
            setDefensa(DefensaLimitada.invulnerable());
            setAtaque(new AtaquePorContacto(0));
            notificarObservers();
            programar(getDuracionMuerte(), this::desaparecer);
        }
    }

    /**
     * Al terminar la animación de muerte: se elimina y avisa al juego.
     */
    protected void desaparecer() {
        eliminar();
        miJuego.enemigoDerrotado(this);
    }

    /**
     * No vigila a Link por defecto.
     */
    protected void vigilarJugador() {
    }

    /**
     * Retrocede unos píxeles, se da vuelta y trata el borde como una pared.
     */
    protected void alSalirDelSector(Direccion d) {
        avanzar(d.opuesta(), DISTANCIA_RETROCESO);
        setDireccion(d.opuesta());
        alChocarConBloqueo();
    }

    // Consultas

    /**
     * Mientras muere muestra la imagen de muerte; si no, la de siempre.
     */
    @Override
    protected String getEstadoImagen() {
        return muriendo ? "muerte" : super.getEstadoImagen();
    }

    /**
     * Devuelve cuánto dura la animación de muerte.
     */
    protected long getDuracionMuerte() {
        return DURACION_MUERTE;
    }

    /**
     * Devuelve el sonido de su derrota.
     */
    protected Sonido getSonidoDerrota() {
        return Sonido.ENEMIGO_DERROTADO;
    }

    /**
     * Les bloquea el paso a quienes frenan contra personajes.
     */
    public boolean bloqueaPasoA(EntidadAnimada quien) {
        return quien.esFrenadoPorPersonajes();
    }

    /**
     * Esquiva las caídas al vacío.
     */
    public boolean esquivaVacios() {
        return true;
    }

    /**
     * Lo frenan Link y los otros enemigos.
     */
    public boolean esFrenadoPorPersonajes() {
        return true;
    }

    /**
     * Devuelve los puntos que da al morir.
     */
    public abstract int getPuntos();
}
