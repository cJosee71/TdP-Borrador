package logica.entidades.enemigos;

import logica.entidades.AdministradorColisiones;
import logica.comportamientos.AtaqueEspada;
import logica.comportamientos.AtaquePorContacto;
import logica.comportamientos.DefensaLimitada;
import logica.comportamientos.MovimientoAleatorio;
import logica.fabricas.Sprite;
import logica.util.Direccion;
import logica.util.Hitbox;

/**
 * Jefe que alterna entre atacar con la espada y lastimar al tocarlo; al morir muestra su animación de muerte en la
 * dirección en que mira.
 */
public class MasterStalfos extends Jefe {

    // Atributos de clase

    private static final int VIDA = 5;
    private static final int PUNTOS = 5000;
    private static final int VELOCIDAD = 3;
    private static final long INTERVALO_CAMBIO_DIRECCION = 1200;
    private static final int DANIO_ESPADA = 2;
    private static final int DANIO_CONTACTO = 1;
    private static final long DURACION_INVULNERABILIDAD = 800;
    private static final long DURACION_FASE = 2000;
    private static final int ALCANCE_ESPADA = 40;
    private static final int VUELTAS_IMAGEN_GOLPE = 25;
    private static final long DURACION_MUERTE = 1530;

    // Atributos de instancia

    private int vueltasMostrandoGolpe;
    private Direccion direccionGolpe;

    // Constructores

    /**
     * Crea el jefe en (x, y), empezando con la espada; su cuerpo y el margen de su imagen los trae el sprite.
     */
    public MasterStalfos(Sprite sprite, int x, int y) {
        super(sprite, x, y, VIDA);
        setMovimiento(new MovimientoAleatorio(VELOCIDAD, INTERVALO_CAMBIO_DIRECCION));
        setDefensa(DefensaLimitada.normal());
        faseEspada();
    }

    // Comandos

    /**
     * Pasa a atacar con la espada (un AtaqueEspada nuevo) y programa la fase de contacto.
     */
    private void faseEspada() {
        setAtaque(new AtaqueEspada(DANIO_ESPADA, ALCANCE_ESPADA));
        programar(DURACION_FASE, this::faseContacto);
    }

    /**
     * Pasa a lastimar al tocar (un AtaquePorContacto nuevo) y programa la fase de espada.
     */
    private void faseContacto() {
        setAtaque(new AtaquePorContacto(DANIO_CONTACTO));
        programar(DURACION_FASE, this::faseEspada);
    }

    /**
     * Queda invulnerable un tiempo y parpadea mientras tanto, salvo si está muriendo.
     */
    @Override
    protected void alSerGolpeado() {
        if (!muriendo) {
            setDefensa(DefensaLimitada.invulnerable());
            parpadearDurante(DURACION_INVULNERABILIDAD);
            programar(DURACION_INVULNERABILIDAD, () -> setDefensa(DefensaLimitada.normal()));
        }
    }

    /**
     * Empieza a mostrar el GIF del golpe de espada hacia donde mira, si no lo estaba mostrando.
     */
    @Override
    public void ataqueRealizado() {
        if (!estaMostrandoGolpe()) {
            vueltasMostrandoGolpe = VUELTAS_IMAGEN_GOLPE;
            direccionGolpe = getDireccion();
            notificarObservers();
        }
    }

    /**
     * Hace una vuelta y avisa a la vista cuando termina el golpe, para volver al GIF de caminar.
     */
    @Override
    public void actualizarEstado(AdministradorColisiones colisiones) {
        super.actualizarEstado(colisiones);
        if (estaMostrandoGolpe()) {
            vueltasMostrandoGolpe--;
            if (!estaMostrandoGolpe())
                notificarObservers();
        }
    }

    // Consultas

    /**
     * Indica si se está mostrando la animación del golpe de espada.
     */
    private boolean estaMostrandoGolpe() {
        return vueltasMostrandoGolpe > 0;
    }

    /**
     * Devuelve el estado de la imagen: la muerte, el golpe en la dirección en que empezó, o caminar.
     */
    @Override
    protected String getEstadoImagen() {
        String estado = super.getEstadoImagen();
        if (muriendo)
            estado = "muerte-" + getDireccion().name().toLowerCase();
        else if (estaMostrandoGolpe())
            estado = "ataque-" + direccionGolpe.name().toLowerCase();
        return estado;
    }

    /**
     * Indica si Link está en la zona de la espada.
     */
    @Override
    public boolean quiereAtacar() {
        Hitbox zona = getHitbox().adelante(getDireccion(), ALCANCE_ESPADA);
        return zona.intersecta(miJuego.getJugador().getHitbox());
    }

    /**
     * Devuelve cuánto dura su animación de muerte: lo que dura su GIF.
     */
    @Override
    protected long getDuracionMuerte() {
        return DURACION_MUERTE;
    }

    /**
     * Devuelve los puntos que da al morir.
     */
    @Override
    public int getPuntos() {
        return PUNTOS;
    }
}
