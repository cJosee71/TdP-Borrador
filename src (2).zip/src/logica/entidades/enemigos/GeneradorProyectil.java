package logica.entidades.enemigos;

import logica.entidades.Proyectil;

/**
 * Crea el proyectil que dispara una entidad (patrón Factory Method).
 */
public interface GeneradorProyectil {

    // Consultas

    /**
     * Crea el proyectil que se dispara.
     */
    public Proyectil generarProyectil();
}
