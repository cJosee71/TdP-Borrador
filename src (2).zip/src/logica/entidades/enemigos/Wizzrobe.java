package logica.entidades.enemigos;

import logica.comportamientos.AtaquePorProyectil;
import logica.comportamientos.DefensaLimitada;
import logica.comportamientos.MovimientoInducido;
import logica.comportamientos.MovimientoTeletransporte;
import logica.entidades.Proyectil;
import logica.fabricas.Sprite;

/**
 * Enemigo que se teletransporta y dispara hacia Link cuando está enfrente sin obstáculos en el medio.
 * Al teletransportarse muestra un GIF de desaparecer antes del salto y uno de aparecer al llegar.
 */
public class Wizzrobe extends EnemigoConDrop implements GeneradorProyectil {

    // Atributos de clase

    private static final int VIDA = 2;
    private static final int PUNTOS = 500;
    private static final double PROBABILIDAD_DROP = 1.0;
    private static final long INTERVALO_TELETRANSPORTE = 3000;
    private static final int CANTIDAD_DISPAROS = 1;
    private static final int DANIO_DISPARO = 1;
    private static final long INTERVALO_DISPARO = 3000;
    private static final long DURACION_INVULNERABILIDAD = 1000;
    private static final long DURACION_APARECER = 500;
    private static final long DURACION_DESAPARECER = 500;

    // Atributos de instancia

    private boolean apareciendo;
    private boolean desapareciendo;
    private int teletransportes;

    // Constructores

    /**
     * Crea el Wizzrobe en (x, y).
     */
    public Wizzrobe(Sprite sprite, int x, int y) {
        super(sprite, x, y, VIDA);
        setMovimiento(new MovimientoTeletransporte(INTERVALO_TELETRANSPORTE));
        setAtaque(new AtaquePorProyectil(this, CANTIDAD_DISPAROS, INTERVALO_DISPARO));
        setDefensa(DefensaLimitada.normal());
    }

    // Comandos

    /**
     * Al aparecer, vuelve a ser vulnerable, mira hacia Link y muestra el GIF de aparecer;
     * deja programado el GIF de desaparecer para antes del próximo salto.
     */
    @Override
    public void teletransportarse() {
        setDefensa(DefensaLimitada.normal());
        setDireccion(direccionHaciaJugador());
        int numero = ++teletransportes;
        desapareciendo = false;
        apareciendo = true;
        notificarObservers();
        programar(DURACION_APARECER, () -> {
            if (sigueSiendoElMismoSalto(numero)) {
                apareciendo = false;
                notificarObservers();
            }
        });
        programar(INTERVALO_TELETRANSPORTE - DURACION_DESAPARECER, () -> {
            if (sigueSiendoElMismoSalto(numero)) {
                desapareciendo = true;
                notificarObservers();
            }
        });
    }

    /**
     * Si sobrevive al golpe, queda quieto, invulnerable y parpadeando un tiempo y después se teletransporta; cancela
     * las imágenes de aparecer y desaparecer pendientes.
     */
    @Override
    protected void alSerGolpeado() {
        if (!muriendo) {
            teletransportes++;
            apareciendo = false;
            desapareciendo = false;
            setDefensa(DefensaLimitada.invulnerable());
            setMovimiento(MovimientoInducido.quieto());
            parpadearDurante(DURACION_INVULNERABILIDAD);
            programar(DURACION_INVULNERABILIDAD,
                    () -> setMovimiento(new MovimientoTeletransporte(INTERVALO_TELETRANSPORTE)));
        }
    }

    // Consultas

    /**
     * Indica si el salto programado sigue siendo el último iniciado.
     */
    private boolean sigueSiendoElMismoSalto(int numero) {
        return numero == teletransportes;
    }

    /**
     * Devuelve el estado de la imagen: aparecer o desaparecer mientras se teletransporta, o el de muerte o el de su
     * dirección.
     */
    @Override
    protected String getEstadoImagen() {
        String estado = super.getEstadoImagen();
        String direccion = getDireccion().name().toLowerCase();
        if (!muriendo && apareciendo)
            estado = "aparecer-" + direccion;
        else if (!muriendo && desapareciendo)
            estado = "desaparecer-" + direccion;
        return estado;
    }

    /**
     * Crea un disparo hacia Link.
     */
    @Override
    public Proyectil generarProyectil() {
        return miJuego.getFabricaEntidades().crearProyectil(getX(), getY(), direccionHaciaJugador(), DANIO_DISPARO);
    }

    /**
     * Devuelve los puntos que da al morir.
     */
    @Override
    public int getPuntos() {
        return PUNTOS;
    }

    /**
     * Devuelve la probabilidad de soltar un power-up.
     */
    @Override
    protected double getProbabilidadDrop() {
        return PROBABILIDAD_DROP;
    }
}
