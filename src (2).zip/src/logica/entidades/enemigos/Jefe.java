package logica.entidades.enemigos;

import logica.fabricas.Sprite;
import logica.sonido.Sonido;

/**
 * Enemigo final de un nivel.
 */
public abstract class Jefe extends Enemigo {

    // Constructores

    /**
     * Crea el jefe en (x, y) con su vida.
     */
    protected Jefe(Sprite sprite, int x, int y, int vida) {
        super(sprite, x, y, vida);
    }

    // Comandos

    /**
     * Al terminar la animación de muerte: se elimina y avisa al juego que se derrotó un jefe.
     */
    protected void desaparecer() {
        eliminar();
        miJuego.jefeDerrotado(this);
    }

    // Consultas

    /**
     * Devuelve el sonido de la derrota de un jefe.
     */
    @Override
    protected Sonido getSonidoDerrota() {
        return Sonido.JEFE_DERROTADO;
    }
}
