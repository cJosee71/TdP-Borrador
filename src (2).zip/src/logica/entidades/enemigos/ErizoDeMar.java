package logica.entidades.enemigos;

import logica.comportamientos.AtaquePorContacto;
import logica.comportamientos.DefensaLimitada;
import logica.comportamientos.MovimientoInducido;
import logica.fabricas.Sprite;
import logica.util.Direccion;

/**
 * Enemigo quieto que lastima al tocarlo.
 */
public class ErizoDeMar extends EnemigoConDrop {

    // Atributos de clase

    private static final int VIDA = 1;
    private static final int PUNTOS = 50;
    private static final double PROBABILIDAD_DROP = 0.2;
    private static final int DANIO_CONTACTO = 1;
    private static final int VELOCIDAD = 0;

    // Constructores

    /**
     * Crea el erizo en (x, y); su cuerpo lo trae el sprite (medidas.txt del dominio).
     */
    public ErizoDeMar(Sprite sprite, int x, int y) {
        super(sprite, x, y, VIDA);
        setMovimiento(new MovimientoInducido((Direccion) null, VELOCIDAD));
        setAtaque(new AtaquePorContacto(DANIO_CONTACTO));
        setDefensa(DefensaLimitada.normal());
    }

    // Consultas

    /**
     * Devuelve los puntos que da al morir.
     */
    public int getPuntos() {
        return PUNTOS;
    }

    /**
     * Devuelve la probabilidad de soltar un power-up.
     */
    protected double getProbabilidadDrop() {
        return PROBABILIDAD_DROP;
    }
}
