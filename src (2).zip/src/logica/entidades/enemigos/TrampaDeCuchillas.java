package logica.entidades.enemigos;

import logica.comportamientos.AtaquePorContacto;
import logica.comportamientos.DefensaLimitada;
import logica.comportamientos.MovimientoInducido;
import logica.fabricas.Sprite;
import logica.util.Direccion;
import logica.util.Posicion;

/**
 * Trampa invulnerable que sale hacia Link cuando queda en línea y vuelve al chocar.
 */
public class TrampaDeCuchillas extends Enemigo {

    // Atributos de clase

    private static final int VIDA = 1;
    private static final int PUNTOS = 0;
    private static final int DANIO_CONTACTO = 1;
    private static final int VELOCIDAD_SALIDA = 6;
    private static final int VELOCIDAD_VUELTA = 4;

    // Atributos de instancia

    private Posicion posicionOriginal;
    private Posicion destino;

    // Constructores

    /**
     * Crea la trampa en reposo en (x, y).
     */
    public TrampaDeCuchillas(Sprite sprite, int x, int y) {
        super(sprite, x, y, VIDA);
        posicionOriginal = new Posicion(x, y);
        setMovimiento(new MovimientoInducido((Direccion) null, VELOCIDAD_SALIDA));
        setAtaque(new AtaquePorContacto(DANIO_CONTACTO));
        setDefensa(DefensaLimitada.invulnerable());
    }

    // Comandos

    /**
     * Si está en reposo y Link queda en línea sin obstáculos en el medio, sale hacia el lugar que ocupaba Link; al
     * llegar, vuelve.
     */
    @Override
    protected void vigilarJugador() {
        if (estaEnReposo() && veAlJugador()) {
            Direccion direccion = direccionHaciaJugador();
            destino = destinoHacia(direccion);
            setDireccion(direccion);
            setMovimiento(new MovimientoInducido(direccion, VELOCIDAD_SALIDA));
        } else if (destino != null && llegoAlDestino()) {
            volver();
        }
    }

    /**
     * Vuelve a su lugar al chocar.
     */
    @Override
    protected void alChocarConBloqueo() {
        volver();
    }

    /**
     * Vuelve despacio a su lugar; al llegar queda en reposo y puede volver a salir.
     */
    private void volver() {
        destino = null;
        setMovimiento(new MovimientoInducido(posicionOriginal, VELOCIDAD_VUELTA));
    }

    /**
     * Calcula el destino de la trampa según la dirección hacia Link.
     */
    private Posicion destinoHacia(Direccion direccion) {
        Posicion posicionDeLink = miJuego.getJugador().getPosicion();
        int destinoX = direccion.getDx() != 0 ? posicionDeLink.getX() : getX();
        int destinoY = direccion.getDy() != 0 ? posicionDeLink.getY() : getY();
        return new Posicion(destinoX, destinoY);
    }

    // Consultas

    /**
     * Indica si la trampa está en su posición original.
     */
    private boolean estaEnReposo() {
        return getX() == posicionOriginal.getX() && getY() == posicionOriginal.getY();
    }

    /**
     * Indica si Link está en línea con la trampa y no hay obstáculos en el medio.
     */
    private boolean veAlJugador() {
        return getHitbox().estaEnLineaCon(miJuego.getJugador().getHitbox())
                && !hayObstaculoHastaJugador();
    }

    /**
     * Indica si ya llegó (o pasó) al lugar que ocupaba Link cuando salió.
     */
    private boolean llegoAlDestino() {
        Direccion direccion = getDireccion();
        boolean llegoEnX = (getX() - destino.getX()) * direccion.getDx() >= 0;
        boolean llegoEnY = (getY() - destino.getY()) * direccion.getDy() >= 0;
        return llegoEnX && llegoEnY;
    }

    /**
     * Devuelve los puntos que da al morir.
     */
    @Override
    public int getPuntos() {
        return PUNTOS;
    }
}
