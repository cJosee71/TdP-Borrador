package logica.entidades;

import java.util.List;

import logica.mapa.Sector;
import logica.util.Direccion;
import logica.util.Hitbox;
import logica.util.Posicion;

/**
 * Resuelve los bloqueos, los choques y los golpes de espada sobre el sector visible.
 */
public class AdministradorColisiones {

    // Atributos de instancia

    protected volatile Sector sector;

    // Constructores

    /**
     * Crea el administrador sin sector; hay que asignarlo con setSector antes de usarlo.
     */
    public AdministradorColisiones() { }

    // Comandos

    /**
     * Cambia el sector visible.
     */
    public void setSector(Sector sector) {
        this.sector = sector;
    }

    /**
     * Mueve la entidad si nada la bloquea y avisa si chocó o salió del sector; devuelve true si avanzó.
     * Si la frena algo, como no llegan a superponerse, dispara a mano el choque (Visitor de efectos).
     */
    public boolean mover(EntidadAnimada entidad, Direccion direccion, int pasos) {
        Entidad bloqueo = buscarBloqueo(entidad, direccion, pasos);
        boolean avanzo = bloqueo == null;
        if (avanzo) {
            entidad.avanzar(direccion, pasos);
            if (estaFuera(entidad.getHitbox()))
                entidad.alSalirDelSector(direccion);
        } else {
            bloqueo.aceptarColision(entidad);
            entidad.alChocarConBloqueo();
        }
        return avanzo;
    }

    /**
     * Resuelve con Visitor los choques de una entidad con las del sector.
     */
    public void verificarColisiones(EntidadAnimada entidadActualizada) {
        Sector sectorVisible = sector;
        List<Entidad> entidades = sectorVisible.getEntidades();
        int indiceEntidad = 0;
        while (indiceEntidad < entidades.size() && sigueEnElSector(entidadActualizada, sectorVisible)) {
            Entidad entidadDelSector = entidades.get(indiceEntidad);
            if (alcanzaA(entidadDelSector, entidadActualizada, entidadActualizada.getHitbox()))
                entidadDelSector.aceptarColision(entidadActualizada);
            indiceEntidad++;
        }
    }

    /**
     * Golpea a las entidades que están en la zona de adelante del atacante.
     */
    public void golpearEn(EntidadAnimada atacante, int alcance, int danio) {
        Hitbox zona = atacante.getHitbox().adelante(atacante.getDireccion(), alcance);
        golpearEnZona(atacante, zona, danio);
    }

    /**
     * Golpea a las entidades que están alrededor del atacante, hacia los cuatro lados.
     */
    public void golpearAlrededor(EntidadAnimada atacante, int alcance, int danio) {
        Hitbox zona = atacante.getHitbox().alrededor(alcance);
        golpearEnZona(atacante, zona, danio);
    }

    /**
     * Golpea a las entidades del sector, salvo el atacante, que tocan la zona y no tienen roca, agua ni vacío en el
     * medio.
     */
    private void golpearEnZona(EntidadAnimada atacante, Hitbox zona, int danio) {
        for (Entidad otra : sector.getEntidades())
            if (alcanzaA(otra, atacante, zona) && !hayObstaculoEntre(atacante, otra))
                otra.recibirGolpeDeEspada(atacante, danio);
    }

    // Consultas

    /**
     * Devuelve el sector visible.
     */
    public Sector getSector() {
        return sector;
    }

    /**
     * Devuelve la entidad que no deja dar el paso, o null si el paso está libre; no frena si ya estaban superpuestas.
     */
    private Entidad buscarBloqueo(EntidadAnimada entidad, Direccion direccion, int pasos) {
        Hitbox siguiente = entidad.getHitbox().desplazada(direccion, pasos);
        List<Entidad> entidades = sector.getEntidades();
        Entidad bloqueo = null;
        int indiceEntidad = 0;
        while (indiceEntidad < entidades.size() && bloqueo == null) {
            Entidad entidadDelSector = entidades.get(indiceEntidad);
            if (bloqueaElPaso(entidadDelSector, entidad, siguiente))
                bloqueo = entidadDelSector;
            indiceEntidad++;
        }
        return bloqueo;
    }

    /**
     * Indica si otra le impide a la entidad ocupar el lugar siguiente: la alcanza en ese lugar, no estaban ya
     * superpuestas y le bloquea el paso.
     */
    private boolean bloqueaElPaso(Entidad otra, EntidadAnimada entidad, Hitbox siguiente) {
        return alcanzaA(otra, entidad, siguiente)
                && !otra.getHitbox().intersecta(entidad.getHitbox())
                && otra.bloqueaPasoA(entidad);
    }

    /**
     * Indica si hay roca, agua o vacío en la línea que va del centro del atacante al centro de la entidad golpeada.
     */
    private boolean hayObstaculoEntre(Entidad atacante, Entidad golpeada) {
        Posicion desde = atacante.getCentro();
        Posicion hasta = golpeada.getCentro();
        List<Entidad> entidades = sector.getEntidades();
        boolean hayObstaculo = false;
        int indiceEntidad = 0;
        while (!hayObstaculo && indiceEntidad < entidades.size()) {
            hayObstaculo = tapaElGolpe(entidades.get(indiceEntidad), atacante, golpeada, desde, hasta);
            indiceEntidad++;
        }
        return hayObstaculo;
    }

    /**
     * Indica si otra es un obstáculo (impide abalanzarse) que cruza la línea del golpe; no cuenta el que el atacante
     * está pisando (el borde de un vacío).
     */
    private boolean tapaElGolpe(Entidad otra, Entidad atacante, Entidad golpeada, Posicion desde, Posicion hasta) {
        return otra != atacante && otra != golpeada && !otra.estaEliminada() && otra.impideAbalanzarse()
                && !otra.getHitbox().intersecta(atacante.getHitbox())
                && otra.getHitbox().cruzaElSegmento(desde, hasta);
    }

    /**
     * Indica si otra, que no es la entidad ni está eliminada, toca la zona.
     */
    private boolean alcanzaA(Entidad otra, Entidad entidad, Hitbox zona) {
        return otra != entidad && !otra.estaEliminada() && otra.getHitbox().intersecta(zona);
    }

    /**
     * Indica si la entidad sigue viva y en el sector recorrido (si murió o se fue, no hay más choques que resolver).
     */
    private boolean sigueEnElSector(EntidadAnimada entidad, Sector sectorRecorrido) {
        return !entidad.estaEliminada() && entidad.getSector() == sectorRecorrido;
    }

    /**
     * Indica si la hitbox quedó, aunque sea en parte, fuera del sector.
     */
    private boolean estaFuera(Hitbox hitbox) {
        return !hitbox.estaDentroDe(Sector.ANCHO, Sector.ALTO);
    }
}
