package logica.entidades;

import logica.entidades.enemigos.Enemigo;
import logica.entidades.fijas.Objeto;
import logica.entidades.fijas.Obstaculo;
import logica.entidades.fijas.PowerUP;

/**
 * Entidad que resuelve un choque según contra qué choca (patrón Visitor).
 */
public interface Colisionador {

    // Comandos

    /**
     * Resuelve el choque con Link.
     */
    public void colisionarCon(Link link);

    /**
     * Resuelve el choque con un enemigo.
     */
    public void colisionarCon(Enemigo enemigo);

    /**
     * Resuelve el choque con un proyectil.
     */
    public void colisionarCon(Proyectil proyectil);

    /**
     * Resuelve el choque con un obstáculo.
     */
    public void colisionarCon(Obstaculo obstaculo);

    /**
     * Resuelve el choque con un power-up.
     */
    public void colisionarCon(PowerUP powerUp);

    /**
     * Resuelve el choque con un objeto.
     */
    public void colisionarCon(Objeto objeto);
}
