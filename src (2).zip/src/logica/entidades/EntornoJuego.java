package logica.entidades;

import logica.entidades.enemigos.Enemigo;
import logica.entidades.enemigos.Jefe;
import logica.entidades.fijas.PowerUP;
import logica.fabricas.FabricaEntidades;
import logica.util.Direccion;

/**
 * Lo que las entidades necesitan de la partida: avisar lo que pasa, agregar entidades y ubicar a Link.
 */
public interface EntornoJuego {

    // Comandos

    /**
     * Agrega una entidad al sector visible y la muestra.
     */
    public void agregarEntidad(Entidad entidad);

    /**
     * Pasa a Link al sector vecino en la dirección indicada.
     */
    public void cambiarDeSector(Direccion direccion);

    /**
     * Avisa que se derrotó un enemigo y devuelve true si con él apareció una bellota.
     */
    public boolean enemigoDerrotado(Enemigo enemigo);

    /**
     * Avisa que se derrotó un jefe.
     */
    public void jefeDerrotado(Jefe jefe);

    /**
     * Avisa que Link recogió un power-up.
     */
    public void powerUpRecogido(PowerUP powerUp);

    /**
     * Avisa que Link recibió daño: un golpe o una caída al vacío.
     */
    public void jugadorDaniado();

    /**
     * Avisa que Link se quedó sin vidas (la partida no termina: se puede reiniciar el nivel o volver al menú).
     */
    public void jugadorSinVidas();

    /**
     * Avisa que Link cayó al vacío (el nivel se vuelve a armar y Link vuelve al inventario con el que lo empezó).
     */
    public void jugadorCayoAlVacio();

    // Consultas

    /**
     * Devuelve la fábrica de entidades de la partida.
     */
    public FabricaEntidades getFabricaEntidades();

    /**
     * Devuelve a Link como entidad, solo para saber dónde está.
     */
    public Entidad getJugador();
}
