package logica.entidades;

import logica.comportamientos.DefensaLimitada;
import logica.comportamientos.MovimientoInducido;
import logica.fabricas.Sprite;
import logica.util.Direccion;
import logica.util.Posicion;

/**
 * Disparo o roca que avanza hasta chocar, salir del sector o llegar a su destino.
 */
public class Proyectil extends EntidadAnimada {

    // Atributos de clase

    private static final int VIDA = 1;
    private static final int VELOCIDAD = 5;
    private static final int PERMANENCIA_EN_PISO = 3000;

    // Atributos de instancia

    private int danio;
    private Posicion destino;
    private boolean aterrizada;

    // Constructores

    /**
     * Crea el proyectil hacia una dirección; su cuerpo (disparo o roca grande) lo trae el sprite.
     */
    public Proyectil(Sprite sprite, int x, int y, Direccion direccion, int danio) {
        super(sprite, x, y, VIDA);
        this.danio = danio;
        setDireccion(direccion);
        setMovimiento(new MovimientoInducido(direccion, VELOCIDAD));
        setDefensa(DefensaLimitada.invulnerable());
    }

    // Comandos

    /**
     * Hace que avance hasta una posición fija.
     */
    public void setDestino(Posicion destino) {
        this.destino = destino;
        setMovimiento(new MovimientoInducido(destino, VELOCIDAD));
    }

    /**
     * Hace su vuelta; al llegar a su destino queda unos segundos en el piso y después desaparece.
     */
    @Override
    public void actualizarEstado(AdministradorColisiones colisiones) {
        super.actualizarEstado(colisiones);
        if (llegoAlDestino()) {
            aterrizada = true;
            programar(PERMANENCIA_EN_PISO, this::desaparecer);
        }
    }

    /**
     * Recibe un choque (patrón Visitor).
     */
    @Override
    public void aceptarColision(Colisionador colisionador) {
        colisionador.colisionarCon(this);
    }

    /**
     * Desaparece al chocar con un bloqueo.
     */
    @Override
    protected void alChocarConBloqueo() {
        desaparecer();
    }

    /**
     * Desaparece al salir del sector.
     */
    @Override
    protected void alSalirDelSector(Direccion direccion) {
        desaparecer();
    }

    /**
     * Desaparece al morir.
     */
    @Override
    protected void morir() {
        desaparecer();
    }

    /**
     * Se elimina del juego.
     */
    private void desaparecer() {
        eliminar();
    }

    // Consultas

    /**
     * Indica si el proyectil llegó a su destino y todavía no aterrizó ni fue eliminado.
     */
    private boolean llegoAlDestino() {
        return destino != null && !aterrizada && !estaEliminada()
                && getX() == destino.getX() && getY() == destino.getY();
    }

    /**
     * Devuelve el daño que hace.
     */
    public int getDanio() {
        return danio;
    }
}
