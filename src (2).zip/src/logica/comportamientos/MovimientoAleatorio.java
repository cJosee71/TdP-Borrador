package logica.comportamientos;

import java.util.Random;

import logica.entidades.AdministradorColisiones;
import logica.entidades.EntidadAnimada;
import logica.util.Direccion;

/**
 * Movimiento que cambia de dirección al azar cada cierto intervalo o al chocar.
 */
public class MovimientoAleatorio implements ComportamientoMovimiento {

    // Atributos de instancia

    private Random azar;
    private int velocidad;
    private long intervaloCambio;
    private long ultimoCambio;

    // Constructores

    /**
     * Crea el movimiento con su velocidad y el intervalo de cambio en milisegundos.
     */
    public MovimientoAleatorio(int velocidad, long intervaloCambio) {
        this.azar = new Random();
        this.velocidad = velocidad;
        this.intervaloCambio = intervaloCambio;
    }

    // Comandos

    /**
     * Avanza y elige otra dirección si pasó el intervalo o si quedó bloqueado.
     */
    @Override
    public void mover(EntidadAnimada entidad, AdministradorColisiones colisiones) {
        long ahora = System.currentTimeMillis();
        if (ahora - ultimoCambio >= intervaloCambio) {
            entidad.setDireccion(direccionAleatoria());
            ultimoCambio = ahora;
        }
        if (!colisiones.mover(entidad, entidad.getDireccion(), velocidad))
            entidad.setDireccion(direccionAleatoria());
    }

    // Consultas

    /**
     * Devuelve una dirección elegida al azar.
     */
    private Direccion direccionAleatoria() {
        Direccion[] direcciones = Direccion.values();
        return direcciones[azar.nextInt(direcciones.length)];
    }
}
