package logica.comportamientos;

import logica.entidades.EntidadAnimada;
import logica.util.Direccion;

/**
 * Defensa que limita el daño por golpe (danioMaximo) durante una cantidad de golpes con daño (golpesRestantes).
 * Combinaciones:
 * - normal(): (SIN_LIMITE, SIEMPRE), deja pasar todo el daño.
 * - invulnerable(): (0, SIEMPRE), no deja pasar daño.
 * - Bellota: (1, 3), medio corazón como máximo en los próximos 3 golpes; después pasa a ser normal.
 */
public class DefensaLimitada implements ComportamientoDefensa {

    // Atributos de clase

    public static final int SIN_LIMITE = Integer.MAX_VALUE;
    public static final int SIEMPRE = -1;

    // Atributos de instancia

    private int danioMaximo;
    private int golpesRestantes;

    // Constructores

    /**
     * Crea la defensa con el daño máximo por golpe y los golpes que dura.
     */
    public DefensaLimitada(int danioMaximo, int golpesProtegidos) {
        this.danioMaximo = danioMaximo;
        golpesRestantes = golpesProtegidos;
    }

    /**
     * Crea una defensa normal: deja pasar todo el daño, siempre.
     */
    public static DefensaLimitada normal() {
        return new DefensaLimitada(SIN_LIMITE, SIEMPRE);
    }

    /**
     * Crea una defensa invulnerable: no deja pasar daño.
     */
    public static DefensaLimitada invulnerable() {
        return new DefensaLimitada(0, SIEMPRE);
    }

    // Comandos

    /**
     * Aplica el daño sin pasarse del máximo y descuenta un golpe si la defensa es limitada.
     */
    @Override
    public boolean recibirDanio(EntidadAnimada entidad, int danio, Direccion origen) {
        boolean recibioDanio = false;
        int danioReal = Math.min(danio, danioMaximo);
        if (danioReal > 0) {
            entidad.aplicarDanio(danioReal);
            recibioDanio = true;
            descontarGolpeProtegido();
        }
        return recibioDanio;
    }

    /**
     * Descuenta un golpe protegido si la defensa es limitada; al llegar a 0 vuelve a ser una defensa normal.
     */
    private void descontarGolpeProtegido() {
        if (tieneGolpesRestantes()) {
            golpesRestantes--;
            if (golpesRestantes == 0) {
                danioMaximo = SIN_LIMITE;
                golpesRestantes = SIEMPRE;
            }
        }
    }

    // Consultas

    /**
     * Devuelve true si todavía le quedan golpes protegidos.
     */
    @Override
    public boolean tieneGolpesRestantes() {
        return golpesRestantes != SIEMPRE;
    }
}
