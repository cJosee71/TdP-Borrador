package logica.comportamientos;

import logica.entidades.AdministradorColisiones;
import logica.entidades.EntidadAnimada;

/**
 * Ataque cuerpo a cuerpo que golpea lo que está adelante del atacante.
 */
public class AtaqueEspada implements ComportamientoAtaque {

    // Atributos de instancia

    protected int danio;
    protected int alcance;

    // Constructores

    /**
     * Crea el ataque con su daño y su alcance en píxeles.
     */
    public AtaqueEspada(int danio, int alcance) {
        this.danio = danio;
        this.alcance = alcance;
    }

    // Comandos

    /**
     * Golpea si el atacante quiere atacar.
     */
    @Override
    public void atacar(EntidadAnimada atacante, AdministradorColisiones colisiones) {
        if (atacante.quiereAtacar()) {
            golpear(atacante, colisiones);
            atacante.ataqueRealizado();
        }
    }

    /**
     * Aplica el golpe en la zona de adelante del atacante.
     */
    protected void golpear(EntidadAnimada atacante, AdministradorColisiones colisiones) {
        colisiones.golpearEn(atacante, alcance, danio);
    }

    /**
     * No hace nada: este ataque no lastima al tocar.
     */
    @Override
    public void ataqueAlContactar(EntidadAnimada atacante, EntidadAnimada tocado) {
    }
}
