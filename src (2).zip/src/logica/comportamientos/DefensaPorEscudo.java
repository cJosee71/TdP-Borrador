package logica.comportamientos;

import logica.entidades.EntidadAnimada;
import logica.util.Direccion;

/**
 * Defensa con escudo: bloquea los golpes de frente o todos, según cómo se construya.
 */
public class DefensaPorEscudo implements ComportamientoDefensa {

    // Atributos de instancia

    private boolean soloDeFrente;
    private ComportamientoDefensa sinEscudo;

    // Constructores

    /**
     * Crea el escudo; si soloDeFrente es false, bloquea todos los golpes.
     */
    public DefensaPorEscudo(boolean soloDeFrente) {
        this.soloDeFrente = soloDeFrente;
        this.sinEscudo = DefensaLimitada.normal();
    }

    // Comandos

    /**
     * Bloquea el golpe si corresponde; si no, aplica el daño normal.
     */
    @Override
    public boolean recibirDanio(EntidadAnimada entidad, int danio, Direccion origen) {
        boolean recibioDanio = false;
        if (!bloqueaElGolpe(entidad, origen))
            recibioDanio = sinEscudo.recibirDanio(entidad, danio, origen);
        return recibioDanio;
    }

    /**
     * Indica si el escudo frena el golpe: siempre, o solo si viene de frente cuando el escudo es de frente.
     */
    private boolean bloqueaElGolpe(EntidadAnimada entidad, Direccion origen) {
        boolean llegaDeFrente = origen == entidad.getDireccion().opuesta();
        return !soloDeFrente || llegaDeFrente;
    }

    // Consultas

    /**
     * El escudo no cuenta golpes: protege mientras esté levantado.
     */
    @Override
    public boolean tieneGolpesRestantes() {
        return false;
    }
}
