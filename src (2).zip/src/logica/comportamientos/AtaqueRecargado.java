package logica.comportamientos;

import logica.entidades.AdministradorColisiones;
import logica.entidades.EntidadAnimada;

/**
 * Ataque con espada de Link: si el atacante tiene el ataque cargado, multiplica daño y alcance por FACTOR_CARGA y
 * golpea alrededor (giro).
 */
public class AtaqueRecargado extends AtaqueEspada {

    // Atributos de clase

    private static final int FACTOR_CARGA = 2;

    // Constructores

    /**
     * Crea el ataque con su daño y su alcance normales.
     */
    public AtaqueRecargado(int danio, int alcance) {
        super(danio, alcance);
    }

    // Comandos

    /**
     * Golpea al soltar la tecla: normal hacia adelante, o recargado con un giro hacia los cuatro lados.
     */
    @Override
    public void atacar(EntidadAnimada atacante, AdministradorColisiones colisiones) {
        if (atacante.soltoElAtaque()) {
            if (atacante.ataqueCargado())
                golpearConGiro(atacante, colisiones);
            else
                golpear(atacante, colisiones);
            atacante.ataqueRealizado();
        }
    }

    /**
     * Golpea hacia los cuatro lados con el daño y el alcance multiplicados por FACTOR_CARGA.
     */
    private void golpearConGiro(EntidadAnimada atacante, AdministradorColisiones colisiones) {
        colisiones.golpearAlrededor(atacante, alcance * FACTOR_CARGA, danio * FACTOR_CARGA);
    }
}
