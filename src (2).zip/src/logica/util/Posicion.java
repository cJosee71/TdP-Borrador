package logica.util;

/**
 * Punto inmutable en píxeles.
 */
public final class Posicion {

    // Atributos de instancia

    private final int x;
    private final int y;

    // Constructores

    /**
     * Crea una posición en (x, y).
     */
    public Posicion(int x, int y) {
        this.x = x;
        this.y = y;
    }

    // Consultas

    /**
     * Devuelve la coordenada x.
     */
    public int getX() {
        return x;
    }

    /**
     * Devuelve la coordenada y.
     */
    public int getY() {
        return y;
    }

    /**
     * Devuelve una posición nueva corrida unos pasos en una dirección.
     */
    public Posicion desplazada(Direccion direccion, int pasos) {
        return new Posicion(x + direccion.getDx() * pasos, y + direccion.getDy() * pasos);
    }

    /**
     * Devuelve la distancia a otra posición.
     */
    public double distancia(Posicion otra) {
        return Math.hypot(otra.x - x, otra.y - y);
    }

    /**
     * Devuelve la dirección principal hacia otra posición.
     */
    public Direccion direccionHacia(Posicion otra) {
        int dx = otra.x - x;
        int dy = otra.y - y;
        return Math.abs(dx) >= Math.abs(dy) ? direccionHorizontal(dx) : direccionVertical(dy);
    }

    /**
     * Devuelve la dirección horizontal según el desplazamiento.
     */
    private Direccion direccionHorizontal(int dx) {
        return dx >= 0 ? Direccion.DERECHA : Direccion.IZQUIERDA;
    }

    /**
     * Devuelve la dirección vertical según el desplazamiento.
     */
    private Direccion direccionVertical(int dy) {
        return dy >= 0 ? Direccion.ABAJO : Direccion.ARRIBA;
    }
}
