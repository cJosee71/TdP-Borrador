package logica.util;

/**
 * Rectángulo de colisión: el cuerpo de una entidad, corrido un margen desde la esquina de la entidad. Sus medidas las
 * define el dominio (ver Cuerpo).
 */
public class Hitbox {

    // Atributos de instancia

    private Posicion posicion;
    private int margenX;
    private int margenY;
    private int ancho;
    private int alto;

    // Constructores

    /**
     * Crea una hitbox sin margen.
     */
    public Hitbox(int x, int y, int ancho, int alto) {
        this(x, y, 0, 0, ancho, alto);
    }

    /**
     * Crea una hitbox cuyo cuerpo está corrido un margen desde la esquina de la entidad.
     */
    public Hitbox(int x, int y, int margenX, int margenY, int ancho, int alto) {
        this.posicion = new Posicion(x, y);
        this.margenX = margenX;
        this.margenY = margenY;
        this.ancho = ancho;
        this.alto = alto;
    }

    // Comandos

    /**
     * Cambia la esquina de la entidad.
     */
    public void setPosicion(Posicion posicion) {
        this.posicion = posicion;
    }

    // Consultas

    /**
     * Devuelve la esquina de la entidad.
     */
    public Posicion getPosicion() {
        return posicion;
    }

    /**
     * Devuelve la x de la esquina del cuerpo.
     */
    public int getX() {
        return posicion.getX() + margenX;
    }

    /**
     * Devuelve la y de la esquina del cuerpo.
     */
    public int getY() {
        return posicion.getY() + margenY;
    }

    /**
     * Devuelve el ancho del cuerpo.
     */
    public int getAncho() {
        return ancho;
    }

    /**
     * Devuelve el alto del cuerpo.
     */
    public int getAlto() {
        return alto;
    }

    /**
     * Devuelve el centro del cuerpo.
     */
    public Posicion getCentro() {
        return new Posicion(getX() + ancho / 2, getY() + alto / 2);
    }

    /**
     * Indica si un punto está dentro del cuerpo.
     */
    public boolean contiene(Posicion punto) {
        return getX() <= punto.getX() && punto.getX() < getX() + ancho
                && getY() <= punto.getY() && punto.getY() < getY() + alto;
    }

    /**
     * Indica si el segmento que va de desde a hasta pasa por el cuerpo; lo recorre de a un píxel.
     */
    public boolean cruzaElSegmento(Posicion desde, Posicion hasta) {
        int dx = hasta.getX() - desde.getX();
        int dy = hasta.getY() - desde.getY();
        int pasos = Math.max(1, Math.max(Math.abs(dx), Math.abs(dy)));
        boolean cruza = false;
        int paso = 0;
        while (!cruza && paso <= pasos) {
            cruza = contiene(new Posicion(desde.getX() + dx * paso / pasos, desde.getY() + dy * paso / pasos));
            paso++;
        }
        return cruza;
    }

    /**
     * Indica si se superpone con otra hitbox.
     */
    public boolean intersecta(Hitbox otra) {
        return seSuperponeHorizontalmente(otra) && seSuperponeVerticalmente(otra);
    }

    /**
     * Indica si los cuerpos se superponen horizontalmente.
     */
    private boolean seSuperponeHorizontalmente(Hitbox otra) {
        return getX() < otra.getX() + otra.ancho
                && otra.getX() < getX() + ancho;
    }

    /**
     * Indica si los cuerpos se superponen verticalmente.
     */
    private boolean seSuperponeVerticalmente(Hitbox otra) {
        return getY() < otra.getY() + otra.alto
                && otra.getY() < getY() + alto;
    }

    /**
     * Devuelve una copia corrida unos pasos en una dirección.
     */
    public Hitbox desplazada(Direccion direccion, int pasos) {
        Posicion desplazada = posicion.desplazada(direccion, pasos);
        return new Hitbox(desplazada.getX(), desplazada.getY(), margenX, margenY, ancho, alto);
    }

    /**
     * Devuelve la posición de la entidad que deja la esquina del cuerpo en (x, y).
     */
    public Posicion posicionParaCuerpoEn(int x, int y) {
        return new Posicion(x - margenX, y - margenY);
    }

    /**
     * Devuelve la zona pegada al cuerpo en una dirección, con el alcance indicado.
     */
    public Hitbox adelante(Direccion direccion, int alcance) {
        switch (direccion) {
            case DERECHA:
                return new Hitbox(getX() + ancho, getY(), alcance, alto);
            case IZQUIERDA:
                return new Hitbox(getX() - alcance, getY(), alcance, alto);
            case ABAJO:
                return new Hitbox(getX(), getY() + alto, ancho, alcance);
            default:
                return new Hitbox(getX(), getY() - alcance, ancho, alcance);
        }
    }

    /**
     * Devuelve la zona que rodea al cuerpo, agrandada el alcance indicado hacia los cuatro lados.
     */
    public Hitbox alrededor(int alcance) {
        return new Hitbox(getX() - alcance, getY() - alcance, ancho + 2 * alcance, alto + 2 * alcance);
    }

    /**
     * Indica si el cuerpo está completo dentro de una zona.
     */
    public boolean estaDentroDe(int anchoZona, int altoZona) {
        return getX() >= 0 && getY() >= 0 && getX() + ancho <= anchoZona && getY() + alto <= altoZona;
    }

    /**
     * Indica si comparte fila o columna con otra hitbox.
     */
    public boolean estaEnLineaCon(Hitbox otra) {
        return seSuperponeVerticalmente(otra) || seSuperponeHorizontalmente(otra);
    }

    /**
     * Devuelve la franja que va desde este cuerpo hasta otro que está en su misma fila o columna.
     */
    public Hitbox caminoHasta(Hitbox otra) {
        Hitbox camino;
        if (seSuperponeVerticalmente(otra)) {
            int izquierda = Math.min(getX(), otra.getX());
            int derecha = Math.max(getX() + ancho, otra.getX() + otra.ancho);
            camino = new Hitbox(izquierda, getY(), derecha - izquierda, alto);
        } else {
            int arriba = Math.min(getY(), otra.getY());
            int abajo = Math.max(getY() + alto, otra.getY() + otra.alto);
            camino = new Hitbox(getX(), arriba, ancho, abajo - arriba);
        }
        return camino;
    }
}
