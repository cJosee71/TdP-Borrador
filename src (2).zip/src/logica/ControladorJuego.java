package logica;

import logica.juego.ModoJuego;
import logica.fabricas.FabricaSprites;
import logica.juego.Ranking;

/**
 * Operaciones que la vista le pide a la lógica del juego.
 */
public interface ControladorJuego {

    // Comandos

    /**
     * Arma y arranca una partida nueva.
     */
    public void iniciar(ModoJuego modo, FabricaSprites dominio);

    /**
     * Registra el puntaje de la partida con el nombre del jugador; si es nulo o está vacío, el juego usa un nombre
     * por defecto.
     */
    public void registrarNombre(String nombre);

    /**
     * Avisa que terminó la animación de cambio de sector.
     */
    public void transicionTerminada();

    /**
     * Carga el nivel siguiente y reanuda la partida después de la ventana de nivel superado.
     */
    public void continuarNivel();

    /**
     * Vuelve a empezar el nivel actual con las vidas llenas, el puntaje en 0 y el inventario con el que se empezó el
     * nivel (desde GAME OVER o desde el menú de pausa).
     */
    public void reiniciarNivel();

    /**
     * Termina la partida sin guardar en el ranking.
     */
    public void abandonarPartida();

    /**
     * Detiene la partida y muestra el menú de pausa (si la partida está en curso y no está ya en pausa).
     */
    public void pausarPartida();

    /**
     * Sigue con la partida después del menú de pausa.
     */
    public void reanudarPartida();

    // Consultas

    /**
     * Devuelve el ranking del modo indicado.
     */
    public Ranking getRanking(ModoJuego m);

    /**
     * Devuelve el control del jugador, o null si no hay partida.
     */
    public ControlJugador getControlJugador();
}
