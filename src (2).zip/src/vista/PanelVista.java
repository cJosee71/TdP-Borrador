package vista;

import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JPanel;

import logica.mapa.Sector;

/**
 * Pantalla de la aplicación del tamaño de un sector más el HUD.
 */
public abstract class PanelVista extends JPanel {

    // Atributos de clase

    protected static final Color COLOR_FONDO = new Color(0x14, 0x1C, 0x2B);
    protected static final Color COLOR_SUPERFICIE = new Color(0x22, 0x2D, 0x42);
    protected static final Color COLOR_DORADO = new Color(0xE0, 0xB8, 0x4C);
    protected static final Color COLOR_TEXTO = new Color(0xEE, 0xEA, 0xDC);
    private static final int ALTURA_FRANJA_HUD = 56;

    // Atributos de instancia

    protected ControladorDeVistas controladorVistas;

    // Constructores

    /**
     * Crea el panel con su tamaño y su color de fondo, y arma sus componentes.
     */
    protected PanelVista(ControladorDeVistas controlador) {
        controladorVistas = controlador;
        setPreferredSize(new Dimension(Sector.ANCHO, Sector.ALTO + ALTURA_FRANJA_HUD));
        setBackground(COLOR_FONDO);
        armarComponentes();
    }

    // Comandos

    /**
     * Crea y ubica los componentes del panel. Se llama desde el constructor:
     * las subclases inicializan sus atributos acá adentro.
     */
    protected abstract void armarComponentes();
}
