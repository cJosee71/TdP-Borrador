package vista;

import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

/**
 * Ventana emergente de nivel superado: muestra el nivel, el puntaje y el nivel que sigue,
 * y al continuar pasa al nivel siguiente.
 */
public class DialogoPasajeNivel extends DialogoVista {

    // Atributos de clase

    private static final String TITULO_VENTANA = "Nivel superado";
    private static final int TAMANIO_FUENTE_TITULO = 32;
    private static final int TAMANIO_FUENTE_PUNTAJE = 18;
    private static final int TAMANIO_FUENTE_SIGUIENTE = 15;

    // Atributos de instancia

    private JLabel titulo;
    private JLabel textoPuntaje;
    private JLabel textoSiguiente;

    // Constructores

    /**
     * Crea la ventana del nivel superado con su número y el puntaje.
     */
    public DialogoPasajeNivel(JFrame duenio, ControladorDeVistas c, int nivelSuperado, int puntaje) {
        super(duenio, TITULO_VENTANA, c);
        titulo.setText("¡NIVEL " + nivelSuperado + " SUPERADO!");
        textoPuntaje.setText("Puntaje: " + puntaje);
        textoSiguiente.setText("Siguiente: nivel " + (nivelSuperado + 1));
        reacomodar();
    }

    // Comandos

    /**
     * Cierra la ventana y sigue con el nivel siguiente.
     */
    public void continuar() {
        dispose();
        controladorVistas.continuarNivel();
    }

    /**
     * Cerrar con la X también sigue con el nivel siguiente.
     */
    @Override
    protected void alCerrar() {
        continuar();
    }

    /**
     * Crea el título, el puntaje, el aviso del nivel siguiente y el botón CONTINUAR, uno debajo del otro.
     */
    @Override
    protected void armarComponentes() {
        titulo = crearEtiqueta("", Font.SERIF, Font.BOLD, TAMANIO_FUENTE_TITULO, PanelVista.COLOR_DORADO);
        textoPuntaje = crearEtiqueta("", Font.SANS_SERIF, Font.BOLD, TAMANIO_FUENTE_PUNTAJE, PanelVista.COLOR_TEXTO);
        textoSiguiente =
                crearEtiqueta("", Font.SANS_SERIF, Font.PLAIN, TAMANIO_FUENTE_SIGUIENTE, PanelVista.COLOR_TEXTO);

        setLayout(new GridBagLayout());
        ubicar(titulo, 0, new Insets(30, 50, 8, 50));
        ubicar(textoPuntaje, 1, new Insets(8, 50, 4, 50));
        ubicar(textoSiguiente, 2, new Insets(8, 50, 4, 50));
        ubicar(crearBotonConAccion("CONTINUAR", true, this::continuar), 3, new Insets(22, 50, 30, 50));
    }

    /**
     * Crea un botón con el estilo de las pantallas que al apretarlo hace la acción.
     */
    private JButton crearBotonConAccion(String texto, boolean principal, Runnable accion) {
        JButton boton = crearBoton(texto, principal);
        boton.addActionListener(e -> accion.run());
        return boton;
    }

    /**
     * Crea una etiqueta centrada con la fuente y el color dados.
     */
    private JLabel crearEtiqueta(String texto, String familia, int estilo, int tamanio, Color color) {
        JLabel etiqueta = new JLabel(texto, SwingConstants.CENTER);
        etiqueta.setFont(new Font(familia, estilo, tamanio));
        etiqueta.setForeground(color);
        return etiqueta;
    }

    /**
     * Agrega un componente en la fila dada de la ventana, con sus márgenes.
     */
    private void ubicar(JComponent componente, int fila, Insets margenes) {
        GridBagConstraints ubicacion = new GridBagConstraints();
        ubicacion.gridx = 0;
        ubicacion.gridy = fila;
        ubicacion.insets = margenes;
        add(componente, ubicacion);
    }
}
