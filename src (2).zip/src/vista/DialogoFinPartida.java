package vista;

import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

/**
 * Ventana emergente de fin de partida, ganada o perdida (GAME OVER): muestra el puntaje; si entra al ranking pide
 * el nombre para guardarlo, y si no, ofrece ver el ranking (solo al ganar). Al perder se puede reiniciar el nivel.
 * Siempre se puede volver al menú.
 */
public class DialogoFinPartida extends DialogoVista {

    // Atributos de clase

    private static final Color COLOR_DERROTA = new Color(0xE0, 0x5A, 0x4C);
    private static final String TITULO_VENTANA_GANADA = "Partida ganada";
    private static final String TITULO_VENTANA_PERDIDA = "Partida perdida";
    private static final String TEXTO_GANASTE = "¡GANASTE!";
    private static final String TEXTO_GAME_OVER = "GAME OVER";
    private static final int TAMANIO_FUENTE_TITULO = 36;
    private static final int TAMANIO_FUENTE_PUNTAJE = 18;
    private static final int TAMANIO_FUENTE_RANKING = 15;
    private static final int TAMANIO_FUENTE_CAMPO = 16;
    private static final int COLUMNAS_CAMPO = 16;

    // Atributos de instancia

    private JLabel titulo;
    private JLabel textoPuntaje;
    private JLabel textoRanking;
    private JTextField campoNombre;
    private JButton botonGuardar;
    private JButton botonVerRanking;
    private JButton botonReiniciar;

    // Constructores

    /**
     * Crea la ventana con el resultado y el puntaje y deja visibles solo las opciones que corresponden (ver
     * mostrarOpciones); maximoRanking es la cantidad de puestos del ranking.
     */
    public DialogoFinPartida(JFrame duenio, ControladorDeVistas c, boolean gano, int puntaje, boolean entraEnRanking,
            int maximoRanking) {
        super(duenio, gano ? TITULO_VENTANA_GANADA : TITULO_VENTANA_PERDIDA, c);
        mostrarResultado(gano, puntaje, maximoRanking);
        mostrarOpciones(gano, entraEnRanking);
        reacomodar();
    }

    // Comandos

    /**
     * Cierra la ventana y guarda el puntaje con el nombre escrito (después se ve el ranking).
     */
    public void guardar() {
        dispose();
        controladorVistas.guardarPuntaje(campoNombre.getText());
    }

    /**
     * Cierra la ventana y muestra el ranking del modo jugado.
     */
    public void verRanking() {
        dispose();
        controladorVistas.verRankingPartida();
    }

    /**
     * Cierra la ventana y reinicia el nivel actual sin lo acumulado y con el inventario del comienzo del nivel (solo
     * al perder).
     */
    public void reiniciarNivel() {
        dispose();
        controladorVistas.reiniciarNivel();
    }

    /**
     * Cierra la ventana y vuelve al menú principal sin guardar (si la partida seguía en pausa, la abandona).
     */
    public void volver() {
        dispose();
        controladorVistas.irAlMenu();
    }

    /**
     * Cerrar con la X vuelve al menú.
     */
    @Override
    protected void alCerrar() {
        volver();
    }

    /**
     * Crea el título, el puntaje, el aviso y el campo del nombre, y los botones GUARDAR, VER RANKING,
     * REINICIAR NIVEL y VOLVER AL MENÚ. Enter en el campo también guarda.
     */
    @Override
    protected void armarComponentes() {
        titulo = new JLabel("", SwingConstants.CENTER);
        titulo.setFont(new Font(Font.SERIF, Font.BOLD, TAMANIO_FUENTE_TITULO));
        textoPuntaje = crearEtiqueta("", Font.SANS_SERIF, Font.BOLD, TAMANIO_FUENTE_PUNTAJE, PanelVista.COLOR_TEXTO);
        textoRanking = crearEtiqueta("", Font.SANS_SERIF, Font.PLAIN, TAMANIO_FUENTE_RANKING, PanelVista.COLOR_TEXTO);
        campoNombre = crearCampoNombre();
        botonGuardar = crearBotonConAccion("GUARDAR", true, this::guardar);
        botonVerRanking = crearBotonConAccion("VER RANKING", true, this::verRanking);
        botonReiniciar = crearBotonConAccion("REINICIAR NIVEL", false, this::reiniciarNivel);
        JButton botonVolver = crearBotonConAccion("VOLVER AL MENÚ", false, this::volver);

        setLayout(new GridBagLayout());
        ubicar(titulo, 0, new Insets(30, 50, 6, 50));
        ubicar(textoPuntaje, 1, new Insets(6, 50, 14, 50));
        ubicar(textoRanking, 2, new Insets(4, 50, 6, 50));
        ubicar(campoNombre, 3, new Insets(4, 50, 6, 50));
        ubicar(crearFilaDeBotones(botonGuardar, botonVerRanking, botonReiniciar, botonVolver), 4,
                new Insets(18, 40, 26, 40));
    }

    /**
     * Muestra "¡GANASTE!" en dorado o "GAME OVER" en rojo, el puntaje y el aviso del top.
     */
    private void mostrarResultado(boolean gano, int puntaje, int maximoRanking) {
        titulo.setText(gano ? TEXTO_GANASTE : TEXTO_GAME_OVER);
        titulo.setForeground(gano ? PanelVista.COLOR_DORADO : COLOR_DERROTA);
        textoPuntaje.setText("Puntaje: " + puntaje);
        textoRanking.setText("¡Entraste al top " + maximoRanking + "! Escribí tu nombre:");
    }

    /**
     * Deja visibles solo las opciones que corresponden: nombre y GUARDAR si entra al ranking, VER RANKING al ganar
     * sin entrar y REINICIAR NIVEL al perder.
     */
    private void mostrarOpciones(boolean gano, boolean entraEnRanking) {
        textoRanking.setVisible(entraEnRanking);
        campoNombre.setVisible(entraEnRanking);
        botonGuardar.setVisible(entraEnRanking);
        botonVerRanking.setVisible(gano && !entraEnRanking);
        botonReiniciar.setVisible(!gano);
    }

    /**
     * Crea el campo del nombre con el estilo de las pantallas; Enter guarda.
     */
    private JTextField crearCampoNombre() {
        JTextField campo = new JTextField(COLUMNAS_CAMPO);
        campo.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, TAMANIO_FUENTE_CAMPO));
        campo.setBackground(PanelVista.COLOR_SUPERFICIE);
        campo.setForeground(PanelVista.COLOR_TEXTO);
        campo.setCaretColor(PanelVista.COLOR_TEXTO);
        campo.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(PanelVista.COLOR_DORADO),
                BorderFactory.createEmptyBorder(6, 8, 6, 8)));
        campo.addActionListener(e -> guardar());
        return campo;
    }

    /**
     * Crea un botón con el estilo de las pantallas que al apretarlo hace la acción.
     */
    private JButton crearBotonConAccion(String texto, boolean principal, Runnable accion) {
        JButton boton = crearBoton(texto, principal);
        boton.addActionListener(e -> accion.run());
        return boton;
    }

    /**
     * Crea una etiqueta centrada con la fuente y el color dados.
     */
    private JLabel crearEtiqueta(String texto, String familia, int estilo, int tamanio, Color color) {
        JLabel etiqueta = new JLabel(texto, SwingConstants.CENTER);
        etiqueta.setFont(new Font(familia, estilo, tamanio));
        etiqueta.setForeground(color);
        return etiqueta;
    }

    /**
     * Crea una fila transparente con los botones uno al lado del otro.
     */
    private JPanel crearFilaDeBotones(JButton... botones) {
        JPanel fila = new JPanel();
        fila.setOpaque(false);
        for (JButton boton : botones)
            fila.add(boton);
        return fila;
    }

    /**
     * Agrega un componente en la fila dada de la ventana, con sus márgenes.
     */
    private void ubicar(JComponent componente, int fila, Insets margenes) {
        GridBagConstraints ubicacion = new GridBagConstraints();
        ubicacion.gridx = 0;
        ubicacion.gridy = fila;
        ubicacion.insets = margenes;
        add(componente, ubicacion);
    }
}
