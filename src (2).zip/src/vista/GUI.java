package vista;

import java.awt.KeyboardFocusManager;
import java.awt.event.KeyEvent;

import javax.swing.SwingUtilities;

import logica.ControladorGrafico;
import logica.ControladorJuego;
import logica.ControlJugador;
import logica.EntidadJugador;
import logica.EntidadLogica;
import logica.Observer;
import logica.fabricas.FabricaSprites;
import logica.juego.ModoJuego;
import logica.juego.Ranking;
import logica.util.Direccion;

/**
 * Vista de la aplicación: maneja las pantallas, dibuja la partida y envía las teclas al jugador.
 */
public class GUI implements ControladorGrafico, ControladorDeVistas {

    // Atributos de instancia

    protected Ventana ventana;
    protected PanelPantallaPrincipal panelPrincipal;
    protected PanelPantallaRanking panelRanking;
    protected PanelPantallaNivel panelNivel;
    protected ControladorJuego controladorJuego;
    protected ControlJugador controlJugador;
    protected ModoJuego modoActual;
    protected DialogoPasajeNivel dialogoPasajeNivel;
    protected DialogoFinPartida dialogoFinPartida;
    protected DialogoPausa dialogoPausa;
    protected boolean arribaPresionada;
    protected boolean abajoPresionada;
    protected boolean izquierdaPresionada;
    protected boolean derechaPresionada;

    // Constructores

    /**
     * Crea la ventana, las pantallas y el lector de teclas.
     */
    public GUI() {
        ventana = new Ventana("The Legend of Zelda: Link's Awakening");
        panelPrincipal = new PanelPantallaPrincipal(this);
        panelRanking = new PanelPantallaRanking(this);
        panelNivel = new PanelPantallaNivel(this);
        KeyboardFocusManager.getCurrentKeyboardFocusManager().addKeyEventDispatcher(e -> {
            if (e.getID() == KeyEvent.KEY_PRESSED) {
                procesarTecla(e.getKeyCode(), true);
            } else if (e.getID() == KeyEvent.KEY_RELEASED) {
                procesarTecla(e.getKeyCode(), false);
            }
            return false;
        });
    }

    // Comandos

    /**
     * Asigna la lógica del juego.
     */
    public void setControladorJuego(ControladorJuego c) {
        controladorJuego = c;
    }

    /**
     * Muestra el menú principal.
     */
    @Override
    public void mostrarPantallaPrincipal() {
        ventana.mostrarPanel(panelPrincipal);
    }

    /**
     * Muestra el ranking de un modo.
     */
    @Override
    public void mostrarPantallaRanking(ModoJuego m) {
        panelRanking.mostrarRanking(controladorJuego.getRanking(m), m.getNombre());
        ventana.mostrarPanel(panelRanking);
    }

    /**
     * Recuerda el modo, muestra el nivel, arranca la partida y toma el control del jugador nuevo
     * (terminarControl lo suelta). Olvida las flechas que quedaron apretadas de antes.
     */
    public void iniciarPartida(ModoJuego modo, FabricaSprites dominio) {
        modoActual = modo;
        arribaPresionada = false;
        abajoPresionada = false;
        izquierdaPresionada = false;
        derechaPresionada = false;
        ventana.mostrarPanel(panelNivel);
        controladorJuego.iniciar(modo, dominio);
        controlJugador = controladorJuego.getControlJugador();
    }

    /**
     * Suelta el control del jugador (pausa, GAME OVER, nivel superado o fin de la partida): le avisa que se soltaron
     * las teclas, deja de enviarle teclas y olvida las flechas apretadas.
     */
    @Override
    public void terminarControl() {
        if (controlJugador != null) {
            controlJugador.detenerMovimiento();
            controlJugador.soltarAtaque();
            controlJugador.soltarEscudo();
        }
        controlJugador = null;
        arribaPresionada = false;
        abajoPresionada = false;
        izquierdaPresionada = false;
        derechaPresionada = false;
    }

    /**
     * Crea la celda de una entidad y la devuelve como su observador.
     */
    @Override
    public Observer mostrarEntidad(EntidadLogica e) {
        CeldaGrafica celda = new CeldaGrafica(e, panelNivel);
        SwingUtilities.invokeLater(() -> panelNivel.agregarCelda(celda));
        return celda;
    }

    /**
     * Crea la celda del jugador y la devuelve como su observador.
     */
    @Override
    public Observer mostrarJugador(EntidadJugador j) {
        CeldaJugador celda = new CeldaJugador(j, panelNivel);
        SwingUtilities.invokeLater(() -> panelNivel.agregarCelda(celda));
        return celda;
    }

    /**
     * Borra todas las celdas.
     */
    public void limpiarEscena() {
        SwingUtilities.invokeLater(panelNivel::limpiar);
    }

    /**
     * Anima el cambio de sector en un hilo aparte.
     */
    public void transicion(Direccion d) {
        new Thread(new AnimadorTransicion(panelNivel, d, controladorJuego)).start();
    }

    /**
     * Muestra el tiempo.
     */
    public void actualizarTiempo(int segundos) {
        SwingUtilities.invokeLater(() -> panelNivel.actualizarTiempo(segundos));
    }

    /**
     * Muestra el número de nivel.
     */
    public void actualizarNivel(int numero) {
        SwingUtilities.invokeLater(() -> panelNivel.actualizarNivel(numero));
    }

    /**
     * Le pasa al panel del nivel la ruta del fondo del sector visible.
     */
    @Override
    public void mostrarFondo(String ruta) {
        SwingUtilities.invokeLater(() -> panelNivel.cambiarFondo(ruta));
    }

    /**
     * Abre la ventana emergente de nivel superado y la guarda en dialogoPasajeNivel.
     */
    @Override
    public void mostrarPasajeNivel(int nivelSuperado, int puntaje) {
        SwingUtilities.invokeLater(() -> {
            dialogoPasajeNivel = new DialogoPasajeNivel(ventana, this, nivelSuperado, puntaje);
            dialogoPasajeNivel.setVisible(true);
        });
    }

    /**
     * Abre el menú de pausa y lo guarda en dialogoPausa.
     */
    @Override
    public void mostrarPausa(int nivel, int puntaje) {
        SwingUtilities.invokeLater(() -> {
            dialogoPausa = new DialogoPausa(ventana, this, nivel, puntaje);
            dialogoPausa.setVisible(true);
        });
    }

    /**
     * Abre la ventana emergente de partida ganada o perdida y la guarda en dialogoFinPartida.
     */
    @Override
    public void mostrarFinPartida(boolean gano, int puntaje, boolean entraEnRanking) {
        SwingUtilities.invokeLater(() -> {
            dialogoFinPartida = new DialogoFinPartida(ventana, this, gano, puntaje, entraEnRanking,
                    controladorJuego.getRanking(modoActual).getMaximo());
            dialogoFinPartida.setVisible(true);
        });
    }

    /**
     * Le pide al juego el nivel siguiente y vuelve a tomar el control de Link.
     */
    @Override
    public void continuarNivel() {
        controladorJuego.continuarNivel();
        controlJugador = controladorJuego.getControlJugador();
    }

    /**
     * Le pide al juego que reinicie el nivel y vuelve a tomar el control de Link.
     */
    @Override
    public void reiniciarNivel() {
        controladorJuego.reiniciarNivel();
        controlJugador = controladorJuego.getControlJugador();
    }

    /**
     * Le pide al juego que salga de la pausa y vuelve a tomar el control de Link.
     */
    @Override
    public void continuarPartida() {
        controladorJuego.reanudarPartida();
        controlJugador = controladorJuego.getControlJugador();
    }

    /**
     * Le pide al juego que abandone la partida y muestra el menú principal.
     */
    @Override
    public void irAlMenu() {
        controladorJuego.abandonarPartida();
        mostrarPantallaPrincipal();
    }

    /**
     * Muestra el ranking del modo de la partida que terminó.
     */
    @Override
    public void verRankingPartida() {
        mostrarPantallaRanking(modoActual);
    }

    /**
     * Registra el puntaje con el nombre que escribió el usuario; si lo deja vacío, el juego guarda un nombre por
     * defecto.
     */
    @Override
    public void guardarPuntaje(String nombre) {
        controladorJuego.registrarNombre(nombre);
    }

    /**
     * Muestra la pantalla del ranking.
     */
    public void mostrarRanking(Ranking r, String nombreModo) {
        SwingUtilities.invokeLater(() -> {
            panelRanking.mostrarRanking(r, nombreModo);
            ventana.mostrarPanel(panelRanking);
        });
    }

    /**
     * Traduce una tecla apretada o soltada en una acción del jugador; sin partida en curso no hace nada. Escape o P
     * alternan la pausa. Las flechas se anotan y Link camina hacia la primera que siga apretada (arriba, abajo,
     * izquierda, derecha), así sigue caminando al soltar una mientras mantiene otra.
     */
    protected void procesarTecla(int codigo, boolean presionada) {
        if (esTeclaDePausa(codigo) && presionada) {
            alternarPausa();
        } else if (controlJugador != null) {
            if (esFlecha(codigo)) {
                anotarFlecha(codigo, presionada);
                moverSegunFlechasApretadas();
            } else {
                procesarAccion(codigo, presionada);
            }
        }
    }

    /**
     * Indica si la tecla es Escape o P.
     */
    private boolean esTeclaDePausa(int codigo) {
        return codigo == KeyEvent.VK_ESCAPE || codigo == KeyEvent.VK_P;
    }

    /**
     * Indica si la tecla es una de las cuatro flechas.
     */
    private boolean esFlecha(int codigo) {
        return codigo == KeyEvent.VK_UP || codigo == KeyEvent.VK_DOWN
                || codigo == KeyEvent.VK_LEFT || codigo == KeyEvent.VK_RIGHT;
    }

    /**
     * Con la partida en curso la pausa; con el menú de pausa abierto, la continúa.
     */
    private void alternarPausa() {
        if (controlJugador != null) {
            controladorJuego.pausarPartida();
        } else if (dialogoPausa != null && dialogoPausa.isShowing()) {
            dialogoPausa.continuar();
        }
    }

    /**
     * Anota si la flecha quedó apretada o suelta.
     */
    private void anotarFlecha(int codigo, boolean presionada) {
        switch (codigo) {
            case KeyEvent.VK_UP:
                arribaPresionada = presionada;
                break;
            case KeyEvent.VK_DOWN:
                abajoPresionada = presionada;
                break;
            case KeyEvent.VK_LEFT:
                izquierdaPresionada = presionada;
                break;
            case KeyEvent.VK_RIGHT:
                derechaPresionada = presionada;
                break;
            default:
                break;
        }
    }

    /**
     * Mueve a Link hacia la primera flecha que siga apretada (arriba, abajo, izquierda, derecha); si no queda
     * ninguna, lo detiene.
     */
    private void moverSegunFlechasApretadas() {
        if (arribaPresionada) {
            controlJugador.mover(Direccion.ARRIBA);
        } else if (abajoPresionada) {
            controlJugador.mover(Direccion.ABAJO);
        } else if (izquierdaPresionada) {
            controlJugador.mover(Direccion.IZQUIERDA);
        } else if (derechaPresionada) {
            controlJugador.mover(Direccion.DERECHA);
        } else {
            controlJugador.detenerMovimiento();
        }
    }

    /**
     * A ataca mientras está apretada, S protege mientras está apretada y D cambia el objeto al apretarla. A y S
     * actúan con el objeto equipado (interpretación del punto 13, ver Link).
     */
    private void procesarAccion(int codigo, boolean presionada) {
        switch (codigo) {
            case KeyEvent.VK_A:
                if (presionada) {
                    controlJugador.atacar();
                } else {
                    controlJugador.soltarAtaque();
                }
                break;
            case KeyEvent.VK_S:
                if (presionada) {
                    controlJugador.usarEscudo();
                } else {
                    controlJugador.soltarEscudo();
                }
                break;
            case KeyEvent.VK_D:
                if (presionada) {
                    controlJugador.cambiarObjeto();
                }
                break;
            default:
                break;
        }
    }
}
