package vista;

import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 * Ventana principal que muestra un panel a la vez.
 */
public class Ventana extends JFrame {

    // Constructores

    /**
     * Crea la ventana con su título.
     */
    public Ventana(String titulo) {
        super(titulo);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
    }

    // Comandos

    /**
     * Muestra un panel; la primera vez ajusta el tamaño y centra la ventana.
     */
    public void mostrarPanel(JPanel panel) {
        setContentPane(panel);
        if (!isVisible()) {
            pack();
            setLocationRelativeTo(null);
            setVisible(true);
        }
        revalidate();
        repaint();
    }
}
