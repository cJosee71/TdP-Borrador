package vista;

import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

/**
 * Ventana emergente del menú de pausa: el juego queda detenido mientras está abierta. Muestra el nivel
 * y el puntaje y deja continuar, reiniciar el nivel o volver al menú (sin guardar en el ranking).
 */
public class DialogoPausa extends DialogoVista {

    // Atributos de clase

    private static final String TITULO_VENTANA = "Pausa";
    private static final String TEXTO_AVISO = "Reiniciar vuelve al inicio del nivel con las vidas llenas y puntaje 0.";
    private static final int TAMANIO_FUENTE_TITULO = 36;
    private static final int TAMANIO_FUENTE_ESTADO = 18;
    private static final int TAMANIO_FUENTE_AVISO = 15;

    // Atributos de instancia

    private JLabel textoEstado;

    // Constructores

    /**
     * Crea la ventana con el nivel y el puntaje actuales.
     */
    public DialogoPausa(JFrame duenio, ControladorDeVistas c, int nivel, int puntaje) {
        super(duenio, TITULO_VENTANA, c);
        textoEstado.setText("Nivel " + nivel + "  ·  Puntaje: " + puntaje);
        reacomodar();
    }

    // Comandos

    /**
     * Cierra la ventana y sigue con la partida donde quedó.
     */
    public void continuar() {
        dispose();
        controladorVistas.continuarPartida();
    }

    /**
     * Cierra la ventana y reinicia el nivel actual sin lo acumulado y con el inventario del comienzo del nivel.
     */
    public void reiniciarNivel() {
        dispose();
        controladorVistas.reiniciarNivel();
    }

    /**
     * Cierra la ventana, abandona la partida sin guardar en el ranking y vuelve al menú.
     */
    public void irAlMenu() {
        dispose();
        controladorVistas.irAlMenu();
    }

    /**
     * Cerrar con la X sigue con la partida.
     */
    @Override
    protected void alCerrar() {
        continuar();
    }

    /**
     * Crea el título, el nivel y el puntaje, el aviso y los botones CONTINUAR, REINICIAR NIVEL e IR AL MENÚ.
     */
    @Override
    protected void armarComponentes() {
        JLabel titulo = crearEtiqueta("PAUSA", Font.SERIF, Font.BOLD, TAMANIO_FUENTE_TITULO, PanelVista.COLOR_DORADO);
        textoEstado = crearEtiqueta("", Font.SANS_SERIF, Font.BOLD, TAMANIO_FUENTE_ESTADO, PanelVista.COLOR_TEXTO);
        JLabel textoAviso = crearEtiqueta(TEXTO_AVISO, Font.SANS_SERIF, Font.PLAIN, TAMANIO_FUENTE_AVISO,
                PanelVista.COLOR_TEXTO);

        setLayout(new GridBagLayout());
        ubicar(titulo, 0, new Insets(30, 50, 6, 50));
        ubicar(textoEstado, 1, new Insets(6, 50, 4, 50));
        ubicar(textoAviso, 2, new Insets(6, 50, 4, 50));
        ubicar(crearFilaDeBotones(
                crearBotonConAccion("CONTINUAR", true, this::continuar),
                crearBotonConAccion("REINICIAR NIVEL", false, this::reiniciarNivel),
                crearBotonConAccion("IR AL MENÚ", false, this::irAlMenu)), 3, new Insets(18, 40, 26, 40));
    }

    /**
     * Crea un botón con el estilo de las pantallas que al apretarlo hace la acción.
     */
    private JButton crearBotonConAccion(String texto, boolean principal, Runnable accion) {
        JButton boton = crearBoton(texto, principal);
        boton.addActionListener(e -> accion.run());
        return boton;
    }

    /**
     * Crea una etiqueta centrada con la fuente y el color dados.
     */
    private JLabel crearEtiqueta(String texto, String familia, int estilo, int tamanio, Color color) {
        JLabel etiqueta = new JLabel(texto, SwingConstants.CENTER);
        etiqueta.setFont(new Font(familia, estilo, tamanio));
        etiqueta.setForeground(color);
        return etiqueta;
    }

    /**
     * Crea una fila transparente con los botones uno al lado del otro.
     */
    private JPanel crearFilaDeBotones(JButton... botones) {
        JPanel fila = new JPanel();
        fila.setOpaque(false);
        for (JButton boton : botones)
            fila.add(boton);
        return fila;
    }

    /**
     * Agrega un componente en la fila dada de la ventana, con sus márgenes.
     */
    private void ubicar(JComponent componente, int fila, Insets margenes) {
        GridBagConstraints ubicacion = new GridBagConstraints();
        ubicacion.gridx = 0;
        ubicacion.gridy = fila;
        ubicacion.insets = margenes;
        add(componente, ubicacion);
    }
}
