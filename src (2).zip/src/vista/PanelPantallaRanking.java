package vista;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

import logica.juego.EntradaRanking;
import logica.juego.Ranking;

/**
 * Pantalla con la tabla del ranking de un modo.
 */
public class PanelPantallaRanking extends PanelVista {

    // Atributos de clase

    private static final Color[] PODIO = {COLOR_DORADO, new Color(0xC4, 0xC8, 0xD0), new Color(0xCD, 0x7F, 0x32)};
    private static final String TEXTO_TITULO = "RANKING";
    private static final String TEXTO_SIN_PUNTAJES = "Todavía no hay puntajes";
    private static final int TAMANIO_FUENTE_TITULO = 36;
    private static final int TAMANIO_FUENTE_TABLA = 18;
    private static final int TAMANIO_FUENTE_CABECERA = 14;
    private static final int TAMANIO_FUENTE_BOTON = 15;
    private static final int ALTO_FILA = 46;
    private static final int ALTO_CABECERA = 40;
    private static final int SEPARACION = 20;
    private static final int MARGEN_VERTICAL = 34;
    private static final int MARGEN_HORIZONTAL = 90;

    // Atributos de instancia

    private JTable tabla;
    private JLabel titulo;

    // Constructores

    /**
     * Crea la pantalla del ranking.
     */
    public PanelPantallaRanking(ControladorDeVistas c) {
        super(c);
    }

    // Comandos

    /**
     * Carga en la tabla las entradas del ranking; si no hay, muestra un aviso.
     */
    public void mostrarRanking(Ranking r, String nombreModo) {
        titulo.setText(TEXTO_TITULO + " " + nombreModo.toUpperCase());
        DefaultTableModel modelo = new DefaultTableModel(new String[] {"PUESTO", "NOMBRE", "PUNTAJE"}, 0);
        int puesto = 1;
        for (EntradaRanking entrada : r.getEntradas()) {
            modelo.addRow(new Object[] {puesto++, entrada.getNombre(), entrada.getPuntaje()});
        }
        if (modelo.getRowCount() == 0) {
            modelo.addRow(new Object[] {"-", TEXTO_SIN_PUNTAJES, "-"});
        }
        tabla.setModel(modelo);
    }

    /**
     * Vuelve al menú principal.
     */
    public void volver() {
        controladorVistas.mostrarPantallaPrincipal();
    }

    /**
     * Crea el título, la tabla con colores de podio y el botón de volver.
     */
    @Override
    protected void armarComponentes() {
        titulo = new JLabel(TEXTO_TITULO, SwingConstants.CENTER);
        titulo.setFont(new Font(Font.SERIF, Font.BOLD, TAMANIO_FUENTE_TITULO));
        titulo.setForeground(COLOR_DORADO);

        tabla = crearTabla();
        JScrollPane desplazable = new JScrollPane(tabla);
        desplazable.setBorder(BorderFactory.createLineBorder(COLOR_DORADO));
        desplazable.getViewport().setBackground(COLOR_SUPERFICIE);

        setLayout(new BorderLayout(0, SEPARACION));
        setBorder(BorderFactory.createEmptyBorder(
                MARGEN_VERTICAL, MARGEN_HORIZONTAL, MARGEN_VERTICAL, MARGEN_HORIZONTAL));
        add(titulo, BorderLayout.NORTH);
        add(desplazable, BorderLayout.CENTER);
        add(crearBotonVolver(), BorderLayout.SOUTH);
    }

    // Consultas

    /**
     * Crea la tabla de solo lectura, con la cabecera dorada, filas alternadas y colores de podio.
     */
    private JTable crearTabla() {
        JTable nueva = new JTable();
        nueva.setEnabled(false);
        nueva.setRowHeight(ALTO_FILA);
        nueva.setShowGrid(false);
        nueva.setIntercellSpacing(new Dimension(0, 0));
        nueva.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, TAMANIO_FUENTE_TABLA));
        nueva.setBackground(COLOR_SUPERFICIE);
        nueva.setForeground(COLOR_TEXTO);
        nueva.getTableHeader().setReorderingAllowed(false);
        nueva.getTableHeader().setPreferredSize(new Dimension(0, ALTO_CABECERA));
        nueva.getTableHeader().setFont(new Font(Font.SANS_SERIF, Font.BOLD, TAMANIO_FUENTE_CABECERA));
        nueva.getTableHeader().setBackground(COLOR_DORADO);
        nueva.getTableHeader().setForeground(COLOR_FONDO);
        nueva.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            /**
             * Arma la celda: texto centrado, filas alternadas y color de podio para los tres primeros puestos.
             */
            @Override
            public Component getTableCellRendererComponent(JTable t, Object valor, boolean seleccionada,
                    boolean foco, int fila, int columna) {
                super.getTableCellRendererComponent(t, valor, false, false, fila, columna);
                setHorizontalAlignment(SwingConstants.CENTER);
                setBackground(fila % 2 == 0 ? COLOR_SUPERFICIE : COLOR_SUPERFICIE.darker());
                boolean destacada = columna == 0 && fila < PODIO.length;
                setForeground(destacada ? PODIO[fila] : COLOR_TEXTO);
                setFont(t.getFont().deriveFont(destacada ? Font.BOLD : Font.PLAIN));
                return this;
            }
        });
        return nueva;
    }

    /**
     * Crea el botón dorado VOLVER, que vuelve al menú principal.
     */
    private JButton crearBotonVolver() {
        JButton botonVolver = new JButton("VOLVER");
        botonVolver.setFont(new Font(Font.SANS_SERIF, Font.BOLD, TAMANIO_FUENTE_BOTON));
        botonVolver.setFocusPainted(false);
        botonVolver.setContentAreaFilled(false);
        botonVolver.setOpaque(true);
        botonVolver.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        botonVolver.setBackground(COLOR_DORADO);
        botonVolver.setForeground(COLOR_FONDO);
        botonVolver.setBorder(BorderFactory.createEmptyBorder(11, 40, 11, 40));
        botonVolver.addActionListener(e -> volver());
        return botonVolver;
    }
}
