package vista;

import logica.juego.ModoJuego;
import logica.fabricas.FabricaSprites;

/**
 * Operaciones que los paneles y las ventanas emergentes le piden a la GUI para cambiar de pantalla.
 */
public interface ControladorDeVistas {

    // Comandos

    /**
     * Muestra el menú principal.
     */
    public void mostrarPantallaPrincipal();

    /**
     * Muestra el ranking de un modo.
     */
    public void mostrarPantallaRanking(ModoJuego m);

    /**
     * Muestra el nivel y arranca la partida.
     */
    public void iniciarPartida(ModoJuego modo, FabricaSprites dominio);

    /**
     * Sigue con el nivel siguiente después de la ventana de nivel superado.
     */
    public void continuarNivel();

    /**
     * Vuelve a empezar el nivel actual (desde GAME OVER o desde el menú de pausa).
     */
    public void reiniciarNivel();

    /**
     * Abandona la partida sin guardar en el ranking y muestra el menú principal.
     */
    public void irAlMenu();

    /**
     * Sigue con la partida después del menú de pausa.
     */
    public void continuarPartida();

    /**
     * Guarda el puntaje en el ranking con el nombre ingresado.
     */
    public void guardarPuntaje(String nombre);

    /**
     * Muestra el ranking del modo de la partida que terminó.
     */
    public void verRankingPartida();
}
