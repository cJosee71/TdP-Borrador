package vista;

import javax.swing.SwingUtilities;
import logica.EntidadJugador;

/**
 * Celda de Link que además actualiza el HUD.
 */
public class CeldaJugador extends CeldaGrafica {

    // Atributos de instancia

    protected EntidadJugador jugadorObservado;

    // Constructores

    /**
     * Crea la celda del jugador en un panel.
     */
    public CeldaJugador(EntidadJugador jugador, PanelPantallaNivel panel) {
        super(jugador, panel);
        this.jugadorObservado = jugador;
    }

    // Comandos

    /**
     * Redibuja a Link y actualiza el HUD.
     */
    @Override
    public void actualizar() {
        super.actualizar();
        SwingUtilities.invokeLater(() -> panelNivel.actualizarHUD(jugadorObservado));
    }
}
