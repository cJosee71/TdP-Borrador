package vista;

import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.GridLayout;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

import logica.EntidadJugador;
import logica.mapa.Sector;
import logica.util.Direccion;

/**
 * Pantalla del juego: dibuja el fondo del sector visible, sus celdas encima y el HUD.
 */
public class PanelPantallaNivel extends PanelVista {

    // Atributos de clase

    private static final int PASOS_TRANSICION = 30;
    private static final long PAUSA_TRANSICION = 15;
    private static final int TAMANIO_FUENTE_HUD = 14;
    private static final int GROSOR_BORDE_HUD = 2;
    private static final int MARGEN_IZQUIERDO_ETIQUETA = 16;
    private static final String CORAZON = "♥";

    // Atributos de instancia

    protected List<CeldaGrafica> celdas;
    private JLabel etiquetaNivel;
    private JLabel etiquetaPuntaje;
    private JLabel etiquetaTiempo;
    private JLabel etiquetaVidas;
    private JLabel etiquetaRupias;
    private JLabel etiquetaObjeto;
    private Image fondo;
    private int desplazamientoFondoX;
    private int desplazamientoFondoY;

    // Constructores

    /**
     * Crea la pantalla del nivel.
     */
    public PanelPantallaNivel(ControladorDeVistas c) {
        super(c);
    }

    // Comandos

    /**
     * Agrega una celda arriba de las de su capa y de las inferiores, debajo de las capas superiores, y la dibuja.
     */
    public void agregarCelda(CeldaGrafica c) {
        int celdasQueLaTapan = contarCeldasDeCapaSuperior(c.entidadObservada.getCapa());
        celdas.add(c);
        add(c, celdasQueLaTapan);
        c.actualizar();
        repaint();
    }

    /**
     * Carga la imagen de fondo del sector visible desde su ruta y la vuelve a ubicar en (0, 0); si la ruta no existe,
     * no dibuja fondo.
     */
    public void cambiarFondo(String ruta) {
        URL url = PanelPantallaNivel.class.getResource(ruta);
        fondo = (url != null) ? new ImageIcon(url).getImage() : null;
        desplazamientoFondoX = 0;
        desplazamientoFondoY = 0;
        repaint();
    }

    /**
     * Pinta el panel y el fondo; Swing dibuja las celdas después, así quedan encima del fondo.
     */
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (fondo != null)
            g.drawImage(fondo, desplazamientoFondoX, desplazamientoFondoY, Sector.ANCHO, Sector.ALTO, this);
    }

    /**
     * Quita una celda.
     */
    public void quitarCelda(CeldaGrafica c) {
        celdas.remove(c);
        remove(c);
        repaint();
    }

    /**
     * Quita todas las celdas.
     */
    public void limpiar() {
        for (CeldaGrafica c : new ArrayList<>(celdas)) {
            quitarCelda(c);
        }
    }

    /**
     * Muestra los datos del jugador en el HUD, con los corazones dibujados.
     */
    public void actualizarHUD(EntidadJugador j) {
        etiquetaVidas.setText(etiqueta("VIDAS", j.getVidas() + " &nbsp; " + dibujarCorazones(j)));
        etiquetaPuntaje.setText(etiqueta("PUNTOS", String.valueOf(j.getPuntaje())));
        etiquetaRupias.setText(etiqueta("RUPIAS", "<font color='#43A047'>◆</font> " + j.getRupias()));
        etiquetaObjeto.setText(etiqueta("OBJETO", j.getNombreObjetoEquipado()));
    }

    /**
     * Muestra el tiempo en minutos y segundos.
     */
    public void actualizarTiempo(int segundos) {
        etiquetaTiempo.setText(etiqueta("TIEMPO", String.format("%02d:%02d", segundos / 60, segundos % 60)));
    }

    /**
     * Muestra el número de nivel.
     */
    public void actualizarNivel(int numero) {
        etiquetaNivel.setText(etiqueta("NIVEL", String.valueOf(numero)));
    }

    /**
     * Desliza el fondo y las celdas fuera de la pantalla en la dirección del cambio de sector; si interrumpen el
     * hilo, corta la animación.
     */
    public void desplazar(Direccion d) {
        for (int paso = 1; paso <= PASOS_TRANSICION && !Thread.currentThread().isInterrupted(); paso++) {
            int dx = -d.getDx() * getWidth() * paso / PASOS_TRANSICION;
            int dy = -d.getDy() * getHeight() * paso / PASOS_TRANSICION;
            SwingUtilities.invokeLater(() -> correrEscena(dx, dy));
            try {
                Thread.sleep(PAUSA_TRANSICION);
            } catch (InterruptedException ex) {
                Thread.currentThread().interrupt();
            }
        }
    }

    /**
     * Crea la lista de celdas y la franja del HUD.
     */
    @Override
    protected void armarComponentes() {
        celdas = new ArrayList<>();
        setLayout(null);

        etiquetaNivel = new JLabel();
        etiquetaTiempo = new JLabel();
        etiquetaPuntaje = new JLabel();
        etiquetaVidas = new JLabel();
        etiquetaRupias = new JLabel();
        etiquetaObjeto = new JLabel();
        actualizarNivel(1);
        actualizarTiempo(0);

        add(crearFranjaHud());
    }

    /**
     * Mueve el fondo y cada celda a su lugar corrido en (dx, dy) y redibuja.
     */
    private void correrEscena(int dx, int dy) {
        desplazamientoFondoX = dx;
        desplazamientoFondoY = dy;
        for (CeldaGrafica c : celdas) {
            c.setLocation(c.entidadObservada.getXImagen() + dx, c.entidadObservada.getYImagen() + dy);
        }
        repaint();
    }

    // Consultas

    /**
     * Cuenta las celdas de una capa más alta, que tienen que quedar encima de una celda de esta capa.
     */
    private int contarCeldasDeCapaSuperior(int capa) {
        int cantidad = 0;
        for (CeldaGrafica otra : celdas) {
            if (otra.entidadObservada.getCapa() > capa) {
                cantidad++;
            }
        }
        return cantidad;
    }

    /**
     * Arma los corazones del HUD: llenos en rojo, el medio en rosa y los vacíos en gris.
     */
    private String dibujarCorazones(EntidadJugador j) {
        int medios = j.getCorazones();
        int llenos = medios / 2;
        boolean hayMedio = medios % 2 == 1;
        int vacios = Math.max(0, j.getCorazonesMaximos() / 2 - llenos - (hayMedio ? 1 : 0));
        return "<font color='#E53935'>" + CORAZON.repeat(llenos) + "</font>"
                + "<font color='#F4A6B0'>" + (hayMedio ? CORAZON : "") + "</font>"
                + "<font color='#5A5F6B'>" + CORAZON.repeat(vacios) + "</font>";
    }

    /**
     * Crea la franja del HUD debajo del sector, con las seis etiquetas en dos filas.
     */
    private JPanel crearFranjaHud() {
        JPanel franjaHud = new JPanel(new GridLayout(2, 3));
        franjaHud.setBackground(COLOR_SUPERFICIE);
        franjaHud.setBorder(BorderFactory.createMatteBorder(GROSOR_BORDE_HUD, 0, 0, 0, COLOR_DORADO));
        franjaHud.setBounds(0, Sector.ALTO, Sector.ANCHO, getPreferredSize().height - Sector.ALTO);
        JLabel[] etiquetas =
                {etiquetaNivel, etiquetaTiempo, etiquetaPuntaje, etiquetaVidas, etiquetaRupias, etiquetaObjeto};
        for (JLabel etiqueta : etiquetas) {
            etiqueta.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, TAMANIO_FUENTE_HUD));
            etiqueta.setForeground(COLOR_TEXTO);
            etiqueta.setBorder(BorderFactory.createEmptyBorder(0, MARGEN_IZQUIERDO_ETIQUETA, 0, 0));
            franjaHud.add(etiqueta);
        }
        return franjaHud;
    }

    /**
     * Arma el texto de una etiqueta del HUD: el título en dorado y el valor en negrita.
     */
    private static String etiqueta(String titulo, String valor) {
        String dorado = String.format("#%06X", COLOR_DORADO.getRGB() & 0xFFFFFF);
        return "<html><span style='color:" + dorado + "'>" + titulo + "</span> &nbsp;<b>" + valor + "</b></html>";
    }
}
