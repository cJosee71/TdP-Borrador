package vista;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JToggleButton;
import javax.swing.SwingConstants;

import logica.fabricas.FabricaSprites;
import logica.fabricas.FabricaSpritesAlternativa;
import logica.fabricas.FabricaSpritesOriginal;
import logica.juego.Clasico;
import logica.juego.Contrarreloj;
import logica.juego.ModoJuego;
import logica.juego.NoHit;

/**
 * Menú principal: elegir dominio gráfico y modo, jugar o ver el ranking.
 */
public class PanelPantallaPrincipal extends PanelVista {

    // Atributos de clase

    private static final String TITULO = "<html><center><span style='font-size:25pt'>THE LEGEND OF ZELDA</span><br>"
            + "<span style='font-size:17pt'>LINK'S AWAKENING</span></center></html>";
    private static final String TEXTO_AYUDA =
            "Flechas: mover   ·   A: atacar   ·   S: escudo   ·   D: cambiar objeto   ·   Esc o P: pausa";
    private static final int TAMANIO_FUENTE_TITULO = 20;
    private static final int TAMANIO_FUENTE_SECCION = 12;
    private static final int TAMANIO_FUENTE_OPCION = 14;
    private static final int TAMANIO_FUENTE_DESCRIPCION = 13;
    private static final int TAMANIO_FUENTE_AYUDA = 12;

    // Atributos de instancia

    private FabricaSprites dominio;
    private ModoJuego modo;

    // Constructores

    /**
     * Crea el menú principal.
     */
    public PanelPantallaPrincipal(ControladorDeVistas c) {
        super(c);
    }

    // Comandos

    /**
     * Elige el dominio gráfico.
     */
    public void elegirDominio(FabricaSprites d) {
        dominio = d;
    }

    /**
     * Elige el modo de juego.
     */
    public void elegirModo(ModoJuego m) {
        modo = m;
    }

    /**
     * Arranca la partida con lo elegido.
     */
    public void jugar() {
        controladorVistas.iniciarPartida(modo, dominio);
    }

    /**
     * Muestra el ranking del modo elegido.
     */
    public void verRanking() {
        controladorVistas.mostrarPantallaRanking(modo);
    }

    /**
     * Crea el título, los botones de dominio y modo (con la descripción del modo), jugar, ranking y la ayuda de teclas.
     */
    @Override
    protected void armarComponentes() {
        dominio = new FabricaSpritesOriginal();
        modo = new Clasico();

        JLabel descripcionModo =
                crearEtiqueta(modo.getDescripcion(), Font.ITALIC, TAMANIO_FUENTE_DESCRIPCION, COLOR_TEXTO);
        JPanel filaDominio = crearFilaDeOpciones(
                crearOpcion("Original", true, () -> elegirDominio(new FabricaSpritesOriginal())),
                crearOpcion("Alternativo", false, () -> elegirDominio(new FabricaSpritesAlternativa())));
        JPanel filaModo = crearFilaDeOpciones(
                crearOpcion("Clásico", true, () -> elegirModoYDescribirlo(new Clasico(), descripcionModo)),
                crearOpcion("Contrarreloj", false, () -> elegirModoYDescribirlo(new Contrarreloj(), descripcionModo)),
                crearOpcion("NoHit", false, () -> elegirModoYDescribirlo(new NoHit(), descripcionModo)));

        setLayout(new GridBagLayout());
        ubicar(crearTitulo(), 2, 2);
        ubicar(crearEtiqueta("DOMINIO GRÁFICO", Font.BOLD, TAMANIO_FUENTE_SECCION, COLOR_DORADO), 26, 2);
        ubicar(filaDominio, 2, 2);
        ubicar(crearEtiqueta("MODO DE JUEGO", Font.BOLD, TAMANIO_FUENTE_SECCION, COLOR_DORADO), 14, 2);
        ubicar(filaModo, 2, 2);
        ubicar(descripcionModo, 2, 2);
        ubicar(crearBotonDeAccion("JUGAR", true, this::jugar), 30, 8);
        ubicar(crearBotonDeAccion("VER RANKING", false, this::verRanking), 2, 2);
        ubicar(crearEtiqueta(TEXTO_AYUDA, Font.PLAIN, TAMANIO_FUENTE_AYUDA, COLOR_TEXTO), 26, 0);
    }

    /**
     * Elige el modo y muestra su descripción.
     */
    private void elegirModoYDescribirlo(ModoJuego m, JLabel descripcionModo) {
        elegirModo(m);
        descripcionModo.setText(modo.getDescripcion());
    }

    /**
     * Agrega un componente debajo del anterior, con margen arriba y abajo.
     */
    private void ubicar(JComponent componente, int margenArriba, int margenAbajo) {
        GridBagConstraints fila = new GridBagConstraints();
        fila.gridx = 0;
        fila.insets = new Insets(margenArriba, 0, margenAbajo, 0);
        add(componente, fila);
    }

    // Consultas

    /**
     * Crea el título del juego en dorado.
     */
    private JLabel crearTitulo() {
        JLabel titulo = new JLabel(TITULO, SwingConstants.CENTER);
        titulo.setFont(new Font(Font.SERIF, Font.BOLD, TAMANIO_FUENTE_TITULO));
        titulo.setForeground(COLOR_DORADO);
        return titulo;
    }

    /**
     * Crea una etiqueta centrada con el estilo y el color dados.
     */
    private JLabel crearEtiqueta(String texto, int estilo, int tamanio, Color color) {
        JLabel etiqueta = new JLabel(texto, SwingConstants.CENTER);
        etiqueta.setFont(new Font(Font.SANS_SERIF, estilo, tamanio));
        etiqueta.setForeground(color);
        return etiqueta;
    }

    /**
     * Crea un botón de opción que se pinta de dorado mientras está elegido y que al apretarlo hace la acción.
     */
    private JToggleButton crearOpcion(String texto, boolean elegida, Runnable accion) {
        JToggleButton opcion = new JToggleButton(texto, elegida);
        opcion.setFont(new Font(Font.SANS_SERIF, Font.BOLD, TAMANIO_FUENTE_OPCION));
        opcion.setFocusPainted(false);
        opcion.setContentAreaFilled(false);
        opcion.setOpaque(true);
        opcion.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        opcion.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(COLOR_DORADO), BorderFactory.createEmptyBorder(8, 20, 8, 20)));
        Runnable pintar = () -> {
            opcion.setBackground(opcion.isSelected() ? COLOR_DORADO : COLOR_SUPERFICIE);
            opcion.setForeground(opcion.isSelected() ? COLOR_FONDO : COLOR_TEXTO);
        };
        pintar.run();
        opcion.addItemListener(e -> pintar.run());
        opcion.addActionListener(e -> accion.run());
        return opcion;
    }

    /**
     * Pone las opciones en una fila transparente y las agrupa para que solo una quede elegida.
     */
    private JPanel crearFilaDeOpciones(JToggleButton... opciones) {
        ButtonGroup grupo = new ButtonGroup();
        JPanel fila = new JPanel();
        fila.setOpaque(false);
        for (JToggleButton opcion : opciones) {
            grupo.add(opcion);
            fila.add(opcion);
        }
        return fila;
    }

    /**
     * Crea JUGAR (dorado y más grande) o VER RANKING (oscuro) que al apretarlo hace la acción.
     */
    private JButton crearBotonDeAccion(String texto, boolean principal, Runnable accion) {
        JButton boton = new JButton(texto);
        boton.setFont(new Font(Font.SANS_SERIF, Font.BOLD, principal ? 20 : 15));
        boton.setFocusPainted(false);
        boton.setContentAreaFilled(false);
        boton.setOpaque(true);
        boton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        boton.setBackground(principal ? COLOR_DORADO : COLOR_SUPERFICIE);
        boton.setForeground(principal ? COLOR_FONDO : COLOR_DORADO);
        boton.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(COLOR_DORADO),
                BorderFactory.createEmptyBorder(
                        principal ? 14 : 9, principal ? 90 : 60, principal ? 14 : 9, principal ? 90 : 60)));
        boton.addActionListener(e -> accion.run());
        return boton;
    }
}
