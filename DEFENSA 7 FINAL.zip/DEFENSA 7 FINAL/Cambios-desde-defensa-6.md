# Cambios desde la defensa 6 — estrategia bloqueaPasoA

Resume todo lo que cambió en `defensa 7/` respecto de la defensa 6, para la versión de esta carpeta. El punto de partida es el código subido a `defensa 7/Codigo` y los diagramas de `Defensa 6/`, con el estilo de `Defensa 6/Diagramas Puntuables/`.

La columna **¿En el extendido?** indica si el cambio ya está dibujado en `Diagrama-extendido-bloqueaPasoA.drawio`:

- **Sí**: ya está dibujado.
- **No aplica**: el cambio no va en el diagrama, porque es un archivo de nivel, una imagen o un detalle interno de un método.

El extendido ahora está en **blanco y negro, como el reducido**: solo conserva en colores la identificación de los patrones de diseño, con los mismos colores que el reducido y una leyenda arriba a la izquierda. Antes, lo agregado o modificado respecto de la defensa 6 iba en naranja y negrita; cuando una sección de este archivo dice "en naranja", indica qué se agregó en el diagrama, aunque ya no se pinte. Lo que se quitó se detalla en este archivo.

Las secciones 1 a 51 explican cada cambio. La sección **Detalle archivo por archivo**, al final, lista cada archivo tocado con sus atributos y métodos agregados, cambiados o quitados.

Los cambios valen para las dos estrategias, salvo el 6, que es el bloqueo propio de esta carpeta. Los cambios 7 a 14 también están en `defensa 7/Codigo`. El 15, el 16 y el 17 están solo en las dos estrategias. El 17 resuelve las correcciones de la defensa 6. Del 18 al 51 están solo en esta carpeta.

## Resumen

| # | Cambio | Clases | ¿Reducido? | ¿En el extendido? |
|---|---|---|---|---|
| 1 | Celdas de 24 px para leer el archivo del nivel | `GeneradorNivel` | no cambia | Sí |
| 2 | Niveles 1 y 2 de cuatro sectores, con un jefe solo al final | `nivel1.txt`, `nivel2.txt` | no cambia | No aplica |
| 3 | Imagen de la roca sin fondo amarillo; sprites nuevos del equipo | imágenes | no cambia | No aplica |
| 4 | Cuerpos de colisión ajustados al dibujo | 9 clases | no cambia | Sí |
| 5 | Dibujo por capas | `EntidadLogica` y 6 clases más, `PanelPantallaNivel` | no cambia | Sí |
| 6 | Bloqueo con `bloqueaPasoA(quien)`, sin Visitor | `Entidad`, `EntidadAnimada`, `Roca`, `Agua`, `CaidasAlVacio`, `Enemigo`, `Link`, `AdministradorColisiones` | no cambia | Sí |
| 7 | La trampa de cuchillas vuelve despacio | `TrampaDeCuchillas` | no cambia | Sí |
| 8 | La trampa va hasta donde estaba Link y vuelve | `TrampaDeCuchillas` | no cambia | Sí |
| 9 | No abalanzarse si hay roca, agua o vacío en el medio | `Entidad`, `Roca`, `Agua`, `CaidasAlVacio`, `Hitbox`, `EntidadAnimada`, `TrampaDeCuchillas`, `MoblinConEspadaYEscudo` | no cambia | Sí |
| 10 | Imágenes de Wizzrobe por dirección y de ataque y escudo de Link | `FabricaSprites`, `Link` | no cambia | Sí |
| 11 | Parpadeo al recibir daño | `EntidadLogica`, `Entidad`, `EntidadAnimada`, `CeldaGrafica` | no cambia | Sí |
| 12 | Wizzrobe invulnerable un segundo después de un golpe | `Wizzrobe` | no cambia | No aplica |
| 13 | Parpadeo durante la invulnerabilidad | `EntidadAnimada`, `Wizzrobe`, `MasterStalfos`, `Link` | no cambia | Sí |
| 14 | Imagen de ataque con espada del MasterStalfos (lo reemplaza el 44) | `FabricaSprites`, `MasterStalfos`, imágenes | no cambia | Sí |
| 15 | Constantes con nombre, ranking sin nombres repetidos y estilo nuevo de las pantallas | 25 clases de la lógica, `Ranking` y 5 de la vista | no cambia | Sí (las constantes y `etiqueta`) |
| 16 | Correcciones de formato en el extendido (un subrayado y cinco cursivas que no correspondían) | `Sector`, `Clasico`, `Contrarreloj`, `NoHit`, `Obstaculo`, `PowerUP` | no cambia | Sí |
| 17 | Correcciones de la defensa 6: interfaces chicas para los colaboradores de `Juego`, `partidaEnCurso` y getters | `OyenteReloj`, `ArbitroPartida`, `TablaRankings`, `EntornoJuego` (nuevas), `Juego`, `Reloj`, `ModoJuego` y sus 3 modos, `FabricaEntidades`, `Entidad`, `EntidadAnimada` | +4 interfaces, +4 realizaciones, 3 flechas pasan a las interfaces | Sí |
| 18 | Imagen del ataque recargado de Link (espada negra con amarillo) | `FabricaSprites`, `Link`, `AtaqueRecargado`, imágenes | no cambia | No aplica |
| 19 | Moblin con espada y escudo: imagen de 96 × 96 con la espada, cuerpo corrido y drop en el cuerpo | `MoblinConEspadaYEscudo`, `EnemigoConDrop`, imágenes | no cambia | Sí |
| 20 | Imágenes del StoneHinox: golpe de la avalancha y vulnerable | `StoneHinox`, `FabricaSprites`, imágenes | no cambia | Sí |
| 21 | Las rocas de la avalancha desaparecen después de caer | `Proyectil` | no cambia | Sí |
| 22 | El drop del enemigo no tapa la bellota | `EntornoJuego`, `Juego`, `EnemigoConDrop` | no cambia | Sí |
| 23 | Imagen nueva del fragmento de corazón, más grande, con su cuerpo | `FragmentoDeCorazon`, imágenes | no cambia | Sí |
| 24 | Ataque de Link hacia la derecha: espejo del ataque hacia la izquierda | imágenes | no cambia | No aplica |
| 25 | La imagen del ataque hacia la izquierda y hacia arriba se dibuja en su lugar | `EntidadLogica`, `Entidad`, `Link`, `CeldaGrafica`, `PanelPantallaNivel` | no cambia | Sí |
| 26 | El Moblin con espada y escudo se abalanza una sola vez por vez, sin temblar | `MoblinConEspadaYEscudo` | no cambia | Sí |
| 27 | Abalanzada más lenta del Moblin con espada y escudo | `MoblinConEspadaYEscudo` | no cambia | Sí |
| 28 | Abalanzada suave: preparación, arranque acelerando y frenado | `MoblinConEspadaYEscudo` | no cambia | Sí |
| 29 | Los que disparan no lo hacen a través de obstáculos | `AtaquePorProyectil` | no cambia | No aplica |
| 30 | Animación de teletransporte del Wizzrobe: desaparece y aparece con su gorrito | `Wizzrobe`, `FabricaSprites`, `CeldaGrafica`, imágenes | no cambia | Sí |
| 31 | Caída al vacío: Link cae cuando su centro está sobre el pozo y se ve un GIF antes de perder la vida | `CaidasAlVacio`, `Hitbox`, `Link`, `FabricaSprites`, imágenes | no cambia | Sí |
| 32 | La caída al vacío dura 400 ms y el GIF dura lo mismo, sin repetirse | `Link`, imágenes | no cambia | Sí |
| 33 | El suelo quebradizo tarda 800 ms en romperse | `Link` | no cambia | Sí |
| 34 | El Moblin camina con un GIF y, al morir, muestra una nube antes de desaparecer | `Moblin`, `MoblinConEspadaYEscudo`, `EntidadAnimada`, `FabricaSprites`, imágenes | no cambia | Sí |
| 35 | El Moblin con espada y escudo camina con un GIF de 126 × 126 con la espada entera | `MoblinConEspadaYEscudo`, `FabricaSprites`, imágenes | no cambia | Sí |
| 36 | Link camina con GIF (normal, con escudo y con espada) y al frenar vuelve al PNG quieto | `Link`, `FabricaSprites`, imágenes | no cambia | No aplica |
| 37 | Cambiar de objeto baja el escudo | `Link` | no cambia | No aplica |
| 38 | Ataque recargado con giro: golpea alrededor | `Hitbox`, `AdministradorColisiones`, `AtaqueRecargado`, `Link` | no cambia | Sí |
| 39 | Golpe de espada animado con los cuadros del juego original | `Link`, `FabricaSprites`, imágenes | no cambia | Sí |
| 40 | Revisión final: diagrama igual al código, sin comentarios `//` sueltos, javadoc al día y `PERIODO_PARPADEO` | diagrama extendido, `EntidadAnimada` y 16 clases (comentarios y javadoc) | no cambia | Sí |
| 41 | El StoneHinox lanza las tres rocas de a una, hacia Link aunque no esté alineado | `AtaqueRafaga` (nueva), `StoneHinox` | +1 clase y +1 herencia | Sí |
| 42 | El daño de cada proyectil lo decide el enemigo que dispara, no la fábrica | `FabricaEntidades`, `Octorok`, `Wizzrobe`, `StoneHinox` | no cambia | Sí |
| 43 | Animación de muerte de Link (gira y cae) y el HUD muestra 0 vidas al perder la última | `Link`, `FabricaSprites`, imágenes | no cambia | Sí |
| 44 | GIFs del Master Stalfos: camina animado y el golpe de espada se anima en las 4 direcciones (reemplaza las imágenes del 14) | `MasterStalfos`, `FabricaSprites`, imágenes | no cambia | Sí |
| 45 | GIF distinto para perder una vida (cae para atrás y se levanta); el de muerte queda para la última | `Link`, `FabricaSprites`, imágenes | no cambia | Sí |
| 46 | Sin `return` anticipado: los métodos que cortaban con `return;` ponen el cuerpo dentro de un `if` | `Link`, `Moblin`, `AtaquePorProyectil`, `AtaqueRecargado`, `GUI`, `CeldaGrafica`, `PanelPantallaNivel` | no cambia | Sí |
| 47 | Animación de muerte del Master Stalfos (golpeado, se desarma y nube) antes de desaparecer | `MasterStalfos`, `FabricaSprites`, imágenes | no cambia | Sí |
| 48 | Animación de muerte para todos los enemigos: pasa del Moblin a `Enemigo` (Template Method con el gancho `desaparecer()`) | `Enemigo`, `EnemigoConDrop`, `Jefe`, `Moblin`, `MasterStalfos`, `Wizzrobe`, `StoneHinox`, `FabricaSprites`, imágenes | no cambia | Sí |
| 49 | Al soltar una flecha, Link sigue caminando si queda otra apretada | `GUI` | no cambia | Sí |
| 50 | Animaciones del StoneHinox en GIF: caminar, embestida, vulnerable y avalancha | `StoneHinox`, `FabricaSprites`, imágenes | no cambia | Sí |
| 51 | Al terminar la partida, la `GUI` suelta el control de Link (`terminarControl()`): después de la muerte definitiva las teclas ya no lo mueven | `ControladorGrafico`, `GUI`, `Juego` | no cambia | Sí |

El diagrama reducido cambia por el cambio 17, que lo deja en 94 clases/interfaces y 131 relaciones (124 dibujadas), y por el cambio 41, que suma `AtaqueRafaga` y su herencia: 95 clases/interfaces y 132 relaciones (125 dibujadas).

## 1. Celdas de 24 px

El archivo del nivel ahora dice el tamaño de la celda: `CELDAS 32 22 24` (ancho, alto y lado en píxeles). Las celdas sirven solo para ubicar entidades al leer el archivo. Las entidades siguen midiendo 48 px y se mueven en píxeles.

| Clase | Antes | Ahora |
|---|---|---|
| `GeneradorNivel` | `- CELDA : int = 48`, que se usaba para ubicar y para medir | `- LADO_ENTIDAD : int = 48`, solo para buscar lugares libres. El lado de la celda se lee de la línea `CELDAS` |

La posición de inicio de Link (`INICIO`) también se multiplica por el lado leído.

## 2. Niveles 1 y 2

`Codigo/src/Recursos/Niveles/` tiene dos niveles de cuatro sectores en fila (`MAPA 1 4`). Link arranca en el sector 0 0.

| Sector | Nivel 1 | Nivel 2 |
|---|---|---|
| 0 0 a 0 2 | 4 enemigos comunes y una trampa de cuchillas por sector, rotando Moblin, Moblin con espada y escudo, Erizo de mar, Octorok y Wizzrobe. También 4 rocas, 3 aguas, 4 pastos, 3 caídas al vacío, 2 suelos quebradizos, una rupia y un corazón | Igual, con otro reparto de enemigos |
| 0 0 | Además, la espada en el piso (`X`), cerca de donde arranca Link | Sin espada: Link la trae del nivel 1 |
| 0 3 | MasterStalfos (`S`) solo, en el centro | StoneHinox (`H`) solo, en el centro |

Cada nivel tiene un solo jefe, como pide el enunciado: MasterStalfos en el primero y StoneHinox en el segundo. Al derrotarlo se pasa de nivel o termina la partida. El juego reparte además 4 fragmentos de corazón en sectores al azar.

`defensa 7/Codigo` conserva su nivel 1 anterior, de dos sectores.

## 3. Imágenes

- `roca-normal.png` (original y alternativa) tiene el fondo transparente.
- El equipo agregó `escudo-normal`, `espada-normal` y `masterstalfos-arriba/izquierda/derecha`, y renombró `stonehinox-abajo` a `stonehinox-normal`.

## 4. Cuerpos de colisión ajustados al dibujo

Cada clase define su cuerpo con constantes y llama a `setCuerpo(margenX, margenY, ancho, alto)` en el constructor. Así Link, por ejemplo, ya no cae al vacío sin tocar el dibujo.

| Clase | margenX | margenY | ancho | alto |
|---|---|---|---|---|
| `Link` | 6 | 2 | 36 | 44 |
| `Moblin` | 4 | 4 | 40 | 40 |
| `Octorok` | 4 | 4 | 40 | 40 |
| `Wizzrobe` | 4 | 2 | 40 | 44 |
| `ErizoDeMar` | 8 | 8 | 32 | 32 |
| `TrampaDeCuchillas` | 8 | 8 | 32 | 32 |
| `CaidasAlVacio` | 8 | 8 | 32 | 32 |
| `Roca` | 4 | 4 | 42 | 42 |
| `StoneHinox` | 6 | 4 | 84 | 88 (antes `CUERPO_LADO = 96`) |

En el extendido, cada una de estas clases suma `- CUERPO_MARGEN_X`, `- CUERPO_MARGEN_Y`, `- CUERPO_ANCHO` y `- CUERPO_ALTO : int` subrayadas, como ya tienen los power-ups.

## 5. Dibujo por capas

Antes, una entidad agregada más tarde podía quedar dibujada debajo de otra; por ejemplo, un enemigo debajo de una roca. Ahora cada entidad lógica dice en qué capa va, y la vista ordena las celdas con ese número.

| Clase | Cambio |
|---|---|
| `EntidadLogica` (interfaz) | `CAPA_SUELO = 0`, `CAPA_OBJETOS = 1`, `CAPA_OBSTACULOS = 2`, `CAPA_PERSONAJES = 3`, `CAPA_JUGADOR = 4` y `+ getCapa() : int` |
| `Obstaculo*` | `getCapa()` → `CAPA_SUELO` (agua, pasto, vacío, suelo quebradizo) |
| `Roca` | `getCapa()` → `CAPA_OBSTACULOS` |
| `PowerUP*`, `Objeto*` | `getCapa()` → `CAPA_OBJETOS` |
| `EntidadAnimada*` | `getCapa()` → `CAPA_PERSONAJES` |
| `Link` | `getCapa()` → `CAPA_JUGADOR` |
| `PanelPantallaNivel` | `agregarCelda` cuenta cuántas celdas tienen capa mayor y agrega la nueva debajo de ellas: `add(c, celdasQueLaTapan)` |

## 6. Bloqueo con `bloqueaPasoA(quien)`, sin Visitor

Qué se logra: los enemigos esquivan las caídas al vacío, mientras que Link las pisa y cae. Link y los enemigos se frenan al chocarse, y el enemigo cambia de dirección. El daño por contacto sigue funcionando, porque al frenarse se dispara `aceptarColision`. Esta versión sigue la observación 4 del ayudante.

| Clase | Se quita | Se agrega |
|---|---|---|
| `Entidad*` | `bloqueaPaso()` | `+ bloqueaPasoA(quien : EntidadAnimada) : boolean` (`false`) |
| `Roca`, `Agua` | `bloqueaPaso()` | `bloqueaPasoA` → `true` |
| `CaidasAlVacio` | — | `bloqueaPasoA` → `quien.esquivaVacios()` |
| `EntidadAnimada*` | — | `+ esquivaVacios()`, `+ esFrenadoPorPersonajes()` (`false`) |
| `Enemigo*` | — | `bloqueaPasoA` → `quien.esFrenadoPorPersonajes()`; `esquivaVacios` y `esFrenadoPorPersonajes` → `true` |
| `Link` | — | `bloqueaPasoA` → `quien.esFrenadoPorPersonajes()`; `esFrenadoPorPersonajes` → `true`; `colisionarCon(Enemigo e)` → `e.colisionarCon(this)` |
| `AdministradorColisiones` | `- puedeMoverA(...)` | `- buscarBloqueo(e, d, pasos) : Entidad`; `mover` dispara `bloqueo.aceptarColision(e)` al frenarse |

El reducido no cambia. Todo el detalle está en `Explicativo-bloqueaPasoA.md`.

## 7. La trampa de cuchillas vuelve despacio

Antes, `volver()` la teletransportaba a su lugar. Si Link seguía en línea, salía de nuevo en la vuelta siguiente y nunca se la veía volver. Ahora cambia su estrategia de movimiento (Strategy) por `MovimientoInducido(posicionOriginal, VELOCIDAD_VUELTA)`: sale a 8 px por vuelta y vuelve a 4. Se agregan las constantes privadas `VELOCIDAD_SALIDA = 8` y `VELOCIDAD_VUELTA = 4`. En el extendido van subrayadas: `- VELOCIDAD_SALIDA : int = 8` y `- VELOCIDAD_VUELTA : int = 4`.

## 8. La trampa va hasta donde estaba Link y vuelve

Como en el juego original. Al salir, la trampa guarda en `destino` el lugar de Link sobre su línea de ataque. En cada vuelta, `vigilarJugador()` pregunta `llegoAlDestino()`, y si ya llegó, llama a `volver()`. Si antes choca con algo, vuelve desde ahí por `alChocarConBloqueo()`.

| Clase | Se agrega |
|---|---|
| `TrampaDeCuchillas` | `# destino : Posicion`, `- llegoAlDestino() : boolean` |

## 9. No abalanzarse a través de obstáculos

Los enemigos que se abalanzan al ver a Link no lo hacen si entre ellos hay una roca, agua o vacío: la `TrampaDeCuchillas` cuando Link queda en su fila o columna, y el `MoblinConEspadaYEscudo` cuando lo tiene enfrente. Los que disparan, como el Octorok, no cambian. La pregunta va aparte del bloqueo, así el vacío tapa a Link aunque no frene el paso.

| Clase | Se agrega |
|---|---|
| `Entidad*` | `+ impideAbalanzarse() : boolean` (`false`) |
| `Roca`, `Agua`, `CaidasAlVacio` | `+ impideAbalanzarse() : boolean` (`true`) |
| `Hitbox` | `+ caminoHasta(otra : Hitbox) : Hitbox`, la franja entre los dos cuerpos |
| `EntidadAnimada*` | `+ hayObstaculoHastaJugador() : boolean` |
| `TrampaDeCuchillas` | `vigilarJugador()` pide `estaEnLineaCon(...) && !hayObstaculoHastaJugador()` |
| `MoblinConEspadaYEscudo` | `vigilarJugador()` pide `linkEstaEnfrente() && !hayObstaculoHastaJugador()` |

## 10. Imágenes de Wizzrobe y de ataque y escudo de Link

`FabricaSprites` pedía `wizzrobe-normal.png`, que no existe. Ahora pide `abajo`, `arriba`, `izquierda` y `derecha`, y `setDireccion` elige la imagen como en los demás enemigos. También carga los estados `escudo-*` de Link. Esto queda dentro de los métodos y no cambia el diagrama.

Las imágenes `ataque-*` de Link estaban cargadas, pero nada las elegía. Ahora Link redefine `getRutaImagen()`:

- Con el escudo levantado usa `escudo-<dir>`.
- Mientras ataca, y durante 7 vueltas (unos 200 ms) después del golpe, usa `ataque-<dir>`.
- En el resto de los casos usa `<dir>`.

Además avisa a la vista al empezar y terminar el ataque y al subir o bajar el escudo.

| Clase | Se agrega |
|---|---|
| `Link` | `- VUELTAS_IMAGEN_GOLPE : int = 7` (subrayado), `# vueltasMostrandoGolpe : int`, `+ actualizarEstado(c : AdministradorColisiones)` y `+ getRutaImagen() : String` |

## 11. Parpadeo al recibir daño

Antes, un enemigo de dos vidas no mostraba nada en el primer golpe y parecía que la espada no le hacía daño. Ahora toda entidad animada que recibe daño y sigue viva parpadea durante 600 ms: se prende y se apaga cada 100 ms. Si la defensa frena el golpe (escudo, invulnerable), no parpadea. Link también parpadea al recibir daño, porque hereda de `EntidadAnimada`.

La lógica decide si la entidad se ve y la vista solo obedece. Se usa el Observer que ya existía.

| Clase | Se agrega |
|---|---|
| `EntidadLogica` | `+ esVisible() : boolean` |
| `Entidad*` | `+ esVisible() : boolean`, que devuelve `true` |
| `EntidadAnimada*` | `- DURACION_PARPADEO : long = 600` (subrayado), `# finParpadeo : long`, `- avisarParpadeo()` y `+ esVisible() : boolean`. `aplicarDanio` arranca el parpadeo, y `actualizarEstado` llama a `avisarParpadeo()` para avisar a la vista en cada vuelta mientras dura |
| `CeldaGrafica` | `actualizar()` hace `setVisible(entidadObservada.esVisible())`. No cambia en el diagrama |

## 12. Wizzrobe invulnerable un segundo después de un golpe

El enunciado dice: *"Luego de ser golpeado, se vuelve invulnerable un segundo hasta que se teletransporta nuevamente"*. Antes, el Wizzrobe quedaba invulnerable hasta su próximo teletransporte, que ocurre cada 3 s. Según cuándo se lo golpeaba, la invulnerabilidad duraba entre 0 y 3 s.

Ahora, al ser golpeado:

- queda invulnerable;
- se queda quieto, cambiando su estrategia de movimiento (Strategy) por `MovimientoInducido(null, 0)`, como el Erizo de mar;
- un segundo después vuelve a `MovimientoTeletransporte(3000)`. Como la estrategia es nueva, se teletransporta en la vuelta siguiente, y `teletransportarse()` lo vuelve vulnerable.

Se usa el gancho `alSerGolpeado()` (Template Method) y `programar(...)`, que ya existían. No hay atributos ni métodos nuevos, así que el diagrama no cambia.

## 13. Parpadeo durante la invulnerabilidad

Antes, toda entidad que recibía daño parpadeaba 600 ms, durara lo que durara su invulnerabilidad. Ahora, los que quedan invulnerables después de un golpe parpadean **exactamente mientras son invulnerables**. Así se ve cuándo no se les puede pegar, como en el Zelda original.

| Quién | Invulnerable | Parpadea |
|---|---|---|
| Wizzrobe | 1 s, hasta que se teletransporta | 1 s |
| MasterStalfos | 800 ms | 800 ms |
| Link | 1 s | 1 s |
| Moblin, Moblin con escudo, Octorok, Erizo | no | 600 ms, solo para mostrar el golpe (como antes) |
| StoneHinox | casi siempre, salvo 1 s después de la embestida | 600 ms cuando recibe daño (sin marca mientras es invulnerable) |
| Trampa de cuchillas | siempre | nunca |

| Clase | Se agrega |
|---|---|
| `EntidadAnimada*` | `# parpadearDurante(ms : long)`: estira `finParpadeo` hasta `ahora + ms` sin acortarlo (`Math.max`) y avisa a la vista |
| `Wizzrobe`, `MasterStalfos`, `Link` | Su `alSerGolpeado()` llama a `parpadearDurante` con el tiempo de su invulnerabilidad. No cambia en el diagrama |

En un golpe, primero `aplicarDanio` arranca el parpadeo de 600 ms y después `alSerGolpeado()` lo estira. `avisarParpadeo()`, `esVisible()`, `aplicarDanio` y `CeldaGrafica` no cambian.

## 14. Imagen de ataque con espada del MasterStalfos

> **Reemplazado por el cambio 44:** las imágenes de esta sección se cambiaron por GIFs y el golpe ya no elige el lado según Link. Se deja la sección como registro.

Antes, el MasterStalfos golpeaba con la espada sin cambiar de imagen: siempre usaba la de caminar según su dirección. Ahora muestra el golpe en dos pasos, primero con la espada levantada y después con la espada abajo, del lado donde está Link.

### Cómo funciona

Se resuelve **igual que el golpe de Link** (cambio 10): un contador de vueltas que arranca al golpear, se descuenta en cada vuelta del hilo del mundo y decide la imagen en `getRutaImagen()`. No se agregan clases ni relaciones, y el ataque en sí (`AtaqueEspada`, `quiereAtacar()`, las fases de 2 s) no cambia.

1. **Golpe.** En la fase de espada, `AtaqueEspada.atacar()` pregunta `quiereAtacar()`. Si Link está en la zona de la espada, lo golpea y llama a `ataqueRealizado()`. Ese gancho ya existía en `EntidadAnimada` (vacío) y Link ya lo redefinía.
2. **Arranque.** `MasterStalfos.ataqueRealizado()` pone `vueltasMostrandoGolpe = VUELTAS_IMAGEN_GOLPE` y avisa a la vista. Solo lo hace si el contador está en 0: como `AtaqueEspada` llama al gancho en cada vuelta mientras Link sigue en la zona, sin esa condición el contador se reiniciaría siempre y la espada nunca bajaría.
3. **Descuento.** `actualizarEstado(c)` hace la vuelta normal (`super.actualizarEstado(c)`) y después descuenta una vuelta. Avisa a la vista solo en los dos momentos en que cambia la imagen: cuando baja la espada y cuando vuelve a la de caminar.
4. **Imagen.** `getRutaImagen()` arma el estado `ataque-<altura>-<lado>`:
   - `<altura>` es `arriba` en las primeras `VUELTAS_ESPADA_ARRIBA` vueltas y `abajo` en las que quedan.
   - `<lado>` es `izquierda` si Link está a la izquierda del centro del cuerpo del MasterStalfos (`getX() + CUERPO_MARGEN_X + CUERPO_ANCHO / 2`), y `derecha` si no. Se usa el centro del cuerpo y no `getX()` porque la imagen tiene márgenes.
   - Si el contador está en 0, o el sprite no tiene ese estado, usa la imagen de caminar (`super.getRutaImagen()`).

### Tiempos

El hilo del mundo da una vuelta cada 30 ms.

| Momento | Vueltas | Tiempo aprox. | Imagen |
|---|---|---|---|
| Golpe | 16 → 10 | 0 a 210 ms | `masterstalfos-ataque-arriba-<lado>.png` |
| Baja la espada | 9 → 1 | 210 a 480 ms | `masterstalfos-ataque-abajo-<lado>.png` |
| Fin | 0 | desde 480 ms | `masterstalfos-<dirección>.png` |

Mientras Link sigue en la zona de la espada, el golpe se repite enseguida (en el juego se ve como un ataque continuo). En la fase de contacto no hay golpe de espada, así que la imagen no cambia. El daño a Link no cambia: lo sigue limitando su invulnerabilidad de 1 s.

### Comparación con Link

| | Link | MasterStalfos |
|---|---|---|
| Quién llama a `ataqueRealizado()` | `AtaqueRecargado`, al soltar la tecla | `AtaqueEspada`, cuando Link está en la zona |
| Contador | `# vueltasMostrandoGolpe : int` | `- vueltasMostrandoGolpe : int` |
| Duración | `VUELTAS_IMAGEN_GOLPE = 7` (~200 ms) | `VUELTAS_IMAGEN_GOLPE = 16` (~480 ms), de las cuales `VUELTAS_ESPADA_ARRIBA = 7` con la espada arriba |
| Dónde se descuenta | `actualizarEstado(c)` | `actualizarEstado(c)` |
| Imagen | `ataque-<dirección>` | `ataque-<arriba/abajo>-<lado de Link>` |
| Si falta la imagen | usa la de caminar | usa la de caminar |

### En los diagramas

| Diagrama | Cambio |
|---|---|
| Extendido (las dos estrategias) | En la caja `MasterStalfos`, en naranja: `- vueltasMostrandoGolpe : int`, `- VUELTAS_IMAGEN_GOLPE : int = 16` y `- VUELTAS_ESPADA_ARRIBA : int = 7` (subrayados, son de clase), `+ ataqueRealizado()`, `+ actualizarEstado(c : AdministradorColisiones)` y `+ getRutaImagen() : String`. La caja crece 6 líneas y se corren las de abajo |
| Reducido | No cambia: no hay clases ni relaciones nuevas. `AdministradorColisiones` llega como parámetro, igual que en `EntidadAnimada` y `Link`, y el reducido no dibuja esas dependencias |
| `FabricaSprites*` | No cambia: es el mismo método, solo arma más estados |

### Recursos

Las imágenes `masterstalfos-ataque-arriba-izquierda.png`, `-abajo-izquierda.png`, `-arriba-derecha.png` y `-abajo-derecha.png` (144 × 144, el mismo tamaño que las de caminar) se recortaron de la hoja de sprites del equipo (cuadros 1, 4, 5 y 8 del ataque), sin fondo. Están en `original/` y en `alternativa/`: `armar` arma la ruta con la carpeta del modo gráfico, así que tienen que estar en las dos.

## 15. Constantes con nombre, ranking sin nombres repetidos y estilo nuevo de las pantallas

Viene del código de la PC de Ani (`p-comision-19-master\Codigo`). Ese código partía de una versión anterior a la defensa 7 (sin cuerpos ajustados, capas, parpadeo ni bloqueo), así que **no se copió entero**: se pasaron solo sus tres mejoras al código de esta carpeta, y se mantuvo todo lo de los cambios 1 a 14. Este cambio está en las dos estrategias, pero no en `defensa 7/Codigo`.

### 15.1. Constantes con nombre en lugar de números sueltos

Los números que estaban escritos directo en el código pasan a ser constantes de clase (`private static final`, salvo que se indique), en la sección `// Atributos de clase`. **Los valores no cambian**, así que el juego se comporta igual. Los comentarios que repetían el número ("Devuelve 100 puntos") pasan a decir qué es ("Devuelve los puntos que da al morir").

| Clase | Constantes nuevas |
|---|---|
| `Juego` | `RACHA_PARA_BELLOTA : int = 4` |
| `Reloj` | `PERIODO : long = 1000` |
| `HiloJugador`, `HiloMundo` | `PERIODO : long = 30` |
| `Clasico`, `Contrarreloj`, `NoHit` | `CANTIDAD_NIVELES : int = 2` |
| `AtaqueAvalancha` | `ROCAS_MINIMAS : int = 5`, `ROCAS_MAXIMAS : int = 10`, `TOLERANCIA_CENTRO : int = 4` |
| `AtaqueRecargado` | `FACTOR_CARGA : int = 2` |
| `Proyectil` | `VIDA : int = 1`, `VELOCIDAD : int = 6` |
| `FabricaEntidades` | `DANIO_DISPARO : int = 1`, `DANIO_ROCA_GRANDE : int = 2` (desde el cambio 42 pasan a `Octorok`, `Wizzrobe` y `StoneHinox`) |
| `PowerUP*` | `PUNTOS : int = 300` |
| `Rupia` | `CANTIDAD_MINIMA : int = 1`, `CANTIDAD_MAXIMA : int = 5`, `PUNTOS_POR_RUPIA : int = 10` |
| `Corazon` | `MEDIOS_CURADOS : int = 2` |
| `Bellota` | `DANIO_MAXIMO : int = 1`, `GOLPES_PROTEGIDOS : int = 3` |
| `Enemigo*` | `DISTANCIA_RETROCESO : int = 8` |
| `EnemigoConDrop*` | `PROBABILIDAD_RUPIA : double = 0.5` |
| `Moblin` | `VIDA = 2`, `PUNTOS = 100`, `PROBABILIDAD_DROP : double = 0.2`, `DANIO_CONTACTO = 1`; protegidas (las usa `MoblinConEspadaYEscudo`): `# VELOCIDAD = 2`, `# INTERVALO_CAMBIO_DIRECCION : long = 1500` |
| `MoblinConEspadaYEscudo` | `PUNTOS = 300`, `PROBABILIDAD_DROP = 0.5`, `VELOCIDAD_ABALANZADA = 6`, `DURACION_ABALANZADA : long = 800` |
| `ErizoDeMar` | `VIDA = 1`, `PUNTOS = 50`, `PROBABILIDAD_DROP = 0.2`, `DANIO_CONTACTO = 1`, `VELOCIDAD = 0` |
| `Octorok` | `VIDA = 1`, `PUNTOS = 150`, `PROBABILIDAD_DROP = 0.4`, `VELOCIDAD = 2`, `INTERVALO_CAMBIO_DIRECCION = 1500`, `CANTIDAD_DISPAROS = 1`, `INTERVALO_DISPARO = 2000` |
| `Wizzrobe` | `VIDA = 2`, `PUNTOS = 500`, `PROBABILIDAD_DROP = 1.0`, `INTERVALO_TELETRANSPORTE = 3000`, `CANTIDAD_DISPAROS = 1`, `INTERVALO_DISPARO = 3000`, `DURACION_INVULNERABILIDAD = 1000` |
| `TrampaDeCuchillas` | `VIDA = 1`, `PUNTOS = 0`, `DANIO_CONTACTO = 1` |
| `StoneHinox` | `VIDA = 10`, `PUNTOS = 5000`, `DANIO_EMBESTIDA = 2`, `CANTIDAD_ROCAS = 3`, `INTERVALO_ROCAS = 2000` (400 desde el cambio 41), `VELOCIDAD = 2`, `INTERVALO_CAMBIO_DIRECCION = 1500`, `DEMORA_PRIMER_ATAQUE = 3000`, `VELOCIDAD_EMBESTIDA = 6`, `DURACION_EMBESTIDA = 1500`, `DURACION_VULNERABILIDAD = 1000`, `DURACION_LANZAMIENTO_ROCAS = 3000`, `VELOCIDAD_AVALANCHA = 3` |
| `MasterStalfos` | `VIDA = 5`, `PUNTOS = 5000`, `VELOCIDAD = 3`, `INTERVALO_CAMBIO_DIRECCION = 1200`, `DANIO_ESPADA = 2`, `DANIO_CONTACTO = 1`, `DURACION_INVULNERABILIDAD = 800` |
| `Link` | `VIDAS_INICIALES = 3`, `MEDIOS_CORAZONES_INICIALES = 6`, `VELOCIDAD_CAMINANDO = 4`, `FACTOR_RALENTIZACION = 2`, `DANIO_ESPADA = 1`, `ALCANCE_ESPADA = 32`, `DURACION_INVULNERABILIDAD = 1000`, `DEMORA_ROTURA_SUELO = 500`, `FRAGMENTOS_POR_CORAZON = 4`, `AUMENTO_VIDA_MAXIMA = 2` |

Donde no se indica el tipo, es `int`; las duraciones, demoras e intervalos son `long` y las probabilidades `double`.

Notas:

- **Se mantienen las constantes de la defensa 7** que el código de la PC no tenía: los `CUERPO_*` de todos los enemigos y de Link (el código de la PC usaba `CUERPO_LADO = 96` en el StoneHinox, que no se pasó), `VELOCIDAD_SALIDA` y `VELOCIDAD_VUELTA` de la trampa (en lugar de su `VELOCIDAD = 8`) y los `VUELTAS_*` de Link y del MasterStalfos.
- En `Link`, el constructor ya no declara las variables locales `velocidadCaminando`, `danioEspada` y `alcanceEspada`: usa las constantes.
- `Wizzrobe.DURACION_INVULNERABILIDAD` es nueva también respecto del código de la PC, porque ese código no tenía el cambio 12. Reemplaza el `1000` de `parpadearDurante` y `programar`, igual que en `Link` y `MasterStalfos`. El `3000` del teletransporte de después del golpe pasa a usar `INTERVALO_TELETRANSPORTE`.

### 15.2. `Ranking.insertar`: un solo puntaje por nombre

Antes se agregaba la entrada y se ordenaba la lista, así que el mismo nombre podía aparecer varias veces. Ahora:

1. Si el nombre ya está en el ranking (se distinguen mayúsculas y minúsculas) con un puntaje **igual o mayor**, no se guarda y devuelve `false`.
2. Si estaba con un puntaje menor, se quita esa entrada vieja.
3. Si el puntaje no entra en el top 5, no se guarda y devuelve `false`, como antes.
4. La nueva se inserta en su lugar, recorriendo la lista hasta el primer puntaje menor (ya no se ordena la lista entera).
5. Si quedan más de 5 entradas, se quita la última, como antes.

La firma no cambia, así que el diagrama tampoco.

### 15.3. Estilo nuevo de las pantallas

Solo cambia cómo se ven las pantallas. Los métodos públicos y el funcionamiento son los mismos.

| Clase | Cambio |
|---|---|
| `GUI` | El título de la ventana pasa a ser "The Legend of Zelda: Link's Awakening" |
| `PanelVista*` | 4 constantes de color nuevas, `# COLOR_FONDO`, `# COLOR_SUPERFICIE`, `# COLOR_DORADO` y `# COLOR_TEXTO` (`protected static final Color`). El fondo usa `COLOR_FONDO` y la franja del HUD pasa de 40 a 56 px |
| `PanelPantallaPrincipal` | Título "THE LEGEND OF ZELDA / LINK'S AWAKENING", botones dorados (el elegido relleno), una descripción del modo elegido debajo de los botones de modo y una línea de ayuda con las teclas |
| `PanelPantallaNivel` | El HUD dibuja los corazones (llenos, medio y vacíos), muestra el tiempo como `mm:ss` y usa los colores de `PanelVista`. El suelo es verde. Consulta nueva `- etiqueta(titulo : String, valor : String) : String` (de clase), que arma el texto de cada etiqueta. **Se mantiene** el `agregarCelda` por capas del cambio 5 |
| `PanelPantallaRanking` | Título y columnas en mayúsculas, filas alternadas, los tres primeros puestos en dorado, plata y bronce, y la fila "Todavía no hay puntajes" cuando el ranking está vacío |

### En los diagramas

| Diagrama | Cambio |
|---|---|
| Extendido (las dos estrategias) | En naranja y subrayadas (son de clase), las constantes de 15.1 en sus cajas, los 4 colores de `PanelVista*` (sin valor inicial, para que entren en la caja) y `- etiqueta(titulo : String, valor : String) : String` en un «consultas» nuevo de `PanelPantallaNivel` (la caja se ensancha de 319 a 345). `EnemigoConDrop*` no tenía sección de atributos y se le agrega. Las cajas crecen y empujan hacia abajo a las de su columna; ninguna se pisa. La línea de separación del título del `StoneHinox` se reubica para que siga debajo del nombre |
| Reducido | No cambia: no hay clases ni relaciones nuevas (`Color` es de Java) |

### Cómo se probó

- Las dos copias compilan con `javac`.
- El juego se corrió en una pantalla virtual (Xvfb): el menú y el nivel 1 se ven con el estilo nuevo, con los corazones en el HUD.

## 16. Correcciones de formato en el extendido

Se comparó por programa el código compilado de esta carpeta con el extendido: clases, atributos y métodos, con su visibilidad, tipos, parámetros, retorno, si son de clase y si son abstractos. Todo coincidía salvo seis marcas de formato del diagrama, que se corrigieron (en naranja y negrita):

| Clase | Antes | Ahora | Por qué |
|---|---|---|---|
| `Sector` | `+ getCentro() : Posicion` subrayado (de clase) | sin subrayar | En el código es un método de instancia |
| `Clasico`, `Contrarreloj`, `NoHit` | `+ getRanking(j : Juego) : Ranking` en cursiva (abstracto) | sin cursiva | Cada modo lo implementa; el abstracto es el de `ModoJuego*`, que sigue en cursiva |
| `Obstaculo*` | `+ afectar(l : Link)` en cursiva | sin cursiva | Tiene cuerpo: por defecto no hace nada |
| `PowerUP*` | `+ serRecogidoPor(l : Link)` en cursiva | sin cursiva | Tiene cuerpo: avisa a Link y se elimina |

No se dibujan los constructores por defecto de `FabricaSprites*` y `Principal`, porque no están escritos en el código. El código y el reducido no cambian.

## 17. Correcciones de la defensa 6: interfaces chicas para los colaboradores de `Juego`

Este cambio responde a la devolución de la defensa 6. El ayudante marcó tres cosas:

1. **Casi todos los colaboradores de `Juego` reciben el `Juego` entero**: `new Reloj(this)`, `new FabricaEntidades(this, dominio)`, `modoJuego.registrarPuntaje(this, e)`, `modoJuego.alRecibirDanio(this)`, `m.getRanking(this)`. Funciona, pero cada uno puede llamar a cualquiera de los métodos públicos de `Juego`. Preguntó qué necesita el `Reloj` de `Juego` (solo `tic(int)`) y qué se gana si recibe una interfaz de un solo método.
2. **¿Para qué son públicos `getJugador()`, `getFabricaEntidades()` y `getNumeroNivel()`?** `getJugador()` devolvía `Link` y deshacía el encapsulamiento que consigue `getControlJugador()`.
3. **`terminarPartida()` preguntaba `reloj.estaActivo()`**: ¿si se pausa el reloj, terminó la partida?

### 17.1. Idea: cada colaborador ve solo lo que usa

Es el **principio de segregación de interfaces**: un cliente no debería depender de métodos que no usa. Ya lo aplicábamos con la vista, que no ve `Juego` sino `ControladorJuego`. Ahora `Juego` implementa una interfaz chica por cada tipo de colaborador:

| Interfaz nueva | Paquete | Métodos | Quién la usa |
|---|---|---|---|
| `OyenteReloj` | `logica.hilos` | `tic(segundos : int)` | `Reloj` |
| `ArbitroPartida` | `logica.juego` | `terminarPartida()` | `ModoJuego*` y sus modos, en `alRecibirDanio` y `alPasarTiempo` |
| `TablaRankings` | `logica.juego` | `agregarAlRankingClasico/Contrarreloj/NoHit(e)` y `getRankingClasico/Contrarreloj/NoHit()` | `ModoJuego*` y sus modos, en `registrarPuntaje` y `getRanking` |
| `EntornoJuego` | `logica.entidades` | `agregarEntidad`, `cambiarDeSector`, `enemigoDerrotado`, `jefeDerrotado`, `powerUpRecogido`, `jugadorDaniado`, `jugadorSinVidas`, `jugadorCayoAlVacio`, `getFabricaEntidades() : FabricaEntidades` y `getJugador() : Entidad` | `FabricaEntidades` y todas las entidades (`Entidad.miJuego`) |

`Juego` queda así:

```java
public class Juego implements ControladorJuego, OyenteReloj, ArbitroPartida, TablaRankings, EntornoJuego {
```

Cada método que viene de una interfaz lleva ahora `@Override`. **Ningún colaborador tiene una referencia de tipo `Juego`**: solo `Principal`, que lo crea. Cada uno guarda o recibe su interfaz.

Qué se gana:

- **El compilador impide el mal uso.** El `Reloj` no puede llamar a `terminarPartida()` ni a `iniciar()`, porque no los ve. Un modo no puede tocar los hilos ni el nivel.
- **Menos acoplamiento.** Si cambia un método de `Juego` que no está en una interfaz, no afecta a ningún colaborador.
- **Se corta la dependencia entre paquetes `hilos` → `juego`.** Antes `logica.hilos.Reloj` importaba `logica.juego.Juego` y `Juego` importaba `Reloj`. Ahora `OyenteReloj` está en `logica.hilos`, junto al `Reloj`, y el reloj no conoce el paquete `juego`. Lo mismo pasa con `Entidad` y `FabricaEntidades`: ya no importan `logica.juego.Juego`.
- **Reutilizable y fácil de probar.** El `Reloj` sirve para cualquiera que quiera recibir un aviso por segundo, y se puede probar sin armar un `Juego`.
- **El diagrama muestra qué necesita cada uno**: la flecha va a una interfaz chica y no a la clase más grande del sistema.

### 17.2. Rankings: interfaz `TablaRankings` (opción B)

Los modos usan `Juego` para dos cosas: terminar la partida y guardar o leer su ranking. Se eligió mantener los tres rankings y la `PersistenciaRanking` dentro de `Juego` y agruparlos detrás de la interfaz `TablaRankings`. Así no cambian las relaciones de `Juego` con `Ranking` (◆ `#rankings 3`) ni con `PersistenciaRanking`, y el menú sigue pudiendo pedir los rankings antes de jugar.

El doble despacho de los modos (sin `instanceof`) sigue igual, solo cambia el tipo del parámetro:

```java
// ModoJuego*
public abstract void registrarPuntaje(TablaRankings t, EntradaRanking e);
public void alRecibirDanio(ArbitroPartida a) { }
public void alPasarTiempo(ArbitroPartida a, int segundos) { }
public abstract Ranking getRanking(TablaRankings t);

// NoHit
@Override
public void registrarPuntaje(TablaRankings t, EntradaRanking e) {
    t.agregarAlRankingNoHit(e);
}

@Override
public void alRecibirDanio(ArbitroPartida a) {
    a.terminarPartida();
}

@Override
public Ranking getRanking(TablaRankings t) {
    return t.getRankingNoHit();
}
```

En `Juego` las llamadas no cambian de forma, porque `this` se pasa como la interfaz que pide cada método:

```java
modoJuego.registrarPuntaje(this, entradaNueva);   // this como TablaRankings
modoJuego.alRecibirDanio(this);                  // this como ArbitroPartida
modoJuego.alPasarTiempo(this, segundos);         // this como ArbitroPartida
Ranking rankingDelModo = m.getRanking(this);     // this como TablaRankings
```

![Secuencia: registrar el puntaje](imagenes-cambio-17/secuencia-ranking.png)

### 17.3. Reloj, fábrica y entidades

```java
// Reloj: ya no importa logica.juego.Juego
protected OyenteReloj oyente;

public Reloj(OyenteReloj o) {
    super(PERIODO);
    oyente = o;
    segundos = 0;
}

@Override
protected void ciclo() {
    segundos++;
    oyente.tic(segundos);
}
```

```java
// FabricaEntidades: ya no importa logica.juego.Juego
protected EntornoJuego entorno;

public FabricaEntidades(EntornoJuego entorno, FabricaSprites fabricaSprites) {
    this.entorno = entorno;
    this.fabricaSprites = fabricaSprites;
}
// en cada crearX(...): entidad.setJuego(entorno);

// Entidad: ya no importa logica.juego.Juego
protected EntornoJuego miJuego;
public void setJuego(EntornoJuego j) { miJuego = j; }
public EntornoJuego getJuego() { return miJuego; }
```

Los nombres `miJuego`, `setJuego` y `getJuego` se mantienen para no tocar las más de 20 llamadas de las entidades (`Link`, `Enemigo`, `Jefe`, `EnemigoConDrop`, `Octorok`, `Wizzrobe`, `StoneHinox`, `TrampaDeCuchillas`, `MasterStalfos` y `AtaquePorProyectil`). Todas siguen compilando porque los métodos que llaman están en `EntornoJuego`.

### 17.4. Los getters públicos que marcó el ayudante

| Método | Antes | Ahora | Por qué |
|---|---|---|---|
| `getNumeroNivel() : int` | público en `Juego` | **se borra** | No lo usaba nadie |
| `getTiempo() : int` | público en `Juego` | **se borra** | Tampoco lo usaba nadie (el ayudante no lo nombró, pero estaba igual) |
| `getJugador()` | `: Link`, público en `Juego` | `: Entidad`, en `EntornoJuego` | Las entidades solo lo usan para ubicar a Link (`getHitbox()`, `getCentro()`, `getPosicion()`, `getX()`), y todo eso está en `Entidad`. Devolver `Link` dejaba hacer `getJugador().sumarPuntos(...)` o `perderVida()` desde cualquier lado |
| `getFabricaEntidades()` | público en `Juego` | en `EntornoJuego` | Lo necesitan las entidades que crean otras: `Link` (caída al vacío), `EnemigoConDrop` (drops), `Octorok` y `Wizzrobe` (proyectiles) y `StoneHinox` (rocas) |

El único cambio en las entidades es en `EntidadAnimada`: `Link link = miJuego.getJugador();` pasa a `Entidad link = miJuego.getJugador();` en `linkEstaEnfrente()` y `hayObstaculoHastaJugador()`.

`Juego` sigue guardando `# jugador : Link`, porque él sí necesita `sumarPuntos`, `getRacha`, `getPuntaje`, etc. Lo que cambia es lo que muestra hacia afuera.

### 17.5. `terminarPartida()` con su propio estado

El `if (reloj.estaActivo())` usaba el estado de un **hilo** para responder algo de la **partida**. Funcionaba de casualidad, porque `pausar()` cambia `pausado` y no `activo`. Si mañana se pausa o se detiene el reloj por otra razón (un menú de pausa, o durante las transiciones para que el Contrarreloj no descuente tiempo), `terminarPartida()` quedaba atado a ese detalle. Además, si se llamaba antes de `iniciar()`, `reloj` era `null`.

Ahora `Juego` tiene `# partidaEnCurso : boolean`:

```java
public void iniciar(ModoJuego modo, FabricaSprites dominio) {
    ...
    cargarNivel();
    partidaEnCurso = true;
    reloj.iniciar();
    hiloJugador.iniciar();
    hiloMundo.iniciar();
}

@Override
public synchronized void terminarPartida() {
    if (partidaEnCurso) {
        partidaEnCurso = false;
        reloj.detener();
        hiloJugador.detener();
        hiloMundo.detener();
        ...
    }
}
```

Sigue cubriendo lo que protegía el `if` anterior: que dos avisos terminen la partida dos veces. Como el método es `synchronized`, el segundo aviso encuentra `partidaEnCurso == false` y no hace nada.

![Secuencia: el Contrarreloj se queda sin tiempo](imagenes-cambio-17/secuencia-contrarreloj.png)

![Secuencia: dos avisos de fin en el mismo momento](imagenes-cambio-17/secuencia-dos-avisos.png)

### 17.6. En los diagramas

**Reducido** (`Diagrama-reducido-bloqueaPasoA.drawio`):

- Se agregan `<<Interface>> OyenteReloj`, `ArbitroPartida`, `TablaRankings` y `EntornoJuego`, cada una con su realización punteada desde `Juego`.
- `Reloj → Juego (#juego 1)` pasa a `Reloj → OyenteReloj (#oyente 1)`.
- `Entidad* → Juego (#miJuego 1)` pasa a `Entidad* → EntornoJuego (#miJuego 1)`.
- Se dibuja `FabricaEntidades → EntornoJuego (#entorno 1)`. Antes faltaba la flecha `FabricaEntidades → Juego`, aunque el atributo existía.
- `ModoJuego*` recibe `ArbitroPartida` y `TablaRankings` solo como parámetros: es una dependencia y no se dibuja, igual que antes con `Juego`.
- `GeneradorNivel` sube, arriba a la derecha de `Juego`, para dejar lugar a `ArbitroPartida` y `EntornoJuego`. Su relación no cambia.
- Totales: 94 clases/interfaces y 131 relaciones (124 dibujadas); antes 90 y 126 (119 dibujadas). Se suman 4 interfaces, 4 realizaciones y la asociación `FabricaEntidades → EntornoJuego`.

![Reducido antes](imagenes-cambio-17/red-antes.png)

![Reducido después](imagenes-cambio-17/red-desp.png)

**Extendido** (`Diagrama-extendido-bloqueaPasoA.drawio`), en naranja y negrita lo cambiado y con fondo amarillo las cuatro interfaces nuevas:

| Clase | Se quita | Se agrega o cambia |
|---|---|---|
| `Juego` | `+ getNumeroNivel() : int`, `+ getTiempo() : int`, `+ getJugador() : Link` | subtítulo "implementa ControladorJuego, OyenteReloj, ArbitroPartida, TablaRankings, EntornoJuego"; `# partidaEnCurso : boolean`; `+ getJugador() : Entidad` |
| `Reloj` | `# juego : Juego`, `+ Reloj(j : Juego)` | `# oyente : OyenteReloj`, `+ Reloj(o : OyenteReloj)` |
| `ModoJuego*`, `Clasico`, `Contrarreloj`, `NoHit` | los parámetros `j : Juego` | `registrarPuntaje(t : TablaRankings, e : EntradaRanking)`, `getRanking(t : TablaRankings) : Ranking`, `alRecibirDanio(a : ArbitroPartida)`, `alPasarTiempo(a : ArbitroPartida, segundos : int)` |
| `FabricaEntidades` | `# juego : Juego`, `FabricaEntidades(juego : Juego, …)` | `# entorno : EntornoJuego`, `FabricaEntidades(entorno : EntornoJuego, fabricaSprites : FabricaSprites)` |
| `Entidad*` | `# miJuego : Juego`, `setJuego(j : Juego)`, `getJuego() : Juego` | `# miJuego : EntornoJuego`, `+ setJuego(j : EntornoJuego)`, `+ getJuego() : EntornoJuego` |
| `OyenteReloj`, `ArbitroPartida`, `EntornoJuego` (nuevas, debajo de `Juego`) | — | sus métodos, como en la tabla de 17.1 |
| `TablaRankings` (nueva, debajo de `PersistenciaRanking`) | — | sus 6 métodos |

Para que entren las firmas nuevas, las cajas de los modos se ensancharon y la columna de `Ranking`, `EntradaRanking` y `PersistenciaRanking` se corrió un poco a la derecha.

![Extendido antes](imagenes-cambio-17/ext-antes.png)

![Extendido después](imagenes-cambio-17/ext-desp.png)

![Extendido después: FabricaEntidades y Entidad](imagenes-cambio-17/ext-fabrica-entidad.png)

### 17.7. Archivos tocados

| Archivo (`Codigo/src/…`) | Qué cambió |
|---|---|
| `logica/hilos/OyenteReloj.java` (nuevo) | Interfaz con `tic(segundos)` |
| `logica/juego/ArbitroPartida.java` (nuevo) | Interfaz con `terminarPartida()` |
| `logica/juego/TablaRankings.java` (nuevo) | Interfaz con los 3 `agregarAlRankingX(e)` y los 3 `getRankingX()` |
| `logica/entidades/EntornoJuego.java` (nuevo) | Interfaz con los 8 avisos de las entidades, `getFabricaEntidades()` y `getJugador() : Entidad` |
| `logica/juego/Juego.java` | Implementa las 4 interfaces nuevas, `@Override` en sus métodos, `partidaEnCurso`, `getJugador() : Entidad`; se borran `getNumeroNivel()` y `getTiempo()` |
| `logica/hilos/Reloj.java` | `# oyente : OyenteReloj` en vez de `# juego : Juego` |
| `logica/juego/ModoJuego.java`, `Clasico.java`, `Contrarreloj.java`, `NoHit.java` | Parámetros `TablaRankings` y `ArbitroPartida` en vez de `Juego` |
| `logica/fabricas/FabricaEntidades.java` | `# entorno : EntornoJuego` en vez de `# juego : Juego` |
| `logica/entidades/Entidad.java` | `miJuego`, `setJuego` y `getJuego` con `EntornoJuego` |
| `logica/entidades/EntidadAnimada.java` | `Entidad link` en vez de `Link link` en 2 métodos |

Como el cambio 15, el 17 tiene su detalle acá y no se repite en **Detalle archivo por archivo**.

### 17.8. Cómo se probó

- Las dos estrategias compilan con `javac`.
- Un programa sin interfaz gráfica armó un `Juego` real con una vista de prueba que cuenta los avisos de fin, en las dos estrategias:
  - `terminarPartida()` antes de `iniciar()` no hace nada (antes daba `NullPointerException`).
  - En Clásico, dos `terminarPartida()` seguidos piden el nombre o muestran el ranking una sola vez.
  - En NoHit, dos `jugadorDaniado()` seguidos terminan la partida una sola vez (por `ArbitroPartida`).
  - En Contrarreloj de 2 segundos, el `Reloj` (por `OyenteReloj`) termina la partida una sola vez.
  - `registrarPuntaje` y `getRanking` del modo Clásico usan el ranking Clásico (por `TablaRankings`).

## 18. Imagen del ataque recargado de Link

Antes, el golpe de Link se veía siempre igual, cargado o no. Ahora, cuando la espada lleva 3 s cargada (`TIEMPO_CARGA`), Link muestra la espada negra con amarillo, y esa imagen se mantiene mientras se ve el golpe.

### Cómo funciona

Se resuelve con lo que ya existía: el estado de imagen de Link (cambio 10), la consulta `AtaqueRecargado.estaCargado()` y el **Observer** que avisa a la vista. No se agregan atributos, métodos, clases ni relaciones.

1. **Imágenes.** `FabricaSprites.crearSpritesLink()` arma cuatro estados más: `ataque-recargado-abajo`, `-arriba`, `-izquierda` y `-derecha`.
2. **Elegir la imagen.** En `Link.getRutaImagen()`, cuando está atacando o mostrando el golpe, el estado es `ataque-recargado-<dir>` si `recargado.estaCargado()` da `true`, y `ataque-<dir>` si no.
3. **Cambio a los 3 s.** La vista solo redibuja a Link cuando él avisa. Por eso `Link.actualizarEstado(c)` pregunta en cada vuelta: si está atacando y la espada ya está cargada, llama a `notificarObservers()`. Así la espada cambia apenas termina la carga, aunque Link esté quieto.
4. **Mantener la imagen después del golpe.** `AtaqueRecargado.atacar` ya no pone `inicioCarga = -1` al golpear. La hora de carga se pisa recién en el próximo `cargar()`. Así, durante las 7 vueltas de `vueltasMostrandoGolpe`, `estaCargado()` sigue diciendo si el golpe fue recargado. El daño no cambia: `atacar` solo golpea después de un `cargar()` nuevo, que reinicia la hora.

### Tiempos

| Momento | Imagen |
|---|---|
| Aprieta A (0 ms) | `link-ataque-<dir>.png` |
| Mantiene A, 3000 ms | `link-ataque-recargado-<dir>.png` (la avisa `actualizarEstado`) |
| Suelta A | Golpe con daño 2 y alcance 64, misma imagen unos 210 ms (7 vueltas) |
| Fin del golpe | `link-<dir>.png` |

Si suelta antes de los 3 s, el golpe es normal y se ve `link-ataque-<dir>.png`, como antes.

### En los diagramas

| Diagrama | Cambio |
|---|---|
| Extendido | No cambia: `getRutaImagen()`, `actualizarEstado(c)`, `estaCargado()` e `inicioCarga` ya estaban dibujados. `TIEMPO_CARGA` sigue privado |
| Reducido | No cambia: no hay clases ni relaciones nuevas |

### Recursos

Las imágenes `link-ataque-recargado-abajo.png`, `-arriba.png`, `-izquierda.png` y `-derecha.png` se recortaron de la hoja de sprites del ataque con espada (el segundo cuadro del ataque recargado, el de la punta roja), sin fondo. Tienen el mismo tamaño que las de ataque normal: 48 × 96 para abajo y arriba, y 96 × 48 para los costados. La de la derecha es la de la izquierda en espejo, porque la hoja solo trae el golpe hacia la izquierda. Están en `original/` y en `alternativa/`.

### Cómo se probó

- El código compila con `javac`.
- No se probó todavía en el juego real.

## 19. Moblin con espada y escudo: imagen con la espada

Antes, el `MoblinConEspadaYEscudo` usaba imágenes de 48 × 48 iguales a las de un Moblin común, sin espada ni escudo. Ahora usa siempre el primer cuadro del ataque de la hoja de sprites del equipo: el Moblin azul con la espada afuera y, mirando hacia abajo, también con el escudo. La imagen no cambia al golpear: es la misma al caminar y al atacar.

### Cómo funciona

La vista dibuja cada entidad desde `getX()`/`getY()`, la esquina de su imagen. Como la espada sale hacia arriba, abajo, izquierda o derecha según la dirección, las cuatro imágenes se arman en un lienzo de 96 × 96 con el cuerpo azul siempre en el centro (de 24 a 72 px). Así el dibujo del cuerpo no se corre al girar.

1. **Cuerpo de colisión.** Es el mismo del `Moblin` (40 × 40), corrido 24 px hacia adentro del lienzo: `setCuerpo(CUERPO_MARGEN_X, CUERPO_MARGEN_Y, CUERPO_ANCHO, CUERPO_ALTO)` con `28, 28, 40, 40`.
2. **Posición.** El constructor llama a `super(sprite, x - MARGEN_IMAGEN, y - MARGEN_IMAGEN)`, con `MARGEN_IMAGEN = 24`. El cuerpo queda exactamente donde estaba antes: con `(x, y) = (96, 96)`, el cuerpo está en `(100, 100)` como en un Moblin común.
3. **Drop.** `EnemigoConDrop.generarDrop()` crea la rupia o el corazón en la esquina del cuerpo (`getHitbox().getX()`, `getY()`) en vez de la esquina de la imagen. Sin esto, el drop del Moblin con espada aparecería 24 px arriba a la izquierda. En los otros enemigos el drop se corre solo su margen de 2 a 13 px.

Las colisiones no cambian: el bloqueo, el daño por contacto, la espada de Link, `linkEstaEnfrente()` y `hayObstaculoHastaJugador()` miran solo el cuerpo. La espada y el escudo del dibujo no lastiman ni frenan, y el escudo sigue funcionando con `DefensaPorEscudo(true)`. La imagen puede dibujarse encima de una roca o de Link, como ya pasa con la espada de Link.

### En los diagramas

| Diagrama | Cambio |
|---|---|
| Extendido | En la caja `MoblinConEspadaYEscudo`, en naranja y subrayadas (son de clase): `- MARGEN_IMAGEN : int = 24`, `- CUERPO_MARGEN_X : int = 28`, `- CUERPO_MARGEN_Y : int = 28`, `- CUERPO_ANCHO : int = 40` y `- CUERPO_ALTO : int = 40`. La caja crece 5 líneas y se corren las 4 de abajo de su columna. `EnemigoConDrop` no cambia de firma |
| Reducido | No cambia: no hay clases ni relaciones nuevas |

### Recursos

`moblinconespadayescudo-abajo.png`, `-arriba.png`, `-izquierda.png` y `-derecha.png` pasan de 48 × 48 a 96 × 96. Se recortaron de la hoja de sprites del Moblin (primer cuadro del ataque de cada dirección), sin fondo, a 3 píxeles de pantalla por píxel de la hoja original. La de la derecha es la de la izquierda en espejo, porque la hoja solo trae el golpe hacia la izquierda. Están en `original/` y en `alternativa/`.

### Cómo se probó

- El código compila con `javac`.
- Un programa sin interfaz crea un `Moblin` y un `MoblinConEspadaYEscudo` en `(96, 96)`: los dos tienen el cuerpo en `(100, 100)` de 40 × 40, y la imagen del segundo empieza en `(72, 72)`.
- No se probó todavía en el juego real.

## 20. Imágenes del StoneHinox: golpe de la avalancha y vulnerable

Antes, el StoneHinox tenía una sola imagen (`stonehinox-normal.png`). Ahora cambia de imagen según lo que hace:

- **Golpe de la avalancha:** cuando llega al centro del sector y larga la avalancha, golpea el suelo con el puño (`stonehinox-avalancha.png`).
- **Vulnerable:** el segundo en que queda vulnerable después de la embestida, se pone naranja (`stonehinox-vulnerable.png`).

### Cómo funciona

Se resuelve como las imágenes de Link y del MasterStalfos: el estado se guarda en la entidad, `getRutaImagen()` elige la imagen y cada cambio avisa a la vista con `notificarObservers()` (**Observer**).

1. **Vulnerable.** `embestidaTerminada()` pone `vulnerable = true` y avisa. Cuando vence `DURACION_VULNERABILIDAD` (1 s), vuelve a ser invulnerable, pone `vulnerable = false`, avisa y pasa al siguiente ataque.
2. **Avalancha.** `AtaqueAvalancha` larga todas las rocas en una sola vuelta y enseguida llama a `ataqueTerminado()`. Antes, ese gancho pasaba directo al siguiente ataque, así que la imagen del golpe no se habría llegado a ver. Ahora `ataqueTerminado()`:
   - pone `golpeandoSuelo = true` y avisa;
   - lo deja quieto (`MovimientoInducido(null, 0)`) con un ataque que no lastima (`AtaquePorContacto(0)`), así no repite la avalancha;
   - a los `DURACION_GOLPE_AVALANCHA` (600 ms) pone `golpeandoSuelo = false`, avisa y elige el siguiente ataque.
3. **Imagen.** `getRutaImagen()` devuelve `vulnerable` si está vulnerable, `avalancha` si está golpeando el suelo y `normal` si no. Si al sprite le falta la imagen, usa la de siempre.

Los atributos son `volatile` porque los escribe el hilo del mundo y los lee la vista. La avalancha no cambia: las rocas, su cantidad y su daño son los mismos. Lo único nuevo es la pausa de 600 ms antes del siguiente ataque.

### Tiempos

| Momento | Imagen |
|---|---|
| Camina, lanza rocas, embiste o va al centro | `stonehinox-normal.png` |
| Llega al centro: cae la avalancha | `stonehinox-avalancha.png` durante 600 ms, quieto |
| Termina la embestida | `stonehinox-vulnerable.png` durante 1 s |

### En los diagramas

| Diagrama | Cambio |
|---|---|
| Extendido | En la caja `StoneHinox`, en naranja: `- vulnerable : boolean`, `- golpeandoSuelo : boolean`, `- DURACION_GOLPE_AVALANCHA : long = 600` (subrayada, es de clase) y `+ getRutaImagen() : String`. `ataqueTerminado()` y `embestidaTerminada()` ya estaban. La caja crece 4 líneas; no tiene cajas debajo |
| Reducido | No cambia: no hay clases ni relaciones nuevas (`MovimientoInducido` y `AtaquePorContacto` ya los usaba) |
| `FabricaSprites*` | No cambia: es el mismo método, solo arma más estados |

### Recursos

`stonehinox-avalancha.png` y `stonehinox-vulnerable.png` (96 × 96, como la normal) se recortaron de la hoja de sprites del StoneHinox, sin fondo: el segundo cuadro (puño contra el suelo) y el tercero (naranja). Se bajaron a 32 × 32 píxeles de la hoja y se agrandaron ×3, igual que la normal (el primer cuadro recortado así da exactamente la imagen que ya estaba). Están en `original/` y en `alternativa/`.

### Cómo se probó

- El código compila con `javac`.
- Un programa sin interfaz crea un StoneHinox con la fábrica de sprites real: empieza con `stonehinox-normal.png`, después de `embestidaTerminada()` devuelve `stonehinox-vulnerable.png` y después de `ataqueTerminado()` devuelve `stonehinox-avalancha.png`.
- Se corrió en el juego real (pantalla virtual, con el jefe en el primer sector de una copia del nivel): en 40 s la imagen de la avalancha apareció 3 veces, unos 600 ms cada una con el jefe quieto, y la naranja después de cada embestida.

## 21. Las rocas de la avalancha desaparecen después de caer

Antes, las rocas de la avalancha caían hasta un lugar libre y se quedaban ahí para siempre: como son invulnerables y cada avalancha larga de 5 a 10, se acumulaban durante toda la pelea. Ahora cada roca queda `PERMANENCIA_EN_PISO` (3 s) en el piso y después desaparece.

### Cómo funciona

- `Proyectil` tiene un atributo nuevo, `aterrizada`, y redefine `actualizarEstado(c)`: hace la vuelta de siempre (`super.actualizarEstado(c)`) y, si tiene `destino`, todavía no aterrizó y ya está en esa posición, pone `aterrizada = true` y programa `desaparecer()` a los 3 s con `programar` (la misma cola de acciones programadas que usan los enemigos).
- Mientras está en el piso sigue siendo invulnerable y sigue lastimando a Link si la toca.
- Los disparos y las rocas que se lanzan en línea recta no tienen `destino`, así que no cambian. `AtaqueAvalancha` tampoco cambia.

### En los diagramas

| Diagrama | Cambio |
|---|---|
| Extendido | En la caja `Proyectil`, en naranja: `# aterrizada : boolean`, `- PERMANENCIA_EN_PISO : int = 3000` (subrayada, es de clase) y `+ actualizarEstado(c : AdministradorColisiones)` |
| Reducido | No cambia: no hay clases ni relaciones nuevas |

### Cómo se probó

- El código compila con `javac`.
- Se corrió en el juego real (pantalla virtual, con el jefe en el primer sector de una copia del nivel): las rocas caen, quedan unos 3 s en el piso y desaparecen, sin acumularse entre una avalancha y la siguiente.

## 22. El drop del enemigo no tapa la bellota

Cuando Link mata 4 enemigos seguidos sin recibir daño, aparece una bellota donde estaba el cuarto. Si ese enemigo era un `EnemigoConDrop` y le tocaba soltar una rupia o un corazón, el drop se creaba en el mismo lugar, después de la bellota, y la tapaba: parecía que la bellota no había aparecido. Ahora, cuando aparece la bellota, ese enemigo no suelta drop.

### Cómo funciona

- `EntornoJuego.enemigoDerrotado(e)` pasa de `void` a `boolean`: devuelve `true` si con esa muerte apareció la bellota.
- `Juego.enemigoDerrotado(e)` hace lo mismo que antes (suma los puntos y la racha, y al llegar a `RACHA_PARA_BELLOTA` reinicia la racha y llama a `aparecerBellota`), y además devuelve si apareció la bellota.
- `EnemigoConDrop.morir()` ya no llama a `super.morir()` y después a `soltarDrop()`. Ahora hace `eliminar()` y llama a `soltarDrop()` solo si `miJuego.enemigoDerrotado(this)` devolvió `false`.
- `Enemigo.morir()` (los enemigos sin drop) y `Jefe.morir()` no cambian: `Enemigo.morir()` ignora el valor que devuelve.

### En los diagramas

| Diagrama | Cambio |
|---|---|
| Extendido | En las cajas `EntornoJuego` y `Juego`: `+ enemigoDerrotado(e : Enemigo) : boolean` (antes sin tipo de retorno) |
| Reducido | No cambia: no hay clases ni relaciones nuevas |

### Cómo se probó

- El código compila con `javac`.
- Se probó en el juego (pantalla virtual) con un enemigo de prueba que siempre suelta drop: de 8 muertes seguidas, la 4.ª y la 8.ª hicieron aparecer la bellota sin drop, y las otras 6 soltaron su drop como antes.

## 23. Imagen nueva del fragmento de corazón

El fragmento de corazón tiene una imagen nueva: un corazón pixel art color piel con un corazón rojo adentro, sin fondo. Se dibuja de 45 × 42 dentro de la imagen de 48 × 48, casi del tamaño del corazón normal, y está en `original/` y `alternativa/`. Como el dibujo cambió de tamaño, el cuerpo de colisión se ajusta para que coincida con él.

### Cómo funciona

- `FragmentoDeCorazon` cambia sus constantes de cuerpo: `CUERPO_MARGEN_X` de 6 a 1, `CUERPO_MARGEN_Y` de 6 a 3, `CUERPO_ANCHO` de 36 a 45 y `CUERPO_ALTO` de 36 a 42.
- El comportamiento no cambia: al tocarlo, Link suma un fragmento y cada 4 gana un corazón máximo más.

### En los diagramas

| Diagrama | Cambio |
|---|---|
| Extendido | En la caja `FragmentoDeCorazon`, los valores de las cuatro constantes de cuerpo |
| Reducido | No cambia |

### Recursos

- `Recursos/Imagenes/original/fragmentodecorazon-normal.png` y `Recursos/Imagenes/alternativa/fragmentodecorazon-normal.png`: imagen nueva de 48 × 48 con el dibujo en (1, 3) y de 45 × 42.

### Cómo se probó

- El código compila con `javac` y el juego carga la imagen nueva.

## 24. Ataque de Link hacia la derecha

La imagen `link-ataque-derecha.png` no era el espejo de `link-ataque-izquierda.png`: Link tenía otra pose y la espada salía a la altura de la cabeza, separada de la mano. Ahora es el espejo horizontal exacto del ataque hacia la izquierda: Link mira a la derecha y la espada sale de la mano, abajo. Sigue midiendo 96 × 48, con Link en la mitad izquierda, así que se dibuja en el mismo lugar que antes. Está en `original/` y `alternativa/`. No cambia el código ni los diagramas.

### Cómo se probó

- Se corrió en el juego (pantalla virtual) con un nivel de prueba de 3 Erizos de Mar: Link ataca hacia la derecha y los mata. Se grabó un video, también en cámara lenta.

## 25. Ataque hacia la izquierda y hacia arriba dibujado en su lugar

Las imágenes de ataque de Link son más grandes que Link: 96 × 48 hacia los costados y 48 × 96 hacia arriba y abajo. La vista dibujaba cada imagen desde la esquina de Link (`getX()`, `getY()`). Hacia la derecha y hacia abajo eso está bien, porque la espada sale hacia ese lado. Hacia la izquierda y hacia arriba, en cambio, la imagen quedaba corrida 48 px: Link aparecía un paso más adelante y la espada salía de donde estaba él. La hitbox del golpe (`getHitbox().adelante(direccion, alcance)`) siempre estuvo bien; solo el dibujo no coincidía.

No se puede corregir cambiando `getX()`/`getY()` de Link, porque la lógica también los usa: `EntidadAnimada` calcula el movimiento con ellos, y el `StoneHinox` y el `MasterStalfos` apuntan a Link con ellos. Por eso se separa dónde se dibuja la imagen de dónde está la entidad:

- `EntidadLogica` agrega `int getXImagen()` e `int getYImagen()`: dónde dibujar la imagen.
- `Entidad` las implementa devolviendo `getX()` y `getY()`. Ninguna otra entidad cambia: todas las imágenes de los enemigos son cuadradas y del mismo tamaño en las cuatro direcciones.
- `Link` las redefine: mientras muestra el ataque, corre la imagen `LARGO_IMAGEN_ESPADA = 48` px hacia la izquierda o hacia arriba, según la dirección.
- `CeldaGrafica` y `PanelPantallaNivel` dibujan con `getXImagen()`/`getYImagen()`.

```java
// Link
@Override
public int getXImagen() {
    int x = getX();
    if (mostrandoAtaque() && getDireccion() == Direccion.IZQUIERDA)
        x -= LARGO_IMAGEN_ESPADA;
    return x;
}

private boolean mostrandoAtaque() {
    return !escudoActivo && (atacando || vueltasMostrandoGolpe > 0);
}
```

`getYImagen()` es igual, con `Direccion.ARRIBA`. `getRutaImagen()` usa también `mostrandoAtaque()`, así la imagen y su lugar se deciden con la misma condición.

En el extendido se agregan `getXImagen()` y `getYImagen()` en `EntidadLogica`, `Entidad` y `Link`, y en `Link` la constante `LARGO_IMAGEN_ESPADA` y la consulta privada `- mostrandoAtaque() : boolean`.

### Cómo se probó

- El código compila con `javac`.
- Se corrió en el juego (pantalla virtual) con un nivel de prueba, dibujando encima los cuerpos y la zona del golpe: en las cuatro direcciones la espada queda sobre la zona que golpea y Link no se mueve al atacar. Se grabó un video.

## 26. Abalanzada del Moblin con espada y escudo

`vigilarJugador()` corre en cada vuelta del juego (cada 30 ms). Mientras Link estaba enfrente, en cada vuelta el Moblin creaba otro `MovimientoInducido` y programaba otra vuelta a `MovimientoAleatorio` para 800 ms después. Se medían hasta 27 acciones pendientes a la vez, y eso causaba dos cosas raras:

- La abalanzada no duraba 800 ms: seguía mientras Link estuviera en la línea.
- Cuando Link se corría, las acciones pendientes se cumplían una por vuelta. Cada una creaba un `MovimientoAleatorio` nuevo, que elige una dirección al azar enseguida, así que el Moblin temblaba durante medio segundo.

Ahora hay un atributo `abalanzandose`: `vigilarJugador()` solo empieza una abalanzada si no hay otra en curso, y al terminar el método privado `terminarAbalanzada()` lo vuelve a `false` y pone el movimiento al azar.

```java
protected boolean abalanzandose;

protected void vigilarJugador() {
    if (!abalanzandose && linkEstaEnfrente() && !hayObstaculoHastaJugador()) {
        abalanzandose = true;
        setMovimiento(new MovimientoInducido(getDireccion(), VELOCIDAD_ABALANZADA));
        programar(DURACION_ABALANZADA, this::terminarAbalanzada);
    }
}

private void terminarAbalanzada() {
    abalanzandose = false;
    setMovimiento(new MovimientoAleatorio(VELOCIDAD, INTERVALO_CAMBIO_DIRECCION));
}
```

En el extendido, `MoblinConEspadaYEscudo` suma `# abalanzandose : boolean` y `- terminarAbalanzada()`. El reducido no cambia: ahí la clase va sin atributos ni métodos. En el mismo extendido se agrandó la caja de `Link` (de 1284 a 1300 de alto), porque con los métodos del cambio 25 el texto se pasaba un poco.

### Cómo se probó

- El código compila con `javac`.
- Se corrió en el juego (pantalla virtual) con un nivel de prueba con solo Link y el Moblin, anotando el estado del Moblin en cada vuelta. Antes: hasta 27 acciones pendientes y 24 cambios de dirección en 9 s, con el temblor al correrse Link. Después: nunca más de 1 acción pendiente, cada abalanzada dura 800 ms y hubo 4 cambios de dirección. Se grabaron videos de antes y después.

## 27. Abalanzada más lenta del Moblin con espada y escudo

La abalanzada era muy rápida. Ahora va a la mitad de velocidad y dura el doble, así que recorre lo mismo que antes (unos 160 px):

| Constante | Antes | Ahora |
|---|---|---|
| `VELOCIDAD_ABALANZADA` | 6 | 3 |
| `DURACION_ABALANZADA` | 800 ms | 1600 ms |

Sigue siendo más rápida que su caminata (`VELOCIDAD = 2`). En el extendido cambian los dos valores en `MoblinConEspadaYEscudo`; el reducido no cambia. Los valores que figuran en las secciones 15 y 26 son los de ese momento.

### Cómo se probó

- El código compila con `javac`.
- Se corrió en el juego (pantalla virtual) con el nivel de prueba de solo Link y el Moblin, anotando su estado en cada vuelta: avanza 3 px por vuelta y cada abalanzada dura unos 1600 ms. Se grabó un video.

## 28. Abalanzada suave del Moblin con espada y escudo

La abalanzada se veía tosca: arrancaba de golpe, frenaba en seco y apenas terminaba giraba al azar (un `MovimientoAleatorio` nuevo elige dirección enseguida). Ahora `vigilarJugador()` arma toda la abalanzada con `programar`:

| Momento | Qué hace |
|---|---|
| 0 ms | Se queda quieto mirando a Link (`MovimientoInducido(null, 0)`) |
| 300 ms (`PREPARACION_ABALANZADA`) | Sale a velocidad 1 |
| 400 y 500 ms | Velocidad 2 y 3 (cada `DURACION_CAMBIO_VELOCIDAD` = 100 ms) |
| 1900 ms (300 + `DURACION_ABALANZADA`) | Frena a su velocidad de caminar (`VELOCIDAD` = 2) y sigue derecho |
| 2400 ms (+ `DURACION_FRENADO` = 500) | `terminarAbalanzada()`: vuelve a caminar al azar |

La dirección se guarda al empezar, así sale hacia donde estaba Link aunque Link se mueva durante la preparación. Mientras dura todo esto `abalanzandose` sigue en `true`, así que no empieza otra.

```java
private static final long PREPARACION_ABALANZADA = 300;
private static final long DURACION_CAMBIO_VELOCIDAD = 100;
private static final long DURACION_FRENADO = 500;

protected void vigilarJugador() {
    if (!abalanzandose && linkEstaEnfrente() && !hayObstaculoHastaJugador()) {
        abalanzandose = true;
        Direccion d = getDireccion();
        setMovimiento(new MovimientoInducido((Direccion) null, 0));
        for (int v = 1; v <= VELOCIDAD_ABALANZADA; v++) {
            int velocidad = v;
            programar(PREPARACION_ABALANZADA + (v - 1) * DURACION_CAMBIO_VELOCIDAD,
                    () -> setMovimiento(new MovimientoInducido(d, velocidad)));
        }
        programar(PREPARACION_ABALANZADA + DURACION_ABALANZADA,
                () -> setMovimiento(new MovimientoInducido(d, VELOCIDAD)));
        programar(PREPARACION_ABALANZADA + DURACION_ABALANZADA + DURACION_FRENADO, this::terminarAbalanzada);
    }
}
```

En el extendido, `MoblinConEspadaYEscudo` suma las tres constantes nuevas. Para que entren, su caja crece 39 de alto y las cajas de `ComportamientoAtaque`, `AtaquePorContacto`, `AtaqueEspada` y `AtaqueRecargado`, que están debajo, bajan 39. El reducido no cambia.

### Cómo se probó

- El código compila con `javac`.
- Se corrió en el juego (pantalla virtual) con el nivel de prueba de solo Link y el Moblin, anotando la posición en cada vuelta: queda quieto 300 ms, avanza 1, 2 y 3 px por vuelta, va a 3 unos 1600 ms, sigue derecho a 2 px por vuelta 500 ms y recién después camina al azar. Se grabó un video, también en cámara lenta.

## 29. No disparar a través de obstáculos

El Octorok y el Wizzrobe disparaban apenas Link quedaba enfrente, aunque hubiera una roca en el medio (el disparo chocaba con la roca y desaparecía). Ahora usan la misma consulta que la trampa de cuchillas y el Moblin con escudo (cambio 9): `AtaquePorProyectil.puedeAtacar` agrega `!a.hayObstaculoHastaJugador()`.

```java
protected boolean puedeAtacar(EntidadAnimada a) {
    return pasoElIntervalo() && a.linkEstaEnfrente() && !a.hayObstaculoHastaJugador();
}
```

- No disparan si hay roca, agua o vacío entre ellos y Link. Por el vacío el disparo pasaría, pero se usa la misma regla que para abalanzarse.
- Vale para todos los que usan `AtaquePorProyectil`: Octorok, Wizzrobe y las rocas que tira el StoneHinox. `AtaqueAvalancha` redefine `puedeAtacar` y no cambia.
- El extendido no cambia: `puedeAtacar` ya figura y la condición no se dibuja. El reducido tampoco cambia.
- Los javadoc acompañan el cambio: la clase `AtaquePorProyectil`, `Octorok` y `Wizzrobe` dicen que disparan sin obstáculos en el medio, y `hayObstaculoHastaJugador()` (en `EntidadAnimada`) e `impideAbalanzarse()` (en `Entidad`, `Roca`, `Agua` y `CaidasAlVacio`) dicen que sirven para abalanzarse **o disparar**.

### Cómo se probó

- El código compila con `javac`.
- Se corrió en el juego (pantalla virtual) con un nivel de prueba: un Octorok en un pasillo de rocas, siempre en la fila de Link, durante 15 s. Sin roca en el medio disparó 5 veces; con una roca en el medio, 0 veces (antes del cambio, con la misma roca, disparaba 6).

## 30. Animación de teletransporte del Wizzrobe

El Wizzrobe saltaba de un lugar a otro de golpe. Ahora medio segundo antes de saltar se ve un GIF en el que el cuerpo parpadea, queda solo el gorrito y el gorrito sube. Al llegar, se ve otro en el que el gorrito baja y el cuerpo aparece parpadeando debajo. Los dos usan el cuerpo de la dirección hacia la que mira.

1. **Imágenes.** 16 GIF de 48 × 48 que se reproducen una sola vez: `wizzrobe-aparecer-{abajo,arriba,izquierda,derecha}.gif` (550 ms) y `wizzrobe-desaparecer-{abajo,arriba,izquierda,derecha}.gif` (500 ms), en `original/` y en `alternativa/`. El gorrito se recortó de la hoja `enemies.png` de Link's Awakening DX HD (cuadro `head` de `wizzrobe.ani`); el cuerpo es la imagen de cada dirección que ya estaba.
2. **`FabricaSprites.crearSpritesWizzrobe()`** agrega los estados `aparecer-<dirección>` y `desaparecer-<dirección>` con extensión `.gif`, porque `armar` usa siempre `.png`.
3. **`Wizzrobe`.**
   - Constantes `DURACION_APARECER = 500` y `DURACION_DESAPARECER = 500`; atributos `apareciendo`, `desapareciendo` y `teletransportes`.
   - `teletransportarse()` prende `apareciendo` y programa apagarlo a los 500 ms, y programa `desapareciendo` para `INTERVALO_TELETRANSPORTE - DURACION_DESAPARECER`, medio segundo antes del próximo salto.
   - `teletransportes` cuenta los saltos: cada acción programada guarda el número de su salto y no hace nada si ya hubo otro. Así, si el Wizzrobe recibe un golpe, un "desaparecer" programado antes no se muestra fuera de tiempo.
   - `alSerGolpeado()` apaga las dos imágenes y suma uno a `teletransportes`.
   - `getRutaImagen()` (nuevo) devuelve `aparecer-<dirección>` o `desaparecer-<dirección>` mientras corresponde y, si no, la imagen de la dirección. Es el mismo patrón que el `StoneHinox`.
4. **`CeldaGrafica.actualizar()`** creaba un `ImageIcon` nuevo en cada actualización, así un GIF nunca pasaba del primer cuadro. Ahora guarda `rutaMostrada` y solo carga la imagen cuando cambia la ruta. Si la ruta es un GIF le hace `flush()`, para que arranque desde el primer cuadro cada vez que se muestra:

```java
String ruta = entidadObservada.getRutaImagen();
if (!ruta.equals(rutaMostrada)) {
    ImageIcon nuevo = new ImageIcon(CeldaGrafica.class.getResource(ruta));
    if (ruta.endsWith(".gif"))
        nuevo.getImage().flush();
    setIcon(nuevo);
    rutaMostrada = ruta;
}
```

- Las demás entidades usan PNG: nunca se les hace `flush()` y se ven igual. Solo dejan de crear un `ImageIcon` nuevo cuando la imagen no cambió.
- En el extendido, `Wizzrobe` suma las 2 constantes, los 3 atributos y `+ getRutaImagen() : String`, y `CeldaGrafica` suma `# rutaMostrada : String`. Los cuadros se agrandaron y `TrampaDeCuchillas` bajó 78. El reducido no cambia.
- Los javadoc acompañan el cambio: la clase `Wizzrobe`, `teletransportarse()`, `alSerGolpeado()`, `getRutaImagen()` y `CeldaGrafica.actualizar()`.

### Cómo se probó

- El código compila con `javac`.
- Se corrió en el juego (pantalla virtual) con un nivel de prueba de solo Link y el Wizzrobe durante 12 s: en cada salto se ve el GIF de desaparecer en el lugar viejo y el de aparecer en el nuevo, con el cuerpo de la dirección hacia la que mira. Se grabó un video, también en cámara lenta.

## 31. Caída al vacío por el centro y con GIF

Link caía apenas cualquier parte de su cuerpo tocaba el cuerpo del pozo (32 × 32 en el medio de la baldosa), y el nivel se reiniciaba en ese mismo instante. Ahora puede pisar el borde: cae recién cuando el **centro** de su cuerpo está sobre el pozo. Al caer se queda quieto 700 ms mostrando un GIF y después pierde la vida, como antes.

1. **`Hitbox`**: consulta nueva `contiene(p : Posicion) : boolean`, que dice si un punto está dentro del cuerpo.
2. **`CaidasAlVacio.afectar(Link l)`** llama a `caerAlVacio()` solo si `getHitbox().contiene(l.getCentro())`. El cuerpo del pozo no cambia, así que para los enemigos (`bloqueaPasoA`), las abalanzadas y los disparos (`impideAbalanzarse`) el pozo es el mismo.

```java
public void afectar(Link l) {
    if (getHitbox().contiene(l.getCentro()))
        l.caerAlVacio();
}
```

3. **`Link`**.
   - Constante `DURACION_CAIDA = 700` y atributo `cayendo`.
   - `caerAlVacio()` ya no saca la vida en el momento: si ya está cayendo no hace nada; si no, prende `cayendo`, se queda quieto (`MovimientoInducido(null, 0)`), se vuelve invulnerable, avisa a la vista y programa `terminarCaida()` a los 700 ms.
   - `terminarCaida()` (privado, nuevo) apaga `cayendo`, devuelve el caminar y la defensa normal y hace lo que antes hacía `caerAlVacio()`: resta una vida, recupera los corazones, corta la racha y avisa al juego.
   - `getRutaImagen()` devuelve `caida` mientras cae. `atacar()` y `usarEscudo()` no hacen nada mientras cae, y `restaurarDefensa()` no lo saca de la invulnerabilidad.
4. **`FabricaSprites.crearSpritesLink()`** agrega el estado `caida` con `link-caida.gif`.
5. **Imágenes**: `link-caida.gif` (48 × 48, 3 cuadros de 200 ms, se reproduce una vez) en `original/` y en `alternativa/`. Se anima gracias a `CeldaGrafica` (cambio 30).

- El suelo quebradizo no cambia: cuando se rompe deja un pozo común, y Link cae si su centro está sobre él.
- En el extendido, `Link` suma `# cayendo : boolean`, `- DURACION_CAIDA : long = 700` y `- terminarCaida()`, y `Hitbox` suma `+ contiene(p : Posicion) : boolean`. El reducido no cambia.
- Los javadoc acompañan el cambio: `CaidasAlVacio.afectar`, `Hitbox.contiene` y, en `Link`, `atacar`, `usarEscudo`, `restaurarDefensa`, `caerAlVacio`, `terminarCaida` y `getRutaImagen`.

### Cómo se probó

- El código compila con `javac`.
- Se corrió en el juego (pantalla virtual) con un nivel de prueba de Link y un pozo en su fila: Link camina hacia el pozo, entra con el borde sin caer, cae cuando el centro llega al pozo, se ve el GIF y vuelve al inicio con una vida menos. Con tres caídas termina la partida. Se grabó un video comparando antes y después.

## 32. Caída al vacío más corta, con el GIF a la par

La caída del cambio 31 duraba 700 ms, pero el GIF duraba 600 ms (3 cuadros de 200 ms) y se repetía: en los últimos 100 ms volvía a empezar. Además, al perder la última vida por caída la partida tardaba 700 ms en terminar.

1. **`Link`**: `DURACION_CAIDA` pasa de 700 a **400** ms. Todas las caídas duran eso, también la última, así que la partida termina a los 400 ms. No hay casos especiales en el código.
2. **Imágenes**: `link-caida.gif` (en `original/` y en `alternativa/`) pasa a 3 cuadros de 140, 130 y 130 ms (400 ms en total) y se reproduce **una sola vez**: termina en el último cuadro, justo cuando `terminarCaida()` saca la vida.

- En el extendido, la constante de `Link` pasa a `- DURACION_CAIDA : long = 400`. El reducido no cambia.

### Cómo se probó

- El código compila con `javac`.
- Se corrió en el juego con el nivel de prueba del cambio 31: el GIF se ve una vez entero y a los 400 ms el nivel se reinicia; con la última vida la partida termina a los 400 ms.

## 33. El suelo quebradizo tarda 800 ms en romperse

Con el cambio 31 Link cae solo si su centro está sobre el pozo. Caminando derecho (4 px cada 30 ms), su centro pasa sobre el pozo entre unos 200 y 430 ms después de pisar el suelo, así que con la demora de 500 ms el suelo casi nunca lo hacía caer.

1. **`Link`**: `DEMORA_ROTURA_SUELO` pasa de 500 a **800** ms. Si Link sigue caminando, el suelo se rompe detrás de él y no cae. Cae si se frena encima, si camina a lo largo de la baldosa o si va ralentizado por pasto (cruza en unos 870 ms).

- En el extendido, la constante de `Link` pasa a `- DEMORA_ROTURA_SUELO : long = 800`. El reducido no cambia.

### Cómo se probó

- El código compila con `javac`.
- Se corrió en el juego con un nivel de prueba con dos suelos quebradizos en la fila de Link: cruza el primero caminando y se rompe detrás sin que caiga; se frena sobre el segundo, a los 800 ms se rompe, cae y el nivel se reinicia. Se grabó un video.

## 34. Moblin con caminata animada y nube de muerte

El Moblin caminaba con una imagen fija y desaparecía en el mismo instante en que moría. Ahora camina con un GIF y, al morir, muestra la nube de muerte de los enemigos del juego original antes de desaparecer.

1. **Imágenes** (en `original/` y en `alternativa/`), sacadas de `moblin.ani` y `Particles/despawn.ani` del juego original:
   - `moblin-abajo.gif`, `moblin-arriba.gif`, `moblin-izquierda.gif` y `moblin-derecha.gif`: caminar, 48 × 48, 2 cuadros de 250 ms en bucle (el original va a 133 ms; se hizo más lento). Los PNG quedan.
   - `moblin-muerte.gif` (48 × 48) y `moblinconespadayescudo-muerte.gif` (96 × 96, la misma nube centrada): 2 cuadros de 150 ms, se reproducen una vez.
2. **`FabricaSprites`**: `crearSpritesMoblin()` usa los GIF por dirección y agrega el estado `muerte`; `crearSpritesMoblinConEspadaYEscudo()` sigue con sus PNG y agrega el estado `muerte`.
3. **`EntidadAnimada`**: comando nuevo `cancelarProgramadas()`, que descarta las acciones programadas pendientes.
4. **`Moblin`**: constante `DURACION_MUERTE = 300` y atributo `muriendo`.
   - `morir()` (redefinido): si ya está muriendo no hace nada; si no, prende `muriendo`, cancela lo programado, se queda quieto (`MovimientoInducido(null, 0)`), se vuelve invulnerable (`DefensaLimitada(0, SIEMPRE)`), avisa a la vista y programa `super.morir()` a los 300 ms. Ahí hace lo de siempre: `eliminar()`, puntos y, a veces, el drop.
   - `colisionarCon(Link)` (redefinido): no lastima a Link mientras muere.
   - `getRutaImagen()` (redefinido): mientras muere devuelve la ruta del estado `muerte`; si el sprite no la tiene, la de su dirección.
5. **`MoblinConEspadaYEscudo`**: hereda la muerte animada. `vigilarJugador()` no empieza una abalanzada mientras muere, y como `morir()` cancela lo programado, una abalanzada en curso no lo mueve.

```java
@Override
protected void morir() {
    if (muriendo)
        return;
    muriendo = true;
    cancelarProgramadas();
    setMovimiento(new MovimientoInducido((Direccion) null, 0));
    setDefensa(new DefensaLimitada(0, DefensaLimitada.SIEMPRE));
    notificarObservers();
    programar(DURACION_MUERTE, super::morir);
}
```

- Los puntos y el drop llegan 300 ms después del golpe. Los demás enemigos no cambian.
- En el extendido, `Moblin` suma `- DURACION_MUERTE : long = 300`, `# muriendo : boolean`, `# morir()`, `+ colisionarCon(l : Link)` y `+ getRutaImagen() : String`, y `EntidadAnimada` suma `# cancelarProgramadas()`. La caja de `Moblin` crece y las de abajo se corren. El reducido no cambia: para el Moblin solo dibuja herencias.

### Cómo se probó

- El código compila con `javac`.
- Se corrió en el juego con un nivel de prueba de dos Moblin y un Moblin con espada y escudo: caminan con el GIF y, al matarlos, cada uno muestra la nube 300 ms, desaparece, suma los puntos y a veces suelta el drop. Se grabó un video.

## 35. Caminata animada del Moblin con espada y escudo, a 126 × 126

El Moblin con espada y escudo caminaba con una imagen fija de 96 × 96. Ahora camina con la animación del juego original (`moblin sword sword.ani`): en un cuadro adelanta la espada y en el otro la retrae. La espada adelantada sale 13 px (de la hoja de sprites) del cuerpo hacia cada lado, así que en 96 × 96 quedaba recortada; por eso la imagen pasa a 126 × 126.

1. **Imágenes** (en `original/` y en `alternativa/`):
   - Nuevas: `moblinconespadayescudo-abajo.gif`, `-arriba.gif`, `-izquierda.gif` y `-derecha.gif`, de 126 × 126, 2 cuadros de 250 ms en bucle (la velocidad del original). Hacia abajo lleva el escudo, como la imagen anterior.
   - Rehecha: `moblinconespadayescudo-muerte.gif` (cambio 34), de 96 × 96 a 126 × 126, con la nube en el centro.
   - Los PNG `moblinconespadayescudo-<dirección>.png` (96 × 96) quedan en la carpeta, pero el juego ya no los usa.
2. **`FabricaSprites.crearSpritesMoblinConEspadaYEscudo()`**: deja de usar `armar(...)` con PNG y agrega las 4 direcciones con su `.gif`, igual que `crearSpritesMoblin()` (cambio 34). Mantiene el estado `muerte`.
3. **`MoblinConEspadaYEscudo`**: cambian tres constantes para que el cuerpo (40 × 40) quede en el mismo lugar dentro de la imagen más grande. El javadoc del constructor pasa a decir 126 × 126.

| Constante | Antes | Ahora | Cuenta |
|---|---|---|---|
| `MARGEN_IMAGEN` | 24 | 39 | `(126 − 48) / 2` |
| `CUERPO_MARGEN_X` | 28 | 43 | `MARGEN_IMAGEN + 4` (el margen del `Moblin`) |
| `CUERPO_MARGEN_Y` | 28 | 43 | ídem |

El cuerpo sigue en la celda del nivel: el constructor ubica la imagen en `(x − 39, y − 39)` y el cuerpo queda en `(x − 39 + 43, y − 39 + 43) = (x + 4, y + 4)`, igual que antes con 24 y 28. El daño, la abalanzada, el escudo y los choques no cambian, porque trabajan con el cuerpo.

- En el extendido, la caja `MoblinConEspadaYEscudo` muestra `- MARGEN_IMAGEN : int = 39`, `- CUERPO_MARGEN_X : int = 43` y `- CUERPO_MARGEN_Y : int = 43`. No hay atributos ni métodos nuevos. El reducido no cambia.

### Cómo se probó

- El código compila con `javac`.
- Se corrió en el juego con un nivel de prueba de dos Moblin con espada y escudo y un Moblin: caminan con la espada entera, se abalanzan como antes y, al matarlos, la nube aparece centrada en el cuerpo. Se grabó un video.

## 36. Caminata animada de Link (normal, con escudo y con espada)

Link caminaba con una imagen fija por dirección. Ahora, mientras se mueve, usa un GIF con los cuadros del juego original (`link0.ani`), a 150 ms por cuadro. Cuando está quieto o solo gira, sigue usando los PNG de siempre, igual que el Moblin.

- **Imágenes nuevas (16 GIF, en `original/` y `alternativa/`):** `link-caminar-<dir>.gif`, `link-caminar-escudo-<dir>.gif`, `link-caminar-ataque-<dir>.gif` y `link-caminar-recargado-<dir>.gif`. La derecha es el espejo de la izquierda. En los GIF con espada, la espada se toma de las imágenes de ataque y se pega al cuerpo que camina.
- **Imágenes corregidas:** `link-escudo-izquierda.png` y `link-escudo-derecha.png` miraban al lado contrario; ahora son el primer cuadro de la caminata con escudo.
- **`FabricaSprites.crearSpritesLink()`:** registra las 16 claves `caminar-[estado-]<dir>`.
- **`Link.getRutaImagen()`:** si Link se está moviendo (`caminar.getDireccion() != null`) antepone `caminar-` a la clave. Con la espada cargada (pasados los 3 s) usa `caminar-recargado-<dir>` al caminar y `ataque-recargado-<dir>` quieto.
- **Frente con escudo:** `link-caminar-escudo-abajo.gif` y `link-escudo-abajo.png` se rehicieron con los cuadros que eligió el equipo (48 × 48, fondo transparente).
- **`Link.detenerMovimiento()`:** ahora llama a `notificarObservers()`. Antes, al soltar la flecha la vista no se enteraba y Link seguía con el GIF de caminar; ahora al frenar muestra el PNG quieto (con o sin escudo).
- **No cambian** la lógica, las hitboxes, las colisiones ni los diagramas: no hay atributos, métodos ni firmas nuevas.

**Prueba:** compila y se probó en el juego con un nivel de prueba, grabando un video con todas las variantes y una pelea contra dos Moblin y dos Octorok.

## 37. Cambiar de objeto baja el escudo

**Bug:** con el escudo levantado (S apretada), si se apretaba D se equipaba la espada pero el escudo seguía activo. Al soltar S se llamaba a `soltarProteccionCon` de la espada, que no hace nada, así que el escudo no bajaba nunca: Link seguía protegido, con la imagen de escudo, y al atacar no se veía el golpe (`mostrandoAtaque()` es falso con el escudo activo).

**Arreglo:** `Link.cambiarObjeto()` llama a `desactivarEscudo()` antes de cambiar de objeto si el escudo estaba activo. Se actualizó su javadoc. Los diagramas no cambian (no hay métodos ni firmas nuevas).

**Prueba:** compila y se probó en el juego: escudo levantado, D, soltar S, atacar y caminar. Después de D el escudo queda desactivado, el golpe de espada se ve y camina con el GIF normal. Se grabó un video.

## 38. Ataque recargado con giro: golpea alrededor

El ataque recargado pegaba solo hacia adelante, con el doble de daño y alcance. Ahora, como en el juego original, al soltar A con la espada cargada (3 s) Link **gira** y golpea a todo lo que tiene alrededor. El golpe sin cargar no cambia.

- **`Hitbox.alrededor(alcance) : Hitbox`** (nuevo): el cuerpo agrandado `alcance` px hacia los cuatro lados.
- **`AdministradorColisiones.golpearAlrededor(atacante, alcance, danio)`** (nuevo): igual que `golpearEn`, pero con la zona de `alrededor`.
- **`AtaqueRecargado.atacar()`**: si `estaCargado()`, llama a `golpearAlrededor` con alcance 64 y daño 2; si no, `golpear` como antes.
- **`Link`**:
  - Constantes nuevas `VUELTAS_IMAGEN_GIRO = 16` y `ORDEN_GIRO = { ABAJO, IZQUIERDA, ARRIBA, DERECHA }`.
  - `ataqueRealizado()` deja `vueltasMostrandoGolpe = VUELTAS_IMAGEN_GIRO` si el golpe fue recargado.
  - Métodos privados nuevos `girando()` y `direccionImagen()`: durante el giro la imagen recorre las cuatro direcciones (`ataque-recargado-<dir>`, ya existentes) y termina en la dirección de Link. Los usan `getRutaImagen`, `getXImagen` y `getYImagen`.
  - `actualizarEstado` avisa a la vista en cada vuelta del giro.
- **Diagrama extendido:** se agregaron `alrededor` en `Hitbox`, `golpearAlrededor` en `AdministradorColisiones`, y las dos constantes y los dos métodos privados en `Link`. El reducido no muestra métodos, así que no cambia.

**Prueba:** compila y se probó en el juego: el golpe normal con un Moblin al costado no lo toca; el recargado con cuatro Moblins alrededor los mata a los cuatro (400 puntos). El giro dura unos 480 ms. Se grabó un video.

## 39. Golpe de espada animado, como el original

El golpe normal mostraba una imagen fija con la espada extendida. Ahora es un GIF con los 3 cuadros del juego original: el cuerpo de `link0.ani` (`attack_<d>`) y la espada de `Objects/sword.ani` (`attack_<d>`), con sus posiciones y tiempos (50, 50 y 133 ms). La espada barre en arco hacia la dirección del golpe.

- **Imágenes:** `link-ataque-<dir>.gif` (4, en `original/` y `alternativa/`), de 156 × 150 con Link siempre en (54, 51). Se borraron los `link-ataque-<dir>.png`, que ya no se usan.
- **`FabricaSprites.crearSpritesLink()`:** `ataque-<dir>` se registra con `agregar` como GIF, en lugar de cargarse como PNG con `armar`.
- **`Link`:**
  - Constantes nuevas `MARGEN_X_GOLPE = 54` y `MARGEN_Y_GOLPE = 51`.
  - Consulta privada nueva `mostrandoGolpeNormal()`: atacando, quieto y sin la espada cargada.
  - `getXImagen()` y `getYImagen()` corren la imagen esos márgenes mientras se ve el golpe normal; el ataque recargado sigue con `LARGO_IMAGEN_ESPADA`.
  - `VUELTAS_IMAGEN_GOLPE` pasa de 7 a 8 (240 ms), para que el GIF de 233 ms se vea completo.
- **Diagrama extendido:** se agregaron `MARGEN_X_GOLPE`, `MARGEN_Y_GOLPE` y `mostrandoGolpeNormal()` en `Link`, y `VUELTAS_IMAGEN_GOLPE` pasa a 8. El reducido no cambia.
- **No cambian** el hitbox, el alcance, el ataque recargado, el giro ni las caminatas con espada.

**Prueba:** compila y se probó en el juego golpeando en las cuatro direcciones: la imagen se corre 54 y 51 px y el cuerpo de Link queda en el mismo lugar. Manteniendo A, a los 3 s pasa a la imagen recargada; caminando usa el GIF de caminar con espada. Se grabó un video.

## 40. Revisión final: diagramas, comentarios y javadoc

Se comparó el código entero con los dos diagramas (atributos, constructores y métodos, uno a uno), se revisaron los comentarios y el javadoc, y se completaron este archivo y el de explicaciones.

- **Diagrama extendido igual al código (PR #102):** los nombres de los parámetros pasan a ser los del código: `Nivel(…, filaInicial, columnaInicial, posicionInicial)`, `AnimadorTransicion(panel, direccion, controlador)`, `AdministradorColisiones.verificarColisiones(entidadActualizada)` y `Hitbox.estaDentroDe(anchoZona, altoZona)`. `Ranking[3]` y los `+` sueltos quedan como estaban, a pedido del equipo.
- **Comentarios `//` (PR #103):** se borraron los comentarios de una línea, salvo los de sección (`// Atributos de clase`, `// Atributos de instancia`, `// Constructor`, `// Comandos`, `// Consultas`). Archivos: `Link`, `Moblin`, `Wizzrobe`, `CeldaGrafica`, `PanelPantallaNivel`, `PanelPantallaPrincipal` y `PanelPantallaRanking`.
- **Javadoc (PR #103 y #109):** nombra las constantes en lugar de sus valores (`AtaqueRecargado`, `Entidad`, `FragmentoDeCorazon`, `HiloJugador`, `HiloMundo`, `Clasico`, `Contrarreloj`, `NoHit` y `Ranking`); se ajustó el de `Moblin.morir()` y el de `AtaqueRecargado` menciona el giro del cambio 38.
- **`EntidadAnimada`:** atributo de clase nuevo `PERIODO_PARPADEO = 100`. `esVisible()` lo usa en lugar del `100` suelto y su javadoc lo nombra. Se agregó en el diagrama extendido.
- **PDF del extendido (PR #104):** exportado desde draw.io con los cambios hasta el 35. Falta volver a exportarlo con los cambios 38 a 40.
- **Diagrama reducido:** tiene todas las clases y las 45 herencias y 27 realizaciones del código. No se dibujan como asociación algunos atributos (por ejemplo `recargado`, `caminar` y `defensaBase` de `Link`), por decisión del equipo.

**Prueba:** compila con `javac` y un script comparó cada clase del código con su caja del extendido: coinciden, salvo `Ranking[3]` y los `+`.

## 41. El StoneHinox lanza las tres rocas de a una

El enunciado pide que el StoneHinox lance "tres rocas, una detrás de la otra, apuntando hacia Link". Antes usaba un `AtaquePorProyectil(this, 3, 2000)` común, que crea las 3 rocas en la misma vuelta: salían del mismo punto, hacia el mismo lado y a la misma velocidad, así que viajaban superpuestas y se veía una sola. Además, solo tiraba si Link estaba en su misma fila o columna (`linkEstaEnfrente()`), así que muchas veces no tiraba nada.

- **Clase nueva `AtaqueRafaga`** (en `logica.comportamientos`), hija de `AtaquePorProyectil`, como `AtaqueAvalancha`. Tira de a un proyectil, separados por `intervalo`, hasta completar `cantidad`:
  - Atributo `# lanzados : int`: cuántos lleva la ráfaga.
  - Constructor `AtaqueRafaga(g, cantidad, intervalo)`: pasa todo al padre.
  - `+ reiniciar()`: pone `lanzados = 0` y `ultimoAtaque = 0`, así el primero sale en la próxima vuelta.
  - `# alTerminar(atacante)`: suma 1 a `lanzados` después de cada disparo.
  - `# puedeAtacar(a)`: `lanzados < cantidad && pasoElIntervalo()`. No pide que Link esté alineado ni mira obstáculos: si hay una roca en el medio, la roca lanzada choca y desaparece.
  - `# cantidadDeProyectiles()`: devuelve 1.
- **`StoneHinox`:**
  - `INTERVALO_ROCAS` pasa de 2000 a 400 ms: ahora es el tiempo entre roca y roca.
  - `lanzarRocas` pasa de `ComportamientoAtaque` a `AtaqueRafaga`, y se crea con `new AtaqueRafaga(this, CANTIDAD_ROCAS, INTERVALO_ROCAS)`.
  - `siguienteAtaque()`: al elegir lanzar rocas llama a `lanzarRocas.reiniciar()` antes de `setAtaque`.
  - `generarProyectil()` no cambia: cada roca sale con `direccionHaciaJugador()`, calculada en el momento del disparo.
- **Diagrama extendido:** caja nueva `AtaqueRafaga` debajo de `AtaqueAvalancha`; en `StoneHinox`, `lanzarRocas : AtaqueRafaga` e `INTERVALO_ROCAS = 400`.
- **Diagrama reducido:** clase nueva `AtaqueRafaga` con su herencia hacia `AtaquePorProyectil`. Pasa a 95 clases/interfaces y 132 relaciones (125 dibujadas).
- **No cambian** `AtaquePorProyectil` (el Octorok y el Wizzrobe tiran igual), `AtaqueAvalancha`, la embestida ni el daño de las rocas (1 corazón).

**Prueba:** compila y se probó en el juego con un sector vacío, Link y el StoneHinox quieto eligiendo siempre lanzar rocas. Con Link alineado abajo y después corrido a un costado, cada ráfaga tira 3 rocas separadas, a los 0, 400 y 800 ms (medido: 17, 435 y 863 ms). Se grabó un video.

## 42. El daño de cada proyectil lo decide el enemigo que dispara

Antes, el daño de los disparos y de las rocas estaba en `FabricaEntidades` (`DANIO_DISPARO = 1` y `DANIO_ROCA_GRANDE = 2`). Ahora lo decide el enemigo que dispara, igual que el daño por contacto (`DANIO_CONTACTO` del Moblin) o el de la embestida (`DANIO_EMBESTIDA` del StoneHinox). La fábrica solo arma el proyectil con el daño que recibe. El daño del juego no cambia: medio corazón el disparo y 1 corazón la roca.

- **`FabricaEntidades`:** se quitan `DANIO_DISPARO` y `DANIO_ROCA_GRANDE` (y con ellas la sección de atributos de clase). `crearProyectil(x, y, d, danio)` y `crearRocaGrande(x, y, d, danio)` reciben el daño por parámetro y se lo pasan al constructor de `Proyectil`.
- **`Octorok`:** atributo de clase nuevo `DANIO_DISPARO = 1`. `generarProyectil()` llama a `crearProyectil(getX(), getY(), getDireccion(), DANIO_DISPARO)`.
- **`Wizzrobe`:** atributo de clase nuevo `DANIO_DISPARO = 1`. `generarProyectil()` llama a `crearProyectil(getX(), getY(), direccionHaciaJugador(), DANIO_DISPARO)`.
- **`StoneHinox`:** atributo de clase nuevo `DANIO_ROCA = 2`, al lado de `DANIO_EMBESTIDA`. `generarProyectil()` llama a `crearRocaGrande(getX(), getY(), direccionHaciaJugador(), DANIO_ROCA)`. Lo usan las dos formas de tirar rocas (la ráfaga y la avalancha).
- **Diagrama extendido:** en `FabricaEntidades` se quitan las dos constantes y los dos métodos suman `danio : int`; `Octorok` y `Wizzrobe` suman `- DANIO_DISPARO : int = 1` y `StoneHinox` suma `- DANIO_ROCA : int = 2`. Para que entre la línea nueva del Wizzrobe, `TrampaDeCuchillas` baja 14 px. El reducido no cambia.
- **No cambian** `Proyectil`, `Link.colisionarCon(Proyectil)` ni las direcciones de disparo.

**Prueba:** compila con `javac`. Es un cambio de lugar de las constantes, con los mismos valores.

## 43. Animación de muerte de Link y HUD en 0 al perder la última vida

Cuando a Link se le acababan los corazones, `morir()` restaba una vida y recargaba los corazones en el acto, sin que se viera nada. Ahora se ve la animación de muerte del juego original.

- **Imagen nueva `link-muerte.gif`** (en `original/` y `alternativa/`): la animación `dying` de `link0.ani`. Link gira 3 vueltas (12 cuadros de 133 ms) y queda tirado en el piso (500 ms). Dura 2,1 s, es de 48 × 48 y no se repite.
- **`FabricaSprites.crearSpritesLink()`:** registra el estado `muerte` con `link-muerte.gif`, al lado de `caida`.
- **`Link`:**
  - Atributo de clase nuevo `DURACION_MUERTE = 2100` y atributo nuevo `# muriendo : boolean` (`volatile`).
  - `morir()`: si ya está muriendo no hace nada; si no, prende `muriendo`, lo deja quieto (`MovimientoInducido(null, 0)`) e invulnerable (`DefensaLimitada(0, SIEMPRE)`), avisa a la vista y programa `terminarMuerte()` a los `DURACION_MUERTE` ms.
  - Método privado nuevo `terminarMuerte()`: apaga `muriendo`, devuelve el movimiento y resta la vida. Sin vidas, avisa a la vista y llama a `jugadorSinVidas()`. Con vidas, llena los corazones y llama a `alSerGolpeado()`, así queda 1 s invulnerable y parpadeando (si no, un enemigo que está al lado le saca medio corazón apenas se levanta).
  - `alSerGolpeado()`: no hace nada mientras está muriendo. `recibirDanio` lo llama después del golpe que lo mató, y si no, Link parpadeaba durante la animación.
  - `getRutaImagen()`: el estado `muerte` va primero, antes que `caida`.
  - `atacar()`, `usarEscudo()` y `restaurarDefensa()`: no hacen nada mientras muere, igual que mientras cae.
- **Arreglo del HUD:** al perder la última vida, nadie le avisaba a la vista antes de terminar la partida, así que el HUD quedaba en 1 vida. Ahora `terminarMuerte()` y `terminarCaida()` llaman a `notificarObservers()` antes de `jugadorSinVidas()`. En `terminarCaida()` los corazones se llenan solo si le quedan vidas.
- **La caída al vacío no cambia:** no pasa por `morir()`, así que muestra su GIF y no la animación de muerte, también en la última vida.
- **Diagrama extendido:** en `Link` se agregan `- DURACION_MUERTE : long = 2100`, `# muriendo : boolean` y `- terminarMuerte()`. El reducido no cambia.

**Prueba:** compila y se probó en el juego con un nivel de prueba de Link y un Moblin que camina hacia él. Con medio corazón y 3 vidas, gira y cae 2,1 s, se levanta con 2 vidas y el Moblin no le pega hasta 1 s después. En la última vida, la misma animación, el HUD pasa a 0 y aparece el pedido del nombre. Cayendo al vacío en la última vida, el HUD también pasa a 0. Se grabaron videos.

## 44. GIFs del Master Stalfos: caminar y golpe de espada en las 4 direcciones

Hasta ahora el Master Stalfos usaba imágenes fijas: al caminar se deslizaba sin mover las piernas (y `abajo` era igual a `derecha`, `arriba` igual a `izquierda`), y el golpe del cambio 14 mostraba dos imágenes (espada arriba y espada abajo) del lado donde estaba Link. Ahora camina y golpea con GIFs animados en las 4 direcciones.

- **Imágenes** (en `original/` y `alternativa/`):
  - Se quitan los 8 PNG: `masterstalfos-<dirección>.png` y `masterstalfos-ataque-<arriba/abajo>-<izquierda/derecha>.png`.
  - Se agregan `masterstalfos-<dirección>.gif` (caminar: 3 cuadros de 200 ms, en bucle) y `masterstalfos-ataque-<dirección>.gif` (golpe: 4 cuadros de 250, 100, 100 y 300 ms, 750 ms en total, sin repetir; el tercero y el cuarto muestran el arco del espadazo).
  - Los 8 GIFs miden 171 × 216 y tienen la calavera en el mismo lugar, así no salta al pasar de caminar a golpear. El cuerpo queda en `(25, 48)` del GIF, es decir, `MARGEN_IMAGEN_X + CUERPO_MARGEN_X` y `MARGEN_IMAGEN_Y + CUERPO_MARGEN_Y`. El lienzo es más grande que el de 144 × 144 porque la espada levantada y el arco salen de ese cuadro.
  - Se armaron con los cuadros de la hoja de sprites del equipo (los mismos de las imágenes anteriores), a la misma escala.
- **`FabricaSprites.crearSpritesMasterStalfos()`:** arma el sprite como el Moblin, con `agregar`: el estado `<dirección>` con `masterstalfos-<dirección>.gif` y `ataque-<dirección>` con `masterstalfos-ataque-<dirección>.gif`. Se van los 4 estados `ataque-<arriba/abajo>-<izquierda/derecha>`.
- **`MasterStalfos`:**
  - `VUELTAS_IMAGEN_GOLPE` pasa de 16 a 25: 25 vueltas de 30 ms son los 750 ms del GIF.
  - Se quita `VUELTAS_ESPADA_ARRIBA`: ya no hay un paso "espada abajo" que avisar aparte.
  - Atributos de clase nuevos `MARGEN_IMAGEN_X = 12` y `MARGEN_IMAGEN_Y = 36`, y atributo nuevo `- direccionGolpe : Direccion`.
  - `ataqueRealizado()`: además de empezar a contar, guarda `direccionGolpe = getDireccion()`. Así, si cambia de dirección en medio del golpe (`MovimientoAleatorio` gira cada 1,2 s), el GIF no se corta.
  - `actualizarEstado(c)`: avisa a la vista solo cuando `vueltasMostrandoGolpe` llega a 0, para volver al GIF de caminar.
  - `getRutaImagen()`: durante el golpe devuelve `ataque-` + la dirección del golpe. Ya no mira de qué lado está Link.
  - Consultas nuevas `getXImagen()` y `getYImagen()` (redefinen las de `Entidad`, como Link): `getX() - MARGEN_IMAGEN_X` y `getY() - MARGEN_IMAGEN_Y`. El cuerpo, el daño, el alcance de la espada y los choques no cambian, porque trabajan con el cuerpo.
- **Por qué el GIF arranca de nuevo en cada golpe:** `CeldaGrafica` solo carga la imagen cuando cambia la ruta, y al cargar un GIF llama a `flush()`. Al empezar el golpe la ruta pasa de `masterstalfos-<dir>.gif` a `masterstalfos-ataque-<dir>.gif`, así que el golpe se ve desde el primer cuadro.
- **Diagrama extendido:** en `MasterStalfos`, `VUELTAS_IMAGEN_GOLPE` pasa a 25, sale `VUELTAS_ESPADA_ARRIBA` y entran `- direccionGolpe : Direccion`, `- MARGEN_IMAGEN_X : int = 12`, `- MARGEN_IMAGEN_Y : int = 36`, `+ getXImagen() : int` y `+ getYImagen() : int`. La caja crece 4 líneas y el `StoneHinox` baja 52 px. El reducido no cambia.

**Prueba:** compila y se probó en el juego real con el modo gráfico original: el Master Stalfos camina al azar con el GIF de caminar y, con Link quieto abajo, a la derecha, arriba y a la izquierda, golpea con el GIF de esa dirección y vuelve a caminar. Se grabó un video.

## 45. GIF distinto para perder una vida y para perder la última

Con el cambio 43, Link mostraba la misma animación de muerte (3 vueltas y tirado en el piso, 2,1 s) cada vez que se quedaba sin corazones, le quedaran vidas o no. Ahora, si le quedan vidas, cae para atrás y se levanta; la animación de muerte queda solo para la última vida.

- **Imagen nueva `link-pierde-vida.gif`** (en `original/` y `alternativa/`), de 48 × 48 y sin repetir: Link mirando abajo (150 ms), retrocede en dos pasos (90 ms cada uno), cae sentado (90 ms), se queda sentado (600 ms), se agacha para levantarse (120 ms) y queda parado (160 ms). Dura 1,3 s. Se armó con la imagen `link-abajo.png` y el cuadro de Link sentado de `link-muerte.gif` (el `stunned` / `pushed_over` del juego original, que no tiene una animación aparte para perder una vida).
- **`FabricaSprites.crearSpritesLink()`:** registra el estado `pierde-vida` con `link-pierde-vida.gif`, al lado de `muerte`.
- **`Link`:**
  - Atributo de clase nuevo `DURACION_PERDER_VIDA = 1300`.
  - `morir()`: programa `terminarMuerte()` a los `vidas > 1 ? DURACION_PERDER_VIDA : DURACION_MUERTE` ms.
  - `getRutaImagen()`: mientras `muriendo`, el estado es `vidas > 1 ? "pierde-vida" : "muerte"`.
  - No hace falta un atributo nuevo: `vidas` se resta recién en `terminarMuerte()`, así que durante la animación todavía vale lo de antes (`vidas == 1` es la última).
  - Lo demás del 43 no cambia: quieto e invulnerable mientras dura la animación, revive con 1 s de parpadeo, y el HUD pasa a 0 en la última vida. La caída al vacío tampoco cambia.
- **Diagrama extendido:** en `Link` se agrega `- DURACION_PERDER_VIDA : long = 1300`. El reducido no cambia.

**Prueba:** compila y se probó en el juego con Link con medio corazón y un Moblin que camina hacia él. Con 3 vidas, cae para atrás y se levanta (1,3 s) y revive con 2 vidas. En la última vida, gira 3 veces y queda tirado (2,1 s), el HUD pasa a 0 y termina la partida. Se grabó un video.

## 46. Sin `return` anticipado

Había 10 lugares que cortaban el método con `return;` cuando no tenía que hacer nada (una "guarda"). Ahora el cuerpo va dentro de un `if` con la condición contraria, así cada método tiene una sola salida, al final. El comportamiento no cambia en ninguno.

| Método | Antes | Ahora |
|---|---|---|
| `Link.alSerGolpeado()` | `if (muriendo) return;` | El cuerpo dentro de `if (!muriendo) { ... }` |
| `Link.morir()` | `if (muriendo) return;` | `if (!muriendo) { ... }` |
| `Link.caerAlVacio()` | `if (cayendo) return;` | `if (!cayendo) { ... }` |
| `Moblin.morir()` (también lo usa `MoblinConEspadaYEscudo`) | `if (muriendo) return;` | `if (!muriendo) { ... }` |
| `AtaquePorProyectil.atacar(...)` | `if (!puedeAtacar(atacante)) { return; }` | `if (puedeAtacar(atacante)) { ... }` |
| `AtaqueRecargado.atacar(...)` | `if (!atacante.soltoElAtaque()) { return; }` | `if (atacante.soltoElAtaque()) { ... }` |
| `GUI.procesarTecla(...)` | `if (controlJugador == null) { return; }` | El `switch` dentro de `if (controlJugador != null) { ... }` |
| `CeldaGrafica.actualizar()` | Dos `return`: si la celda ya no está en el panel y después de quitarla | `if (getParent() != null)` y adentro `if (estaEliminada()) quitarCelda(this); else redibujar();` |
| `PanelPantallaNivel.desplazar(d)` | `return;` dentro del `catch (InterruptedException)` | El `for` sigue mientras `paso <= pasos && !Thread.currentThread().isInterrupted()`; el `catch` solo vuelve a marcar la interrupción |

- **`CeldaGrafica`: método privado nuevo `redibujar()`.** Tiene, sin cambios, lo que estaba después de los dos `return`: carga la imagen si cambió la ruta (con `flush()` si es GIF), `setVisible` y `setBounds`. Así `actualizar()` queda en las cuatro líneas que deciden qué hacer, en lugar de tres niveles de `if` anidados.
- **`PanelPantallaNivel.desplazar`:** si interrumpen el hilo mientras duerme, el `catch` vuelve a marcar la interrupción, y el `for` termina en la próxima vuelta sin dar otro paso. Después del `for` no hay nada, así que hace lo mismo que el `return`.
- **Javadoc:** `CeldaGrafica.actualizar()` y `redibujar()`, `GUI.procesarTecla()` (sin partida no hace nada) y `PanelPantallaNivel.desplazar()` (si interrumpen el hilo, corta la animación).
- **Diagrama extendido:** en `CeldaGrafica` se agrega `- redibujar()`. La caja crece una línea y `CeldaJugador` baja 13 px. El reducido no cambia.
- En `Cambios` y en `Explicaciones`, el código de los cambios anteriores (por ejemplo el 34 y el 43) queda como se escribió en su momento en las secciones de cada cambio; las explicaciones del código actual muestran la versión con `if`.

**Prueba:** compila y se probó en el juego (pantalla virtual) con un programa que aprieta las teclas y revisa el resultado de cada uno de los 10 lugares: las flechas mueven a Link y sin partida no hacen nada; el golpe normal sale al soltar A y el cargado al soltar después de 3 s; el Octorok dispara; el Moblin y el Moblin con espada y escudo muestran la nube, ignoran golpes mientras mueren y su celda se quita; Link pierde una vida, cae al vacío (pierde una sola vida aunque se llame dos veces) y en la última vida termina la partida; el cambio de sector se anima y, si se interrumpe el hilo, la animación corta enseguida. Se grabó un video.

## 47. Animación de muerte del Master Stalfos

Hasta ahora el Master Stalfos desaparecía en el mismo instante en que recibía el último golpe. Ahora, como el Moblin (cambio 34) y Link (cambio 43), se queda quieto e invulnerable mostrando su muerte y recién después desaparece.

- **Imágenes nuevas `masterstalfos-muerte-<dirección>.gif`** (en `original/` y `alternativa/`), de 171 × 216 como los del cambio 44 y sin repetir. Duran 1,53 s: el cuadro de golpeado de esa dirección parpadeando (6 cuadros de 80 ms), el esqueleto desarmado en el piso (450 ms, alineado por la calavera) y la nube de muerte de los enemigos agrandada (4 cuadros de 150 ms).
- **`FabricaSprites.crearSpritesMasterStalfos()`:** registra el estado `muerte-<dirección>` con `masterstalfos-muerte-<dirección>.gif`.
- **`MasterStalfos`:**
  - Atributo de clase nuevo `DURACION_MUERTE = 1530` y atributo nuevo `# muriendo : boolean`.
  - Comando nuevo `morir()` (redefine el de `Jefe`): si no estaba muriendo, marca `muriendo`, cancela las acciones programadas (el cambio de fase), queda quieto (`MovimientoInducido` sin dirección) e invulnerable (`DefensaLimitada(0, SIEMPRE)`), avisa a la vista y programa `super.morir()` a los 1530 ms. `Jefe.morir()` lo elimina y llama a `jefeDerrotado`, que suma los puntos y pasa de nivel o termina la partida.
  - Comando nuevo `colisionarCon(Link l)`: mientras muere no lastima al tocarlo (como el Moblin).
  - Cambia `alSerGolpeado()`: el cuerpo va dentro de `if (!muriendo)`. El último golpe llama a `morir()` y después a `alSerGolpeado()`; sin el `if`, la animación de muerte parpadeaba y a los 800 ms volvía a la defensa normal.
  - Cambia `getRutaImagen()`: mientras muere devuelve `muerte-` + la dirección en que mira.
  - Cambia `quiereAtacar()`: `return !muriendo && zona.intersecta(...)`, así no golpea con la espada mientras muere.
  - Se importan `MovimientoInducido` y `Link`.
- **Qué cambia al jugar:** el paso al nivel siguiente (o el fin de la partida) llega 1,5 s más tarde, cuando termina la animación. Los puntos no cambian. El StoneHinox no cambia.
- **Javadoc:** el de la clase, `morir()`, `colisionarCon(Link)`, `alSerGolpeado()`, `getRutaImagen()`, `quiereAtacar()` y `FabricaSprites.crearSpritesMasterStalfos()`.
- **Diagrama extendido:** en `MasterStalfos` se agregan `# muriendo : boolean`, `- DURACION_MUERTE : long = 1530`, `# morir()` y `+ colisionarCon(l : Link)`. La caja crece 4 líneas y el `StoneHinox` baja 52 px. El reducido no cambia.

**Prueba:** compila y se probó en el juego con el mismo programa del cambio 46: con una vida, al recibir el golpe muestra el GIF de muerte de su dirección, no quiere atacar, no parpadea, no lastima a Link aunque lo toque, ignora otro golpe y a los 1530 ms desaparece y suma 5000 puntos. Se grabó un video.

## 48. Animación de muerte para todos los enemigos

Hasta ahora solo el Moblin (cambio 34), el Moblin con espada y escudo y el Master Stalfos (cambio 47) mostraban una animación al morir; el Octorok, el Erizo de mar, el Wizzrobe y el StoneHinox desaparecían en el instante del último golpe. Ahora todos la muestran. En lugar de copiar el código del Moblin en cada clase, la muerte animada pasa a `Enemigo` y la heredan todos (la trampa de cuchillas no muere).

- **`Enemigo` (Template Method):**
  - Atributo de clase nuevo `DURACION_MUERTE = 300` y atributo nuevo `# muriendo : boolean` (los dos estaban en `Moblin`).
  - Cambia `morir()`: si no estaba muriendo, marca `muriendo`, cancela lo programado, queda quieto (`MovimientoInducido` sin dirección), invulnerable (`DefensaLimitada(0, SIEMPRE)`) y sin atacar (`AtaquePorContacto(0)`), avisa a la vista y programa `desaparecer()` a los `getDuracionMuerte()` ms. Antes hacía `eliminar()` y `enemigoDerrotado(this)`.
  - Gancho nuevo `# desaparecer()`: lo que antes hacía `morir()` (`eliminar()` y `enemigoDerrotado(this)`).
  - Consulta nueva `# getDuracionMuerte() : long`: devuelve `DURACION_MUERTE`.
  - Consulta nueva `+ getRutaImagen() : String`: mientras muere, el estado `muerte` del sprite.
  - Cambia `colisionarCon(Link l)`: mientras muere no lastima a Link (estaba en `Moblin`).
  - Se importan `AtaquePorContacto`, `DefensaLimitada` y `MovimientoInducido`.
- **`EnemigoConDrop` y `Jefe`:** su `morir()` pasa a llamarse `desaparecer()`, con el mismo cuerpo (soltar el drop o avisar `jefeDerrotado`).
- **`Moblin`:** se eliminan `DURACION_MUERTE`, `muriendo`, `morir()`, `colisionarCon(Link)`, `getRutaImagen()` y los imports de `MovimientoInducido`, `Link` y `Direccion`: ahora los hereda. `MoblinConEspadaYEscudo` no cambia (sigue mirando `muriendo` en `vigilarJugador()`).
- **`MasterStalfos`:** se eliminan `muriendo`, `morir()`, `colisionarCon(Link)` y los imports de `MovimientoInducido` y `Link`. `quiereAtacar()` ya no mira `muriendo`: al morir, el ataque pasa a ser `AtaquePorContacto(0)` y su `AtaqueEspada` no se usa más. Consulta nueva `getDuracionMuerte()`, que devuelve su `DURACION_MUERTE = 1530`. Quedan `alSerGolpeado()` con `if (!muriendo)` y `getRutaImagen()` con `muerte-<dirección>`.
- **`Wizzrobe`:** `alSerGolpeado()` va dentro de `if (!muriendo)` (el golpe que lo mata no lo hace parpadear ni teletransportarse), y `getRutaImagen()` no muestra aparecer ni desaparecer mientras muere.
- **`StoneHinox`:** en `getRutaImagen()`, el estado `muerte` va antes que `vulnerable` y `avalancha`.
- **`FabricaSprites`:** `crearSpritesOctorok()`, `crearSpritesErizoDeMar()`, `crearSpritesWizzrobe()` y `crearSpritesStoneHinox()` agregan el estado `muerte` con `<nombre>-muerte.gif`.
- **Imágenes nuevas** (en `original/` y `alternativa/`): `octorok-muerte.gif`, `erizodemar-muerte.gif` y `wizzrobe-muerte.gif` son la misma nube de `moblin-muerte.gif` (48 × 48, 2 cuadros de 150 ms, sin repetir); `stonehinox-muerte.gif` es esa nube agrandada al doble (96 × 96).
- **Qué cambia al jugar:** el Octorok, el Erizo, el Wizzrobe y el StoneHinox muestran la nube 300 ms antes de desaparecer (y soltar el drop, o pasar de nivel). Mientras tanto ninguno ataca, dispara ni lastima. El Moblin y el Master Stalfos se ven igual que antes.
- **Javadoc:** el de la clase `Enemigo` y sus métodos nuevos o cambiados, `desaparecer()` de `EnemigoConDrop` y `Jefe`, `MasterStalfos` (clase, `getDuracionMuerte()` y `quiereAtacar()`), `Wizzrobe.alSerGolpeado()` y `getRutaImagen()`, `StoneHinox.getRutaImagen()` y los cuatro `crearSprites...()`.
- **Diagrama extendido:** en `Enemigo*` se agregan `- DURACION_MUERTE : long = 300`, `# muriendo : boolean`, `# desaparecer()`, `+ getRutaImagen() : String` y `# getDuracionMuerte() : long` (la caja crece 5 líneas y `EnemigoConDrop*` y `Moblin` bajan 65 px); en `EnemigoConDrop*` y `Jefe*`, `# morir()` pasa a `# desaparecer()`; en `Moblin` salen `DURACION_MUERTE`, `muriendo`, `morir()`, `colisionarCon(l : Link)`, `getRutaImagen()` y el «comandos» que quedaba vacío; en `MasterStalfos` salen `muriendo`, `morir()` y `colisionarCon(l : Link)`, y entra `# getDuracionMuerte() : long`. El reducido no cambia: no hay clases ni relaciones nuevas.

**Prueba:** compila y se probó en el juego, con los dos modos gráficos, con un programa que mata a cada enemigo (Octorok, Erizo, Wizzrobe, Moblin, Moblin con espada y escudo, StoneHinox y Master Stalfos) con Link encima: los 7 muestran su muerte, quedan quietos, no parpadean, no lastiman a Link ni disparan, ignoran otro golpe, y al terminar desaparecen y suman sus puntos una sola vez (28 de 28 en cada modo). La prueba de los cambios 46 y 47 sigue dando 33 de 33. Se grabó un video.

## 49. Link sigue caminando al soltar una flecha si queda otra apretada

Antes, cualquier flecha que se soltaba llamaba a `detenerMovimiento()`. Si se mantenía → y se tocaba y soltaba ↑, Link se frenaba aunque → siguiera apretada, y había que volver a apretarla. Ahora `GUI` recuerda qué flechas están apretadas.

- **`GUI`:**
  - Atributos nuevos `# arribaPresionada`, `# abajoPresionada`, `# izquierdaPresionada` y `# derechaPresionada`, todos `boolean`.
  - Cambia `procesarTecla(int codigo, boolean presionada)`: cada flecha solo anota en su atributo si se apretó o se soltó, y marca la variable local `esFlecha`. Después del `switch`, si fue una flecha, Link se mueve hacia una que siga apretada, en el orden arriba, abajo, izquierda, derecha; si no queda ninguna, `detenerMovimiento()`. A (ataque), S (escudo) y D (cambiar objeto) no cambian. Sigue sin `return` anticipado (cambio 46).
  - Cambia `iniciarPartida(...)`: pone los 4 atributos en `false`, para que una flecha que quedó anotada de antes no mueva a Link en la partida nueva.
- **Qué cambia al jugar:** al soltar una flecha mientras se mantiene otra, Link sigue caminando hacia la que queda apretada. Con dos flechas apretadas a la vez gana la primera en ese orden.
- **Javadoc:** `procesarTecla(...)` e `iniciarPartida(...)`.
- **Diagrama extendido:** en `GUI` se agregan los 4 atributos (la caja crece 4 líneas y `Ventana` y el paquete `principal` bajan 52 px). El reducido no cambia.

**Prueba:** compila y se probó con un programa que le pasa teclas a `procesarTecla` y anota lo que recibe el jugador: mantener →, apretar y soltar ↑ y soltar → da `mover(DERECHA)`, `mover(ARRIBA)`, `mover(DERECHA)` y `detenerMovimiento()`; A, S y D hacen lo mismo que antes; sin partida no se anota nada, e `iniciarPartida` limpia las flechas.

## 50. Animaciones del StoneHinox en GIF

El StoneHinox tenía tres imágenes fijas (cambio 20): normal, golpe de la avalancha y vulnerable. Ahora todos sus estados son GIF animados, hechos con los cuadros del juego original, y la embestida tiene su propia animación.

- **`StoneHinox`:**
  - Atributo nuevo `- embistiendo : boolean` (`volatile`, como `vulnerable` y `golpeandoSuelo`).
  - Cambia `siguienteAtaque()`: al elegir la embestida pone `embistiendo = true` y avisa a la vista.
  - Cambia `embestidaTerminada()`: pone `embistiendo = false` antes de quedar vulnerable.
  - Cambia `getRutaImagen()`: el orden es `muerte`, `vulnerable`, `avalancha`, `embestida` y `normal`.
- **`FabricaSprites.crearSpritesStoneHinox()`:** ya no usa `armar(...)`, que pide PNG; agrega los estados `normal`, `embestida`, `vulnerable`, `avalancha` y `muerte` con `stonehinox-<estado>.gif`.
- **Imágenes** (en `original/` y `alternativa/`, 96 × 96, sin fondo):
  - `stonehinox-normal.gif`: caminar, 2 cuadros de 300 ms, en bucle.
  - `stonehinox-embestida.gif`: los pasos rápidos, 2 cuadros de 110 ms, en bucle.
  - `stonehinox-vulnerable.gif`: los cuadros de la embestida en naranja, 2 cuadros de 300 ms, en bucle (al ritmo de caminar).
  - `stonehinox-avalancha.gif`: brazos arriba (150 ms) y puño contra el suelo (450 ms), sin repetir; dura los 600 ms del golpe.
  - Se quitan `stonehinox-normal.png`, `stonehinox-avalancha.png` y `stonehinox-vulnerable.png`.
- **Qué cambia al jugar:** el StoneHinox camina moviendo las piernas, embiste con pasos rápidos, queda vulnerable en naranja caminando en el lugar y golpea el suelo levantando los brazos.
- **Javadoc:** `embestidaTerminada()`, `getRutaImagen()` y `crearSpritesStoneHinox()`.
- **Diagrama extendido:** en `StoneHinox` se agrega `- embistiendo : boolean` (la caja crece una línea). El reducido no cambia.

**Prueba:** compila y se probó con los dos modos gráficos: el StoneHinox recién creado usa `normal.gif`, al embestir `embestida.gif`, al terminar `vulnerable.gif` y al golpear el suelo `avalancha.gif`, y los 5 GIF cargan a 96 × 96 (14 de 14 resultados, junto con el cambio 49). Las pruebas de los cambios 46 a 48 siguen dando 33 de 33 y 28 de 28. Se grabó un video del StoneHinox embistiendo y quedando vulnerable.

## 51. La GUI suelta el control de Link al terminar la partida

Después de la muerte definitiva de Link, al apretar teclas seguía girando, sacaba la espada o levantaba el escudo. `Juego.terminarPartida()` frenaba el reloj y los hilos, pero la `GUI` seguía guardando a Link en `controlJugador` y le mandaba cada tecla. Link no avanzaba, porque su hilo estaba detenido, pero cada tecla le cambiaba la imagen. Pasaba también mientras se escribía el nombre del ranking y en el menú, hasta empezar otra partida. Ahora el juego le avisa a la vista que la partida terminó y la `GUI` suelta el control.

- **`ControladorGrafico`:** comando nuevo `+ terminarControl()`: deja de enviarle las teclas al jugador porque la partida terminó.
- **`Juego`:** cambia `terminarPartida()`: después de `hiloMundo.detener()` llama a `controladorGrafico.terminarControl()`, antes de pedir el nombre o mostrar el ranking.
- **`GUI`:** comando nuevo `+ terminarControl()`, lo opuesto de `iniciarPartida(...)`: pone `controlJugador = null` y las cuatro flechas en `false`. Como `procesarTecla(...)` ya ignora las teclas cuando `controlJugador` es `null` (cambio 46), Link deja de responder. No usa `invokeLater` porque no toca Swing.
- **Qué cambia al jugar:** cuando termina la partida (sin vidas, se acabó el tiempo en Contrarreloj, el primer daño en NoHit o ganar el último nivel), las teclas no hacen nada en el cuadro del nombre, en el ranking ni en el menú. Al empezar otra partida, `iniciarPartida` toma el control del Link nuevo, como antes.
- **Javadoc:** `ControladorGrafico.terminarControl()`, `GUI.terminarControl()`, `GUI.iniciarPartida(...)`, `GUI.procesarTecla(...)` y `Juego.terminarPartida()`.
- **Diagrama extendido:** en `ControladorGrafico` y en `GUI` se agrega `+ terminarControl()`, antes de `pedirNombre`. Las dos cajas crecen una línea; `Ventana`, el paquete `principal` y `ControladorDeVistas` bajan 13 px. El reducido no cambia: `Juego` ya conocía a `ControladorGrafico` y `GUI` ya lo realizaba.

**Prueba:** compila y se probó con un programa (pantalla virtual) que arma la `GUI` y el `Juego` reales: sin partida no hay jugador; en partida la `GUI` tiene a Link y anota las flechas; al llamar `terminarPartida()` queda sin jugador y sin flechas, y apretar ↑, A, S y D no gira a Link, no lo hace atacar ni levantar el escudo; al volver al menú sigue sin jugador; al empezar otra partida toma el control de un Link nuevo y las flechas llegan (11 de 11).

## Detalle archivo por archivo

El cambio 15 toca muchos archivos con el mismo tipo de cambio, así que su detalle está en su propia sección (15.1 a 15.3) y no se repite acá. Lo mismo pasa con el cambio 17 (sección 17.7).

Esta sección lista cada archivo de `Codigo/` que cambió respecto del código subido a `defensa 7/Codigo` (el commit `efc5be2`, punto de partida). Se comparó archivo por archivo con `diff`. Para cada archivo se indica qué atributos, constructores y métodos se agregaron, cambiaron o quitaron, y a qué cambio del resumen corresponde (entre corchetes, por ejemplo **[4]**).

Fuera de los cambios 15 y 17, no cambiaron los demás archivos de `src/`: `Juego` (salvo el cambio 22), `Escena`, `Sector`, `Nivel`, los comportamientos (salvo `AtaqueRecargado`, cambio 18, y `AtaquePorProyectil`, cambio 29), los hilos, `Sprite`, las fábricas de entidades, el resto de la vista (salvo `GUI`, cambio 46) y el enemigo `Jefe` (salvo el cambio 48; `EnemigoConDrop` cambia con el 19). `ControladorGrafico`, `Juego` y `GUI` cambian también con el 51.

### Índice

| Archivo (`Codigo/src/…`) | Cambios |
|---|---|
| `logica/EntidadLogica.java` | [5] [11] [25] |
| `logica/entidades/AdministradorColisiones.java` | [6] [38] [40] |
| `logica/entidades/Entidad.java` | [6] [9] [11] [25] |
| `logica/entidades/EntidadAnimada.java` | [5] [6] [9] [11] [13] [34] [40] |
| `logica/comportamientos/AtaqueRecargado.java` | [18] [38] [40] [46] |
| `logica/comportamientos/AtaquePorProyectil.java` | [29] [46] |
| `logica/comportamientos/AtaqueRafaga.java` (nueva) | [41] |
| `logica/entidades/Link.java` | [4] [5] [6] [10] [13] [18] [25] [31] [32] [33] [36] [37] [38] [39] [40] [43] [45] [46] |
| `logica/entidades/enemigos/Enemigo.java` | [6] [48] |
| `logica/entidades/enemigos/ErizoDeMar.java` | [4] |
| `logica/entidades/enemigos/Moblin.java` | [4] [34] [46] [48] |
| `logica/entidades/EntornoJuego.java` | [22] |
| `logica/entidades/enemigos/EnemigoConDrop.java` | [19] [22] [48] |
| `logica/entidades/enemigos/Jefe.java` | [48] |
| `logica/entidades/enemigos/MoblinConEspadaYEscudo.java` | [9] [19] [26] [27] [28] [34] [35] |
| `logica/entidades/enemigos/Octorok.java` | [4] [42] |
| `logica/entidades/enemigos/StoneHinox.java` | [4] [20] [41] [42] [48] [50] |
| `logica/entidades/enemigos/TrampaDeCuchillas.java` | [4] [7] [8] [9] |
| `logica/entidades/enemigos/MasterStalfos.java` | [13] [14] [44] [47] [48] |
| `logica/entidades/enemigos/Wizzrobe.java` | [4] [12] [13] [30] [42] [48] |
| `logica/entidades/fijas/Agua.java` | [6] [9] |
| `logica/entidades/fijas/CaidasAlVacio.java` | [4] [6] [9] [31] |
| `logica/entidades/fijas/FragmentoDeCorazon.java` | [23] |
| `logica/entidades/fijas/Objeto.java` | [5] |
| `logica/entidades/fijas/Obstaculo.java` | [5] |
| `logica/entidades/fijas/PowerUP.java` | [5] |
| `logica/entidades/fijas/Roca.java` | [4] [5] [6] [9] |
| `logica/fabricas/FabricaEntidades.java` | [42] |
| `logica/fabricas/FabricaSprites.java` | [10] [14] [18] [20] [30] [31] [34] [35] [36] [39] [43] [44] [45] [47] [48] [50] |
| `logica/ControladorGrafico.java` | [51] |
| `logica/juego/Juego.java` | [22] [51] |
| `logica/mapa/GeneradorNivel.java` | [1] |
| `logica/util/Hitbox.java` | [9] [31] [38] [40] |
| `vista/CeldaGrafica.java` | [11] [25] [30] [46] |
| `vista/GUI.java` | [46] [49] [51] |
| `vista/PanelPantallaNivel.java` | [5] [25] [46] |
| `Recursos/Niveles/nivel1.txt`, `nivel2.txt` | [1] [2] |
| `Recursos/Imagenes/original/` y `alternativa/` | [3] [14] [18] [19] [20] [23] [24] [36] [39] [43] [44] [45] [47] [48] [50] |
| Comentarios y javadoc de 16 clases (ver la sección 40) | [40] |

### Paquete `logica`

#### `EntidadLogica.java` (interfaz que ve la vista)

- **[5]** Se agregan 5 constantes de capa, en una sección nueva `// Atributos de clase`:
  ```java
  int CAPA_SUELO = 0;       // pasto, agua, caídas al vacío y suelo quebradizo
  int CAPA_OBJETOS = 1;     // objetos y power-ups
  int CAPA_OBSTACULOS = 2;  // rocas
  int CAPA_PERSONAJES = 3;  // enemigos, jefes y proyectiles
  int CAPA_JUGADOR = 4;     // Link, la más alta
  ```
- **[5]** Se agrega la consulta `int getCapa();`: las capas más altas tapan a las más bajas.
- **[11]** Se agrega la consulta `boolean esVisible();`: es falso en los instantes apagados de un parpadeo.
- **[25]** Se agregan las consultas `int getXImagen();` e `int getYImagen();`: dónde se dibuja la imagen, que puede no coincidir con `getX()`/`getY()`.

#### `ControladorGrafico.java` **[51]**

- **[51]** **Comando nuevo** `void terminarControl();`, antes de `pedirNombre`: la vista deja de enviarle las teclas al jugador porque la partida terminó.

### Paquete `logica.comportamientos`

#### `AtaquePorProyectil.java` **[29] [46]**

- **Cambia** `puedeAtacar(EntidadAnimada a)`: agrega `&& !a.hayObstaculoHastaJugador()`.
- **Cambia** el javadoc de la clase y el de `puedeAtacar`. También cambian los javadoc de `Octorok`, `Wizzrobe`, `EntidadAnimada.hayObstaculoHastaJugador()` e `impideAbalanzarse()` en `Entidad`, `Roca`, `Agua` y `CaidasAlVacio`.
- **[46]** **Cambia** `atacar(...)`: en lugar de `if (!puedeAtacar(atacante)) return;`, dispara dentro de `if (puedeAtacar(atacante)) { ... }`.

#### `AtaqueRafaga.java` **[41]** (nueva)

- Hereda de `AtaquePorProyectil`. Atributo `# lanzados : int`, constructor `AtaqueRafaga(GeneradorProyectil g, int cantidad, long intervalo)`, comando `+ reiniciar()` y los ganchos redefinidos `# alTerminar`, `# puedeAtacar` y `# cantidadDeProyectiles` (ver la sección 41).

#### `AtaqueRecargado.java` **[18] [38] [40] [46]**

- **[18]** **Cambia** `atacar(EntidadAnimada atacante, AdministradorColisiones c)`: ya no pone `inicioCarga = -1` después de golpear. La hora la pisa el próximo `cargar()`, así `estaCargado()` sigue respondiendo por el último golpe mientras se ve su imagen.
- **[18]** El javadoc de `estaCargado()` lo explica.
- **[38]** **Cambia** `atacar(...)`: si `estaCargado()`, llama a `c.golpearAlrededor(atacante, alcance * FACTOR_CARGA, danio * FACTOR_CARGA)`; si no, `golpear(...)` como antes.
- **[40]** El javadoc de la clase nombra las constantes y menciona el giro.
- **[46]** **Cambia** `atacar(...)`: en lugar de `if (!atacante.soltoElAtaque()) return;`, golpea dentro de `if (atacante.soltoElAtaque()) { ... }`.

### Paquete `logica.entidades`

#### `AdministradorColisiones.java` **[6] [38] [40]**

- **Se quita** `private boolean puedeMoverA(EntidadAnimada e, Direccion d, int pasos)`. Antes devolvía `false` si alguna entidad con `bloqueaPaso()` en `true` se cruzaba con el paso siguiente.
- **Se agrega** `private Entidad buscarBloqueo(EntidadAnimada e, Direccion d, int pasos)`. Devuelve la entidad que no deja dar el paso, o `null` si el paso está libre. Una entidad frena el paso si cumple todo esto:
  - no es la misma `e`;
  - no está eliminada (`!estaEliminada()`, condición nueva);
  - su cuerpo se cruza con el paso siguiente;
  - su cuerpo **no** se cruza ya con el de `e` (condición nueva: si ya estaban superpuestas, no la frena y puede salir);
  - `entidadDelSector.bloqueaPasoA(e)` (le pregunta a la entidad si le bloquea el paso a `e`).
- **Cambia** `public boolean mover(EntidadAnimada e, Direccion d, int pasos)`:
  ```java
  // Antes
  boolean avanzo = puedeMoverA(e, d, pasos);
  ... else { e.alChocarConBloqueo(); }
  // Ahora
  Entidad bloqueo = buscarBloqueo(e, d, pasos);
  boolean avanzo = bloqueo == null;
  ... else { bloqueo.aceptarColision(e); e.alChocarConBloqueo(); }
  ```
  Como al frenarse los cuerpos no llegan a superponerse, `mover` dispara a mano el choque (Visitor de efectos). Así sigue funcionando el daño por contacto entre Link y los enemigos.
- **[38]** **Comando nuevo** `public void golpearAlrededor(EntidadAnimada atacante, int alcance, int danio)`: igual que `golpearEn`, pero golpea a todas las entidades cuyo cuerpo se cruza con `atacante.getHitbox().alrededor(alcance)`.
- **[40]** En el extendido, el parámetro de `verificarColisiones` pasa a llamarse `entidadActualizada`, como en el código.

#### `Entidad.java`

- **[6]** La declaración de la clase no cambia (`implements Colisionable, EntidadLogica`).
- **[6]** **Se quita** `public boolean bloqueaPaso()` (devolvía `false`).
- **[6]** **Se agrega** `public boolean bloqueaPasoA(EntidadAnimada quien)`, que devuelve `false`: por defecto no le bloquea el paso a nadie.
- **[9]** **Se agrega** `public boolean impideAbalanzarse()`, que devuelve `false`. Ocupa el lugar donde estaba `bloqueaPaso()`.
- **[11]** **Se agrega** `public boolean esVisible()`, que devuelve `true`: las entidades fijas siempre se ven.
- **[25]** **Se agregan** `public int getXImagen()` y `public int getYImagen()`, que devuelven `getX()` y `getY()`.

#### `EntidadAnimada.java`

- **[6]** La declaración de la clase no cambia (`extends Entidad implements Colisionador`).
- **[9]** Se importa `logica.util.Hitbox`.
- **[11]** **Atributo de clase nuevo:** `private static final long DURACION_PARPADEO = 600;` (en una sección nueva `// Atributos de clase`).
- **[11]** **Atributo de instancia nuevo:** `protected volatile long finParpadeo;`. Guarda hasta cuándo parpadea, en milisegundos; `0` quiere decir que no parpadea. Es `volatile` porque lo escribe el hilo del juego y lo lee la vista.
- **[11]** **Cambia** `public synchronized void aplicarDanio(int danio)`. Después de restar la vida, si sigue viva arranca el parpadeo:
  ```java
  vida -= danio;
  if (vida > 0)
      finParpadeo = System.currentTimeMillis() + DURACION_PARPADEO;
  notificarObservers();
  ```
- **[11]** **Cambia** `actualizarEstado(AdministradorColisiones c)`: al final de la vuelta llama a `avisarParpadeo()`.
- **[11]** **Método privado nuevo** `private void avisarParpadeo()`. Mientras `finParpadeo != 0`, avisa a la vista en cada vuelta (`notificarObservers()`) para que la prenda y la apague. Cuando se pasa la hora, pone `finParpadeo = 0` y avisa una última vez, para que quede visible.
- **[11]** **Consulta nueva** `public boolean esVisible()` (redefine la de `Entidad`):
  ```java
  long ahora = System.currentTimeMillis();
  return ahora >= finParpadeo || (ahora / 100) % 2 == 0;
  ```
  Fuera del parpadeo siempre es `true`; durante el parpadeo alterna cada 100 ms.
- **[40]** **Atributo de clase nuevo** `private static final long PERIODO_PARPADEO = 100;`. `esVisible()` usa `(ahora / PERIODO_PARPADEO) % 2 == 0` en lugar del `100` suelto.
- **[6]** **Consultas nuevas** que usa `bloqueaPasoA`:

  | Método | Devuelve | Qué indica |
  |---|---|---|
  | `public boolean esquivaVacios()` | `false` | si trata las caídas al vacío como una pared |
  | `public boolean esFrenadoPorPersonajes()` | `false` | si lo frenan Link y los enemigos |
- **[13]** **Comando nuevo** `protected void parpadearDurante(long ms)`, después del gancho `alSerGolpeado()`:
  ```java
  finParpadeo = Math.max(finParpadeo, System.currentTimeMillis() + ms);
  notificarObservers();
  ```
  Estira el parpadeo hasta `ahora + ms`; si ya parpadeaba más, no lo acorta.
- **[34]** **Comando nuevo** `protected synchronized void cancelarProgramadas()`, después de `programar(...)`: vacía `pendientes`. Lo usa el Moblin al morir.
- **[5]** **Consulta nueva** `public int getCapa()`, que devuelve `CAPA_PERSONAJES`. La heredan enemigos, jefes y proyectiles.
- **[9]** **Consulta nueva** `public boolean hayObstaculoHastaJugador()`. Arma la franja entre su cuerpo y el de Link con `getHitbox().caminoHasta(link.getHitbox())` y recorre las entidades del sector. Devuelve `true` si alguna (que no sea ella misma, ni Link, ni una eliminada) tiene `impideAbalanzarse()` en `true` y se cruza con la franja.

#### `Link.java`

- **[4]** **Atributos de clase nuevos**, en una sección nueva `// Atributos de clase`:
  ```java
  private static final int CUERPO_MARGEN_X = 6;
  private static final int CUERPO_MARGEN_Y = 2;
  private static final int CUERPO_ANCHO = 36;
  private static final int CUERPO_ALTO = 44;
  ```
- **[10]** **Atributo de clase nuevo** `private static final int VUELTAS_IMAGEN_GOLPE = 7;` (unos 200 ms mostrando la imagen del golpe).
- **[10]** **Atributo de instancia nuevo** `protected int vueltasMostrandoGolpe;`, entre `atacando` y `soltoAtaque`.
- **[4]** **Constructor:** después de `super(sprite, x, y, 6)` llama a `setCuerpo(CUERPO_MARGEN_X, CUERPO_MARGEN_Y, CUERPO_ANCHO, CUERPO_ALTO)`.
- **[10]** **Cambia** `cargarAtaque()`: al final agrega `notificarObservers()`, para que la vista muestre la imagen de ataque.
- **[10]** **Cambia** `ataqueRealizado()`: agrega `vueltasMostrandoGolpe = VUELTAS_IMAGEN_GOLPE;` y `notificarObservers()`.
- **[10]** **Método nuevo** `public void actualizarEstado(AdministradorColisiones c)` (`@Override`). Llama a `super.actualizarEstado(c)`. Si `vueltasMostrandoGolpe > 0`, lo baja en 1, y cuando llega a 0 avisa a la vista para volver a la imagen de caminar.
- **[10]** **Cambian** `activarEscudo()` y `desactivarEscudo()`: al final agregan `notificarObservers()`.
- **[6]** **Cambia** `colisionarCon(Enemigo e)`. Antes estaba vacío (`{ }`, "el choque lo resuelve el enemigo"). Ahora hace `e.colisionarCon(this)`. Sirve cuando el que se frena es Link: `mover` llama a `enemigo.aceptarColision(link)` y Link le devuelve el choque al enemigo, que le hace el daño.
- **[6]** **Consulta nueva** `public boolean bloqueaPasoA(EntidadAnimada quien)` (`@Override`), que devuelve `quien.esFrenadoPorPersonajes()`: frena a los enemigos.
- **[6]** **Consulta nueva** `public boolean esFrenadoPorPersonajes()` (`@Override`), que devuelve `true`: a Link lo frenan los enemigos.
- **[10]** **Consulta nueva** `public String getRutaImagen()` (`@Override`):
  ```java
  String dir = getDireccion().name().toLowerCase();
  String estado = dir;
  if (escudoActivo)
      estado = "escudo-" + dir;
  else if (atacando || vueltasMostrandoGolpe > 0)
      estado = "ataque-" + dir;
  String ruta = sprite.getRuta(estado);
  return ruta != null ? ruta : super.getRutaImagen();
  ```
- **[18]** **Cambia** `getRutaImagen()`: en el caso de ataque, el estado es `(recargado.estaCargado() ? "ataque-recargado-" : "ataque-") + dir`.
- **[18]** **Cambia** `actualizarEstado(AdministradorColisiones c)`: después de `super.actualizarEstado(c)` agrega `if (atacando && recargado.estaCargado()) notificarObservers();`, para que la espada recargada se vea apenas termina la carga.
- **[5]** **Consulta nueva** `public int getCapa()` (`@Override`), que devuelve `CAPA_JUGADOR`.
- **[13]** **Cambia** `alSerGolpeado()`: después de `setDefensa(new DefensaLimitada(0, DefensaLimitada.SIEMPRE))` agrega `parpadearDurante(1000);`, así parpadea el segundo en que es invulnerable.
- **[25]** **Atributo de clase nuevo** `private static final int LARGO_IMAGEN_ESPADA = 48;`.
- **[25]** **Consultas nuevas** `public int getXImagen()` y `public int getYImagen()` (`@Override`): restan `LARGO_IMAGEN_ESPADA` mientras se muestra el ataque hacia la izquierda o hacia arriba.
- **[25]** **Método privado nuevo** `mostrandoAtaque()`, que devuelve `!escudoActivo && (atacando || vueltasMostrandoGolpe > 0)`. `getRutaImagen()` lo usa en lugar de `atacando || vueltasMostrandoGolpe > 0`.
- **[31]** **Atributo de clase nuevo** `private static final long DURACION_CAIDA = 700;` y **atributo nuevo** `protected volatile boolean cayendo;`.
- **[31]** **Cambia** `caerAlVacio()`: queda quieto e invulnerable, avisa a la vista y programa `terminarCaida()` a los `DURACION_CAIDA` ms; si ya está cayendo no hace nada.
- **[31]** **Método privado nuevo** `terminarCaida()`: apaga `cayendo`, vuelve a `caminar` y a `defensaBase`, y hace lo que antes hacía `caerAlVacio()` (resta una vida, recupera los corazones, corta la racha y avisa al juego).
- **[32]** **Cambia** el valor de `DURACION_CAIDA`: de 700 a 400 ms.
- **[33]** **Cambia** el valor de `DEMORA_ROTURA_SUELO`: de 500 a 800 ms.
- **[31]** **Cambian** `getRutaImagen()` (estado `caida` mientras cae), `atacar()` y `usarEscudo()` (no hacen nada mientras cae) y `restaurarDefensa()` (no restaura mientras cae).
- **[36]** **Cambia** `getRutaImagen()`: si Link se está moviendo (`caminar.getDireccion() != null`) antepone `caminar-` a la clave; con la espada cargada usa `caminar-recargado-<dir>` al caminar y `ataque-recargado-<dir>` quieto.
- **[36]** **Cambia** `detenerMovimiento()`: después de `caminar.setDireccion(null)` llama a `notificarObservers()`, para que la vista vuelva al PNG quieto.
- **[37]** **Cambia** `cambiarObjeto()`: si `escudoActivo`, llama a `desactivarEscudo()` antes de cambiar de objeto.
- **[38]** **Atributos de clase nuevos** `VUELTAS_IMAGEN_GIRO = 16` y `ORDEN_GIRO = { ABAJO, IZQUIERDA, ARRIBA, DERECHA }`.
- **[38]** **Cambian** `ataqueRealizado()` (deja `vueltasMostrandoGolpe = VUELTAS_IMAGEN_GIRO` si el golpe fue recargado) y `actualizarEstado(...)` (avisa a la vista en cada vuelta del giro).
- **[38]** **Métodos privados nuevos** `girando()` y `direccionImagen()`: durante el giro la imagen recorre `ORDEN_GIRO`. Los usan `getRutaImagen()`, `getXImagen()` y `getYImagen()`.
- **[39]** **Atributos de clase nuevos** `MARGEN_X_GOLPE = 54` y `MARGEN_Y_GOLPE = 51`; **cambia** `VUELTAS_IMAGEN_GOLPE` de 7 a 8.
- **[39]** **Consulta privada nueva** `mostrandoGolpeNormal()`: atacando, quieto y sin la espada cargada. **Cambian** `getXImagen()` y `getYImagen()`: restan `MARGEN_X_GOLPE` y `MARGEN_Y_GOLPE` mientras se ve el golpe normal; si no, `LARGO_IMAGEN_ESPADA` como antes.
- **[40]** Se borraron los comentarios `//` que no eran de sección.
- **[43]** **Atributo de clase nuevo** `DURACION_MUERTE = 2100` y **atributo nuevo** `protected volatile boolean muriendo;`. **Cambian** `morir()` (muestra la animación y programa `terminarMuerte()`), `alSerGolpeado()`, `getRutaImagen()`, `atacar()`, `usarEscudo()` y `restaurarDefensa()`; **método privado nuevo** `terminarMuerte()`. **Cambia** `terminarCaida()`: avisa a la vista antes de `jugadorSinVidas()` y llena los corazones solo si le quedan vidas (ver la sección 43).
- **[45]** **Atributo de clase nuevo** `DURACION_PERDER_VIDA = 1300`. **Cambian** `morir()` (programa `terminarMuerte()` a los `vidas > 1 ? DURACION_PERDER_VIDA : DURACION_MUERTE` ms) y `getRutaImagen()` (mientras muere, `vidas > 1 ? "pierde-vida" : "muerte"`). Ver la sección 45.
- **[46]** **Cambian** `alSerGolpeado()`, `morir()` y `caerAlVacio()`: en lugar de `if (muriendo) return;` (o `cayendo`), el cuerpo va dentro de `if (!muriendo) { ... }` (o `!cayendo`).

#### `EntornoJuego.java` **[22]**

- **[22]** **Cambia** `public void enemigoDerrotado(Enemigo e)` a `public boolean enemigoDerrotado(Enemigo e)`: devuelve `true` si con esa muerte apareció la bellota.

### Paquete `logica.entidades.enemigos`

#### `Enemigo.java` **[6] [48]**

- **Consultas nuevas:**

  | Método | Devuelve | Qué indica |
  |---|---|---|
  | `public boolean bloqueaPasoA(EntidadAnimada quien)` | `quien.esFrenadoPorPersonajes()` | frena a Link y a los otros enemigos |
  | `public boolean esquivaVacios()` | `true` | esquiva las caídas al vacío |
  | `public boolean esFrenadoPorPersonajes()` | `true` | lo frenan Link y los otros enemigos |

- **[48]** **Atributo de clase nuevo** `private static final long DURACION_MUERTE = 300;` y **atributo nuevo** `protected boolean muriendo;`. Se importan `AtaquePorContacto`, `DefensaLimitada` y `MovimientoInducido`.
- **[48]** **Cambian** `morir()` (muestra la muerte quieto, invulnerable y sin atacar, y programa `desaparecer()`) y `colisionarCon(Link l)` (no lastima mientras muere).
- **[48]** **Comando nuevo** `protected void desaparecer()` (`eliminar()` y `enemigoDerrotado(this)`, lo que hacía `morir()`), y **consultas nuevas** `public String getRutaImagen()` (estado `muerte` mientras muere) y `protected long getDuracionMuerte()`.

#### Cuerpos de colisión de los enemigos **[4]**

`ErizoDeMar`, `Moblin`, `Octorok`, `Wizzrobe` y `TrampaDeCuchillas` reciben el mismo cambio:

- una sección nueva `// Atributos de clase` con `private static final int CUERPO_MARGEN_X`, `CUERPO_MARGEN_Y`, `CUERPO_ANCHO` y `CUERPO_ALTO`;
- en el constructor, justo después de `super(...)`, la llamada `setCuerpo(CUERPO_MARGEN_X, CUERPO_MARGEN_Y, CUERPO_ANCHO, CUERPO_ALTO);`.

| Archivo | MARGEN_X | MARGEN_Y | ANCHO | ALTO |
|---|---|---|---|---|
| `ErizoDeMar.java` | 8 | 8 | 32 | 32 |
| `Moblin.java` | 4 | 4 | 40 | 40 |
| `Octorok.java` | 4 | 4 | 40 | 40 |
| `Wizzrobe.java` | 4 | 2 | 40 | 44 |
| `TrampaDeCuchillas.java` | 8 | 8 | 32 | 32 |

#### `Moblin.java` **[4] [34] [46] [48]**

- **[34]** **Atributo de clase nuevo** `private static final long DURACION_MUERTE = 300;` y **atributo nuevo** `protected boolean muriendo;`.
- **[34]** **Comandos nuevos** (redefinen): `morir()` (nube de muerte 300 ms y después `super.morir()`) y `colisionarCon(Link l)` (no lastima mientras muere).
- **[34]** **Consulta nueva** (redefine): `getRutaImagen()`, que devuelve el estado `muerte` mientras muere.
- **[34]** Se importan `MovimientoInducido`, `Link` y `Direccion`.
- **[46]** **Cambia** `morir()`: en lugar de `if (muriendo) return;`, el cuerpo va dentro de `if (!muriendo) { ... }`.
- **[48]** **Se quitan** `DURACION_MUERTE`, `muriendo`, `morir()`, `colisionarCon(Link l)`, `getRutaImagen()` y los imports de `MovimientoInducido`, `Link` y `Direccion`: pasan a `Enemigo`.

#### `Wizzrobe.java` **[12] [13] [30] [42] [48]**

- Se importan `logica.comportamientos.MovimientoInducido` y `logica.util.Direccion`.
- **Cambia** `protected void alSerGolpeado()`:
  ```java
  // Antes: invulnerable hasta el próximo teletransporte (cada 3 s)
  setDefensa(new DefensaLimitada(0, DefensaLimitada.SIEMPRE));
  // Ahora: quieto e invulnerable un segundo; después se teletransporta y vuelve a ser vulnerable
  setDefensa(new DefensaLimitada(0, DefensaLimitada.SIEMPRE));
  setMovimiento(new MovimientoInducido((Direccion) null, 0));
  parpadearDurante(1000);   // [13]
  programar(1000, () -> setMovimiento(new MovimientoTeletransporte(3000)));
  ```
- **[13]** `parpadearDurante(1000)` lo hace parpadear el segundo en que es invulnerable.
- **[30]** **Constantes nuevas** `- DURACION_APARECER : long = 500` y `- DURACION_DESAPARECER : long = 500`.
- **[30]** **Atributos nuevos** `# apareciendo : boolean`, `# desapareciendo : boolean` y `# teletransportes : int`.
- **[30]** **Cambia** `teletransportarse()`: prende `apareciendo` por 500 ms y programa `desapareciendo` medio segundo antes del próximo salto; las acciones programadas se ignoran si ya hubo otro salto.
- **[30]** **Cambia** `alSerGolpeado()`: apaga `apareciendo` y `desapareciendo` y suma uno a `teletransportes`.
- **[30]** **Consulta nueva** `public String getRutaImagen()`: devuelve `aparecer-<dirección>` o `desaparecer-<dirección>` mientras corresponde y, si no, la imagen de la dirección.
- `teletransportarse()` no cambia: sigue devolviendo la defensa normal y mirando hacia Link.
- **[42]** **Atributo de clase nuevo** `private static final int DANIO_DISPARO = 1;`. `generarProyectil()` lo pasa a `crearProyectil`.
- **[48]** **Cambian** `alSerGolpeado()` (el cuerpo va dentro de `if (!muriendo)`) y `getRutaImagen()` (no muestra aparecer ni desaparecer mientras muere).

#### `Octorok.java` **[42]**

- **[42]** **Atributo de clase nuevo** `private static final int DANIO_DISPARO = 1;`. `generarProyectil()` lo pasa a `crearProyectil`.

#### `MasterStalfos.java` **[13] [14] [44] [47] [48]**

- **[13]** **Cambia** `protected void alSerGolpeado()`: después de `setDefensa(new DefensaLimitada(0, DefensaLimitada.SIEMPRE))` agrega `parpadearDurante(800);`. El resto queda igual: a los 800 ms vuelve a la defensa normal.
- **[14]** Se importa `logica.entidades.AdministradorColisiones`.
- **[14]** **Atributos de clase nuevos:** `private static final int VUELTAS_IMAGEN_GOLPE = 16;` y `private static final int VUELTAS_ESPADA_ARRIBA = 7;`.
- **[14]** **Atributo de instancia nuevo:** `private int vueltasMostrandoGolpe;`.
- **[14]** **Comando nuevo** `public void ataqueRealizado()` (redefine el de `EntidadAnimada`):
  ```java
  if (vueltasMostrandoGolpe == 0) {
      vueltasMostrandoGolpe = VUELTAS_IMAGEN_GOLPE;
      notificarObservers();
  }
  ```
- **[14]** **Comando nuevo** `public void actualizarEstado(AdministradorColisiones c)`:
  ```java
  super.actualizarEstado(c);
  if (vueltasMostrandoGolpe > 0) {
      vueltasMostrandoGolpe--;
      if (vueltasMostrandoGolpe == VUELTAS_IMAGEN_GOLPE - VUELTAS_ESPADA_ARRIBA || vueltasMostrandoGolpe == 0)
          notificarObservers();
  }
  ```
- **[14]** **Consulta nueva** `public String getRutaImagen()`:
  ```java
  String ruta = null;
  if (vueltasMostrandoGolpe > 0) {
      String altura = vueltasMostrandoGolpe > VUELTAS_IMAGEN_GOLPE - VUELTAS_ESPADA_ARRIBA ? "arriba" : "abajo";
      String lado = miJuego.getJugador().getX() < getX() + CUERPO_MARGEN_X + CUERPO_ANCHO / 2 ? "izquierda" : "derecha";
      ruta = sprite.getRuta("ataque-" + altura + "-" + lado);
  }
  return ruta != null ? ruta : super.getRutaImagen();
  ```
- **[44]** **Cambia** `VUELTAS_IMAGEN_GOLPE` (de 16 a 25) y **se quita** `VUELTAS_ESPADA_ARRIBA`.
- **[44]** **Atributos de clase nuevos** `private static final int MARGEN_IMAGEN_X = 12;` y `private static final int MARGEN_IMAGEN_Y = 36;`, y **atributo nuevo** `private Direccion direccionGolpe;`. Se importa `logica.util.Direccion`.
- **[44]** **Cambia** `ataqueRealizado()`: guarda `direccionGolpe = getDireccion();` al empezar el golpe.
- **[44]** **Cambia** `actualizarEstado(c)`: avisa a la vista solo con `vueltasMostrandoGolpe == 0`.
- **[44]** **Cambia** `getRutaImagen()`:
  ```java
  String ruta = null;
  if (vueltasMostrandoGolpe > 0)
      ruta = sprite.getRuta("ataque-" + direccionGolpe.name().toLowerCase());
  return ruta != null ? ruta : super.getRutaImagen();
  ```
- **[44]** **Consultas nuevas** `public int getXImagen()` (`return getX() - MARGEN_IMAGEN_X;`) y `public int getYImagen()` (`return getY() - MARGEN_IMAGEN_Y;`).
- **[47]** **Atributo de clase nuevo** `private static final long DURACION_MUERTE = 1530;` y **atributo nuevo** `protected boolean muriendo;`. Se importan `MovimientoInducido` y `Link`.
- **[47]** **Comandos nuevos** (redefinen): `morir()` (quieto e invulnerable con el GIF de muerte y, a los 1530 ms, `super.morir()`) y `colisionarCon(Link l)` (no lastima mientras muere).
- **[47]** **Cambian** `alSerGolpeado()` (el cuerpo va dentro de `if (!muriendo)`), `getRutaImagen()` (mientras muere, `muerte-<dirección>`) y `quiereAtacar()` (`return !muriendo && ...`). Ver la sección 47.
- **[48]** **Se quitan** `muriendo`, `morir()`, `colisionarCon(Link l)` y los imports de `MovimientoInducido` y `Link` (los hereda de `Enemigo`); `quiereAtacar()` vuelve a no mirar `muriendo`. **Consulta nueva** `protected long getDuracionMuerte()` (devuelve `DURACION_MUERTE`).

#### `StoneHinox.java` **[4] [20] [41] [42] [48] [50]**

- **Se quita** `private static final int CUERPO_LADO = 96;`.
- **Se agregan** `CUERPO_MARGEN_X = 6`, `CUERPO_MARGEN_Y = 4`, `CUERPO_ANCHO = 84` y `CUERPO_ALTO = 88`.
- **Constructor:** `setCuerpo(0, 0, CUERPO_LADO, CUERPO_LADO)` pasa a `setCuerpo(CUERPO_MARGEN_X, CUERPO_MARGEN_Y, CUERPO_ANCHO, CUERPO_ALTO)`.
- **[20]** **Atributo de clase nuevo** `private static final long DURACION_GOLPE_AVALANCHA = 600;`.
- **[20]** **Atributos de instancia nuevos** `private volatile boolean vulnerable;` y `private volatile boolean golpeandoSuelo;`.
- **[20]** **Cambia** `ataqueTerminado()`: antes llamaba a `siguienteAtaque()`. Ahora pone `golpeandoSuelo = true`, lo deja quieto con `MovimientoInducido((Direccion) null, 0)` y `AtaquePorContacto(0)`, avisa a la vista y programa a los 600 ms `golpeandoSuelo = false`, otro aviso y `siguienteAtaque()`.
- **[20]** **Cambia** `embestidaTerminada()`: pone `vulnerable = true` y avisa; al vencer la vulnerabilidad pone `vulnerable = false` y avisa antes de `siguienteAtaque()`.
- **[20]** **Consulta nueva** `public String getRutaImagen()` (`@Override`): `vulnerable`, `avalancha` o `normal`; si falta la imagen usa `super.getRutaImagen()`.
- **[20]** Se importa `logica.util.Direccion`.
- **[41]** **Cambian** `INTERVALO_ROCAS` (de 2000 a 400) y el tipo de `lanzarRocas` (de `ComportamientoAtaque` a `AtaqueRafaga`); el constructor crea `new AtaqueRafaga(this, CANTIDAD_ROCAS, INTERVALO_ROCAS)` y se importa `AtaqueRafaga` en lugar de `AtaquePorProyectil`.
- **[41]** **Cambia** `siguienteAtaque()`: al elegir lanzar rocas llama a `lanzarRocas.reiniciar()`.
- **[42]** **Atributo de clase nuevo** `private static final int DANIO_ROCA = 2;`. `generarProyectil()` lo pasa a `crearRocaGrande`.
- **[48]** **Cambia** `getRutaImagen()`: mientras muere, el estado `muerte`.
- **[50]** **Atributo de instancia nuevo** `private volatile boolean embistiendo;`. **Cambian** `siguienteAtaque()` (al embestir lo pone en `true` y avisa a la vista), `embestidaTerminada()` (lo pone en `false`) y `getRutaImagen()` (estado `embestida` después de `avalancha`).

#### `EnemigoConDrop.java` **[19] [22] [48]**

- **[19]** **Cambia** `generarDrop()`: crea el power-up en `getHitbox().getX()`, `getHitbox().getY()` (la esquina del cuerpo) en vez de `getX()`, `getY()` (la esquina de la imagen).
- **[22]** **Cambia** `protected void morir()`: antes `super.morir(); soltarDrop();`; ahora `eliminar();` y `if (!miJuego.enemigoDerrotado(this)) soltarDrop();`.
- **[48]** `morir()` pasa a llamarse `desaparecer()`, con el mismo cuerpo.

#### `Jefe.java` **[48]**

- **[48]** `morir()` pasa a llamarse `desaparecer()`, con el mismo cuerpo (`eliminar()` y `jefeDerrotado(this)`).

#### `MoblinConEspadaYEscudo.java` **[9] [19] [26] [27] [28] [34] [35]**

- **[19]** **Atributos de clase nuevos:** `MARGEN_IMAGEN = 24`, `CUERPO_MARGEN_X = 28`, `CUERPO_MARGEN_Y = 28`, `CUERPO_ANCHO = 40` y `CUERPO_ALTO = 40` (todos `private static final int`).
- **[19]** **Cambia** el constructor: `super(sprite, x - MARGEN_IMAGEN, y - MARGEN_IMAGEN)` y después `setCuerpo(CUERPO_MARGEN_X, CUERPO_MARGEN_Y, CUERPO_ANCHO, CUERPO_ALTO)`.
- **Cambia** `protected void vigilarJugador()`: la condición `if (linkEstaEnfrente())` pasa a `if (linkEstaEnfrente() && !hayObstaculoHastaJugador())`. Lo de adentro no cambia: se abalanza 800 ms con `MovimientoInducido(getDireccion(), 6)` y después vuelve a `MovimientoAleatorio(2, 1500)`.
- **[26]** **Atributo de instancia nuevo** `protected boolean abalanzandose;`.
- **[26]** **Cambia** `vigilarJugador()`: solo se abalanza si `!abalanzandose`, lo pone en `true` y programa `this::terminarAbalanzada`.
- **[26]** **Método privado nuevo** `terminarAbalanzada()`: pone `abalanzandose` en `false` y vuelve a `MovimientoAleatorio`.
- **[27]** **Cambian** `VELOCIDAD_ABALANZADA` (de 6 a 3) y `DURACION_ABALANZADA` (de 800 a 1600).
- **[28]** **Atributos de clase nuevos** `PREPARACION_ABALANZADA = 300`, `DURACION_CAMBIO_VELOCIDAD = 100` y `DURACION_FRENADO = 500` (todos `private static final long`), e `import logica.util.Direccion`.
- **[28]** **Cambia** `vigilarJugador()`: se queda quieto, programa la salida a velocidad 1, 2 y 3, el frenado a `VELOCIDAD` y `terminarAbalanzada()`.
- **[34]** **Cambia** `vigilarJugador()`: no se abalanza mientras `muriendo`.
- **[35]** **Cambian** `MARGEN_IMAGEN` (de 24 a 39), `CUERPO_MARGEN_X` y `CUERPO_MARGEN_Y` (de 28 a 43), por la imagen de 126 × 126. El cuerpo queda en el mismo lugar.

#### `TrampaDeCuchillas.java` **[4] [7] [8] [9]**

- **[4]** Constantes de cuerpo (ver la tabla de arriba) y `setCuerpo(...)` en el constructor.
- **[7]** **Atributos de clase nuevos:** `private static final int VELOCIDAD_SALIDA = 8;` y `private static final int VELOCIDAD_VUELTA = 4;`.
- **[8]** **Atributo de instancia nuevo:** `protected Posicion destino;`, el lugar de Link sobre la línea de ataque cuando la trampa salió. Vale `null` mientras no sale.
- **[7]** **Constructor:** `new MovimientoInducido((Direccion) null, 8)` pasa a `new MovimientoInducido((Direccion) null, VELOCIDAD_SALIDA)`.
- **[8] [9]** **Cambia** `protected void vigilarJugador()`:
  ```java
  // Antes
  if (enReposo && getHitbox().estaEnLineaCon(miJuego.getJugador().getHitbox())) {
      Direccion d = direccionHaciaJugador();
      setDireccion(d);
      setMovimiento(new MovimientoInducido(d, 8));
  }
  // Ahora
  if (enReposo && getHitbox().estaEnLineaCon(miJuego.getJugador().getHitbox()) && !hayObstaculoHastaJugador()) {
      Direccion d = direccionHaciaJugador();
      Posicion posicionDeLink = miJuego.getJugador().getPosicion();
      int destinoX = d.getDx() != 0 ? posicionDeLink.getX() : getX();
      int destinoY = d.getDy() != 0 ? posicionDeLink.getY() : getY();
      destino = new Posicion(destinoX, destinoY);
      setDireccion(d);
      setMovimiento(new MovimientoInducido(d, VELOCIDAD_SALIDA));
  } else if (destino != null && llegoAlDestino()) {
      volver();
  }
  ```
- **[7] [8]** **Cambia** `private void volver()`:
  ```java
  // Antes: se teletransportaba
  setPosicion(posicionOriginal);
  setMovimiento(new MovimientoInducido((Direccion) null, 8));
  // Ahora: vuelve despacio con Strategy
  destino = null;
  setMovimiento(new MovimientoInducido(posicionOriginal, VELOCIDAD_VUELTA));
  ```
- **[8]** **Consulta privada nueva** `private boolean llegoAlDestino()`. Indica si ya llegó (o se pasó) al `destino`, mirando el signo de la diferencia en la dirección en la que va:
  ```java
  boolean llegoEnX = (getX() - destino.getX()) * d.getDx() >= 0;
  boolean llegoEnY = (getY() - destino.getY()) * d.getDy() >= 0;
  return llegoEnX && llegoEnY;
  ```
- `alChocarConBloqueo()` no cambia: sigue llamando a `volver()`. Ahora la vuelta es despacio también desde ahí.

### Paquete `logica.entidades.fijas`

#### `Roca.java` **[4] [5] [6] [9]**

- Se importa `logica.entidades.EntidadAnimada`.
- **[4]** Constantes `CUERPO_MARGEN_X = 4`, `CUERPO_MARGEN_Y = 4`, `CUERPO_ANCHO = 42`, `CUERPO_ALTO = 42`, y `setCuerpo(...)` en el constructor.
- **[5]** **Consulta nueva** `public int getCapa()`, que devuelve `CAPA_OBSTACULOS`.
- **[6]** **Se quita** `public boolean bloqueaPaso()` (devolvía `true`).
- **[6]** **Consulta nueva** `public boolean bloqueaPasoA(EntidadAnimada quien)`, que devuelve `true`: le bloquea el paso a cualquiera.
- **[9]** **Consulta nueva** `public boolean impideAbalanzarse()`, que devuelve `true`.
- **[31]** **Cambia** `afectar(Link l)`: llama a `l.caerAlVacio()` solo si `getHitbox().contiene(l.getCentro())`.

#### `Agua.java` **[6] [9]**

- Se importa `logica.entidades.EntidadAnimada`.
- **[6]** **Se quita** `public boolean bloqueaPaso()` (devolvía `true`).
- **[6]** **Consulta nueva** `public boolean bloqueaPasoA(EntidadAnimada quien)`, que devuelve `true`: le bloquea el paso a cualquiera.
- **[9]** **Consulta nueva** `public boolean impideAbalanzarse()`, que devuelve `true`.
- No tiene cuerpo propio ni `getCapa()` propio: usa el de `Obstaculo` (`CAPA_SUELO`).

#### `CaidasAlVacio.java` **[4] [6] [9] [31]**

- Se importa `logica.entidades.EntidadAnimada`.
- **[4]** Constantes `CUERPO_MARGEN_X = 8`, `CUERPO_MARGEN_Y = 8`, `CUERPO_ANCHO = 32`, `CUERPO_ALTO = 32`, y `setCuerpo(...)` en el constructor. Así Link cae solo si pisa el centro del pozo.
- **[6]** **Consulta nueva** `public boolean bloqueaPasoA(EntidadAnimada quien)`, que devuelve `quien.esquivaVacios()`: frena a los enemigos, y Link la pisa y cae. Antes no tenía nada: heredaba `bloqueaPaso()` en `false`.
- **[9]** **Consulta nueva** `public boolean impideAbalanzarse()`, que devuelve `true`.

#### `FragmentoDeCorazon.java` **[23]**

- **[23]** **Cambian** las constantes de cuerpo: `CUERPO_MARGEN_X` 6 → 1, `CUERPO_MARGEN_Y` 6 → 3, `CUERPO_ANCHO` 36 → 45 y `CUERPO_ALTO` 36 → 42.

#### `Obstaculo.java`, `Objeto.java` y `PowerUP.java` **[5]**

Cada una agrega una consulta `public int getCapa()`:

| Archivo | Devuelve | Lo heredan |
|---|---|---|
| `Obstaculo.java` | `CAPA_SUELO` | `Agua`, `Pasto`, `CaidasAlVacio`, `SuelosQuebradizo` (`Roca` lo redefine) |
| `Objeto.java` | `CAPA_OBJETOS` | `Espada` y `Escudo` |
| `PowerUP.java` | `CAPA_OBJETOS` | `Rupia`, `Bellota`, `Corazon` y `FragmentoDeCorazon` |

### Paquete `logica.fabricas`

#### `FabricaSprites.java` **[10] [14] [18] [20] [30] [31] [34] [35] [36] [39] [43] [44] [45] [47] [48] [50]**

| Método | Antes | Ahora |
|---|---|---|
| `crearSpritesLink()` | `armar("link", "abajo", "arriba", "izquierda", "derecha", "ataque-abajo", "ataque-arriba", "ataque-izquierda", "ataque-derecha")` | lo mismo, más `"escudo-abajo", "escudo-arriba", "escudo-izquierda", "escudo-derecha"` y, con el cambio 18, `"ataque-recargado-abajo", "ataque-recargado-arriba", "ataque-recargado-izquierda", "ataque-recargado-derecha"`; con el cambio 31, el estado `caida` con `link-caida.gif`; con el cambio 36, las 16 claves `caminar-[escudo-|ataque-|recargado-]<dirección>` con su `.gif`; con el cambio 39, `ataque-<dirección>` sale de `armar` y se registra con `agregar` como `link-ataque-<dirección>.gif`; con el cambio 43, el estado `muerte` con `link-muerte.gif`; con el cambio 45, el estado `pierde-vida` con `link-pierde-vida.gif` |
| `crearSpritesWizzrobe()` | `armar("wizzrobe", "normal")`: pedía `wizzrobe-normal.png`, que no existe | `armar("wizzrobe", "abajo", "arriba", "izquierda", "derecha")` y, con el cambio 30, los estados `aparecer-<dirección>` y `desaparecer-<dirección>` con su `.gif` |
| `crearSpritesMoblin()` **[34]** | `armar("moblin", "abajo", "arriba", "izquierda", "derecha")` (PNG) | las cuatro direcciones con `moblin-<dirección>.gif` y el estado `muerte` con `moblin-muerte.gif` |
| `crearSpritesMoblinConEspadaYEscudo()` **[34] [35]** | `armar("moblinconespadayescudo", ...)` (PNG) | con el cambio 34, el estado `muerte` con `moblinconespadayescudo-muerte.gif`; con el cambio 35, las cuatro direcciones con `moblinconespadayescudo-<dirección>.gif` (126 × 126) |
| `crearSpritesStoneHinox()` **[20]** | `armar("stonehinox", "normal")` | `armar("stonehinox", "normal", "avalancha", "vulnerable")` |
| `crearSpritesMasterStalfos()` **[14] [44]** | `armar("masterstalfos", "abajo", "arriba", "izquierda", "derecha")` | con el cambio 14, lo mismo más `"ataque-arriba-izquierda", "ataque-abajo-izquierda", "ataque-arriba-derecha", "ataque-abajo-derecha"`; con el cambio 44, `new Sprite()` con `agregar`: `<dirección>` con `masterstalfos-<dirección>.gif` y `ataque-<dirección>` con `masterstalfos-ataque-<dirección>.gif`; con el cambio 47, `muerte-<dirección>` con `masterstalfos-muerte-<dirección>.gif` |
| `crearSpritesOctorok()`, `crearSpritesErizoDeMar()`, `crearSpritesWizzrobe()`, `crearSpritesStoneHinox()` **[48]** | `armar(...)` | lo mismo y el estado `muerte` con `<nombre>-muerte.gif` |
| `crearSpritesStoneHinox()` **[50]** | `armar("stonehinox", "normal", "avalancha", "vulnerable")` (PNG) y `muerte` | los estados `normal`, `embestida`, `vulnerable`, `avalancha` y `muerte` con `stonehinox-<estado>.gif` |

#### `FabricaEntidades.java` **[42]**

- **Se quitan** `DANIO_DISPARO` y `DANIO_ROCA_GRANDE`.
- **Cambian** `crearProyectil(int x, int y, Direccion d)` y `crearRocaGrande(int x, int y, Direccion d)`: suman el parámetro `int danio` y se lo pasan al constructor de `Proyectil`.

### Paquete `logica.juego`

#### `Juego.java` **[22] [51]**

- **[22]** **Cambia** `public synchronized void enemigoDerrotado(Enemigo e)` a `public synchronized boolean enemigoDerrotado(Enemigo e)`: guarda en `aparecioBellota` si la racha llegó a `RACHA_PARA_BELLOTA` y lo devuelve.
- **[51]** **Cambia** `terminarPartida()`: después de detener los hilos llama a `controladorGrafico.terminarControl()`.

### Paquete `logica.mapa`

#### `GeneradorNivel.java` **[1]**

- **Se renombra** la constante `CELDA = 48` a `LADO_ENTIDAD = 48`. Solo se usa en `colocarFragmentosDeCorazon`, en `posicionLibreAlAzar(LADO_ENTIDAD, LADO_ENTIDAD)`.
- **Cambia** la lectura del archivo: se agrega `int celda = Integer.parseInt(celdas[3]);`, el lado de la celda que trae la línea `CELDAS` (por ejemplo `CELDAS 32 22 24`).
- Las posiciones de las entidades pasan de `k * CELDA` y `r * CELDA` a `k * celda` y `r * celda`.
- La posición de inicio de Link pasa de `inicio[3] * CELDA` a `inicio[3] * celda` (lo mismo con `inicio[4]`).

### Paquete `logica.util`

#### `Hitbox.java` **[9] [31] [38] [40]**

- **Consulta nueva** `public Hitbox caminoHasta(Hitbox otra)`. Devuelve la franja entre este cuerpo y otro que está en su misma fila o columna:
  - si comparten fila, va del borde izquierdo del primero al borde derecho del último, con la altura de este cuerpo;
  - si no, va del borde de arriba al de abajo, con el ancho de este cuerpo.
- **[31]** **Consulta nueva** `public boolean contiene(Posicion p)`: indica si el punto está dentro del cuerpo.
- **[38]** **Consulta nueva** `public Hitbox alrededor(int alcance)`: el cuerpo agrandado `alcance` px hacia los cuatro lados.
- **[40]** En el extendido, los parámetros de `estaDentroDe` pasan a llamarse `anchoZona` y `altoZona`, como en el código.

### Paquete `vista`

#### `CeldaGrafica.java` **[11] [25] [30] [46]**

- **[11]** **Cambia** `actualizar()`: dentro del `invokeLater`, después de `setIcon(icono)`, agrega `setVisible(entidadObservada.esVisible());`.
- **[25]** **Cambia** `actualizar()`: `setBounds` usa `getXImagen()`/`getYImagen()` en lugar de `getX()`/`getY()`.
- **[30]** **Atributo nuevo** `# rutaMostrada : String` y se importa `javax.swing.Icon`.
- **[30]** **Cambia** `actualizar()`: solo carga la imagen cuando cambia la ruta, y si es un GIF le hace `flush()` para que arranque desde el primer cuadro. El `setBounds` toma el tamaño de `getIcon()`.
- **[46]** **Cambia** `actualizar()`: sin `return`, con `if (getParent() != null)` y adentro `quitarCelda(this)` o `redibujar()`. **Método privado nuevo** `redibujar()` con lo que estaba después de los `return`.

#### `GUI.java` **[46] [49] [51]**

- **[46]** **Cambia** `procesarTecla(int codigo, boolean presionada)`: en lugar de `if (controlJugador == null) return;`, el `switch` va dentro de `if (controlJugador != null) { ... }`.
- **[49]** **Atributos nuevos** `protected boolean arribaPresionada`, `abajoPresionada`, `izquierdaPresionada` y `derechaPresionada`. **Cambian** `procesarTecla(...)` (las flechas anotan si están apretadas y después Link se mueve hacia una que siga apretada, o se detiene) e `iniciarPartida(...)` (pone las 4 en `false`).
- **[51]** **Comando nuevo** `public void terminarControl()`: pone `controlJugador = null` y las 4 flechas en `false`. Cambian los javadoc de `iniciarPartida(...)` y `procesarTecla(...)`.

#### `PanelPantallaNivel.java` **[5] [25] [46]**

- **[25]** **Cambia** `desplazar`: ubica cada celda con `getXImagen()`/`getYImagen()`, así el ataque no salta al cambiar de sector.
- **[46]** **Cambia** `desplazar`: el `for` sigue mientras `!Thread.currentThread().isInterrupted()` y se quita el `return` del `catch`.

- **Cambia** `agregarCelda(CeldaGrafica c)`. Antes hacía `add(c, 0)`, que la ponía arriba de todo. Ahora cuenta las celdas que ya están y son de una capa más alta, y la agrega debajo de ellas:
  ```java
  int capa = c.entidadObservada.getCapa();
  int celdasQueLaTapan = 0;
  for (CeldaGrafica otra : celdas)
      if (otra.entidadObservada.getCapa() > capa)
          celdasQueLaTapan++;
  celdas.add(c);
  add(c, celdasQueLaTapan);
  ```

### `Recursos/`

Estas carpetas se reemplazaron por las del equipo (las de la PC de Ani). Las dos estrategias tienen exactamente los mismos recursos.

#### `Recursos/Niveles/` **[1] [2]**

| Archivo | Cambio |
|---|---|
| `nivel1.txt` | Cambia entero: `MAPA 1 4`, `CELDAS 32 22 24`, `INICIO 0 0 4 10` y cuatro sectores (ver el cambio 2). MasterStalfos (`S`) solo, en el centro del sector 0 3 |
| `nivel2.txt` | Nuevo: misma forma que el nivel 1, con StoneHinox (`H`) solo en el centro del sector 0 3 y sin la espada en el piso |

#### `Recursos/Imagenes/original/` y `Recursos/Imagenes/alternativa/` **[3] [14] [18] [19] [20] [23] [24] [36] [39] [43] [44] [45] [47] [48] [50]**

El mismo cambio en los dos modos gráficos:

| Imagen | Cambio | Por qué |
|---|---|---|
| `roca-normal.png` | Modificada | Fondo transparente en lugar del amarillo |
| `escudo-normal.png` | Nueva | `crearSpritesEscudo()` la pedía y no estaba |
| `espada-normal.png` | Nueva | `crearSpritesEspada()` la pedía y no estaba |
| `masterstalfos-arriba.png`, `-izquierda.png`, `-derecha.png` | Nuevas | `crearSpritesMasterStalfos()` pide las cuatro direcciones y solo estaba `abajo` |
| `stonehinox-normal.png` | Nueva | `crearSpritesStoneHinox()` pide `normal` |
| `stonehinox-abajo.png` | Quitada | La reemplaza `stonehinox-normal.png` |
| `masterstalfos-ataque-arriba-izquierda.png`, `-abajo-izquierda.png`, `-arriba-derecha.png`, `-abajo-derecha.png` | Nuevas **[14]** | El golpe de espada del MasterStalfos, recortadas de la hoja de sprites del equipo, sin fondo y a 144 × 144 |
| `link-ataque-recargado-abajo.png`, `-arriba.png`, `-izquierda.png`, `-derecha.png` | Nuevas **[18]** | El golpe recargado de Link (espada negra con amarillo), sin fondo, a 48 × 96 y 96 × 48 |
| `moblinconespadayescudo-abajo.png`, `-arriba.png`, `-izquierda.png`, `-derecha.png` | Modificadas **[19]** | Moblin azul con espada (y escudo hacia abajo), a 96 × 96 con el cuerpo en el centro |
| `stonehinox-avalancha.png`, `stonehinox-vulnerable.png` | Nuevas **[20]** | El StoneHinox golpeando el suelo y vulnerable (naranja), sin fondo, a 96 × 96 |
| `fragmentodecorazon-normal.png` | Modificada **[23]** | Corazón color piel con un corazón rojo adentro, sin fondo, de 45 × 42 dentro de 48 × 48 |
| `link-ataque-derecha.png` | Modificada **[24]** | Espejo horizontal de `link-ataque-izquierda.png`, a 96 × 48 |
| `link-caminar-<dir>.gif`, `link-caminar-escudo-<dir>.gif`, `link-caminar-ataque-<dir>.gif`, `link-caminar-recargado-<dir>.gif` | Nuevas **[36]** | Las 16 caminatas de Link con los cuadros del juego original, a 150 ms por cuadro |
| `link-escudo-izquierda.png`, `link-escudo-derecha.png` | Modificadas **[36]** | Miraban al lado contrario; ahora son el primer cuadro de la caminata con escudo |
| `link-escudo-abajo.png`, `link-caminar-escudo-abajo.gif` | Modificadas **[36]** | Rehechas con los cuadros que eligió el equipo, a 48 × 48 y sin fondo |
| `link-ataque-<dir>.gif` | Nuevas **[39]** | El golpe de espada en 3 cuadros (50, 50 y 133 ms), a 156 × 150 con Link en (54, 51) |
| `link-ataque-<dir>.png` | Quitadas **[39]** | Las reemplazan los GIF |
| `link-muerte.gif` | Nueva **[43]** | La animación de muerte del juego original: 3 vueltas y tirado en el piso, 2,1 s, 48 × 48 |
| `masterstalfos-<dirección>.gif`, `masterstalfos-ataque-<dirección>.gif` | Nuevas **[44]** | Caminar (3 cuadros, en bucle) y golpe de espada (4 cuadros, 750 ms, sin repetir) del Master Stalfos, a 171 × 216 |
| Los 8 `masterstalfos-*.png` | Quitadas **[44]** | Las reemplazan los GIFs |
| `link-pierde-vida.gif` | Nueva **[45]** | Link cae sentado para atrás y se levanta, 1,3 s, 48 × 48. Se usa al perder una vida que no es la última |
| `masterstalfos-muerte-<dirección>.gif` | Nuevas **[47]** | Muerte del Master Stalfos: golpeado, desarmado y nube, 1,53 s, 171 × 216, sin repetir |
| `octorok-muerte.gif`, `erizodemar-muerte.gif`, `wizzrobe-muerte.gif`, `stonehinox-muerte.gif` | Nuevas **[48]** | La nube de muerte de `moblin-muerte.gif` (48 × 48); la del StoneHinox, agrandada a 96 × 96 |
| `stonehinox-normal.gif`, `-embestida.gif`, `-vulnerable.gif`, `-avalancha.gif` | Nuevas **[50]** | Caminar (2 × 300 ms), embestida (2 × 110 ms), vulnerable en naranja (2 × 300 ms) y golpe de la avalancha (150 + 450 ms, sin repetir), a 96 × 96 |
| `stonehinox-normal.png`, `-avalancha.png`, `-vulnerable.png` | Quitadas **[50]** | Las reemplazan los GIF |

Las imágenes `wizzrobe-*` por dirección y `link-ataque-*` y `link-escudo-*` ya estaban; lo que faltaba era que el código las pidiera (cambio 10).

### Diagramas y documentos de esta carpeta

| Archivo | Cambio |
|---|---|
| `Diagrama-extendido-bloqueaPasoA.drawio` y `.pdf` | Incluye todo lo de esta sección que va en el diagrama (el `.pdf`, hasta el cambio 43). Está en blanco y negro, con los patrones de diseño en colores (los mismos que el reducido) y su leyenda arriba a la izquierda |
| `Diagrama-reducido-bloqueaPasoA.drawio` y `.pdf` | Cambia por el cambio 17 (4 interfaces) y el 41 (`AtaqueRafaga`). El `.pdf` ya incluye el 41 |
| `Explicativo-bloqueaPasoA.md` | Explica el bloqueo de esta estrategia y apunta a este archivo |
| `imagenes-cambio-17/` | Diagramas ilustrativos del cambio 17: reducido y extendido antes y después, y tres diagramas de secuencia |
| `Cambios-desde-defensa-6.md` | Este archivo |

## Patrones

No hay patrones nuevos. Los cambios usan los que ya estaban: **Strategy** (`MovimientoInducido`), **Template Method** (los ganchos `vigilarJugador` y `alChocarConBloqueo`) y el **Visitor** de efectos (daño por contacto, `Colisionable` / `Colisionador`). El parpadeo (cambio 11) usa el **Observer** que ya avisaba a la vista. El cambio 12 usa **Strategy** (cambia el movimiento del Wizzrobe) y el gancho `alSerGolpeado()`. El cambio 13 usa el mismo gancho (**Template Method**) y el **Observer** del parpadeo. El cambio 14 redefine `ataqueRealizado()`, `actualizarEstado` y `getRutaImagen()` como Link, y avisa a la vista con el **Observer**. El cambio 17 no agrega patrones: aplica el **principio de segregación de interfaces** y mantiene el doble despacho de los modos de juego, que ahora reciben `TablaRankings` y `ArbitroPartida` en vez de `Juego`. El cambio 18 usa el **Strategy** del ataque (`AtaqueRecargado`) para saber si el golpe está cargado y el **Observer** para avisar a la vista. El cambio 30 usa el **Observer** para que la vista cambie al GIF de aparecer o desaparecer, y redefine `getRutaImagen()` como el `StoneHinox`. El cambio 31 usa el gancho `afectar` del obstáculo, `programar` para la demora de la caída y el **Observer** para mostrar el GIF. El cambio 34 redefine el gancho `morir()` (**Template Method**), usa el **Strategy** de movimiento y defensa para dejar quieto e invulnerable al Moblin, `programar` para la demora y el **Observer** para mostrar la nube. Los cambios 36 a 39 usan el **Strategy** del ataque (`AtaqueRecargado`) y el **Observer** para avisar a la vista. El cambio 41 agrega una estrategia de ataque (**Strategy**) que redefine los ganchos del **Template Method** `AtaquePorProyectil.atacar()`, como `AtaqueAvalancha`. El cambio 42 deja que cada **Factory Method** `generarProyectil()` decida el daño de lo que crea. El cambio 43 redefine el gancho `morir()` (**Template Method**) como el Moblin del cambio 34, usa `programar` para la demora y el **Observer** para mostrar el GIF y el HUD. El cambio 44 no agrega patrones: usa el **Observer** para que la vista cambie de GIF y redefine `getXImagen()` y `getYImagen()` como Link. El cambio 45 tampoco: usa el mismo gancho `morir()`, `programar` y el **Observer** del 43. El cambio 46 no agrega patrones: solo reescribe las guardas sin `return`. El cambio 47 redefine el gancho `morir()` (**Template Method**) como el Moblin del 34, usa el **Strategy** de movimiento y defensa para dejarlo quieto e invulnerable, `programar` para la demora y el **Observer** para mostrar el GIF. El cambio 48 sube esa muerte a `Enemigo` como **Template Method**: `morir()` es el algoritmo fijo y `desaparecer()` y `getDuracionMuerte()` son los ganchos que redefinen `EnemigoConDrop`, `Jefe` y `MasterStalfos`; usa el **Strategy** de movimiento, defensa y ataque para dejarlo quieto, invulnerable y sin atacar.

## Cómo se probó

- Las tres copias del código compilan con `javac`.
- La trampa y el bloqueo se probaron con un programa sin interfaz que arma un sector a mano. Se cubrieron estos casos: roca o borde de por medio, Link quieto o moviéndose, y roca, agua o vacío en el medio.
- Los niveles 1 y 2 se cargaron con el `GeneradorNivel` real: cada uno tiene cuatro sectores y un jefe.
- El juego real se corrió en una pantalla virtual (Xvfb) con teclas de verdad (`java.awt.Robot`), en las tres copias:
  - Con la espada, Link les hace daño a Octorok, Erizo, Moblin, Moblin con escudo (de costado o de atrás) y Wizzrobe.
  - Las imágenes de Wizzrobe y las de ataque y escudo de Link se encuentran.
  - El parpadeo se ve desde el primer golpe.
- El Wizzrobe se probó en el juego real, en las tres copias: después del primer golpe, un golpe a los 200 ms no le hace daño; se teletransporta a los ~1050 ms y el segundo golpe lo mata.
- El parpadeo durante la invulnerabilidad se midió en las tres copias: Moblin ~600 ms, Wizzrobe ~1000 ms, MasterStalfos ~800 ms y Link ~1000 ms. También se grabó un video con todos los enemigos.
- La imagen de ataque del MasterStalfos se probó en el juego real, en las tres copias y con los dos modos gráficos: con Link a la izquierda y a la derecha muestra la espada arriba ~180 ms, la espada abajo ~270 ms y vuelve a caminar. También se grabó un video.
- El cambio 17 se probó en las dos estrategias con un programa sin interfaz gráfica (ver 17.8).
- El cambio 18 compila con `javac`; falta probarlo en el juego real (ver 18).
- El cambio 19 compila, se probó la ubicación del cuerpo y los golpes de espada con un programa sin interfaz, y se corrió en el juego real (pantalla virtual): camina, choca y lastima a Link como antes.
- El cambio 20 compila, se probó la elección de imagen con un programa sin interfaz y se corrió en el juego real (ver 20).
- El cambio 22 compila y se probó en el juego con un enemigo que siempre suelta drop (ver 22).
- El cambio 23 compila y el juego carga la imagen nueva (ver 23).
- El cambio 24 se probó en el juego atacando erizos hacia la derecha (ver 24).
- El cambio 25 compila y se probó en el juego atacando en las cuatro direcciones (ver 25).
- El cambio 26 compila y se probó en el juego con un nivel de prueba, midiendo las acciones pendientes y grabando videos (ver 26).
- El cambio 27 compila y se probó en el juego con el mismo nivel de prueba (ver 27).
- El cambio 28 compila y se probó en el juego con el mismo nivel de prueba (ver 28).
- El cambio 29 compila y se probó en el juego con un Octorok y una roca en el medio (ver 29).
- El cambio 30 compila y se probó en el juego con un nivel de prueba de solo Link y el Wizzrobe, grabando un video (ver 30).
- El cambio 31 compila y se probó en el juego con un nivel de prueba de Link y un pozo, grabando un video (ver 31).
- El cambio 32 compila y se probó en el juego con el mismo nivel de prueba (ver 32).
- El cambio 33 compila y se probó en el juego con un nivel de prueba de dos suelos quebradizos, grabando un video (ver 33).
- El cambio 34 compila y se probó en el juego con un nivel de prueba de dos Moblin y un Moblin con espada y escudo, grabando un video (ver 34).
- El cambio 35 compila y se probó en el juego con un nivel de prueba de dos Moblin con espada y escudo y un Moblin, grabando un video (ver 35).
- El cambio 36 compila y se probó en el juego con un nivel de prueba, grabando un video (ver 36).
- El cambio 37 compila y se probó en el juego cambiando de objeto con el escudo levantado, grabando un video (ver 37).
- El cambio 38 compila y se probó en el juego con cuatro Moblins alrededor de Link, grabando un video (ver 38).
- El cambio 39 compila y se probó en el juego golpeando en las cuatro direcciones, grabando un video (ver 39).
- El cambio 40 compila y el extendido se comparó con el código con un script (ver 40).
- El cambio 41 compila y se probó en el juego con el StoneHinox lanzando rocas, con Link alineado y sin alinear, grabando un video (ver 41).
- El cambio 42 compila; los valores del daño no cambian (ver 42).
- El cambio 43 compila y se probó en el juego muriendo con vidas, en la última vida y cayendo al vacío en la última vida, grabando videos (ver 43).
- El cambio 44 compila y se probó en el juego con el Master Stalfos caminando y golpeando en las 4 direcciones, grabando un video (ver 44).
- El cambio 45 compila y se probó en el juego perdiendo una vida y después la última, grabando un video (ver 45).
- Los cambios 46 y 47 compilan y se probaron juntos en el juego con un programa que aprieta las teclas y revisa 33 resultados (los 10 lugares sin `return` y la muerte del Master Stalfos), grabando un video (ver 46 y 47).
- El cambio 48 compila y se probó en el juego, con los dos modos gráficos, matando a cada uno de los 7 enemigos que mueren (28 de 28 resultados), grabando un video (ver 48).
- Los cambios 49 y 50 compilan y se probaron juntos, con los dos modos gráficos, con un programa que revisa las flechas y las imágenes del StoneHinox (14 de 14 resultados), grabando un video del StoneHinox (ver 49 y 50).
- El cambio 21 compila y se corrió en el juego real: las rocas de la avalancha desaparecen a los 3 s de caer (ver 21).
