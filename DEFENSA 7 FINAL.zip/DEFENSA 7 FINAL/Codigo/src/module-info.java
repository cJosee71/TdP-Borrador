/**
 * Módulo del juego Zelda.
 */
module Zelda {
    requires java.desktop;
}
