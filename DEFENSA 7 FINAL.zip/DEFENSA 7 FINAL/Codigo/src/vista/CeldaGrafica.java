package vista;

import javax.swing.JLabel;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.SwingUtilities;

import logica.Observer;
import logica.EntidadLogica;

/**
 * Etiqueta que dibuja una entidad y se actualiza cuando ella cambia (patrón Observer).
 */
public class CeldaGrafica extends JLabel implements Observer {

    // Atributos de instancia

    protected EntidadLogica entidadObservada;
    protected PanelPantallaNivel panelNivel;
    protected String rutaMostrada;

    // Constructores

    /**
     * Crea la celda de una entidad en un panel.
     */
    public CeldaGrafica(EntidadLogica e, PanelPantallaNivel p) {
        entidadObservada = e;
        panelNivel = p;
    }

    // Comandos

    /**
     * Si la celda sigue en el panel, la quita cuando la entidad fue eliminada o, si no, la redibuja.
     */
    @Override
    public void actualizar() {
        SwingUtilities.invokeLater(() -> {
            if (getParent() != null) {
                if (entidadObservada.estaEliminada())
                    panelNivel.quitarCelda(this);
                else
                    redibujar();
            }
        });
    }

    /**
     * Carga la imagen si cambió su ruta (así un GIF puede avanzar entre actualizaciones) y la ubica donde se dibuja la entidad.
     */
    private void redibujar() {
        String ruta = entidadObservada.getRutaImagen();
        if (!ruta.equals(rutaMostrada)) {
            ImageIcon nuevo = new ImageIcon(CeldaGrafica.class.getResource(ruta));
            if (ruta.endsWith(".gif"))
                nuevo.getImage().flush();
            setIcon(nuevo);
            rutaMostrada = ruta;
        }
        Icon icono = getIcon();
        setVisible(entidadObservada.esVisible());
        setBounds(entidadObservada.getXImagen(), entidadObservada.getYImagen(), icono.getIconWidth(), icono.getIconHeight());
    }
}
