package vista;

import logica.ControladorJuego;
import logica.util.Direccion;

/**
 * Tarea que anima el cambio de sector en su propio hilo y avisa al terminar.
 */
public class AnimadorTransicion implements Runnable {

    // Atributos de instancia

    protected PanelPantallaNivel panel;
    protected Direccion direccion;
    protected ControladorJuego controlador;

    // Constructores

    /**
     * Crea la animación para un panel y una dirección.
     */
    public AnimadorTransicion(PanelPantallaNivel panel, Direccion direccion, ControladorJuego controlador) {
        this.panel = panel;
        this.direccion = direccion;
        this.controlador = controlador;
    }

    // Comandos

    /**
     * Desliza la pantalla y avisa que terminó la transición.
     */
    @Override
    public void run() {
        panel.desplazar(direccion);
        controlador.transicionTerminada();
    }
}
