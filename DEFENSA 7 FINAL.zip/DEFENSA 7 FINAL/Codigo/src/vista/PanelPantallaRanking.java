package vista;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

import logica.juego.EntradaRanking;
import logica.juego.Ranking;

/**
 * Pantalla con la tabla del ranking de un modo.
 */
public class PanelPantallaRanking extends PanelVista {

    // Atributos de instancia

    private JTable tabla;
    private JLabel titulo;

    // Constructores

    /**
     * Crea la pantalla del ranking.
     */
    public PanelPantallaRanking(ControladorDeVistas c) {
        super(c);
    }

    // Comandos

    /**
     * Carga en la tabla las entradas del ranking; si no hay, muestra un aviso.
     */
    public void mostrarRanking(Ranking r, String nombreModo) {
        titulo.setText("RANKING " + nombreModo.toUpperCase());
        DefaultTableModel modelo = new DefaultTableModel(new String[] {"PUESTO", "NOMBRE", "PUNTAJE"}, 0);
        int puesto = 1;
        for (EntradaRanking entrada : r.getEntradas()) {
            modelo.addRow(new Object[] {puesto++, entrada.getNombre(), entrada.getPuntaje()});
        }
        if (modelo.getRowCount() == 0) {
            modelo.addRow(new Object[] {"-", "Todavía no hay puntajes", "-"});
        }
        tabla.setModel(modelo);
    }

    /**
     * Vuelve al menú principal.
     */
    public void volver() {
        controladorVistas.mostrarPantallaPrincipal();
    }

    /**
     * Crea el título, la tabla con colores de podio y el botón de volver.
     */
    protected void armarComponentes() {
        Color plata = new Color(0xC4, 0xC8, 0xD0);
        Color bronce = new Color(0xCD, 0x7F, 0x32);
        Color[] podio = {COLOR_DORADO, plata, bronce};

        titulo = new JLabel("RANKING", SwingConstants.CENTER);
        titulo.setFont(new Font(Font.SERIF, Font.BOLD, 36));
        titulo.setForeground(COLOR_DORADO);

        tabla = new JTable();
        tabla.setEnabled(false);
        tabla.setRowHeight(46);
        tabla.setShowGrid(false);
        tabla.setIntercellSpacing(new Dimension(0, 0));
        tabla.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 18));
        tabla.setBackground(COLOR_SUPERFICIE);
        tabla.setForeground(COLOR_TEXTO);
        tabla.getTableHeader().setReorderingAllowed(false);
        tabla.getTableHeader().setPreferredSize(new Dimension(0, 40));
        tabla.getTableHeader().setFont(new Font(Font.SANS_SERIF, Font.BOLD, 14));
        tabla.getTableHeader().setBackground(COLOR_DORADO);
        tabla.getTableHeader().setForeground(COLOR_FONDO);
        tabla.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            /**
             * Arma la celda: texto centrado, filas alternadas y color de podio para los tres primeros puestos.
             */
            public Component getTableCellRendererComponent(JTable t, Object valor, boolean seleccionada,
                    boolean foco, int fila, int columna) {
                super.getTableCellRendererComponent(t, valor, false, false, fila, columna);
                setHorizontalAlignment(SwingConstants.CENTER);
                setBackground(fila % 2 == 0 ? COLOR_SUPERFICIE : COLOR_SUPERFICIE.darker());
                boolean destacada = columna == 0 && fila < podio.length;
                setForeground(destacada ? podio[fila] : COLOR_TEXTO);
                setFont(t.getFont().deriveFont(destacada ? Font.BOLD : Font.PLAIN));
                return this;
            }
        });

        JScrollPane desplazable = new JScrollPane(tabla);
        desplazable.setBorder(BorderFactory.createLineBorder(COLOR_DORADO));
        desplazable.getViewport().setBackground(COLOR_SUPERFICIE);

        JButton botonVolver = new JButton("VOLVER");
        botonVolver.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 15));
        botonVolver.setFocusPainted(false);
        botonVolver.setContentAreaFilled(false);
        botonVolver.setOpaque(true);
        botonVolver.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        botonVolver.setBackground(COLOR_DORADO);
        botonVolver.setForeground(COLOR_FONDO);
        botonVolver.setBorder(BorderFactory.createEmptyBorder(11, 40, 11, 40));
        botonVolver.addActionListener(e -> volver());

        setLayout(new BorderLayout(0, 20));
        setBorder(BorderFactory.createEmptyBorder(34, 90, 34, 90));
        add(titulo, BorderLayout.NORTH);
        add(desplazable, BorderLayout.CENTER);
        add(botonVolver, BorderLayout.SOUTH);
    }
}
