package vista;

import logica.juego.ModoJuego;
import logica.fabricas.FabricaSprites;

/**
 * Operaciones que los paneles le piden a la GUI para cambiar de pantalla.
 */
public interface ControladorDeVistas {

    // Comandos

    /**
     * Muestra el menú principal.
     */
    public void mostrarPantallaPrincipal();

    /**
     * Muestra el ranking de un modo.
     */
    public void mostrarPantallaRanking(ModoJuego m);

    /**
     * Muestra el nivel y arranca la partida.
     */
    public void iniciarPartida(ModoJuego modo, FabricaSprites dominio);
}
