package vista;

import java.awt.Cursor;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JToggleButton;
import javax.swing.SwingConstants;

import logica.fabricas.FabricaSprites;
import logica.fabricas.FabricaSpritesAlternativa;
import logica.fabricas.FabricaSpritesOriginal;
import logica.juego.Clasico;
import logica.juego.Contrarreloj;
import logica.juego.ModoJuego;
import logica.juego.NoHit;

/**
 * Menú principal: elegir dominio gráfico y modo, jugar o ver el ranking.
 */
public class PanelPantallaPrincipal extends PanelVista {

    // Atributos de instancia

    private FabricaSprites dominio;
    private ModoJuego modo;

    // Constructores

    /**
     * Crea el menú principal.
     */
    public PanelPantallaPrincipal(ControladorDeVistas c) {
        super(c);
    }

    // Comandos

    /**
     * Elige el dominio gráfico.
     */
    public void elegirDominio(FabricaSprites d) {
        dominio = d;
    }

    /**
     * Elige el modo de juego.
     */
    public void elegirModo(ModoJuego m) {
        modo = m;
    }

    /**
     * Arranca la partida con lo elegido.
     */
    public void jugar() {
        controladorVistas.iniciarPartida(modo, dominio);
    }

    /**
     * Muestra el ranking del modo elegido.
     */
    public void verRanking() {
        controladorVistas.mostrarPantallaRanking(modo);
    }

    /**
     * Crea el título, los botones de dominio y modo (con la descripción del modo), jugar, ranking y la ayuda de teclas.
     */
    protected void armarComponentes() {
        dominio = new FabricaSpritesOriginal();
        modo = new Clasico();
        int tiempoLimiteSegundos = 120;
        String descripcionClasico = "Superá los dos niveles y derrotá a sus jefes.";
        String descripcionContrarreloj = "Tenés " + tiempoLimiteSegundos + " segundos por nivel.";
        String descripcionNoHit = "Un solo golpe y la partida termina.";

        JToggleButton botonOriginal = new JToggleButton("Original", true);
        JToggleButton botonAlternativo = new JToggleButton("Alternativo");
        JToggleButton botonClasico = new JToggleButton("Clásico", true);
        JToggleButton botonContrarreloj = new JToggleButton("Contrarreloj");
        JToggleButton botonNoHit = new JToggleButton("NoHit");
        JButton botonJugar = new JButton("JUGAR");
        JButton botonRanking = new JButton("VER RANKING");
        JLabel descripcionModo = new JLabel(descripcionClasico, SwingConstants.CENTER);

        ButtonGroup grupoDominio = new ButtonGroup();
        grupoDominio.add(botonOriginal);
        grupoDominio.add(botonAlternativo);
        ButtonGroup grupoModo = new ButtonGroup();
        grupoModo.add(botonClasico);
        grupoModo.add(botonContrarreloj);
        grupoModo.add(botonNoHit);

        botonOriginal.addActionListener(e -> elegirDominio(new FabricaSpritesOriginal()));
        botonAlternativo.addActionListener(e -> elegirDominio(new FabricaSpritesAlternativa()));
        botonClasico.addActionListener(e -> {
            elegirModo(new Clasico());
            descripcionModo.setText(descripcionClasico);
        });
        botonContrarreloj.addActionListener(e -> {
            elegirModo(new Contrarreloj(tiempoLimiteSegundos));
            descripcionModo.setText(descripcionContrarreloj);
        });
        botonNoHit.addActionListener(e -> {
            elegirModo(new NoHit());
            descripcionModo.setText(descripcionNoHit);
        });
        botonJugar.addActionListener(e -> jugar());
        botonRanking.addActionListener(e -> verRanking());

        JToggleButton[] opciones = {botonOriginal, botonAlternativo, botonClasico, botonContrarreloj, botonNoHit};
        for (JToggleButton opcion : opciones) {
            opcion.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 14));
            opcion.setFocusPainted(false);
            opcion.setContentAreaFilled(false);
            opcion.setOpaque(true);
            opcion.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            opcion.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(COLOR_DORADO), BorderFactory.createEmptyBorder(8, 20, 8, 20)));
            Runnable pintar = () -> {
                opcion.setBackground(opcion.isSelected() ? COLOR_DORADO : COLOR_SUPERFICIE);
                opcion.setForeground(opcion.isSelected() ? COLOR_FONDO : COLOR_TEXTO);
            };
            pintar.run();
            opcion.addItemListener(e -> pintar.run());
        }

        JButton[] acciones = {botonJugar, botonRanking};
        for (JButton accion : acciones) {
            boolean principal = accion == botonJugar;
            accion.setFont(new Font(Font.SANS_SERIF, Font.BOLD, principal ? 20 : 15));
            accion.setFocusPainted(false);
            accion.setContentAreaFilled(false);
            accion.setOpaque(true);
            accion.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            accion.setBackground(principal ? COLOR_DORADO : COLOR_SUPERFICIE);
            accion.setForeground(principal ? COLOR_FONDO : COLOR_DORADO);
            accion.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(COLOR_DORADO),
                    BorderFactory.createEmptyBorder(principal ? 14 : 9, principal ? 90 : 60, principal ? 14 : 9, principal ? 90 : 60)));
        }

        JLabel titulo = new JLabel("<html><center><span style='font-size:25pt'>THE LEGEND OF ZELDA</span><br>"
            + "<span style='font-size:17pt'>LINK'S AWAKENING</span></center></html>", SwingConstants.CENTER
        );
        titulo.setFont(new Font(Font.SERIF, Font.BOLD, 20));
        titulo.setForeground(COLOR_DORADO);

        JLabel etiquetaDominio = new JLabel("DOMINIO GRÁFICO", SwingConstants.CENTER);
        JLabel etiquetaModo = new JLabel("MODO DE JUEGO", SwingConstants.CENTER);
        JLabel ayuda = new JLabel("Flechas: mover   ·   A: atacar   ·   S: escudo   ·   D: cambiar objeto", SwingConstants.CENTER);
        for (JLabel seccion : new JLabel[] {etiquetaDominio, etiquetaModo}) {
            seccion.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 12));
            seccion.setForeground(COLOR_DORADO);
        }
        descripcionModo.setFont(new Font(Font.SANS_SERIF, Font.ITALIC, 13));
        descripcionModo.setForeground(COLOR_TEXTO);
        ayuda.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 12));
        ayuda.setForeground(COLOR_TEXTO);

        JPanel filaDominio = new JPanel();
        filaDominio.setOpaque(false);
        filaDominio.add(botonOriginal);
        filaDominio.add(botonAlternativo);
        JPanel filaModo = new JPanel();
        filaModo.setOpaque(false);
        filaModo.add(botonClasico);
        filaModo.add(botonContrarreloj);
        filaModo.add(botonNoHit);

        setLayout(new GridBagLayout());
        GridBagConstraints fila = new GridBagConstraints();
        fila.gridx = 0;
        fila.insets = new Insets(2, 0, 2, 0);
        add(titulo, fila);
        fila.insets = new Insets(26, 0, 2, 0);
        add(etiquetaDominio, fila);
        fila.insets = new Insets(2, 0, 2, 0);
        add(filaDominio, fila);
        fila.insets = new Insets(14, 0, 2, 0);
        add(etiquetaModo, fila);
        fila.insets = new Insets(2, 0, 2, 0);
        add(filaModo, fila);
        add(descripcionModo, fila);
        fila.insets = new Insets(30, 0, 8, 0);
        add(botonJugar, fila);
        fila.insets = new Insets(2, 0, 2, 0);
        add(botonRanking, fila);
        fila.insets = new Insets(26, 0, 0, 0);
        add(ayuda, fila);
    }
}
