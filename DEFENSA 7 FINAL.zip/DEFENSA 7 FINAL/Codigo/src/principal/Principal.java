package principal;

import javax.swing.SwingUtilities;

import logica.juego.Juego;
import vista.GUI;

/**
 * Punto de entrada: arma la vista y la lógica y las conecta.
 */
public class Principal {

    /**
     * Inicia la aplicación en el hilo de Swing.
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            GUI gui = new GUI();
            Juego juego = new Juego(gui);
            gui.setControladorJuego(juego);
            gui.mostrarPantallaPrincipal();
        });
    }
}
