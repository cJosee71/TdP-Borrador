package logica.util;

/**
 * Punto inmutable en píxeles.
 */
public final class Posicion {

    // Atributos de instancia

    private final int x;
    private final int y;

    // Constructores

    /**
     * Crea una posición en (x, y).
     */
    public Posicion(int x, int y) {
        this.x = x;
        this.y = y;
    }

    // Consultas

    /**
     * Devuelve la coordenada x.
     */
    public int getX() {
        return x;
    }

    /**
     * Devuelve la coordenada y.
     */
    public int getY() {
        return y;
    }

    /**
     * Devuelve una posición nueva corrida unos pasos en una dirección.
     */
    public Posicion desplazada(Direccion d, int pasos) {
        return new Posicion(
            x + d.getDx() * pasos,
            y + d.getDy() * pasos
        );
    }

    /**
     * Devuelve la distancia a otra posición.
     */
    public double distancia(Posicion otra) {
        return Math.hypot(otra.x - x, otra.y - y);
    }

    /**
     * Devuelve la dirección principal hacia otra posición.
     */
    public Direccion direccionHacia(Posicion otra) {
        int dx = otra.x - x;
        int dy = otra.y - y;
        if (Math.abs(dx) >= Math.abs(dy)) {
            return dx >= 0 ? Direccion.DERECHA : Direccion.IZQUIERDA;
        }
        return dy >= 0 ? Direccion.ABAJO : Direccion.ARRIBA;
    }
}
