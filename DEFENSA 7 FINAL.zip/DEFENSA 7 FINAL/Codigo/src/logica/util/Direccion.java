package logica.util;

/**
 * Las cuatro direcciones de movimiento con su paso en cada eje.
 */
public enum Direccion {
    ARRIBA(0, -1), ABAJO(0, 1), IZQUIERDA(-1, 0), DERECHA(1, 0);

    // Atributos de instancia

    private final int dx;
    private final int dy;

    // Constructores

    /**
     * Crea una dirección con su paso en x y en y.
     */
    Direccion(int dx, int dy) {
        this.dx = dx;
        this.dy = dy;
    }

    // Consultas

    /**
     * Devuelve la dirección contraria.
     */
    public Direccion opuesta() {
        switch (this) {
            case ARRIBA:    return ABAJO;
            case ABAJO:     return ARRIBA;
            case IZQUIERDA: return DERECHA;
            default:        return IZQUIERDA;
        }
    }

    /**
     * Devuelve el paso en x.
     */
    public int getDx() {
        return dx;
    }

    /**
     * Devuelve el paso en y.
     */
    public int getDy() {
        return dy;
    }
}
