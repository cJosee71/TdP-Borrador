package logica;

import logica.util.Direccion;
import logica.juego.Ranking;

/**
 * Operaciones que la lógica le pide a la vista.
 */
public interface ControladorGrafico {

    // Comandos

    /**
     * Crea la celda gráfica de una entidad y la devuelve como su observador.
     */
    public Observer mostrarEntidad(EntidadLogica e);

    /**
     * Crea la celda gráfica del jugador y la devuelve como su observador.
     */
    public Observer mostrarJugador(EntidadJugador j);

    /**
     * Borra todas las entidades dibujadas.
     */
    public void limpiarEscena();

    /**
     * Anima el cambio de sector en la dirección indicada.
     */
    public void transicion(Direccion d);

    /**
     * Muestra el tiempo de la partida.
     */
    public void actualizarTiempo(int segundos);

    /**
     * Muestra el número de nivel.
     */
    public void actualizarNivel(int numero);

    /**
     * Deja de enviarle las teclas al jugador porque la partida terminó.
     */
    public void terminarControl();

    /**
     * Pide el nombre del jugador para el ranking.
     */
    public void pedirNombre(int puntaje);

    /**
     * Muestra el ranking de un modo de juego.
     */
    public void mostrarRanking(Ranking r, String nombreModo);
}
