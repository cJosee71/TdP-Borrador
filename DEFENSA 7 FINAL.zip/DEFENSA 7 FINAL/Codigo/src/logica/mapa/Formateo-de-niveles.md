# Formato de archivo de niveles

Documentación del formato que lee `GeneradorNivel` (paquete `logica.mapa`), actualizada con el código de la defensa 7.

## Índice

- **Formato**
  - [1. Qué es y cómo se carga un nivel](#1-qué-es-y-cómo-se-carga-un-nivel)
  - [2. Estructura del archivo](#2-estructura-del-archivo)
  - [3. Símbolos](#3-símbolos)
  - [4. Reglas](#4-reglas)
  - [5. Ejemplo: sector 0,0 del nivel 1](#5-ejemplo-sector-00-del-nivel-1)
  - [6. Errores](#6-errores)
  - [7. Cómo armar o editar un nivel](#7-cómo-armar-o-editar-un-nivel)

---

## Formato

### 1. Qué es y cómo se carga un nivel

El mapa de cada nivel no está escrito en el código: está en un archivo de texto, `nivel<N>.txt`, dentro de `/Recursos/Niveles/`. Así se puede cambiar un nivel, o agregar uno, sin tocar Java. Cada carácter del archivo representa un lugar del mapa, y `GeneradorNivel` lo convierte en la entidad que corresponde (una roca, un enemigo, un corazón...).

El archivo se busca entre los recursos del programa con `getResourceAsStream`. Por eso funciona igual desde el IDE que desde el `.jar`: en los dos casos el archivo viaja junto con el código.

**Paso a paso, cuando empieza un nivel:**

1. `Juego` crea el generador una sola vez con `new GeneradorNivel("/Recursos/Niveles/")`, indicando la carpeta.
2. Al empezar el nivel N, `Juego` llama a `generar(N, fabricaEntidades)`.
3. `leerArchivo` abre `/Recursos/Niveles/nivelN.txt` y guarda todas sus líneas en una lista. Las líneas en blanco se saltean, así que se pueden usar para separar visualmente los sectores.
4. `generar` lee las tres líneas de cabecera (`MAPA`, `CELDAS`, `INICIO`) y crea la `Escena`, que es la grilla de sectores vacía.
5. Para cada bloque `SECTOR`, crea un `Sector`, lo ubica en la escena y recorre sus filas carácter por carácter, pidiendo a la fábrica la entidad de cada símbolo.
6. Al terminar, reparte los 4 fragmentos de corazón al azar.
7. Devuelve el `Nivel`, que guarda la escena, la lista de jefes y dónde empieza Link.

| Clase | Rol |
|---|---|
| `Juego` | Pide el nivel con `generadorNivel.generar(numero, fabricaEntidades)` y después lo juega. |
| `GeneradorNivel` | Lee el archivo, interpreta la cabecera y los sectores, y arma el nivel. |
| `Nivel` | El nivel armado: su escena, sus jefes y el lugar de inicio. Se gana cuando todos sus jefes están derrotados. |
| `Escena` | La grilla de sectores. Sabe cuál es el vecino de cada sector (`getVecino`). |
| `Sector` | Una pantalla de 768 × 528 px con sus entidades. |
| `FabricaEntidades` | Crea cada entidad con su sprite; el generador nunca hace `new` de una entidad directamente. |

La relación es `Nivel` ◆ `Escena` ◆ `Sector`: un nivel tiene una escena, y la escena tiene varios sectores.

### 2. Estructura del archivo

El archivo tiene dos partes:

1. **Cabecera:** las tres primeras líneas no vacías, siempre en este orden: `MAPA`, `CELDAS` e `INICIO`.
2. **Sectores:** después, un bloque por cada pantalla del mapa. Cada bloque empieza con la línea `SECTOR` y sigue con las filas del dibujo.

Así empieza `nivel1.txt`:

```
MAPA 1 4
CELDAS 32 22 24
INICIO 0 0 4 10
SECTOR 0 0
..............................T.
................................
(... 20 filas más ...)
SECTOR 0 1
(... 22 filas ...)
```

Cada línea de cabecera es una palabra seguida de números separados por un espacio:

| Línea | Sintaxis | Qué significa | En los niveles actuales |
|---|---|---|---|
| `MAPA` | `MAPA <filas> <columnas>` | Cuántos sectores tiene la escena, como una grilla. | `MAPA 1 4`: una fila de 4 sectores, uno al lado del otro. Link recorre el nivel de izquierda a derecha. |
| `CELDAS` | `CELDAS <ancho> <alto> <lado>` | Cuántas celdas tiene cada sector de ancho y de alto, y cuánto mide cada celda en píxeles. | `CELDAS 32 22 24`: 32 × 22 celdas de 24 px. Da 768 × 528 px, que es el tamaño de la pantalla de juego. |
| `INICIO` | `INICIO <fila> <columna> <x> <y>` | En qué sector empieza Link (fila y columna de la grilla) y en qué celda (x, y) de ese sector. | `INICIO 0 0 4 10`: sector de la esquina izquierda, celda (4, 10). En píxeles: (4 × 24, 10 × 24) = (96, 240). |
| `SECTOR` | `SECTOR <fila> <columna>` | Abre el bloque de un sector y dice en qué lugar de la grilla va. | `SECTOR 0 0` a `SECTOR 0 3`. |

Debajo de cada `SECTOR` van exactamente `alto` filas (22) de `ancho` caracteres (32). La fila 0 es la de arriba y la columna 0 la de la izquierda.

**Por qué los símbolos van separados.** Las entidades miden 48 × 48 px, o sea 2 × 2 celdas de 24 px. Cada símbolo marca la esquina superior izquierda de la entidad. Por eso en los niveles los símbolos van en columnas y filas pares y las filas impares quedan vacías: si dos símbolos estuvieran en celdas vecinas, sus entidades se pisarían.

### 3. Símbolos

Cada carácter del dibujo es una de estas entidades. Mayúsculas y minúsculas importan: `r` no es una roca.

| Símbolo | Entidad | Tipo | Comportamiento en el juego |
|---|---|---|---|
| `R` | Roca | Obstáculo | Bloquea el paso a Link, a los enemigos y a los proyectiles. |
| `A` | Agua | Obstáculo | Bloquea el paso como la roca, pero se dibuja en el suelo. |
| `P` | Pasto | Obstáculo | Link puede pasar, pero más lento. Se corta con la espada. |
| `V` | Caída al vacío | Obstáculo | Si Link la pisa, cae y pierde una vida. Los enemigos la esquivan. |
| `Q` | Suelo quebradizo | Obstáculo | Se rompe cuando Link lo pisa y se convierte en una caída al vacío. |
| `M` | Moblin | Enemigo | Camina por el sector; tiene 2 de vida. |
| `N` | Moblin con espada y escudo | Enemigo | El escudo lo protege de frente. Si ve a Link enfrente, se abalanza. |
| `E` | Erizo de mar | Enemigo | Se queda quieto; lastima al que lo toca. |
| `O` | Octorok | Enemigo | Dispara proyectiles. |
| `T` | Trampa de cuchillas | Enemigo | Cuando ve a Link en línea recta, se lanza hacia él y después vuelve a su lugar. |
| `W` | Wizzrobe | Enemigo | Se teletransporta y dispara. |
| `S` | Master Stalfos | Jefe | Ataca con espada. Es jefe: hay que derrotarlo para ganar el nivel. |
| `H` | Stone Hinox | Jefe | Embiste, lanza rocas y hace avalanchas. Es jefe: hay que derrotarlo para ganar el nivel. |
| `$` | Rupia | Power-up | Suma rupias y puntos al tocarla. |
| `C` | Corazón | Power-up | Cura a Link. |
| `X` | Espada | Objeto | Link la equipa al tocarla. |
| `.` | Celda libre | — | No crea nada. En el borde del sector es el paso al sector vecino. |

**Cómo se traduce cada símbolo.** Casi todos pasan por `crearEntidad(simbolo, x, y, fabrica)`, que tiene un `switch` con un `case` por letra; cada uno llama al método de la fábrica que corresponde (por ejemplo `'R'` llama a `fabrica.crearRoca(x, y)`). El `.` devuelve `null`, y el generador no agrega nada.

Los jefes son la excepción. `S` y `H` los resuelve `generar` antes del `switch`, porque además de agregarlos al sector tiene que anotarlos en la lista `jefes` del nivel. Esa lista es la que se revisa para saber si el nivel se ganó.

### 4. Reglas

**Coordenadas.** La entidad de la columna `k` y la fila `r` se crea en x = k × 24, y = r × 24. Las coordenadas son locales al sector: (0, 0) es la esquina superior izquierda de su pantalla, no del mapa completo. Por ejemplo, la `T` de la fila 0, columna 30 del sector 0,0 queda en (720, 0).

**Fragmentos de corazón.** No se escriben en el archivo. Cuando terminan de cargarse los sectores, `colocarFragmentosDeCorazon` elige 4 sectores distintos al azar y pone un fragmento en cada uno, en un lugar donde no choque con nada (`posicionLibreAlAzar`). Por eso cambian de lugar en cada partida.

**Entidades sin símbolo.** La bellota no está en el archivo: aparece durante el juego (`Juego.aparecerBellota`). El escudo tiene un método en la fábrica (`crearEscudo`), pero el archivo no tiene una letra para él.

**Paso entre sectores.** Cuando Link sale por un borde del sector, `Escena.getVecino(sector, direccion)` busca el sector de al lado en la grilla. Si existe, Link pasa a ese sector y entra por el borde opuesto. Si no existe (por ejemplo, el borde izquierdo del primer sector), Link vuelve a entrar al mismo sector. Para que se pueda pasar, el borde tiene que estar libre (`.`) en los dos sectores.

**Sin `instanceof`.** El `switch` traduce caracteres de texto en objetos. No pregunta de qué clase es ningún objeto, así que respeta la prohibición de `instanceof` del enunciado.

### 5. Ejemplo: sector 0,0 del nivel 1

Este es el primer bloque de `nivel1.txt`, la pantalla donde empieza Link:

```
SECTOR 0 0
..............................T.
................................
..............V.....O...........
................................
......R.R.............P.P.......
................................
............Q.........P.P.......
................................
......N.............C...........
................................
..........X.....................
................................
........$...............E.......
................................
............V.......Q...........
................................
......A.A.............R.R.......
................................
......A.....W...V...............
................................
................................
................................
```

**Cómo leerlo:**

- `SECTOR 0 0` dice que es el sector de la fila 0, columna 0 de la grilla: el primero de la izquierda.
- La `T` de la primera fila está en la columna 30, así que es una trampa de cuchillas en (30 × 24, 0) = (720, 0), arriba a la derecha.
- La `X` de la fila 10, columna 10, es la espada, en (240, 240). Es lo primero que conviene agarrar.
- Los `.` de los bordes izquierdo, superior e inferior no llevan a ningún lado, porque no hay sectores ahí. El borde derecho lleva al sector 0,1.

**Resultado:** se crean 24 entidades: 4 rocas, 3 aguas, 4 pastos, 3 caídas al vacío, 2 suelos quebradizos, 1 trampa de cuchillas, 1 Octorok, 1 Moblin con espada y escudo, 1 erizo, 1 Wizzrobe, 1 corazón, 1 rupia y 1 espada. A eso se suman los fragmentos de corazón que le toquen al azar. Con `INICIO 0 0 4 10`, Link aparece en este sector en (96, 240).

### 6. Errores

Esta sección explica qué pasa si un archivo de nivel está mal escrito. Hoy los dos niveles están bien, así que ninguno de estos casos ocurre al jugar. Sirve como guía para quien edite o agregue un `nivel<N>.txt`.

Hay dos tipos de casos:

- **Controlados:** `GeneradorNivel` los detecta y corta la carga con un mensaje claro que dice qué está mal.
- **No controlados:** el generador no los revisa. Java corta con un error genérico, que no dice qué línea del archivo falla, o el nivel se carga con un problema que se nota recién al jugar.

#### 6.1 Casos controlados

**El archivo no existe o no se puede leer.**
Por ejemplo, el juego pide el nivel 3 y no hay `nivel3.txt`, o la carpeta no se llama `/Recursos/Niveles/`.
`leerArchivo` atrapa el problema y lanza `IllegalStateException` con el mensaje `No se pudo leer /Recursos/Niveles/nivel3.txt`. El juego no arranca ese nivel.

**Hay un símbolo que no está en la tabla.**
Por ejemplo, una fila tiene una `Z`, o se usó la `b` minúscula.
`crearEntidad` llega al `default` del `switch` y lanza `IllegalArgumentException` con el mensaje `Símbolo desconocido: Z`. Para corregirlo hay que reemplazar el carácter por uno de la sección 3. Las mayúsculas y minúsculas importan.

#### 6.2 Casos no controlados

**Una fila tiene menos de 32 caracteres.**
El generador recorre siempre los 32 caracteres de cada fila. Si la fila es más corta, al pedir un carácter que no existe `charAt` lanza `StringIndexOutOfBoundsException`. El mensaje solo dice la posición (por ejemplo `index 31, length 30`), no en qué fila ni en qué sector está el error.
Si la fila es más larga, lo que sobra se ignora sin aviso.

**Un sector tiene menos de 22 filas.**
El generador lee 22 filas después de cada `SECTOR`. Si faltan, toma como fila la línea siguiente, que es el `SECTOR` del próximo bloque, y todo lo que sigue queda corrido. Según dónde falle, corta con `IndexOutOfBoundsException` (se acabó el archivo) o con `NumberFormatException` (intenta leer una fila de mapa como si fuera una cabecera `SECTOR f c`). Un sector con filas de más produce el mismo `NumberFormatException`.
Las líneas en blanco no cuentan: el generador las saltea.

**Falta el bloque de un sector.**
Por ejemplo, `MAPA 1 4` pide 4 sectores y el archivo trae solo `SECTOR 0 0`, `0 1` y `0 3`.
El nivel se carga igual y ese lugar de la grilla queda vacío (`null`). Cuando Link intenta salir hacia el sector que falta, `Escena.getVecino` devuelve `null` y Link vuelve a entrar por el mismo borde, como si fuera el límite del mapa. Además, los sectores siguientes quedan inalcanzables. Pasa lo mismo si un `SECTOR` tiene una fila o columna fuera de la grilla: `agregarSector` lo descarta sin avisar.

**El nivel no tiene jefe (`S` o `H`).**
El nivel se carga y se juega normalmente, pero la lista de jefes queda vacía. Como el nivel se gana al derrotar a todos sus jefes, y eso solo se revisa cuando muere un jefe, el nivel nunca termina.

### 7. Cómo armar o editar un nivel

1. Copiar uno de los archivos existentes y cambiarle el número: `nivel3.txt`.
2. Ajustar `MAPA` a la cantidad de sectores y escribir un bloque `SECTOR f c` para cada uno.
3. Escribir cada bloque con exactamente 22 filas de 32 caracteres. Poner los símbolos en columnas y filas pares, porque cada entidad ocupa 2 × 2 celdas.
4. Dejar `.` en los bordes por donde Link tiene que pasar al sector vecino, y en el mismo lugar del borde del vecino.
5. Poner al menos un jefe (`S` o `H`).
6. Revisar que `INICIO` apunte a un sector que exista y a una celda libre.

Si algo de esto falla, la sección 6 explica qué error aparece.
