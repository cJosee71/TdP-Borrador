package logica.mapa;

import logica.util.Direccion;

/**
 * Grilla de sectores de un nivel.
 */
public class Escena {

    // Atributos de instancia

    protected Sector[][] sectores;
    protected int filas;
    protected int columnas;

    // Constructores

    /**
     * Crea una escena vacía de filas por columnas.
     */
    public Escena(int filas, int columnas) {
        this.filas = filas;
        this.columnas = columnas;
        this.sectores = new Sector[filas][columnas];
    }

    // Comandos

    /**
     * Ubica un sector en la grilla si la celda existe.
     */
    public void agregarSector(int fila, int columna, Sector s) {
        if (fila >= 0 && fila < filas && columna >= 0 && columna < columnas) {
            sectores[fila][columna] = s;
        }
    }

    // Consultas

    /**
     * Devuelve el sector de una celda, o null.
     */
    public Sector getSector(int fila, int columna) {
        if (fila >= 0 && fila < filas && columna >= 0 && columna < columnas) {
            return sectores[fila][columna];
        }
        return null;
    }

    /**
     * Devuelve el sector vecino en una dirección, o null.
     */
    public Sector getVecino(Sector s, Direccion d) {
        if (s == null || d == null) {
            return null;
        }
        int f = s.getFila() + d.getDy();
        int c = s.getColumna() + d.getDx();
        if (f < 0 || f >= filas || c < 0 || c >= columnas) {
            return null;
        }
        return sectores[f][c];
    }

    /**
     * Devuelve la cantidad de filas.
     */
    public int getFilas() {
        return filas;
    }

    /**
     * Devuelve la cantidad de columnas.
     */
    public int getColumnas() {
        return columnas;
    }
}
