package logica.mapa;

import logica.entidades.AdministradorColisiones;
import logica.util.Hitbox;
import java.util.Random;
import logica.util.Direccion;
import logica.util.Posicion;
import logica.entidades.Entidad;
import logica.entidades.EntidadAnimada;
import java.util.List;
import java.util.ArrayList;

/**
 * Pantalla del nivel con sus entidades.
 */
public class Sector {

    // Atributos de clase

    public static final int ANCHO = 768;
    public static final int ALTO = 528;

    // Atributos de instancia

    protected List<Entidad> entidades;
    protected int fila;
    protected int columna;

    // Constructores

    /**
     * Crea un sector vacío en una celda de la escena.
     */
    public Sector(int fila, int columna) {
        this.fila = fila;
        this.columna = columna;
        this.entidades = new ArrayList<>();
    }

    // Comandos

    /**
     * Agrega una entidad al sector.
     */
    public synchronized void agregar(Entidad e) {
        entidades.add(e);
        e.setSector(this);
    }

    /**
     * Quita una entidad eliminada.
     */
    public synchronized void quitar(Entidad e) {
        entidades.remove(e);
    }

    /**
     * Saca una entidad que se va a otro sector.
     */
    public synchronized void retirar(Entidad e) {
        entidades.remove(e);
    }

    /**
     * Actualiza una vez cada entidad no eliminada.
     */
    public void actualizarEntidades(AdministradorColisiones c) {
        for (Entidad e : getEntidades())
            if (!e.estaEliminada())
                e.actualizarPorMundo(c);
    }

    // Consultas

    /**
     * Devuelve una copia de la lista de entidades.
     */
    public synchronized List<Entidad> getEntidades() {
        return new ArrayList<>(entidades);
    }

    /**
     * Devuelve un lugar libre al azar para un cuerpo de ese tamaño, o el centro si no encuentra.
     */
    public Posicion posicionLibreAlAzar(int ancho, int alto) {
        Random azar = new Random();
        List<Entidad> todas = getEntidades();
        for (int intento = 0; intento < 200; intento++) {
            int x = azar.nextInt(ANCHO - ancho + 1);
            int y = azar.nextInt(ALTO - alto + 1);
            Hitbox lugar = new Hitbox(x, y, ancho, alto);
            boolean libre = true;
            for (Entidad e : todas)
                if (!e.estaEliminada() && e.getHitbox().intersecta(lugar))
                    libre = false;
            if (libre)
                return new Posicion(x, y);
        }
        return getCentro();
    }

    /**
     * Devuelve el centro de la pantalla.
     */
    public Posicion getCentro() {
        return new Posicion(ANCHO / 2, ALTO / 2);
    }

    /**
     * Devuelve la fila en la escena.
     */
    public int getFila() {
        return fila;
    }

    /**
     * Devuelve la columna en la escena.
     */
    public int getColumna() {
        return columna;
    }
}
