package logica.mapa;

import logica.util.Posicion;
import logica.entidades.enemigos.Jefe;
import java.util.List;

/**
 * Nivel del juego: su escena, sus jefes y dónde empieza Link.
 */
public class Nivel {

    // Atributos de instancia

    protected Escena mapa;
    protected List<Jefe> jefes;
    protected int filaInicial;
    protected int columnaInicial;
    protected Posicion posicionInicial;

    // Constructores

    /**
     * Crea el nivel con su escena, sus jefes y el lugar de inicio.
     */
    public Nivel(Escena mapa, List<Jefe> jefes, int filaInicial, int columnaInicial, Posicion posicionInicial) {
        this.mapa = mapa;
        this.jefes = jefes;
        this.filaInicial = filaInicial;
        this.columnaInicial = columnaInicial;
        this.posicionInicial = posicionInicial;
    }

    // Consultas

    /**
     * Devuelve la escena.
     */
    public Escena getMapa() {
        return mapa;
    }

    /**
     * Devuelve el sector donde empieza Link.
     */
    public Sector getSectorInicial() {
        return mapa.getSector(filaInicial, columnaInicial);
    }

    /**
     * Devuelve la posición donde empieza Link.
     */
    public Posicion getPosicionInicial() {
        return posicionInicial;
    }

    /**
     * Devuelve los jefes del nivel.
     */
    public List<Jefe> getJefes() {
        return jefes;
    }

    /**
     * Indica si todos los jefes fueron derrotados.
     */
    public boolean jefesDerrotados() {
        for (Jefe j : jefes) {
            if (!j.estaEliminada()) {
                return false;
            }
        }
        return true;
    }
}
