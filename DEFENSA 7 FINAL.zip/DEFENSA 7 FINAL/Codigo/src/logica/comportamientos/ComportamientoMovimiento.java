package logica.comportamientos;

import logica.entidades.AdministradorColisiones;
import logica.entidades.EntidadAnimada;

/**
 * Estrategia de movimiento de una entidad animada (patrón Strategy).
 */
public interface ComportamientoMovimiento {

    // Comandos

    /**
     * Ejecuta una vuelta del movimiento.
     */
    public void mover(EntidadAnimada e, AdministradorColisiones c);
}
