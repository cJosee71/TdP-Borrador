package logica.comportamientos;

import logica.entidades.AdministradorColisiones;
import logica.entidades.EntidadAnimada;

/**
 * Estrategia de ataque de una entidad animada (patrón Strategy).
 */
public interface ComportamientoAtaque {

    // Comandos

    /**
     * Ejecuta una vuelta del ataque.
     */
    public void atacar(EntidadAnimada atacante, AdministradorColisiones c);

    /**
     * Resuelve el contacto con la entidad tocada.
     */
    public void ataqueAlContactar(EntidadAnimada atacante, EntidadAnimada tocado);
}
