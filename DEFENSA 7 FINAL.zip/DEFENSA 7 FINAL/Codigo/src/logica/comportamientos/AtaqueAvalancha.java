package logica.comportamientos;

import java.util.Random;

import logica.entidades.AdministradorColisiones;
import logica.entidades.EntidadAnimada;
import logica.entidades.Proyectil;
import logica.entidades.enemigos.GeneradorProyectil;
import logica.util.Direccion;
import logica.util.Posicion;

/**
 * Ataque de StoneHinox: desde el centro del sector hace caer rocas en lugares libres al azar.
 */
public class AtaqueAvalancha extends AtaquePorProyectil {

    // Atributos de clase

    private static final int ROCAS_MINIMAS = 5;
    private static final int ROCAS_MAXIMAS = 10;
    private static final int TOLERANCIA_CENTRO = 4;

    // Atributos de instancia

    private Random azar;

    // Constructores

    /**
     * Crea la avalancha con el generador de rocas.
     */
    public AtaqueAvalancha(GeneradorProyectil g) {
        super(g, 0, 0);
        azar = new Random();
    }

    // Comandos

    /**
     * Ubica la roca arriba de un lugar libre y la hace caer hasta él.
     */
    protected void ubicar(Proyectil p, EntidadAnimada a, AdministradorColisiones c) {
        Posicion lugar = c.getSector().posicionLibreAlAzar(p.getAncho(), p.getAlto());
        p.ubicarCuerpoEn(lugar.getX(), 0);
        p.setDireccion(Direccion.ABAJO);
        p.setDestino(p.getHitbox().posicionParaCuerpoEn(lugar.getX(), lugar.getY()));
    }

    /**
     * Avisa al atacante que terminó la avalancha.
     */
    protected void alTerminar(EntidadAnimada atacante) {
        atacante.ataqueTerminado();
    }

    // Consultas

    /**
     * Indica si el atacante llegó al centro del sector.
     */
    protected boolean puedeAtacar(EntidadAnimada a) {
        return a.getCentro().distancia(a.getSector().getCentro()) < TOLERANCIA_CENTRO;
    }

    /**
     * Devuelve una cantidad de rocas al azar.
     */
    protected int cantidadDeProyectiles() {
        return ROCAS_MINIMAS + azar.nextInt(ROCAS_MAXIMAS - ROCAS_MINIMAS + 1);
    }
}
