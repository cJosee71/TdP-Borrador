package logica.comportamientos;

import logica.entidades.AdministradorColisiones;
import logica.entidades.EntidadAnimada;

/**
 * Ataque que lastima solo al tocar a la otra entidad.
 */
public class AtaquePorContacto implements ComportamientoAtaque {

    // Atributos de instancia

    protected int danio;

    // Constructores

    /**
     * Crea el ataque con el daño que hace al tocar.
     */
    public AtaquePorContacto(int danio) {
        this.danio = danio;
    }

    // Comandos

    /**
     * No hace nada: este ataque no actúa en cada vuelta.
     */
    @Override
    public void atacar(EntidadAnimada atacante, AdministradorColisiones c) { }

    /**
     * Le aplica el daño a la entidad tocada.
     */
    @Override
    public void ataqueAlContactar(EntidadAnimada atacante, EntidadAnimada tocado) {
        tocado.recibirDanio(danio, atacante.getDireccion());
    }
}
