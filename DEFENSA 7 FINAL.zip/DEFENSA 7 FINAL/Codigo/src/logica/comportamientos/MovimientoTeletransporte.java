package logica.comportamientos;

import logica.entidades.AdministradorColisiones;
import logica.entidades.EntidadAnimada;
import logica.util.Posicion;

/**
 * Movimiento que cada cierto intervalo ubica a la entidad en un lugar libre al azar.
 */
public class MovimientoTeletransporte implements ComportamientoMovimiento {

    // Atributos de instancia

    protected long intervalo;
    protected long ultimo;

    // Constructores

    /**
     * Crea el movimiento con el intervalo en milisegundos.
     */
    public MovimientoTeletransporte(long intervalo) {
        this.intervalo = intervalo;
    }

    // Comandos

    /**
     * Teletransporta a la entidad si pasó el intervalo.
     */
    public void mover(EntidadAnimada e, AdministradorColisiones c) {
        long ahora = System.currentTimeMillis();
        if (ahora - ultimo >= intervalo) {
            Posicion lugar = c.getSector().posicionLibreAlAzar(e.getAncho(), e.getAlto());
            e.ubicarCuerpoEn(lugar.getX(), lugar.getY());
            e.teletransportarse();
            ultimo = ahora;
        }
    }
}
