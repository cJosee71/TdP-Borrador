package logica.comportamientos;

import logica.entidades.AdministradorColisiones;
import logica.entidades.EntidadAnimada;
import logica.entidades.Proyectil;
import logica.entidades.enemigos.GeneradorProyectil;
import logica.util.Posicion;

/**
 * Ataque a distancia que dispara proyectiles cada cierto intervalo, si Link está enfrente y no hay obstáculos en el medio.
 */
public class AtaquePorProyectil implements ComportamientoAtaque {

    // Atributos de instancia

    protected GeneradorProyectil generadorProyectil;
    protected int cantidad;
    protected long intervalo;
    protected long ultimoAtaque;

    // Constructores

    /**
     * Crea el ataque con su generador, la cantidad de proyectiles y el intervalo en milisegundos.
     */
    public AtaquePorProyectil(GeneradorProyectil g, int cantidad, long intervalo) {
        this.generadorProyectil = g;
        this.cantidad = cantidad;
        this.intervalo = intervalo;
    }

    // Comandos

    /**
     * Dispara los proyectiles si puede atacar.
     */
    public void atacar(EntidadAnimada atacante, AdministradorColisiones c) {
        if (puedeAtacar(atacante)) {
            int total = cantidadDeProyectiles();
            for (int i = 0; i < total; i++) {
                Proyectil p = generadorProyectil.generarProyectil();
                ubicar(p, atacante, c);
                atacante.getJuego().agregarEntidad(p);
            }
            ultimoAtaque = System.currentTimeMillis();
            alTerminar(atacante);
        }
    }

    /**
     * Centra el cuerpo del proyectil en el del atacante.
     */
    protected void ubicar(Proyectil p, EntidadAnimada a, AdministradorColisiones c) {
        Posicion centro = a.getCentro();
        p.ubicarCuerpoEn(centro.getX() - p.getAncho() / 2, centro.getY() - p.getAlto() / 2);
    }

    /**
     * Gancho al terminar el disparo; vacío por defecto.
     */
    protected void alTerminar(EntidadAnimada atacante) {
    }

    /**
     * No hace nada: este ataque no lastima al tocar.
     */
    public void ataqueAlContactar(EntidadAnimada atacante, EntidadAnimada tocado) {
    }

    // Consultas

    /**
     * Indica si pasó el intervalo, Link está enfrente y no hay roca, agua ni vacío en el medio.
     */
    protected boolean puedeAtacar(EntidadAnimada a) {
        return pasoElIntervalo() && a.linkEstaEnfrente() && !a.hayObstaculoHastaJugador();
    }

    /**
     * Devuelve cuántos proyectiles dispara.
     */
    protected int cantidadDeProyectiles() {
        return cantidad;
    }

    /**
     * Indica si pasó el intervalo desde el último disparo.
     */
    protected boolean pasoElIntervalo() {
        return System.currentTimeMillis() - ultimoAtaque >= intervalo;
    }
}
