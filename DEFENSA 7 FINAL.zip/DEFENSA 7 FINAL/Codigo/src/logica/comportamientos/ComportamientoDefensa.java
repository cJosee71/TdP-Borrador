package logica.comportamientos;

import logica.entidades.EntidadAnimada;
import logica.util.Direccion;

/**
 * Estrategia de defensa de una entidad animada (patrón Strategy).
 */
public interface ComportamientoDefensa {

    // Comandos

    /**
     * Recibe un golpe y aplica el daño que pasa; devuelve true si la entidad recibió daño.
     */
    public boolean recibirDanio(EntidadAnimada e, int danio, Direccion origen);
}
