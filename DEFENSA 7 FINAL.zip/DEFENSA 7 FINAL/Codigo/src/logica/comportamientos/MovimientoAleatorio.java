package logica.comportamientos;

import java.util.Random;

import logica.entidades.AdministradorColisiones;
import logica.entidades.EntidadAnimada;
import logica.util.Direccion;

/**
 * Movimiento que cambia de dirección al azar cada cierto intervalo o al chocar.
 */
public class MovimientoAleatorio implements ComportamientoMovimiento {

    // Atributos de instancia

    private Random azar;
    protected int velocidad;
    protected long intervaloCambio;
    protected long ultimoCambio;

    // Constructores

    /**
     * Crea el movimiento con su velocidad y el intervalo de cambio en milisegundos.
     */
    public MovimientoAleatorio(int velocidad, long intervaloCambio) {
        this.azar = new Random();
        this.velocidad = velocidad;
        this.intervaloCambio = intervaloCambio;
    }

    // Comandos

    /**
     * Avanza y elige otra dirección si pasó el intervalo o si quedó bloqueado.
     */
    public void mover(EntidadAnimada e, AdministradorColisiones c) {
        long ahora = System.currentTimeMillis();
        if (ahora - ultimoCambio >= intervaloCambio) {
            e.setDireccion(Direccion.values()[azar.nextInt(4)]);
            ultimoCambio = ahora;
        }
        if (!c.mover(e, e.getDireccion(), velocidad)) {
            e.setDireccion(Direccion.values()[azar.nextInt(4)]);
        }
    }
}
