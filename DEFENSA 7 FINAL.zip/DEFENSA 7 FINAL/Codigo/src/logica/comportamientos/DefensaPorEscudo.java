package logica.comportamientos;

import logica.entidades.EntidadAnimada;
import logica.util.Direccion;

/**
 * Defensa con escudo: bloquea los golpes de frente o todos, según cómo se construya.
 */
public class DefensaPorEscudo implements ComportamientoDefensa {

    // Atributos de instancia

    protected boolean soloDeFrente;
    protected ComportamientoDefensa sinEscudo;

    // Constructores

    /**
     * Crea el escudo; si soloDeFrente es false, bloquea todos los golpes.
     */
    public DefensaPorEscudo(boolean soloDeFrente) {
        this.soloDeFrente = soloDeFrente;
        this.sinEscudo = new DefensaLimitada(DefensaLimitada.SIN_LIMITE, DefensaLimitada.SIEMPRE);
    }

    // Comandos

    /**
     * Bloquea el golpe si corresponde; si no, aplica el daño normal.
     */
    public boolean recibirDanio(EntidadAnimada e, int danio, Direccion origen) {
        boolean deFrente = origen == e.getDireccion().opuesta();
        if (!soloDeFrente || deFrente) {
            return false;
        }
        return sinEscudo.recibirDanio(e, danio, origen);
    }
}
