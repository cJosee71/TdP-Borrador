package logica.comportamientos;

import logica.entidades.AdministradorColisiones;
import logica.entidades.EntidadAnimada;

/**
 * Ataque cuerpo a cuerpo que golpea lo que está adelante del atacante.
 */
public class AtaqueEspada implements ComportamientoAtaque {

    // Atributos de instancia

    protected int danio;
    protected int alcance;

    // Constructores

    /**
     * Crea el ataque con su daño y su alcance en píxeles.
     */
    public AtaqueEspada(int danio, int alcance) {
        this.danio = danio;
        this.alcance = alcance;
    }

    // Comandos

    /**
     * Golpea si el atacante quiere atacar.
     */
    public void atacar(EntidadAnimada atacante, AdministradorColisiones c) {
        if (atacante.quiereAtacar()) {
            golpear(atacante, danio, alcance, c);
            atacante.ataqueRealizado();
        }
    }

    /**
     * Aplica el golpe en la zona de adelante del atacante.
     */
    protected void golpear(EntidadAnimada a, int danio, int alcance, AdministradorColisiones c) {
        c.golpearEn(a, alcance, danio);
    }

    /**
     * No hace nada: este ataque no lastima al tocar.
     */
    public void ataqueAlContactar(EntidadAnimada atacante, EntidadAnimada tocado) {
    }
}
