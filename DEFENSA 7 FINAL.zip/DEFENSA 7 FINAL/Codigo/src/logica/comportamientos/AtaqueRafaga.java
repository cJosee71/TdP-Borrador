package logica.comportamientos;

import logica.entidades.EntidadAnimada;
import logica.entidades.enemigos.GeneradorProyectil;

/**
 * Ataque que dispara sus proyectiles de a uno, separados por el intervalo, hasta completar la cantidad.
 */
public class AtaqueRafaga extends AtaquePorProyectil {

    // Atributos de instancia

    protected int lanzados;

    // Constructores

    /**
     * Crea la ráfaga con su generador, la cantidad de proyectiles y el tiempo entre uno y otro en milisegundos.
     */
    public AtaqueRafaga(GeneradorProyectil g, int cantidad, long intervalo) {
        super(g, cantidad, intervalo);
    }

    // Comandos

    /**
     * Empieza una ráfaga nueva: el primer proyectil sale en la próxima vuelta.
     */
    public void reiniciar() {
        lanzados = 0;
        ultimoAtaque = 0;
    }

    /**
     * Cuenta el proyectil que se acaba de lanzar.
     */
    protected void alTerminar(EntidadAnimada atacante) {
        lanzados++;
    }

    // Consultas

    /**
     * Indica si falta lanzar alguno y ya pasó el intervalo; no hace falta que Link esté alineado.
     */
    protected boolean puedeAtacar(EntidadAnimada a) {
        return lanzados < cantidad && pasoElIntervalo();
    }

    /**
     * Lanza de a un proyectil por vez.
     */
    protected int cantidadDeProyectiles() {
        return 1;
    }
}
