package logica.comportamientos;

import logica.entidades.AdministradorColisiones;
import logica.entidades.EntidadAnimada;

/**
 * Ataque con espada de Link: si se carga TIEMPO_CARGA milisegundos, multiplica daño y alcance por FACTOR_CARGA y golpea alrededor (giro).
 */
public class AtaqueRecargado extends AtaqueEspada {

    // Atributos de clase

    private static final int FACTOR_CARGA = 2;
    private static final long TIEMPO_CARGA = 3000;

    // Atributos de instancia

    private long inicioCarga = -1;

    // Constructores

    /**
     * Crea el ataque con su daño y su alcance normales.
     */
    public AtaqueRecargado(int danio, int alcance) {
        super(danio, alcance);
    }

    // Comandos

    /**
     * Empieza a cargar el ataque.
     */
    public void cargar() {
        inicioCarga = System.currentTimeMillis();
    }

    /**
     * Golpea al soltar la tecla: normal hacia adelante, o recargado con un giro hacia los cuatro lados.
     */
    public void atacar(EntidadAnimada atacante, AdministradorColisiones c) {
        if (atacante.soltoElAtaque()) {
            if (estaCargado())
                c.golpearAlrededor(atacante, alcance * FACTOR_CARGA, danio * FACTOR_CARGA);
            else
                golpear(atacante, danio, alcance, c);
            atacante.ataqueRealizado();
        }
    }

    // Consultas

    /**
     * Indica si el ataque lleva cargándose el tiempo necesario.
     * Después de golpear sigue respondiendo por el último golpe hasta la próxima carga,
     * así Link puede mostrar la imagen del golpe recargado.
     */
    public boolean estaCargado() {
        return inicioCarga >= 0 && System.currentTimeMillis() - inicioCarga >= TIEMPO_CARGA;
    }
}
