package logica;

import logica.juego.ModoJuego;
import logica.fabricas.FabricaSprites;
import logica.juego.Ranking;

/**
 * Operaciones que la vista le pide a la lógica del juego.
 */
public interface ControladorJuego {

    // Comandos

    /**
     * Arma y arranca una partida nueva.
     */
    public void iniciar(ModoJuego modo, FabricaSprites dominio);

    /**
     * Registra el puntaje de la partida con el nombre del jugador.
     */
    public void registrarNombre(String nombre);

    /**
     * Avisa que terminó la animación de cambio de sector.
     */
    public void transicionTerminada();

    // Consultas

    /**
     * Devuelve el ranking del modo indicado.
     */
    public Ranking getRanking(ModoJuego m);

    /**
     * Devuelve el control del jugador, o null si no hay partida.
     */
    public ControlJugador getControlJugador();
}
