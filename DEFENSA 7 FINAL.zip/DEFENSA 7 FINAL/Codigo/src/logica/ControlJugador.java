package logica;

import logica.util.Direccion;

/**
 * Acciones del jugador con el teclado; la vista las envía sin conocer a Link.
 */
public interface ControlJugador {

    // Comandos

    /**
     * Empieza a mover al jugador en una dirección.
     */
    public void mover(Direccion d);

    /**
     * Detiene el movimiento del jugador.
     */
    public void detenerMovimiento();

    /**
     * Empieza el ataque con el objeto equipado.
     */
    public void atacar();

    /**
     * Suelta el ataque: golpe normal o recargado.
     */
    public void soltarAtaque();

    /**
     * Levanta el escudo equipado.
     */
    public void usarEscudo();

    /**
     * Baja el escudo.
     */
    public void soltarEscudo();

    /**
     * Equipa el siguiente objeto del inventario.
     */
    public void cambiarObjeto();
}
