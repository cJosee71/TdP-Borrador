package logica.hilos;

import logica.entidades.AdministradorColisiones;
import logica.mapa.Sector;

/**
 * Hilo que actualiza cada PERIODO milisegundos las entidades del sector visible, menos a Link.
 */
public class HiloMundo extends HiloJuego {

    // Atributos de clase

    private static final long PERIODO = 30;

    // Atributos de instancia

    protected AdministradorColisiones colisiones;

    // Constructores

    /**
     * Crea el hilo del mundo sin arrancarlo.
     */
    public HiloMundo(AdministradorColisiones c) {
        super(PERIODO);
        colisiones = c;
    }

    // Comandos

    /**
     * Actualiza una vez las entidades del sector visible, si hay uno.
     */
    @Override
    protected void ciclo() {
        Sector sectorVisible = colisiones.getSector();
        if (sectorVisible != null)
            sectorVisible.actualizarEntidades(colisiones);
    }
}
