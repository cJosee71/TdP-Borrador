package logica.hilos;

import logica.entidades.AdministradorColisiones;
import logica.entidades.Link;

/**
 * Hilo que actualiza solo a Link cada PERIODO milisegundos.
 */
public class HiloJugador extends HiloJuego {

    // Atributos de clase

    private static final long PERIODO = 30;

    // Atributos de instancia

    protected Link jugador;
    protected AdministradorColisiones colisiones;

    // Constructores

    /**
     * Crea el hilo de Link sin arrancarlo.
     */
    public HiloJugador(Link l, AdministradorColisiones c) {
        super(PERIODO);
        jugador = l;
        colisiones = c;
    }

    // Comandos

    /**
     * Actualiza a Link una vez.
     */
    @Override
    protected void ciclo() {
        jugador.actualizarEstado(colisiones);
    }
}
