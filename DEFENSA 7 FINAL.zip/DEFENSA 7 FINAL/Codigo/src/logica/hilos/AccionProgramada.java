package logica.hilos;

/**
 * Acción que una entidad ejecuta cuando vence, sin crear un hilo nuevo.
 */
public class AccionProgramada {

    // Atributos de instancia

    protected long instante;
    protected Runnable accion;

    // Constructores

    /**
     * Crea la acción con el instante en que vence, en milisegundos.
     */
    public AccionProgramada(long instante, Runnable accion) {
        this.instante = instante;
        this.accion = accion;
    }

    // Comandos

    /**
     * Ejecuta la acción en el hilo que la llama.
     */
    public void ejecutar() {
        accion.run();
    }

    // Consultas

    /**
     * Indica si la acción ya venció.
     */
    public boolean estaVencida(long ahora) {
        boolean vencida = ahora >= instante;
        return vencida;
    }
}
