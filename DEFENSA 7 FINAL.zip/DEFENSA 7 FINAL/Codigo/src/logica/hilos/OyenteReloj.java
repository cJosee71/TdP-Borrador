package logica.hilos;

/**
 * Lo que el reloj necesita de quien lo usa: recibir un aviso por cada segundo.
 */
public interface OyenteReloj {

    // Comandos

    /**
     * Recibe los segundos transcurridos.
     */
    public void tic(int segundos);
}
