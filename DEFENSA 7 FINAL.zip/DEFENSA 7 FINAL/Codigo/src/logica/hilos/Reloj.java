package logica.hilos;

/**
 * Hilo que cuenta los segundos de la partida y le avisa a su oyente.
 */
public class Reloj extends HiloJuego {

    // Atributos de clase

    private static final long PERIODO = 1000;

    // Atributos de instancia

    protected volatile int segundos;
    protected OyenteReloj oyente;

    // Constructores

    /**
     * Crea el reloj en 0 segundos sin arrancarlo.
     */
    public Reloj(OyenteReloj o) {
        super(PERIODO);
        oyente = o;
        segundos = 0;
    }

    // Comandos

    /**
     * Vuelve la cuenta a 0.
     */
    public void reiniciar() {
        segundos = 0;
    }

    /**
     * Suma un segundo y avisa al oyente.
     */
    @Override
    protected void ciclo() {
        segundos++;
        oyente.tic(segundos);
    }

    // Consultas

    /**
     * Devuelve los segundos transcurridos.
     */
    public int getSegundos() {
        return segundos;
    }
}
