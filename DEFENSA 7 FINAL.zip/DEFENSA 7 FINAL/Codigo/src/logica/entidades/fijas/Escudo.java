package logica.entidades.fijas;

import logica.entidades.Link;
import logica.fabricas.Sprite;

/**
 * Objeto que protege a Link mientras lo usa.
 */
public class Escudo extends Objeto {

    // Constructores

    /**
     * Crea el escudo en (x, y).
     */
    public Escudo(Sprite sprite, int x, int y) {
        super(sprite, x, y);
    }

    // Comandos

    /**
     * Levanta el escudo de Link.
     */
    public void protegerCon(Link l) {
        l.activarEscudo();
    }

    /**
     * Baja el escudo de Link.
     */
    public void soltarProteccionCon(Link l) {
        l.desactivarEscudo();
    }

    // Consultas

    /**
     * Devuelve "Escudo".
     */
    public String getNombre() {
        return "Escudo";
    }
}
