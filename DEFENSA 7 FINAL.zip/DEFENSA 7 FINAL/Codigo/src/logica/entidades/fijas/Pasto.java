package logica.entidades.fijas;

import logica.entidades.EntidadAnimada;
import logica.entidades.Link;
import logica.fabricas.Sprite;

/**
 * Obstáculo que ralentiza a Link y se corta con la espada.
 */
public class Pasto extends Obstaculo {

    // Constructores

    /**
     * Crea el pasto en (x, y).
     */
    public Pasto(Sprite sprite, int x, int y) {
        super(sprite, x, y);
    }

    // Comandos

    /**
     * Ralentiza a Link.
     */
    public void afectar(Link l) {
        l.ralentizar();
    }

    /**
     * Se corta con el golpe.
     */
    public void recibirGolpeDeEspada(EntidadAnimada atacante, int danio) {
        eliminar();
    }
}
