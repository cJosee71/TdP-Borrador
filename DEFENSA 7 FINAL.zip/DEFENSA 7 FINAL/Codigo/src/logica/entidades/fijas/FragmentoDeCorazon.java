package logica.entidades.fijas;

import logica.entidades.Link;
import logica.fabricas.Sprite;

/**
 * Power-up que suma un fragmento; cada FRAGMENTOS_POR_CORAZON (de Link) aumenta la vida máxima.
 */
public class FragmentoDeCorazon extends PowerUP {

    // Atributos de clase

    private static final int CUERPO_MARGEN_X = 1;
    private static final int CUERPO_MARGEN_Y = 3;
    private static final int CUERPO_ANCHO = 45;
    private static final int CUERPO_ALTO = 42;

    // Constructores

    /**
     * Crea el fragmento en (x, y) con el cuerpo de su dibujo.
     */
    public FragmentoDeCorazon(Sprite sprite, int x, int y) {
        super(sprite, x, y);
        setCuerpo(CUERPO_MARGEN_X, CUERPO_MARGEN_Y, CUERPO_ANCHO, CUERPO_ALTO);
    }

    // Comandos

    /**
     * Le suma a Link un fragmento.
     */
    public void serRecogidoPor(Link l) {
        l.sumarFragmento();
        super.serRecogidoPor(l);
    }
}
