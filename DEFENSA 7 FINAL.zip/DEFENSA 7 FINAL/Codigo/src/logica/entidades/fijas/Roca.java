package logica.entidades.fijas;

import logica.entidades.EntidadAnimada;
import logica.entidades.Link;
import logica.fabricas.Sprite;

/**
 * Obstáculo que no se puede atravesar.
 */
public class Roca extends Obstaculo {

    // Atributos de clase

    private static final int CUERPO_MARGEN_X = 4;
    private static final int CUERPO_MARGEN_Y = 4;
    private static final int CUERPO_ANCHO = 42;
    private static final int CUERPO_ALTO = 42;

    // Constructores

    /**
     * Crea la roca en (x, y).
     */
    public Roca(Sprite sprite, int x, int y) {
        super(sprite, x, y);
        setCuerpo(CUERPO_MARGEN_X, CUERPO_MARGEN_Y, CUERPO_ANCHO, CUERPO_ALTO);
    }

    // Comandos

    /**
     * No le hace nada a Link.
     */
    public void afectar(Link l) {
    }

    // Consultas

    /**
     * Se dibuja en la capa de los obstáculos altos.
     */
    public int getCapa() {
        return CAPA_OBSTACULOS;
    }

    /**
     * Le bloquea el paso a cualquiera.
     */
    public boolean bloqueaPasoA(EntidadAnimada quien) {
        return true;
    }

    /**
     * Impide que un enemigo se abalance o dispare a través de ella.
     */
    public boolean impideAbalanzarse() {
        return true;
    }
}
