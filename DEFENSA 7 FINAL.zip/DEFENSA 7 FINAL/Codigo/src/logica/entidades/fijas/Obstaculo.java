package logica.entidades.fijas;

import logica.entidades.Colisionador;
import logica.entidades.Entidad;
import logica.entidades.Link;
import logica.fabricas.Sprite;

/**
 * Elemento fijo del mapa que afecta a Link al tocarlo.
 */
public abstract class Obstaculo extends Entidad {

    // Constructores

    /**
     * Crea el obstáculo en (x, y).
     */
    protected Obstaculo(Sprite sprite, int x, int y) {
        super(sprite, x, y);
    }

    // Comandos

    /**
     * Recibe un choque (patrón Visitor).
     */
    public void aceptarColision(Colisionador c) {
        c.colisionarCon(this);
    }

    /**
     * Le aplica su efecto a Link; no hace nada por defecto.
     */
    public void afectar(Link l) {
    }

    // Consultas

    /**
     * Se dibuja en la capa del suelo.
     */
    public int getCapa() {
        return CAPA_SUELO;
    }
}
