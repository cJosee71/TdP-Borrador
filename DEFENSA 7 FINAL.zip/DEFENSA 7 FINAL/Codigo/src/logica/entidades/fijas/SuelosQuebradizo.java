package logica.entidades.fijas;

import logica.entidades.Link;
import logica.fabricas.Sprite;

/**
 * Suelo que se rompe poco después de que Link lo pisa.
 */
public class SuelosQuebradizo extends Obstaculo {

    // Atributos de instancia

    protected boolean pisado;

    // Constructores

    /**
     * Crea el suelo en (x, y).
     */
    public SuelosQuebradizo(Sprite sprite, int x, int y) {
        super(sprite, x, y);
    }

    // Comandos

    /**
     * La primera vez que Link lo pisa, empieza a romperse.
     */
    public void afectar(Link l) {
        if (!pisado) {
            pisado = true;
            l.romperSuelo(this);
        }
    }

    // Consultas

    /**
     * Indica si ya fue pisado.
     */
    public boolean estaPisado() {
        return pisado;
    }
}
