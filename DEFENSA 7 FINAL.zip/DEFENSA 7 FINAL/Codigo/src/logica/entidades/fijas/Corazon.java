package logica.entidades.fijas;

import logica.entidades.Link;
import logica.fabricas.Sprite;

/**
 * Power-up que cura a Link.
 */
public class Corazon extends PowerUP {

    // Atributos de clase

    private static final int MEDIOS_CURADOS = 2;
    private static final int CUERPO_MARGEN_X = 3;
    private static final int CUERPO_MARGEN_Y = 6;
    private static final int CUERPO_ANCHO = 42;
    private static final int CUERPO_ALTO = 36;

    // Constructores

    /**
     * Crea el corazón en (x, y) con el cuerpo de su dibujo.
     */
    public Corazon(Sprite sprite, int x, int y) {
        super(sprite, x, y);
        setCuerpo(CUERPO_MARGEN_X, CUERPO_MARGEN_Y, CUERPO_ANCHO, CUERPO_ALTO);
    }

    // Comandos

    /**
     * Cura a Link.
     */
    public void serRecogidoPor(Link l) {
        l.curar(MEDIOS_CURADOS);
        super.serRecogidoPor(l);
    }
}
