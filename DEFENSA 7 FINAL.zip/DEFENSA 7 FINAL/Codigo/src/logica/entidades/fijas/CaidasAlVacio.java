package logica.entidades.fijas;

import logica.entidades.EntidadAnimada;
import logica.entidades.Link;
import logica.fabricas.Sprite;

/**
 * Obstáculo que hace caer a Link y perder una vida.
 */
public class CaidasAlVacio extends Obstaculo {

    // Atributos de clase

    private static final int CUERPO_MARGEN_X = 8;
    private static final int CUERPO_MARGEN_Y = 8;
    private static final int CUERPO_ANCHO = 32;
    private static final int CUERPO_ALTO = 32;

    // Constructores

    /**
     * Crea la caída en (x, y).
     */
    public CaidasAlVacio(Sprite sprite, int x, int y) {
        super(sprite, x, y);
        setCuerpo(CUERPO_MARGEN_X, CUERPO_MARGEN_Y, CUERPO_ANCHO, CUERPO_ALTO);
    }

    // Comandos

    /**
     * Hace caer a Link cuando el centro de su cuerpo está sobre el pozo; si solo pisa el borde, no cae.
     */
    public void afectar(Link l) {
        if (getHitbox().contiene(l.getCentro()))
            l.caerAlVacio();
    }

    // Consultas

    /**
     * Le bloquea el paso solo a quien esquiva los vacíos (los enemigos); Link la pisa y cae.
     */
    public boolean bloqueaPasoA(EntidadAnimada quien) {
        return quien.esquivaVacios();
    }

    /**
     * Impide que un enemigo se abalance o dispare a través de ella.
     */
    public boolean impideAbalanzarse() {
        return true;
    }
}
