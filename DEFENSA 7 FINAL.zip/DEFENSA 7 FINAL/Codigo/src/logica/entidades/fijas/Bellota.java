package logica.entidades.fijas;

import logica.comportamientos.DefensaLimitada;
import logica.entidades.Link;
import logica.fabricas.Sprite;

/**
 * Power-up que limita el daño de los próximos golpes.
 */
public class Bellota extends PowerUP {

    // Atributos de clase

    private static final int DANIO_MAXIMO = 1;
    private static final int GOLPES_PROTEGIDOS = 3;
    private static final int CUERPO_MARGEN_X = 12;
    private static final int CUERPO_MARGEN_Y = 1;
    private static final int CUERPO_ANCHO = 24;
    private static final int CUERPO_ALTO = 45;

    // Constructores

    /**
     * Crea la bellota en (x, y) con el cuerpo de su dibujo.
     */
    public Bellota(Sprite sprite, int x, int y) {
        super(sprite, x, y);
        setCuerpo(CUERPO_MARGEN_X, CUERPO_MARGEN_Y, CUERPO_ANCHO, CUERPO_ALTO);
    }

    // Comandos

    /**
     * Le da a Link la defensa de la bellota.
     */
    public void serRecogidoPor(Link l) {
        l.setDefensaBase(new DefensaLimitada(DANIO_MAXIMO, GOLPES_PROTEGIDOS));
        super.serRecogidoPor(l);
    }
}
