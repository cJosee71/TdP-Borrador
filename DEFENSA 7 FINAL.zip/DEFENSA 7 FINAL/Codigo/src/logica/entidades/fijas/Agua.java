package logica.entidades.fijas;

import logica.entidades.EntidadAnimada;
import logica.entidades.Link;
import logica.fabricas.Sprite;

/**
 * Obstáculo que no se puede atravesar.
 */
public class Agua extends Obstaculo {

    // Constructores

    /**
     * Crea el agua en (x, y).
     */
    public Agua(Sprite sprite, int x, int y) {
        super(sprite, x, y);
    }

    // Comandos

    /**
     * No le hace nada a Link.
     */
    public void afectar(Link l) {
    }

    // Consultas

    /**
     * Le bloquea el paso a cualquiera.
     */
    public boolean bloqueaPasoA(EntidadAnimada quien) {
        return true;
    }

    /**
     * Impide que un enemigo se abalance o dispare a través de ella.
     */
    public boolean impideAbalanzarse() {
        return true;
    }
}
