package logica.entidades;

import java.util.ArrayList;
import java.util.List;

import logica.ControlJugador;
import logica.EntidadJugador;
import logica.comportamientos.AtaqueRecargado;
import logica.comportamientos.ComportamientoDefensa;
import logica.comportamientos.DefensaLimitada;
import logica.comportamientos.DefensaPorEscudo;
import logica.comportamientos.MovimientoInducido;
import logica.entidades.enemigos.Enemigo;
import logica.entidades.fijas.Objeto;
import logica.entidades.fijas.Obstaculo;
import logica.entidades.fijas.PowerUP;
import logica.entidades.fijas.SuelosQuebradizo;
import logica.fabricas.Sprite;
import logica.mapa.Sector;
import logica.util.Direccion;
import logica.util.Hitbox;
import logica.util.Posicion;

/**
 * Personaje del jugador: recibe las teclas, guarda el estado de la partida y reacciona a lo que toca.
 */
public class Link extends EntidadAnimada implements EntidadJugador, ControlJugador {

    // Atributos de clase

    private static final int VIDAS_INICIALES = 3;
    private static final int MEDIOS_CORAZONES_INICIALES = 6;
    private static final int VELOCIDAD_CAMINANDO = 4;
    private static final int FACTOR_RALENTIZACION = 2;
    private static final int DANIO_ESPADA = 1;
    private static final int ALCANCE_ESPADA = 32;
    private static final long DURACION_INVULNERABILIDAD = 1000;
    private static final long DEMORA_ROTURA_SUELO = 800;
    private static final int FRAGMENTOS_POR_CORAZON = 4;
    private static final int AUMENTO_VIDA_MAXIMA = 2;
    private static final int CUERPO_MARGEN_X = 6;
    private static final int CUERPO_MARGEN_Y = 2;
    private static final int CUERPO_ANCHO = 36;
    private static final int CUERPO_ALTO = 44;
    private static final int VUELTAS_IMAGEN_GOLPE = 8;
    private static final int VUELTAS_IMAGEN_GIRO = 16;
    private static final Direccion[] ORDEN_GIRO = { Direccion.ABAJO, Direccion.IZQUIERDA, Direccion.ARRIBA, Direccion.DERECHA };
    private static final int LARGO_IMAGEN_ESPADA = 48;
    private static final int MARGEN_X_GOLPE = 54;
    private static final int MARGEN_Y_GOLPE = 51;
    private static final long DURACION_CAIDA = 400;
    private static final long DURACION_MUERTE = 2100;
    private static final long DURACION_PERDER_VIDA = 1300;

    // Atributos de instancia

    protected int vidas;
    protected int corazonesMaximos;
    protected int puntaje;
    protected int rupias;
    protected int fragmentos;
    protected int racha;
    protected List<Objeto> inventario;
    protected Objeto objetoEquipado;
    protected MovimientoInducido caminar;
    protected AtaqueRecargado recargado;
    protected ComportamientoDefensa defensaBase;
    protected volatile boolean escudoActivo;
    protected volatile boolean atacando;
    protected int vueltasMostrandoGolpe;
    protected volatile boolean soltoAtaque;
    protected boolean ralentizado;
    protected volatile boolean cayendo;
    protected volatile boolean muriendo;

    // Constructores

    /**
     * Crea a Link con sus vidas y corazones iniciales, sin objetos y quieto.
     */
    public Link(Sprite sprite, int x, int y) {
        super(sprite, x, y, MEDIOS_CORAZONES_INICIALES);
        setCuerpo(CUERPO_MARGEN_X, CUERPO_MARGEN_Y, CUERPO_ANCHO, CUERPO_ALTO);
        vidas = VIDAS_INICIALES;
        corazonesMaximos = vida;
        inventario = new ArrayList<>();
        caminar = new MovimientoInducido((Direccion) null, VELOCIDAD_CAMINANDO);
        recargado = new AtaqueRecargado(DANIO_ESPADA, ALCANCE_ESPADA);
        defensaBase = new DefensaLimitada(DefensaLimitada.SIN_LIMITE, DefensaLimitada.SIEMPRE);
        movimiento = caminar;
        ataque = recargado;
        defensa = defensaBase;
    }

    // Comandos

    /**
     * Empieza a caminar en una dirección.
     */
    @Override
    public void mover(Direccion d) {
        caminar.setDireccion(d);
        setDireccion(d);
    }

    /**
     * Deja de caminar y avisa a la vista para que muestre la imagen quieta.
     */
    @Override
    public void detenerMovimiento() {
        caminar.setDireccion(null);
        notificarObservers();
    }

    /**
     * Ataca con el objeto equipado, salvo mientras cae al vacío o muere.
     */
    @Override
    public void atacar() {
        if (objetoEquipado != null && !cayendo && !muriendo)
            objetoEquipado.atacarCon(this);
    }

    /**
     * Suelta el ataque del objeto equipado.
     */
    @Override
    public void soltarAtaque() {
        if (objetoEquipado != null)
            objetoEquipado.soltarAtaqueCon(this);
    }

    /**
     * Se protege con el objeto equipado, salvo mientras cae al vacío o muere.
     */
    @Override
    public void usarEscudo() {
        if (objetoEquipado != null && !cayendo && !muriendo)
            objetoEquipado.protegerCon(this);
    }

    /**
     * Suelta la protección del objeto equipado.
     */
    @Override
    public void soltarEscudo() {
        if (objetoEquipado != null)
            objetoEquipado.soltarProteccionCon(this);
    }

    /**
     * Equipa el siguiente objeto si no está atacando; si tenía el escudo levantado, lo baja.
     */
    @Override
    public void cambiarObjeto() {
        if (!inventario.isEmpty() && !atacando) {
            if (escudoActivo)
                desactivarEscudo();
            int indiceSiguiente = (inventario.indexOf(objetoEquipado) + 1) % inventario.size();
            objetoEquipado = inventario.get(indiceSiguiente);
            notificarObservers();
        }
    }

    /**
     * Empieza a cargar el ataque de la espada.
     */
    public void cargarAtaque() {
        if (!atacando) {
            atacando = true;
            soltoAtaque = false;
            recargado.cargar();
            notificarObservers();
        }
    }

    /**
     * Marca que soltó la tecla de ataque.
     */
    public void liberarAtaque() {
        soltoAtaque = true;
    }

    /**
     * Termina el ataque y deja la imagen del golpe; si fue recargado, la del giro.
     */
    @Override
    public void ataqueRealizado() {
        atacando = false;
        soltoAtaque = false;
        vueltasMostrandoGolpe = recargado.estaCargado() ? VUELTAS_IMAGEN_GIRO : VUELTAS_IMAGEN_GOLPE;
        notificarObservers();
    }

    /**
     * Hace una vuelta: si la espada ya está cargada avisa para mostrarla, durante el giro recargado avisa en cada vuelta y, al terminar de mostrar el golpe, vuelve a la imagen de caminar.
     */
    @Override
    public void actualizarEstado(AdministradorColisiones c) {
        super.actualizarEstado(c);
        if (atacando && recargado.estaCargado())
            notificarObservers();
        if (vueltasMostrandoGolpe > 0) {
            vueltasMostrandoGolpe--;
            if (vueltasMostrandoGolpe == 0 || girando())
                notificarObservers();
        }
    }

    /**
     * Levanta el escudo.
     */
    public void activarEscudo() {
        escudoActivo = true;
        setDefensa(new DefensaPorEscudo(false));
        notificarObservers();
    }

    /**
     * Baja el escudo y vuelve a la defensa base.
     */
    public void desactivarEscudo() {
        escudoActivo = false;
        setDefensa(defensaBase);
        notificarObservers();
    }

    /**
     * Cambia la defensa base y la aplica si no usa el escudo.
     */
    public void setDefensaBase(ComportamientoDefensa d) {
        defensaBase = d;
        if (!escudoActivo)
            setDefensa(d);
    }

    /**
     * Vuelve a la defensa base si no usa el escudo ni está cayendo al vacío o muriendo.
     */
    @Override
    public void restaurarDefensa() {
        if (!escudoActivo && !cayendo && !muriendo)
            setDefensa(defensaBase);
    }

    /**
     * Avanza; si está ralentizado, menos pasos.
     */
    @Override
    public void avanzar(Direccion d, int pasos) {
        int pasosReales = ralentizado ? pasos / FACTOR_RALENTIZACION : pasos;
        ralentizado = false;
        super.avanzar(d, pasosReales);
    }

    /**
     * Hace que el próximo paso avance la mitad.
     */
    public void ralentizar() {
        ralentizado = true;
    }

    /**
     * Pide pasar al sector vecino.
     */
    @Override
    protected void alSalirDelSector(Direccion d) {
        miJuego.cambiarDeSector(d);
    }

    /**
     * No hace nada: a Link lo actualiza solo su propio hilo.
     */
    @Override
    public void actualizarPorMundo(AdministradorColisiones c) { }

    /**
     * Ubica el cuerpo en el borde opuesto al que salió.
     */
    public void entrarPorBordeOpuesto(Direccion d) {
        Hitbox cuerpo = getHitbox();
        switch (d) {
            case DERECHA:
                ubicarCuerpoEn(0, cuerpo.getY());
                break;
            case IZQUIERDA:
                ubicarCuerpoEn(Sector.ANCHO - getAncho(), cuerpo.getY());
                break;
            case ABAJO:
                ubicarCuerpoEn(cuerpo.getX(), 0);
                break;
            default:
                ubicarCuerpoEn(cuerpo.getX(), Sector.ALTO - getAlto());
                break;
        }
    }

    /**
     * Recibe un choque (patrón Visitor).
     */
    @Override
    public void aceptarColision(Colisionador c) {
        c.colisionarCon(this);
    }

    /**
     * Le pide al enemigo que resuelva el choque (sirve cuando Link es el que se frena contra él).
     */
    @Override
    public void colisionarCon(Enemigo e) {
        e.colisionarCon(this);
    }

    /**
     * Recibe el daño del proyectil y lo elimina.
     */
    @Override
    public void colisionarCon(Proyectil p) {
        recibirDanio(p.getDanio(), p.getDireccion());
        p.eliminar();
    }

    /**
     * Recibe el efecto del obstáculo.
     */
    @Override
    public void colisionarCon(Obstaculo o) {
        o.afectar(this);
    }

    /**
     * Recoge el power-up.
     */
    @Override
    public void colisionarCon(PowerUP p) {
        p.serRecogidoPor(this);
    }

    /**
     * Recoge el objeto.
     */
    @Override
    public void colisionarCon(Objeto o) {
        o.serRecogidoPor(this);
    }

    /**
     * Recibe el daño de un golpe de espada.
     */
    @Override
    public void recibirGolpeDeEspada(EntidadAnimada atacante, int danio) {
        recibirDanio(danio, atacante.getDireccion());
    }

    /**
     * Recibe un golpe; si le hace daño, corta la racha y avisa al juego.
     */
    @Override
    public synchronized void recibirDanio(int danio, Direccion origen) {
        boolean recibioDanio = defensa.recibirDanio(this, danio, origen);
        if (recibioDanio) {
            reiniciarRacha();
            miJuego.jugadorDaniado();
            alSerGolpeado();
        }
    }

    /**
     * Queda invulnerable un tiempo y parpadea mientras tanto, salvo si está muriendo.
     */
    @Override
    protected void alSerGolpeado() {
        if (!muriendo) {
            setDefensa(new DefensaLimitada(0, DefensaLimitada.SIEMPRE));
            parpadearDurante(DURACION_INVULNERABILIDAD);
            programar(DURACION_INVULNERABILIDAD, this::restaurarDefensa);
        }
    }

    /**
     * Se queda quieto e invulnerable mostrando la animación (cae para atrás si le quedan vidas, o la muerte si es la última) y, al terminar, pierde la vida.
     */
    @Override
    protected void morir() {
        if (!muriendo) {
            muriendo = true;
            setMovimiento(new MovimientoInducido((Direccion) null, 0));
            setDefensa(new DefensaLimitada(0, DefensaLimitada.SIEMPRE));
            notificarObservers();
            programar(vidas > 1 ? DURACION_PERDER_VIDA : DURACION_MUERTE, this::terminarMuerte);
        }
    }

    /**
     * Termina la muerte: pierde una vida y, si le quedan, recupera los corazones y queda invulnerable un momento; si no, avisa al juego.
     */
    private void terminarMuerte() {
        muriendo = false;
        setMovimiento(caminar);
        caminar.setDireccion(null);
        vidas--;
        if (vidas <= 0) {
            notificarObservers();
            miJuego.jugadorSinVidas();
        } else {
            vida = corazonesMaximos;
            alSerGolpeado();
            notificarObservers();
        }
    }

    /**
     * Cae al vacío: queda quieto e invulnerable mostrando la caída y, al terminar, pierde la vida.
     */
    public void caerAlVacio() {
        if (!cayendo) {
            cayendo = true;
            setMovimiento(new MovimientoInducido((Direccion) null, 0));
            setDefensa(new DefensaLimitada(0, DefensaLimitada.SIEMPRE));
            notificarObservers();
            programar(DURACION_CAIDA, this::terminarCaida);
        }
    }

    /**
     * Termina la caída: pierde una vida y avisa al juego.
     */
    private void terminarCaida() {
        cayendo = false;
        setMovimiento(caminar);
        caminar.setDireccion(null);
        setDefensa(defensaBase);
        vidas--;
        reiniciarRacha();
        if (vidas <= 0) {
            notificarObservers();
            miJuego.jugadorSinVidas();
        } else {
            vida = corazonesMaximos;
            miJuego.jugadorCayoAlVacio();
        }
    }

    /**
     * Rompe el suelo quebradizo tras una demora y deja una caída al vacío.
     */
    public void romperSuelo(SuelosQuebradizo s) {
        programar(DEMORA_ROTURA_SUELO, () -> {
            Sector sectorDelSuelo = s.getSector();
            Entidad caida = miJuego.getFabricaEntidades().crearCaidasAlVacio(s.getX(), s.getY());
            s.eliminar();
            if (sectorDelSuelo == getSector())
                miJuego.agregarEntidad(caida);
            else
                sectorDelSuelo.agregar(caida);
        });
    }

    /**
     * Agrega un objeto al inventario y lo equipa.
     */
    public void agregarAlInventario(Objeto o) {
        inventario.add(o);
        objetoEquipado = o;
        notificarObservers();
    }

    /**
     * Suma puntos.
     */
    public void sumarPuntos(int p) {
        puntaje += p;
        notificarObservers();
    }

    /**
     * Vuelve el puntaje a 0.
     */
    public void reiniciarPuntaje() {
        puntaje = 0;
    }

    /**
     * Suma rupias.
     */
    public void sumarRupias(int n) {
        rupias += n;
        notificarObservers();
    }

    /**
     * Recupera vida sin pasarse del máximo.
     */
    public void curar(int medios) {
        vida = Math.min(vida + medios, corazonesMaximos);
        notificarObservers();
    }

    /**
     * Suma un fragmento; al juntar los necesarios suma un corazón máximo.
     */
    public void sumarFragmento() {
        fragmentos++;
        if (fragmentos % FRAGMENTOS_POR_CORAZON == 0) {
            corazonesMaximos += AUMENTO_VIDA_MAXIMA;
            vida = corazonesMaximos;
        }
        notificarObservers();
    }

    /**
     * Suma uno a la racha sin recibir daño.
     */
    public void incrementarRacha() {
        racha++;
    }

    /**
     * Vuelve la racha a 0.
     */
    public void reiniciarRacha() {
        racha = 0;
    }

    /**
     * Vuelve a las vidas iniciales con los corazones llenos.
     */
    public void reiniciarVidas() {
        vidas = VIDAS_INICIALES;
        vida = corazonesMaximos;
    }

    /**
     * Avisa al juego que recogió un power-up.
     */
    public void powerUpRecogido(PowerUP p) {
        miJuego.powerUpRecogido(p);
    }

    // Consultas

    /**
     * Les bloquea el paso a quienes frenan contra personajes.
     */
    @Override
    public boolean bloqueaPasoA(EntidadAnimada quien) {
        return quien.esFrenadoPorPersonajes();
    }

    /**
     * Lo frenan los enemigos.
     */
    @Override
    public boolean esFrenadoPorPersonajes() {
        return true;
    }

    /**
     * Devuelve la imagen según lo que hace: perdiendo una vida o muriendo, cayendo al vacío, escudo, ataque (normal o recargado), caminando (GIF) o quieto (PNG), mirando hacia su dirección.
     */
    @Override
    public String getRutaImagen() {
        String dir = direccionImagen().name().toLowerCase();
        String caminando = caminar.getDireccion() != null ? "caminar-" : "";
        String estado = caminando + dir;
        if (muriendo)
            estado = vidas > 1 ? "pierde-vida" : "muerte";
        else if (cayendo)
            estado = "caida";
        else if (escudoActivo)
            estado = caminando + "escudo-" + dir;
        else if (girando())
            estado = "ataque-recargado-" + dir;
        else if (mostrandoAtaque())
            estado = caminando + (recargado.estaCargado() ? (caminando.isEmpty() ? "ataque-recargado-" : "recargado-") : "ataque-") + dir;
        String ruta = sprite.getRuta(estado);
        return ruta != null ? ruta : super.getRutaImagen();
    }

    /**
     * Devuelve la x de la imagen: el GIF del golpe normal se corre MARGEN_X_GOLPE; con la imagen de ataque recargado hacia la izquierda se corre LARGO_IMAGEN_ESPADA.
     */
    @Override
    public int getXImagen() {
        int x = getX();
        if (mostrandoGolpeNormal())
            x -= MARGEN_X_GOLPE;
        else if (mostrandoAtaque() && direccionImagen() == Direccion.IZQUIERDA)
            x -= LARGO_IMAGEN_ESPADA;
        return x;
    }

    /**
     * Devuelve la y de la imagen: el GIF del golpe normal se corre MARGEN_Y_GOLPE; con la imagen de ataque recargado hacia arriba se corre LARGO_IMAGEN_ESPADA.
     */
    @Override
    public int getYImagen() {
        int y = getY();
        if (mostrandoGolpeNormal())
            y -= MARGEN_Y_GOLPE;
        else if (mostrandoAtaque() && direccionImagen() == Direccion.ARRIBA)
            y -= LARGO_IMAGEN_ESPADA;
        return y;
    }

    /**
     * Indica si está mostrando el giro del ataque recargado.
     */
    private boolean girando() {
        return !escudoActivo && !atacando && vueltasMostrandoGolpe > 0 && recargado.estaCargado();
    }

    /**
     * Devuelve hacia dónde mira la imagen: durante el giro recorre las cuatro direcciones y termina en la suya.
     */
    private Direccion direccionImagen() {
        if (!girando())
            return getDireccion();
        int paso = (VUELTAS_IMAGEN_GIRO - vueltasMostrandoGolpe) * ORDEN_GIRO.length / VUELTAS_IMAGEN_GIRO;
        int inicio = java.util.Arrays.asList(ORDEN_GIRO).indexOf(getDireccion()) + 1;
        return ORDEN_GIRO[(inicio + paso) % ORDEN_GIRO.length];
    }

    /**
     * Indica si muestra el GIF del golpe normal: atacando, quieto y sin la espada cargada.
     */
    private boolean mostrandoGolpeNormal() {
        return mostrandoAtaque() && !recargado.estaCargado() && caminar.getDireccion() == null;
    }

    /**
     * Indica si se está mostrando una imagen de ataque.
     */
    private boolean mostrandoAtaque() {
        return !escudoActivo && (atacando || vueltasMostrandoGolpe > 0);
    }

    /**
     * Se dibuja en la capa del jugador, arriba de todo.
     */
    @Override
    public int getCapa() {
        return CAPA_JUGADOR;
    }

    /**
     * Devuelve las vidas que le quedan.
     */
    @Override
    public int getVidas() {
        return vidas;
    }

    /**
     * Devuelve la vida actual en medios corazones.
     */
    @Override
    public int getCorazones() {
        return vida;
    }

    /**
     * Devuelve la vida máxima en medios corazones.
     */
    @Override
    public int getCorazonesMaximos() {
        return corazonesMaximos;
    }

    /**
     * Devuelve el puntaje.
     */
    @Override
    public int getPuntaje() {
        return puntaje;
    }

    /**
     * Devuelve las rupias.
     */
    @Override
    public int getRupias() {
        return rupias;
    }

    /**
     * Devuelve el nombre del objeto equipado, o "Ninguno".
     */
    @Override
    public String getNombreObjetoEquipado() {
        String nombreObjeto = "Ninguno";
        if (objetoEquipado != null)
            nombreObjeto = objetoEquipado.getNombre();
        return nombreObjeto;
    }

    /**
     * Devuelve la racha de enemigos derrotados sin recibir daño.
     */
    public int getRacha() {
        return racha;
    }

    /**
     * Devuelve el inventario.
     */
    public List<Objeto> getInventario() {
        return inventario;
    }

    /**
     * Indica si está cargando el ataque.
     */
    @Override
    public boolean quiereAtacar() {
        return atacando;
    }

    /**
     * Indica si soltó la tecla de ataque.
     */
    @Override
    public boolean soltoElAtaque() {
        return soltoAtaque;
    }

    /**
     * Indica si el escudo está activo.
     */
    public boolean tieneEscudoActivo() {
        return escudoActivo;
    }
}
