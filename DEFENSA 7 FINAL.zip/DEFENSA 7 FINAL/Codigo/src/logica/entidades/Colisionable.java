package logica.entidades;

/**
 * Entidad que acepta choques (patrón Visitor).
 */
public interface Colisionable {

    // Comandos

    /**
     * Recibe el choque y se lo devuelve al colisionador.
     */
    void aceptarColision(Colisionador c);
}
