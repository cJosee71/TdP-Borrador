package logica.entidades.enemigos;

import logica.comportamientos.DefensaPorEscudo;
import logica.comportamientos.MovimientoAleatorio;
import logica.comportamientos.MovimientoInducido;
import logica.fabricas.Sprite;
import logica.util.Direccion;

/**
 * Moblin con escudo de frente que se abalanza cuando ve a Link.
 */
public class MoblinConEspadaYEscudo extends Moblin {

    // Atributos de clase

    private static final int PUNTOS = 300;
    private static final double PROBABILIDAD_DROP = 0.5;
    private static final int VELOCIDAD_ABALANZADA = 3;
    private static final long DURACION_ABALANZADA = 1600;
    private static final long PREPARACION_ABALANZADA = 300;
    private static final long DURACION_CAMBIO_VELOCIDAD = 100;
    private static final long DURACION_FRENADO = 500;
    private static final int MARGEN_IMAGEN = 39;
    private static final int CUERPO_MARGEN_X = 43;
    private static final int CUERPO_MARGEN_Y = 43;
    private static final int CUERPO_ANCHO = 40;
    private static final int CUERPO_ALTO = 40;

    // Atributos de instancia

    protected boolean abalanzandose;

    // Constructores

    /**
     * Crea el Moblin en (x, y) con escudo de frente.
     * La imagen mide 126 × 126 con el cuerpo en el centro, así que se ubica MARGEN_IMAGEN
     * píxeles más arriba y a la izquierda para que el cuerpo quede en la celda (x, y).
     */
    public MoblinConEspadaYEscudo(Sprite sprite, int x, int y) {
        super(sprite, x - MARGEN_IMAGEN, y - MARGEN_IMAGEN);
        setCuerpo(CUERPO_MARGEN_X, CUERPO_MARGEN_Y, CUERPO_ANCHO, CUERPO_ALTO);
        setDefensa(new DefensaPorEscudo(true));
    }

    // Comandos

    /**
     * Si no está muriendo ni abalanzándose, Link está enfrente y no hay obstáculos en el medio, se abalanza:
     * se queda quieto un momento, sale acelerando hasta VELOCIDAD_ABALANZADA y, al terminar,
     * frena a su velocidad de caminar y sigue derecho un rato antes de volver a caminar al azar.
     */
    protected void vigilarJugador() {
        if (!muriendo && !abalanzandose && linkEstaEnfrente() && !hayObstaculoHastaJugador()) {
            abalanzandose = true;
            Direccion d = getDireccion();
            setMovimiento(new MovimientoInducido((Direccion) null, 0));
            for (int v = 1; v <= VELOCIDAD_ABALANZADA; v++) {
                int velocidad = v;
                programar(PREPARACION_ABALANZADA + (v - 1) * DURACION_CAMBIO_VELOCIDAD,
                        () -> setMovimiento(new MovimientoInducido(d, velocidad)));
            }
            programar(PREPARACION_ABALANZADA + DURACION_ABALANZADA,
                    () -> setMovimiento(new MovimientoInducido(d, VELOCIDAD)));
            programar(PREPARACION_ABALANZADA + DURACION_ABALANZADA + DURACION_FRENADO, this::terminarAbalanzada);
        }
    }

    /**
     * Vuelve a caminar al azar al terminar la abalanzada.
     */
    private void terminarAbalanzada() {
        abalanzandose = false;
        setMovimiento(new MovimientoAleatorio(VELOCIDAD, INTERVALO_CAMBIO_DIRECCION));
    }

    // Consultas

    /**
     * Devuelve los puntos que da al morir.
     */
    public int getPuntos() {
        return PUNTOS;
    }

    /**
     * Devuelve la probabilidad de soltar un power-up.
     */
    protected double getProbabilidadDrop() {
        return PROBABILIDAD_DROP;
    }
}
