package logica.entidades.enemigos;

import logica.comportamientos.AtaquePorContacto;
import logica.comportamientos.DefensaLimitada;
import logica.comportamientos.MovimientoAleatorio;
import logica.fabricas.Sprite;

/**
 * Enemigo que camina al azar y lastima al tocarlo.
 */
public class Moblin extends EnemigoConDrop {

    // Atributos de clase

    private static final int VIDA = 2;
    private static final int PUNTOS = 100;
    private static final double PROBABILIDAD_DROP = 0.2;
    private static final int DANIO_CONTACTO = 1;
    protected static final int VELOCIDAD = 2;
    protected static final long INTERVALO_CAMBIO_DIRECCION = 1500;
    private static final int CUERPO_MARGEN_X = 4;
    private static final int CUERPO_MARGEN_Y = 4;
    private static final int CUERPO_ANCHO = 40;
    private static final int CUERPO_ALTO = 40;

    // Constructores

    /**
     * Crea el Moblin en (x, y).
     */
    public Moblin(Sprite sprite, int x, int y) {
        super(sprite, x, y, VIDA);
        setCuerpo(CUERPO_MARGEN_X, CUERPO_MARGEN_Y, CUERPO_ANCHO, CUERPO_ALTO);
        setMovimiento(new MovimientoAleatorio(VELOCIDAD, INTERVALO_CAMBIO_DIRECCION));
        setAtaque(new AtaquePorContacto(DANIO_CONTACTO));
        setDefensa(new DefensaLimitada(DefensaLimitada.SIN_LIMITE, DefensaLimitada.SIEMPRE));
    }

    // Consultas

    /**
     * Devuelve los puntos que da al morir.
     */
    public int getPuntos() {
        return PUNTOS;
    }

    /**
     * Devuelve la probabilidad de soltar un power-up.
     */
    protected double getProbabilidadDrop() {
        return PROBABILIDAD_DROP;
    }
}
