package logica.entidades.enemigos;

import logica.entidades.AdministradorColisiones;
import logica.comportamientos.AtaqueEspada;
import logica.comportamientos.AtaquePorContacto;
import logica.comportamientos.ComportamientoAtaque;
import logica.comportamientos.DefensaLimitada;
import logica.comportamientos.MovimientoAleatorio;
import logica.fabricas.Sprite;
import logica.util.Direccion;
import logica.util.Hitbox;

/**
 * Jefe que alterna entre atacar con la espada y lastimar al tocarlo; al morir muestra su animación de muerte en la dirección en que mira.
 */
public class MasterStalfos extends Jefe {

    // Atributos de clase

    private static final int VIDA = 5;
    private static final int PUNTOS = 5000;
    private static final int VELOCIDAD = 3;
    private static final long INTERVALO_CAMBIO_DIRECCION = 1200;
    private static final int DANIO_ESPADA = 2;
    private static final int DANIO_CONTACTO = 1;
    private static final long DURACION_INVULNERABILIDAD = 800;
    private static final long DURACION_FASE = 2000;
    private static final int ALCANCE_ESPADA = 40;
    private static final int CUERPO_MARGEN_X = 13;
    private static final int CUERPO_MARGEN_Y = 12;
    private static final int CUERPO_ANCHO = 117;
    private static final int CUERPO_ALTO = 120;
    private static final int VUELTAS_IMAGEN_GOLPE = 25;
    private static final int MARGEN_IMAGEN_X = 12;
    private static final int MARGEN_IMAGEN_Y = 36;
    private static final long DURACION_MUERTE = 1530;

    // Atributos de instancia

    private ComportamientoAtaque espada;
    private ComportamientoAtaque contacto;
    private int vueltasMostrandoGolpe;
    private Direccion direccionGolpe;

    // Constructores

    /**
     * Crea el jefe en (x, y) con el cuerpo de su dibujo, empezando con la espada.
     */
    public MasterStalfos(Sprite sprite, int x, int y) {
        super(sprite, x, y, VIDA);
        setCuerpo(CUERPO_MARGEN_X, CUERPO_MARGEN_Y, CUERPO_ANCHO, CUERPO_ALTO);
        setMovimiento(new MovimientoAleatorio(VELOCIDAD, INTERVALO_CAMBIO_DIRECCION));
        setDefensa(new DefensaLimitada(DefensaLimitada.SIN_LIMITE, DefensaLimitada.SIEMPRE));
        espada = new AtaqueEspada(DANIO_ESPADA, ALCANCE_ESPADA);
        contacto = new AtaquePorContacto(DANIO_CONTACTO);
        faseEspada();
    }

    // Comandos

    /**
     * Ataca con la espada y programa la fase de contacto.
     */
    private void faseEspada() {
        setAtaque(espada);
        programar(DURACION_FASE, this::faseContacto);
    }

    /**
     * Lastima al tocar y programa la fase de espada.
     */
    private void faseContacto() {
        setAtaque(contacto);
        programar(DURACION_FASE, this::faseEspada);
    }

    /**
     * Queda invulnerable un tiempo y parpadea mientras tanto, salvo si está muriendo.
     */
    protected void alSerGolpeado() {
        if (!muriendo) {
            setDefensa(new DefensaLimitada(0, DefensaLimitada.SIEMPRE));
            parpadearDurante(DURACION_INVULNERABILIDAD);
            programar(DURACION_INVULNERABILIDAD, () -> setDefensa(new DefensaLimitada(DefensaLimitada.SIN_LIMITE, DefensaLimitada.SIEMPRE)));
        }
    }

    /**
     * Empieza a mostrar el GIF del golpe de espada hacia donde mira, si no lo estaba mostrando.
     */
    @Override
    public void ataqueRealizado() {
        if (vueltasMostrandoGolpe == 0) {
            vueltasMostrandoGolpe = VUELTAS_IMAGEN_GOLPE;
            direccionGolpe = getDireccion();
            notificarObservers();
        }
    }

    /**
     * Hace una vuelta y avisa a la vista cuando termina el golpe, para volver al GIF de caminar.
     */
    @Override
    public void actualizarEstado(AdministradorColisiones c) {
        super.actualizarEstado(c);
        if (vueltasMostrandoGolpe > 0) {
            vueltasMostrandoGolpe--;
            if (vueltasMostrandoGolpe == 0)
                notificarObservers();
        }
    }

    // Consultas

    /**
     * Devuelve el GIF de muerte, el del golpe en la dirección en que empezó, o el de caminar.
     */
    @Override
    public String getRutaImagen() {
        String ruta = null;
        if (muriendo)
            ruta = sprite.getRuta("muerte-" + getDireccion().name().toLowerCase());
        else if (vueltasMostrandoGolpe > 0)
            ruta = sprite.getRuta("ataque-" + direccionGolpe.name().toLowerCase());
        return ruta != null ? ruta : super.getRutaImagen();
    }

    /**
     * Devuelve la x de la imagen: los GIFs tienen MARGEN_IMAGEN_X de más a la izquierda para el arco de la espada.
     */
    @Override
    public int getXImagen() {
        return getX() - MARGEN_IMAGEN_X;
    }

    /**
     * Devuelve la y de la imagen: los GIFs tienen MARGEN_IMAGEN_Y de más arriba para la espada levantada.
     */
    @Override
    public int getYImagen() {
        return getY() - MARGEN_IMAGEN_Y;
    }

    /**
     * Indica si Link está en la zona de la espada.
     */
    public boolean quiereAtacar() {
        Hitbox zona = getHitbox().adelante(getDireccion(), ALCANCE_ESPADA);
        return zona.intersecta(miJuego.getJugador().getHitbox());
    }

    /**
     * Devuelve cuánto dura su animación de muerte: lo que dura su GIF.
     */
    @Override
    protected long getDuracionMuerte() {
        return DURACION_MUERTE;
    }

    /**
     * Devuelve los puntos que da al morir.
     */
    public int getPuntos() {
        return PUNTOS;
    }
}
