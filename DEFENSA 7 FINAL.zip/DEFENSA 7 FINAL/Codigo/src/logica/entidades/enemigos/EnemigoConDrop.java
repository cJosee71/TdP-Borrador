package logica.entidades.enemigos;

import logica.entidades.fijas.PowerUP;
import logica.fabricas.FabricaEntidades;
import logica.fabricas.Sprite;

/**
 * Enemigo que al morir puede soltar una rupia o un corazón (patrón Factory Method).
 */
public abstract class EnemigoConDrop extends Enemigo implements GeneradorDrop {

    // Atributos de clase

    private static final double PROBABILIDAD_RUPIA = 0.5;

    // Constructores

    /**
     * Crea el enemigo en (x, y) con su vida.
     */
    protected EnemigoConDrop(Sprite sprite, int x, int y, int vida) {
        super(sprite, x, y, vida);
    }

    // Comandos

    /**
     * Suelta un power-up según su probabilidad.
     */
    protected void soltarDrop() {
        if (Math.random() < getProbabilidadDrop()) {
            miJuego.agregarEntidad(generarDrop());
        }
    }

    /**
     * Al terminar la animación de muerte: se elimina y puede soltar un power-up, salvo que con su muerte aparezca la bellota (así no la tapa).
     */
    protected void desaparecer() {
        eliminar();
        if (!miJuego.enemigoDerrotado(this))
            soltarDrop();
    }

    // Consultas

    /**
     * Crea una rupia o un corazón, al azar, donde está su cuerpo.
     */
    public PowerUP generarDrop() {
        FabricaEntidades fabrica = miJuego.getFabricaEntidades();
        int x = getHitbox().getX();
        int y = getHitbox().getY();
        if (Math.random() < PROBABILIDAD_RUPIA) {
            return fabrica.crearRupia(x, y);
        }
        return fabrica.crearCorazon(x, y);
    }

    /**
     * Devuelve la probabilidad de soltar un power-up.
     */
    protected abstract double getProbabilidadDrop();
}
