package logica.entidades.enemigos;

import logica.comportamientos.AtaquePorProyectil;
import logica.comportamientos.DefensaLimitada;
import logica.comportamientos.MovimientoAleatorio;
import logica.entidades.Proyectil;
import logica.fabricas.Sprite;

/**
 * Enemigo que camina al azar y dispara cuando Link está enfrente sin obstáculos en el medio.
 */
public class Octorok extends EnemigoConDrop implements GeneradorProyectil {

    // Atributos de clase

    private static final int VIDA = 1;
    private static final int PUNTOS = 150;
    private static final double PROBABILIDAD_DROP = 0.4;
    private static final int VELOCIDAD = 2;
    private static final long INTERVALO_CAMBIO_DIRECCION = 1500;
    private static final int CANTIDAD_DISPAROS = 1;
    private static final int DANIO_DISPARO = 1;
    private static final long INTERVALO_DISPARO = 2000;
    private static final int CUERPO_MARGEN_X = 4;
    private static final int CUERPO_MARGEN_Y = 4;
    private static final int CUERPO_ANCHO = 40;
    private static final int CUERPO_ALTO = 40;

    // Constructores

    /**
     * Crea el Octorok en (x, y).
     */
    public Octorok(Sprite sprite, int x, int y) {
        super(sprite, x, y, VIDA);
        setCuerpo(CUERPO_MARGEN_X, CUERPO_MARGEN_Y, CUERPO_ANCHO, CUERPO_ALTO);
        setMovimiento(new MovimientoAleatorio(VELOCIDAD, INTERVALO_CAMBIO_DIRECCION));
        setAtaque(new AtaquePorProyectil(this, CANTIDAD_DISPAROS, INTERVALO_DISPARO));
        setDefensa(new DefensaLimitada(DefensaLimitada.SIN_LIMITE, DefensaLimitada.SIEMPRE));
    }

    // Consultas

    /**
     * Crea un disparo hacia donde mira.
     */
    public Proyectil generarProyectil() {
        return miJuego.getFabricaEntidades().crearProyectil(getX(), getY(), getDireccion(), DANIO_DISPARO);
    }

    /**
     * Devuelve los puntos que da al morir.
     */
    public int getPuntos() {
        return PUNTOS;
    }

    /**
     * Devuelve la probabilidad de soltar un power-up.
     */
    protected double getProbabilidadDrop() {
        return PROBABILIDAD_DROP;
    }
}
