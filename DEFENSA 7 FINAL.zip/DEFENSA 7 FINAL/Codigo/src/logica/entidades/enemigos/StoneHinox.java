package logica.entidades.enemigos;

import java.util.Random;

import logica.comportamientos.AtaqueAvalancha;
import logica.comportamientos.AtaquePorContacto;
import logica.comportamientos.AtaqueRafaga;
import logica.comportamientos.ComportamientoAtaque;
import logica.comportamientos.ComportamientoMovimiento;
import logica.comportamientos.DefensaLimitada;
import logica.comportamientos.MovimientoAleatorio;
import logica.comportamientos.MovimientoInducido;
import logica.entidades.Proyectil;
import logica.fabricas.Sprite;
import logica.util.Direccion;
import logica.util.Posicion;

/**
 * Jefe que elige al azar entre embestir, lanzar rocas o provocar una avalancha.
 */
public class StoneHinox extends Jefe implements GeneradorProyectil {

    // Atributos de clase

    private static final int VIDA = 10;
    private static final int PUNTOS = 5000;
    private static final int DANIO_EMBESTIDA = 2;
    private static final int DANIO_ROCA = 2;
    private static final int CANTIDAD_ROCAS = 3;
    private static final long INTERVALO_ROCAS = 400;
    private static final int VELOCIDAD = 2;
    private static final long INTERVALO_CAMBIO_DIRECCION = 1500;
    private static final long DEMORA_PRIMER_ATAQUE = 3000;
    private static final int VELOCIDAD_EMBESTIDA = 6;
    private static final long DURACION_EMBESTIDA = 1500;
    private static final long DURACION_VULNERABILIDAD = 1000;
    private static final long DURACION_LANZAMIENTO_ROCAS = 3000;
    private static final int VELOCIDAD_AVALANCHA = 3;
    private static final int CUERPO_MARGEN_X = 6;
    private static final int CUERPO_MARGEN_Y = 4;
    private static final int CUERPO_ANCHO = 84;
    private static final int CUERPO_ALTO = 88;
    private static final long DURACION_GOLPE_AVALANCHA = 600;

    // Atributos de instancia

    private ComportamientoAtaque embestida;
    private AtaqueRafaga lanzarRocas;
    private ComportamientoAtaque avalancha;
    private ComportamientoMovimiento caminar;
    private Random azar;
    private volatile boolean vulnerable;
    private volatile boolean golpeandoSuelo;
    private volatile boolean embistiendo;

    // Constructores

    /**
     * Crea el jefe en (x, y), invulnerable y lanzando rocas.
     */
    public StoneHinox(Sprite sprite, int x, int y) {
        super(sprite, x, y, VIDA);
        setCuerpo(CUERPO_MARGEN_X, CUERPO_MARGEN_Y, CUERPO_ANCHO, CUERPO_ALTO);
        azar = new Random();
        embestida = new AtaquePorContacto(DANIO_EMBESTIDA);
        lanzarRocas = new AtaqueRafaga(this, CANTIDAD_ROCAS, INTERVALO_ROCAS);
        avalancha = new AtaqueAvalancha(this);
        caminar = new MovimientoAleatorio(VELOCIDAD, INTERVALO_CAMBIO_DIRECCION);
        setMovimiento(caminar);
        setAtaque(lanzarRocas);
        setDefensa(new DefensaLimitada(0, DefensaLimitada.SIEMPRE));
        programar(DEMORA_PRIMER_ATAQUE, this::siguienteAtaque);
    }

    // Comandos

    /**
     * Termina la avalancha: se queda quieto golpeando el suelo un momento y pasa al siguiente ataque.
     */
    public void ataqueTerminado() {
        golpeandoSuelo = true;
        setMovimiento(new MovimientoInducido((Direccion) null, 0));
        setAtaque(new AtaquePorContacto(0));
        notificarObservers();
        programar(DURACION_GOLPE_AVALANCHA, () -> {
            golpeandoSuelo = false;
            notificarObservers();
            siguienteAtaque();
        });
    }

    /**
     * Termina la embestida: queda vulnerable un tiempo y pasa al siguiente ataque.
     */
    public void embestidaTerminada() {
        setMovimiento(caminar);
        setDefensa(new DefensaLimitada(DefensaLimitada.SIN_LIMITE, DefensaLimitada.SIEMPRE));
        embistiendo = false;
        vulnerable = true;
        notificarObservers();
        programar(DURACION_VULNERABILIDAD, () -> {
            setDefensa(new DefensaLimitada(0, DefensaLimitada.SIEMPRE));
            vulnerable = false;
            notificarObservers();
            siguienteAtaque();
        });
    }

    /**
     * Elige al azar el próximo ataque.
     */
    private void siguienteAtaque() {
        switch (azar.nextInt(3)) {
            case 0:
                Posicion link = miJuego.getJugador().getCentro();
                setMovimiento(new MovimientoInducido(
                        getHitbox().posicionParaCuerpoEn(link.getX() - getAncho() / 2, link.getY() - getAlto() / 2), VELOCIDAD_EMBESTIDA));
                setAtaque(embestida);
                embistiendo = true;
                notificarObservers();
                programar(DURACION_EMBESTIDA, this::embestidaTerminada);
                break;
            case 1:
                setMovimiento(caminar);
                lanzarRocas.reiniciar();
                setAtaque(lanzarRocas);
                programar(DURACION_LANZAMIENTO_ROCAS, this::siguienteAtaque);
                break;
            default:
                Posicion centro = getSector().getCentro();
                Posicion objetivo = getHitbox().posicionParaCuerpoEn(centro.getX() - getAncho() / 2, centro.getY() - getAlto() / 2);
                setMovimiento(new MovimientoInducido(objetivo, VELOCIDAD_AVALANCHA));
                setAtaque(avalancha);
                break;
        }
    }

    // Consultas

    /**
     * Crea una roca grande hacia Link.
     */
    public Proyectil generarProyectil() {
        return miJuego.getFabricaEntidades().crearRocaGrande(getX(), getY(), direccionHaciaJugador(), DANIO_ROCA);
    }

    /**
     * Devuelve la imagen según lo que hace: la nube de muerte, vulnerable (naranja), golpeando el suelo en la avalancha,
     * embistiendo (pasos rápidos) o normal (caminando).
     */
    @Override
    public String getRutaImagen() {
        String estado = "normal";
        if (muriendo)
            estado = "muerte";
        else if (vulnerable)
            estado = "vulnerable";
        else if (golpeandoSuelo)
            estado = "avalancha";
        else if (embistiendo)
            estado = "embestida";
        String ruta = sprite.getRuta(estado);
        return ruta != null ? ruta : super.getRutaImagen();
    }

    /**
     * Devuelve los puntos que da al morir.
     */
    public int getPuntos() {
        return PUNTOS;
    }
}
