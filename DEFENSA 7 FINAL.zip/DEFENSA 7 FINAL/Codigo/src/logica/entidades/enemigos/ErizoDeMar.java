package logica.entidades.enemigos;

import logica.comportamientos.AtaquePorContacto;
import logica.comportamientos.DefensaLimitada;
import logica.comportamientos.MovimientoInducido;
import logica.fabricas.Sprite;
import logica.util.Direccion;

/**
 * Enemigo quieto que lastima al tocarlo.
 */
public class ErizoDeMar extends EnemigoConDrop {

    // Atributos de clase

    private static final int VIDA = 1;
    private static final int PUNTOS = 50;
    private static final double PROBABILIDAD_DROP = 0.2;
    private static final int DANIO_CONTACTO = 1;
    private static final int VELOCIDAD = 0;
    private static final int CUERPO_MARGEN_X = 8;
    private static final int CUERPO_MARGEN_Y = 8;
    private static final int CUERPO_ANCHO = 32;
    private static final int CUERPO_ALTO = 32;

    // Constructores

    /**
     * Crea el erizo en (x, y).
     */
    public ErizoDeMar(Sprite sprite, int x, int y) {
        super(sprite, x, y, VIDA);
        setCuerpo(CUERPO_MARGEN_X, CUERPO_MARGEN_Y, CUERPO_ANCHO, CUERPO_ALTO);
        setMovimiento(new MovimientoInducido((Direccion) null, VELOCIDAD));
        setAtaque(new AtaquePorContacto(DANIO_CONTACTO));
        setDefensa(new DefensaLimitada(DefensaLimitada.SIN_LIMITE, DefensaLimitada.SIEMPRE));
    }

    // Consultas

    /**
     * Devuelve los puntos que da al morir.
     */
    public int getPuntos() {
        return PUNTOS;
    }

    /**
     * Devuelve la probabilidad de soltar un power-up.
     */
    protected double getProbabilidadDrop() {
        return PROBABILIDAD_DROP;
    }
}
