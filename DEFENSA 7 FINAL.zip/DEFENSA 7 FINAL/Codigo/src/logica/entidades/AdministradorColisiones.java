package logica.entidades;

import java.util.List;

import logica.mapa.Sector;
import logica.util.Direccion;
import logica.util.Hitbox;

/**
 * Resuelve los bloqueos, los choques y los golpes de espada sobre el sector visible.
 */
public class AdministradorColisiones {

    // Atributos de instancia

    protected volatile Sector sector;

    // Constructores

    /**
     * Crea el administrador sin sector.
     */
    public AdministradorColisiones() { }

    // Comandos

    /**
     * Cambia el sector visible.
     */
    public void setSector(Sector s) {
        sector = s;
    }

    /**
     * Mueve la entidad si nada la bloquea y avisa si chocó o salió del sector; devuelve true si avanzó.
     * Si la frena algo, como no llegan a superponerse, dispara a mano el choque (Visitor de efectos).
     */
    public boolean mover(EntidadAnimada e, Direccion d, int pasos) {
        Entidad bloqueo = buscarBloqueo(e, d, pasos);
        boolean avanzo = bloqueo == null;
        if (avanzo) {
            e.avanzar(d, pasos);
            if (estaFuera(e.getHitbox()))
                e.alSalirDelSector(d);
        } else {
            bloqueo.aceptarColision(e);
            e.alChocarConBloqueo();
        }
        return avanzo;
    }

    /**
     * Resuelve con Visitor los choques de una entidad con las del sector.
     */
    public void verificarColisiones(EntidadAnimada entidadActualizada) {
        Sector s = sector;
        List<Entidad> entidades = s.getEntidades();
        int i = 0;
        while (i < entidades.size() && !entidadActualizada.estaEliminada() && entidadActualizada.getSector() == s) {
            Entidad entidadDelSector = entidades.get(i);
            boolean seTocan = entidadDelSector != entidadActualizada
                    && !entidadDelSector.estaEliminada()
                    && entidadDelSector.getHitbox().intersecta(entidadActualizada.getHitbox());
            if (seTocan)
                entidadDelSector.aceptarColision(entidadActualizada);
            i++;
        }
    }

    /**
     * Golpea a las entidades que están en la zona de adelante del atacante.
     */
    public void golpearEn(EntidadAnimada atacante, int alcance, int danio) {
        Hitbox zona = atacante.getHitbox().adelante(atacante.getDireccion(), alcance);
        for (Entidad otra : sector.getEntidades())
            if (otra != atacante && !otra.estaEliminada() && otra.getHitbox().intersecta(zona))
                otra.recibirGolpeDeEspada(atacante, danio);
    }

    /**
     * Golpea a las entidades que están alrededor del atacante, hacia los cuatro lados.
     */
    public void golpearAlrededor(EntidadAnimada atacante, int alcance, int danio) {
        Hitbox zona = atacante.getHitbox().alrededor(alcance);
        for (Entidad otra : sector.getEntidades())
            if (otra != atacante && !otra.estaEliminada() && otra.getHitbox().intersecta(zona))
                otra.recibirGolpeDeEspada(atacante, danio);
    }

    // Consultas

    /**
     * Devuelve el sector visible.
     */
    public Sector getSector() {
        return sector;
    }

    /**
     * Devuelve la entidad que no deja dar el paso, o null si el paso está libre.
     * Le pregunta a cada entidad si le bloquea el paso a e y no frena si ya estaban superpuestas.
     */
    private Entidad buscarBloqueo(EntidadAnimada e, Direccion d, int pasos) {
        Hitbox siguiente = e.getHitbox().desplazada(d, pasos);
        List<Entidad> entidades = sector.getEntidades();
        Entidad bloqueo = null;
        int i = 0;
        while (i < entidades.size() && bloqueo == null) {
            Entidad entidadDelSector = entidades.get(i);
            boolean bloquea = entidadDelSector != e
                    && !entidadDelSector.estaEliminada()
                    && entidadDelSector.getHitbox().intersecta(siguiente)
                    && !entidadDelSector.getHitbox().intersecta(e.getHitbox())
                    && entidadDelSector.bloqueaPasoA(e);
            if (bloquea)
                bloqueo = entidadDelSector;
            i++;
        }
        return bloqueo;
    }

    /**
     * Indica si la hitbox quedó, aunque sea en parte, fuera del sector.
     */
    public boolean estaFuera(Hitbox h) {
        return !h.estaDentroDe(Sector.ANCHO, Sector.ALTO);
    }
}
