package logica.entidades;

import logica.entidades.enemigos.Enemigo;
import logica.entidades.fijas.Objeto;
import logica.entidades.fijas.Obstaculo;
import logica.entidades.fijas.PowerUP;

/**
 * Entidad que resuelve un choque según contra qué choca (patrón Visitor).
 */
public interface Colisionador {

    // Comandos

    /**
     * Resuelve el choque con Link.
     */
    void colisionarCon(Link l);

    /**
     * Resuelve el choque con un enemigo.
     */
    void colisionarCon(Enemigo e);

    /**
     * Resuelve el choque con un proyectil.
     */
    void colisionarCon(Proyectil p);

    /**
     * Resuelve el choque con un obstáculo.
     */
    void colisionarCon(Obstaculo o);

    /**
     * Resuelve el choque con un power-up.
     */
    void colisionarCon(PowerUP p);

    /**
     * Resuelve el choque con un objeto.
     */
    void colisionarCon(Objeto o);
}
