package logica;

/**
 * Observador que se actualiza cuando cambia su entidad.
 */
public interface Observer {

    // Comandos

    /**
     * Refresca la vista de la entidad observada.
     */
    void actualizar();
}
