package logica.fabricas;

/**
 * Fábrica de sprites del dominio gráfico original.
 */
public class FabricaSpritesOriginal extends FabricaSprites {

    // Constructores

    /**
     * Crea la fábrica del dominio original.
     */
    public FabricaSpritesOriginal() {
    }

    // Consultas

    /**
     * Devuelve la carpeta de imágenes originales.
     */
    protected String carpeta() {
        return "/Recursos/Imagenes/original";
    }
}
