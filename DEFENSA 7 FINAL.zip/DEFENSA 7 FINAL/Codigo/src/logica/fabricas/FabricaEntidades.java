package logica.fabricas;

import logica.entidades.fijas.Agua;
import logica.entidades.fijas.Bellota;
import logica.entidades.fijas.CaidasAlVacio;
import logica.entidades.fijas.Corazon;
import logica.entidades.enemigos.ErizoDeMar;
import logica.entidades.fijas.Escudo;
import logica.entidades.fijas.Espada;
import logica.entidades.fijas.FragmentoDeCorazon;
import logica.entidades.EntornoJuego;
import logica.entidades.Link;
import logica.entidades.enemigos.MasterStalfos;
import logica.entidades.enemigos.Moblin;
import logica.entidades.enemigos.MoblinConEspadaYEscudo;
import logica.entidades.enemigos.Octorok;
import logica.entidades.fijas.Pasto;
import logica.entidades.Proyectil;
import logica.entidades.fijas.Roca;
import logica.entidades.fijas.Rupia;
import logica.entidades.enemigos.StoneHinox;
import logica.entidades.fijas.SuelosQuebradizo;
import logica.entidades.enemigos.TrampaDeCuchillas;
import logica.entidades.enemigos.Wizzrobe;
import logica.util.Direccion;

/**
 * Crea las entidades del juego con los sprites del dominio elegido.
 */
public class FabricaEntidades {

    // Atributos de instancia

    protected FabricaSprites fabricaSprites;
    protected EntornoJuego entorno;

    // Constructores

    /**
     * Crea la fábrica para el entorno de la partida y un dominio gráfico.
     */
    public FabricaEntidades(EntornoJuego entorno, FabricaSprites fabricaSprites) {
        this.entorno = entorno;
        this.fabricaSprites = fabricaSprites;
    }

    // Consultas

    /**
     * Crea Link con su escudo en (x, y).
     */
    public Link crearLink(int x, int y) {
        Link l = new Link(fabricaSprites.crearSpritesLink(), x, y);
        l.setJuego(entorno);
        l.agregarAlInventario(crearEscudo(x, y));
        return l;
    }

    /**
     * Crea un Moblin en (x, y).
     */
    public Moblin crearMoblin(int x, int y) {
        Moblin m = new Moblin(fabricaSprites.crearSpritesMoblin(), x, y);
        m.setJuego(entorno);
        return m;
    }

    /**
     * Crea un Moblin con espada y escudo en (x, y).
     */
    public MoblinConEspadaYEscudo crearMoblinConEspadaYEscudo(int x, int y) {
        MoblinConEspadaYEscudo m = new MoblinConEspadaYEscudo(fabricaSprites.crearSpritesMoblinConEspadaYEscudo(), x, y);
        m.setJuego(entorno);
        return m;
    }

    /**
     * Crea un erizo de mar en (x, y).
     */
    public ErizoDeMar crearErizoDeMar(int x, int y) {
        ErizoDeMar e = new ErizoDeMar(fabricaSprites.crearSpritesErizoDeMar(), x, y);
        e.setJuego(entorno);
        return e;
    }

    /**
     * Crea un Octorok en (x, y).
     */
    public Octorok crearOctorok(int x, int y) {
        Octorok o = new Octorok(fabricaSprites.crearSpritesOctorok(), x, y);
        o.setJuego(entorno);
        return o;
    }

    /**
     * Crea una trampa de cuchillas en (x, y).
     */
    public TrampaDeCuchillas crearTrampaDeCuchillas(int x, int y) {
        TrampaDeCuchillas t = new TrampaDeCuchillas(fabricaSprites.crearSpritesTrampaDeCuchillas(), x, y);
        t.setJuego(entorno);
        return t;
    }

    /**
     * Crea un Wizzrobe en (x, y).
     */
    public Wizzrobe crearWizzrobe(int x, int y) {
        Wizzrobe w = new Wizzrobe(fabricaSprites.crearSpritesWizzrobe(), x, y);
        w.setJuego(entorno);
        return w;
    }

    /**
     * Crea a MasterStalfos en (x, y).
     */
    public MasterStalfos crearMasterStalfos(int x, int y) {
        MasterStalfos ms = new MasterStalfos(fabricaSprites.crearSpritesMasterStalfos(), x, y);
        ms.setJuego(entorno);
        return ms;
    }

    /**
     * Crea a StoneHinox en (x, y).
     */
    public StoneHinox crearStoneHinox(int x, int y) {
        StoneHinox sh = new StoneHinox(fabricaSprites.crearSpritesStoneHinox(), x, y);
        sh.setJuego(entorno);
        return sh;
    }

    /**
     * Crea una rupia en (x, y).
     */
    public Rupia crearRupia(int x, int y) {
        Rupia r = new Rupia(fabricaSprites.crearSpritesRupia(), x, y);
        r.setJuego(entorno);
        return r;
    }

    /**
     * Crea una bellota en (x, y).
     */
    public Bellota crearBellota(int x, int y) {
        Bellota b = new Bellota(fabricaSprites.crearSpritesBellota(), x, y);
        b.setJuego(entorno);
        return b;
    }

    /**
     * Crea un corazón en (x, y).
     */
    public Corazon crearCorazon(int x, int y) {
        Corazon c = new Corazon(fabricaSprites.crearSpritesCorazon(), x, y);
        c.setJuego(entorno);
        return c;
    }

    /**
     * Crea un fragmento de corazón en (x, y).
     */
    public FragmentoDeCorazon crearFragmentoDeCorazon(int x, int y) {
        FragmentoDeCorazon fc = new FragmentoDeCorazon(fabricaSprites.crearSpritesFragmentoDeCorazon(), x, y);
        fc.setJuego(entorno);
        return fc;
    }

    /**
     * Crea una espada en (x, y).
     */
    public Espada crearEspada(int x, int y) {
        Espada esp = new Espada(fabricaSprites.crearSpritesEspada(), x, y);
        esp.setJuego(entorno);
        return esp;
    }

    /**
     * Crea un escudo en (x, y).
     */
    public Escudo crearEscudo(int x, int y) {
        Escudo esc = new Escudo(fabricaSprites.crearSpritesEscudo(), x, y);
        esc.setJuego(entorno);
        return esc;
    }

    /**
     * Crea una roca en (x, y).
     */
    public Roca crearRoca(int x, int y) {
        return new Roca(fabricaSprites.crearSpritesRoca(), x, y);
    }

    /**
     * Crea agua en (x, y).
     */
    public Agua crearAgua(int x, int y) {
        return new Agua(fabricaSprites.crearSpritesAgua(), x, y);
    }

    /**
     * Crea pasto en (x, y).
     */
    public Pasto crearPasto(int x, int y) {
        return new Pasto(fabricaSprites.crearSpritesPasto(), x, y);
    }

    /**
     * Crea una caída al vacío en (x, y).
     */
    public CaidasAlVacio crearCaidasAlVacio(int x, int y) {
        return new CaidasAlVacio(fabricaSprites.crearSpritesCaidasAlVacio(), x, y);
    }

    /**
     * Crea un suelo quebradizo en (x, y).
     */
    public SuelosQuebradizo crearSuelosQuebradizo(int x, int y) {
        return new SuelosQuebradizo(fabricaSprites.crearSpritesSuelosQuebradizo(), x, y);
    }

    /**
     * Crea un disparo en (x, y) hacia una dirección, con el daño que decide quien dispara.
     */
    public Proyectil crearProyectil(int x, int y, Direccion d, int danio) {
        Proyectil p = new Proyectil(fabricaSprites.crearSpritesProyectil(), x, y, d, danio, Proyectil.LADO_DISPARO);
        p.setJuego(entorno);
        return p;
    }

    /**
     * Crea una roca grande en (x, y) hacia una dirección, con el daño que decide quien la lanza.
     */
    public Proyectil crearRocaGrande(int x, int y, Direccion d, int danio) {
        Proyectil p = new Proyectil(fabricaSprites.crearSpritesRocaGrande(), x, y, d, danio, Proyectil.LADO_ROCA_GRANDE);
        p.setJuego(entorno);
        return p;
    }
}
