package logica.fabricas;

/**
 * Fábrica de sprites del dominio gráfico alternativo.
 */
public class FabricaSpritesAlternativa extends FabricaSprites {

    // Constructores

    /**
     * Crea la fábrica del dominio alternativo.
     */
    public FabricaSpritesAlternativa() {
    }

    // Consultas

    /**
     * Devuelve la carpeta de imágenes alternativas.
     */
    protected String carpeta() {
        return "/Recursos/Imagenes/alternativa";
    }
}
