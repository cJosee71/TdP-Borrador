package logica.fabricas;

/**
 * Crea los sprites de cada entidad desde la carpeta de un dominio gráfico (patrón Abstract Factory).
 */
public abstract class FabricaSprites {

    // Consultas

    /**
     * Crea el sprite de Link.
     */
    public Sprite crearSpritesLink() {
        Sprite s = armar("link", "abajo", "arriba", "izquierda", "derecha",
                "ataque-recargado-abajo", "ataque-recargado-arriba", "ataque-recargado-izquierda", "ataque-recargado-derecha",
                "escudo-abajo", "escudo-arriba", "escudo-izquierda", "escudo-derecha");
        s.agregar("caida", carpeta() + "/link-caida.gif");
        s.agregar("muerte", carpeta() + "/link-muerte.gif");
        s.agregar("pierde-vida", carpeta() + "/link-pierde-vida.gif");
        for (String direccion : new String[] { "abajo", "arriba", "izquierda", "derecha" }) {
            s.agregar("ataque-" + direccion, carpeta() + "/link-ataque-" + direccion + ".gif");
            for (String estado : new String[] { "", "escudo-", "ataque-", "recargado-" })
                s.agregar("caminar-" + estado + direccion, carpeta() + "/link-caminar-" + estado + direccion + ".gif");
        }
        return s;
    }

    /**
     * Crea el sprite de el Moblin.
     */
    public Sprite crearSpritesMoblin() {
        Sprite s = new Sprite();
        for (String direccion : new String[] { "abajo", "arriba", "izquierda", "derecha" })
            s.agregar(direccion, carpeta() + "/moblin-" + direccion + ".gif");
        s.agregar("muerte", carpeta() + "/moblin-muerte.gif");
        return s;
    }

    /**
     * Crea el sprite de el Moblin con espada y escudo.
     */
    public Sprite crearSpritesMoblinConEspadaYEscudo() {
        Sprite s = new Sprite();
        for (String direccion : new String[] { "abajo", "arriba", "izquierda", "derecha" })
            s.agregar(direccion, carpeta() + "/moblinconespadayescudo-" + direccion + ".gif");
        s.agregar("muerte", carpeta() + "/moblinconespadayescudo-muerte.gif");
        return s;
    }

    /**
     * Crea el sprite de el erizo de mar, con la nube de muerte.
     */
    public Sprite crearSpritesErizoDeMar() {
        Sprite s = armar("erizodemar", "normal");
        s.agregar("muerte", carpeta() + "/erizodemar-muerte.gif");
        return s;
    }

    /**
     * Crea el sprite de el Octorok, con la nube de muerte.
     */
    public Sprite crearSpritesOctorok() {
        Sprite s = armar("octorok", "abajo", "arriba", "izquierda", "derecha");
        s.agregar("muerte", carpeta() + "/octorok-muerte.gif");
        return s;
    }

    /**
     * Crea el sprite de la trampa de cuchillas.
     */
    public Sprite crearSpritesTrampaDeCuchillas() {
        return armar("trampadecuchillas", "normal");
    }

    /**
     * Crea el sprite de el Wizzrobe: una imagen por dirección, los GIFs de aparecer y desaparecer, y la nube de muerte.
     */
    public Sprite crearSpritesWizzrobe() {
        Sprite s = armar("wizzrobe", "abajo", "arriba", "izquierda", "derecha");
        for (String direccion : new String[] {"abajo", "arriba", "izquierda", "derecha"}) {
            s.agregar("aparecer-" + direccion, carpeta() + "/wizzrobe-aparecer-" + direccion + ".gif");
            s.agregar("desaparecer-" + direccion, carpeta() + "/wizzrobe-desaparecer-" + direccion + ".gif");
        }
        s.agregar("muerte", carpeta() + "/wizzrobe-muerte.gif");
        return s;
    }

    /**
     * Crea el sprite de MasterStalfos: un GIF para caminar, otro para el golpe de espada y otro para la muerte en cada dirección.
     */
    public Sprite crearSpritesMasterStalfos() {
        Sprite s = new Sprite();
        for (String direccion : new String[] { "abajo", "arriba", "izquierda", "derecha" }) {
            s.agregar(direccion, carpeta() + "/masterstalfos-" + direccion + ".gif");
            s.agregar("ataque-" + direccion, carpeta() + "/masterstalfos-ataque-" + direccion + ".gif");
            s.agregar("muerte-" + direccion, carpeta() + "/masterstalfos-muerte-" + direccion + ".gif");
        }
        return s;
    }

    /**
     * Crea el sprite de StoneHinox: todos sus estados son GIF animados (caminar, embestida,
     * vulnerable, avalancha y la nube de muerte agrandada).
     */
    public Sprite crearSpritesStoneHinox() {
        Sprite s = new Sprite();
        for (String estado : new String[] {"normal", "embestida", "vulnerable", "avalancha", "muerte"}) {
            s.agregar(estado, carpeta() + "/stonehinox-" + estado + ".gif");
        }
        return s;
    }

    /**
     * Crea el sprite de la rupia.
     */
    public Sprite crearSpritesRupia() {
        return armar("rupia", "normal");
    }

    /**
     * Crea el sprite de la bellota.
     */
    public Sprite crearSpritesBellota() {
        return armar("bellota", "normal");
    }

    /**
     * Crea el sprite de el corazón.
     */
    public Sprite crearSpritesCorazon() {
        return armar("corazon", "normal");
    }

    /**
     * Crea el sprite de el fragmento de corazón.
     */
    public Sprite crearSpritesFragmentoDeCorazon() {
        return armar("fragmentodecorazon", "normal");
    }

    /**
     * Crea el sprite de la espada.
     */
    public Sprite crearSpritesEspada() {
        return armar("espada", "normal");
    }

    /**
     * Crea el sprite de el escudo.
     */
    public Sprite crearSpritesEscudo() {
        return armar("escudo", "normal");
    }

    /**
     * Crea el sprite de la roca.
     */
    public Sprite crearSpritesRoca() {
        return armar("roca", "normal");
    }

    /**
     * Crea el sprite de el agua.
     */
    public Sprite crearSpritesAgua() {
        return armar("agua", "normal");
    }

    /**
     * Crea el sprite de el pasto.
     */
    public Sprite crearSpritesPasto() {
        return armar("pasto", "normal");
    }

    /**
     * Crea el sprite de la caída al vacío.
     */
    public Sprite crearSpritesCaidasAlVacio() {
        return armar("vacio", "normal");
    }

    /**
     * Crea el sprite de el suelo quebradizo.
     */
    public Sprite crearSpritesSuelosQuebradizo() {
        return armar("suelo-quebradizo", "normal");
    }

    /**
     * Crea el sprite de el disparo.
     */
    public Sprite crearSpritesProyectil() {
        return armar("proyectil", "normal");
    }

    /**
     * Crea el sprite de la roca grande.
     */
    public Sprite crearSpritesRocaGrande() {
        return armar("rocagrande", "normal");
    }

    /**
     * Arma un sprite con una imagen por estado.
     */
    protected Sprite armar(String nombre, String... estados) {
        Sprite s = new Sprite();
        for (String estado : estados) {
            s.agregar(estado, carpeta() + "/" + nombre + "-" + estado + ".png");
        }
        return s;
    }

    /**
     * Devuelve la carpeta de imágenes del dominio.
     */
    protected abstract String carpeta();
}
