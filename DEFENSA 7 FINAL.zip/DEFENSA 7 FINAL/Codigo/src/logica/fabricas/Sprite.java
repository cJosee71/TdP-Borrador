package logica.fabricas;

import java.util.HashMap;
import java.util.Map;

/**
 * Conjunto de imágenes de una entidad, una por estado, con el estado actual.
 */
public class Sprite {

    // Atributos de instancia

    protected final Map<String, String> rutas;
    protected String estadoActual;

    // Constructores

    /**
     * Crea un sprite sin imágenes.
     */
    public Sprite() {
        rutas = new HashMap<>();
    }

    // Comandos

    /**
     * Agrega la imagen de un estado; el primero queda como actual.
     */
    public void agregar(String estado, String ruta) {
        rutas.put(estado, ruta);
        if (estadoActual == null) {
            estadoActual = estado;
        }
    }

    /**
     * Cambia el estado actual si existe.
     */
    public void setEstado(String estado) {
        if (tieneEstado(estado)) {
            estadoActual = estado;
        }
    }

    // Consultas

    /**
     * Devuelve la ruta de la imagen actual.
     */
    public String getRutaActual() {
        return rutas.get(estadoActual);
    }

    /**
     * Devuelve la ruta de la imagen de un estado.
     */
    public String getRuta(String estado) {
        return rutas.get(estado);
    }

    /**
     * Indica si tiene imagen para un estado.
     */
    public boolean tieneEstado(String estado) {
        return rutas.containsKey(estado);
    }
}
