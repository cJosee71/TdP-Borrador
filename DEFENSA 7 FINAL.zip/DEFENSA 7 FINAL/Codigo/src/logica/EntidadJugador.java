package logica;

/**
 * Datos del jugador que la vista muestra en el HUD.
 */
public interface EntidadJugador extends EntidadLogica {

    // Consultas

    /**
     * Devuelve las vidas que le quedan.
     */
    public int getVidas();

    /**
     * Devuelve la vida actual en medios corazones.
     */
    public int getCorazones();

    /**
     * Devuelve la vida máxima en medios corazones.
     */
    public int getCorazonesMaximos();

    /**
     * Devuelve el puntaje acumulado.
     */
    public int getPuntaje();

    /**
     * Devuelve las rupias juntadas.
     */
    public int getRupias();

    /**
     * Devuelve el nombre del objeto equipado.
     */
    public String getNombreObjetoEquipado();
}
