package logica.juego;

/**
 * Modo en el que cada nivel tiene un tiempo límite; al agotarse, termina la partida.
 */
public class Contrarreloj extends ModoJuego {

    // Atributos de clase

    private static final int CANTIDAD_NIVELES = 2;

    // Atributos de instancia

    protected int tiempoLimite;
    protected int tiempoRestante;

    // Constructores

    /**
     * Crea el modo con CANTIDAD_NIVELES niveles y el tiempo límite en segundos.
     */
    public Contrarreloj(int tiempoLimite) {
        super(CANTIDAD_NIVELES);
        this.tiempoLimite = tiempoLimite;
    }

    // Comandos

    /**
     * Agrega la entrada al ranking de este modo.
     */
    @Override
    public void registrarPuntaje(TablaRankings t, EntradaRanking e) {
        t.agregarAlRankingContrarreloj(e);
    }

    /**
     * Reinicia el tiempo restante.
     */
    @Override
    public void alIniciarNivel() {
        tiempoRestante = tiempoLimite;
    }

    /**
     * Descuenta un segundo y termina la partida si se agotó el tiempo.
     */
    @Override
    public void alPasarTiempo(ArbitroPartida a, int segundos) {
        tiempoRestante--;
        if (tiempoRestante <= 0) {
            a.terminarPartida();
        }
    }

    // Consultas

    /**
     * Devuelve el nombre del modo.
     */
    @Override
    public String getNombre() {
        return "Contrarreloj";
    }

    /**
     * Devuelve el ranking de este modo.
     */
    @Override
    public Ranking getRanking(TablaRankings t) {
        return t.getRankingContrarreloj();
    }

    /**
     * Devuelve el tiempo límite por nivel.
     */
    public int getTiempoLimite() {
        return tiempoLimite;
    }

    /**
     * Devuelve el tiempo que queda.
     */
    public int getTiempoRestante() {
        return tiempoRestante;
    }
}
