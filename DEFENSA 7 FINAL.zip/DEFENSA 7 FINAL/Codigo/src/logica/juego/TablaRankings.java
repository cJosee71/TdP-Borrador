package logica.juego;

/**
 * Los tres rankings de la partida, uno por modo de juego.
 */
public interface TablaRankings {

    // Comandos

    /**
     * Agrega una entrada al ranking Clásico.
     */
    public void agregarAlRankingClasico(EntradaRanking e);

    /**
     * Agrega una entrada al ranking Contrarreloj.
     */
    public void agregarAlRankingContrarreloj(EntradaRanking e);

    /**
     * Agrega una entrada al ranking NoHit.
     */
    public void agregarAlRankingNoHit(EntradaRanking e);

    // Consultas

    /**
     * Devuelve el ranking Clásico.
     */
    public Ranking getRankingClasico();

    /**
     * Devuelve el ranking Contrarreloj.
     */
    public Ranking getRankingContrarreloj();

    /**
     * Devuelve el ranking NoHit.
     */
    public Ranking getRankingNoHit();
}
