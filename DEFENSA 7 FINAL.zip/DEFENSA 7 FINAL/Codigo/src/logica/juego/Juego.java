package logica.juego;

import logica.ControlJugador;
import logica.ControladorGrafico;
import logica.ControladorJuego;
import logica.entidades.AdministradorColisiones;
import logica.entidades.Entidad;
import logica.entidades.Link;
import logica.entidades.enemigos.Enemigo;
import logica.entidades.enemigos.Jefe;
import logica.entidades.fijas.PowerUP;
import logica.fabricas.FabricaEntidades;
import logica.fabricas.FabricaSprites;
import logica.entidades.EntornoJuego;
import logica.hilos.HiloJugador;
import logica.hilos.HiloMundo;
import logica.hilos.OyenteReloj;
import logica.hilos.Reloj;
import logica.mapa.GeneradorNivel;
import logica.mapa.Nivel;
import logica.mapa.Sector;
import logica.util.Direccion;

/**
 * Árbitro de la partida: arma el juego, maneja los hilos, los niveles, el puntaje y los rankings.
 */
public class Juego implements ControladorJuego, OyenteReloj, ArbitroPartida, TablaRankings, EntornoJuego {

    // Atributos de clase

    private static final int RACHA_PARA_BELLOTA = 4;

    // Atributos de instancia

    protected ControladorGrafico controladorGrafico;
    protected Link jugador;
    protected Nivel nivel;
    protected int numeroNivel;
    protected ModoJuego modoJuego;
    protected Ranking[] rankings;
    protected Reloj reloj;
    protected HiloJugador hiloJugador;
    protected HiloMundo hiloMundo;
    protected AdministradorColisiones colisiones;
    protected GeneradorNivel generadorNivel;
    protected FabricaEntidades fabricaEntidades;
    protected PersistenciaRanking persistencia;
    protected boolean partidaEnCurso;

    // Constructores

    /**
     * Crea el juego sin partida y carga los tres rankings.
     */
    public Juego(ControladorGrafico vista) {
        controladorGrafico = vista;
        colisiones = new AdministradorColisiones();
        generadorNivel = new GeneradorNivel("/Recursos/Niveles/");
        persistencia = new PersistenciaRanking();
        rankings = new Ranking[3];
        for (int indiceRanking = 0; indiceRanking < rankings.length; indiceRanking++)
            rankings[indiceRanking] = persistencia.cargar("ranking" + indiceRanking + ".txt");
    }

    // Comandos

    /**
     * Empieza una partida: crea a Link y los hilos, carga el primer nivel y arranca los hilos.
     */
    @Override
    public void iniciar(ModoJuego modo, FabricaSprites dominio) {
        modoJuego = modo;
        numeroNivel = 1;
        fabricaEntidades = new FabricaEntidades(this, dominio);
        jugador = fabricaEntidades.crearLink(0, 0);
        reloj = new Reloj(this);
        hiloJugador = new HiloJugador(jugador, colisiones);
        hiloMundo = new HiloMundo(colisiones);
        cargarNivel();
        partidaEnCurso = true;
        reloj.iniciar();
        hiloJugador.iniciar();
        hiloMundo.iniciar();
    }

    /**
     * Guarda el puntaje con el nombre del jugador y muestra el ranking.
     */
    @Override
    public void registrarNombre(String nombre) {
        EntradaRanking entradaNueva = new EntradaRanking(nombre, jugador.getPuntaje());
        modoJuego.registrarPuntaje(this, entradaNueva);
        controladorGrafico.mostrarRanking(getRanking(modoJuego), modoJuego.getNombre());
    }

    /**
     * Muestra el sector nuevo y reanuda los hilos al terminar la transición.
     */
    @Override
    public void transicionTerminada() {
        activarSector(colisiones.getSector());
        hiloJugador.reanudar();
        hiloMundo.reanudar();
    }

    /**
     * Suma los puntos del enemigo y la racha; al llegar a la racha necesaria aparece una bellota y devuelve true.
     */
    @Override
    public synchronized boolean enemigoDerrotado(Enemigo e) {
        boolean aparecioBellota = false;
        jugador.sumarPuntos(e.getPuntos());
        jugador.incrementarRacha();
        if (jugador.getRacha() == RACHA_PARA_BELLOTA) {
            jugador.reiniciarRacha();
            aparecerBellota(e.getX(), e.getY());
            aparecioBellota = true;
        }
        return aparecioBellota;
    }

    /**
     * Suma los puntos del jefe y, si no quedan jefes, pasa de nivel o termina la partida.
     */
    @Override
    public void jefeDerrotado(Jefe j) {
        jugador.sumarPuntos(j.getPuntos());
        if (nivel.jefesDerrotados()) {
            if (modoJuego.esUltimoNivel(numeroNivel)) {
                terminarPartida();
            } else {
                numeroNivel++;
                hiloMundo.pausar();
                cargarNivel();
                hiloMundo.reanudar();
            }
        }
    }

    /**
     * Suma los puntos del power-up.
     */
    @Override
    public synchronized void powerUpRecogido(PowerUP p) {
        jugador.sumarPuntos(p.getPuntos());
    }

    /**
     * Avisa al modo que Link recibió daño.
     */
    @Override
    public synchronized void jugadorDaniado() {
        modoJuego.alRecibirDanio(this);
    }

    /**
     * Termina la partida porque Link se quedó sin vidas.
     */
    @Override
    public void jugadorSinVidas() {
        terminarPartida();
    }

    /**
     * Reinicia el nivel después de una caída al vacío.
     */
    @Override
    public void jugadorCayoAlVacio() {
        hiloMundo.pausar();
        cargarNivel();
        hiloMundo.reanudar();
    }

    /**
     * Pasa a Link al sector vecino y arranca la transición; si no hay vecino, lo devuelve al sector.
     */
    @Override
    public void cambiarDeSector(Direccion d) {
        Sector sectorActual = colisiones.getSector();
        Sector sectorVecino = nivel.getMapa().getVecino(sectorActual, d);
        if (sectorVecino == null) {
            jugador.entrarPorBordeOpuesto(d.opuesta());
        } else {
            hiloJugador.pausar();
            hiloMundo.pausar();
            sectorActual.retirar(jugador);
            jugador.entrarPorBordeOpuesto(d);
            sectorVecino.agregar(jugador);
            colisiones.setSector(sectorVecino);
            controladorGrafico.transicion(d);
        }
    }

    /**
     * Agrega una entidad al sector visible y la muestra.
     */
    @Override
    public void agregarEntidad(Entidad e) {
        colisiones.getSector().agregar(e);
        e.registrarObserver(controladorGrafico.mostrarEntidad(e));
    }

    /**
     * Detiene el reloj y los hilos, le pide a la vista que deje de enviarle teclas a Link
     * y pide el nombre o muestra el ranking; no hace nada si la partida ya terminó.
     */
    @Override
    public synchronized void terminarPartida() {
        if (partidaEnCurso) {
            partidaEnCurso = false;
            reloj.detener();
            hiloJugador.detener();
            hiloMundo.detener();
            controladorGrafico.terminarControl();
            int puntajeFinal = jugador.getPuntaje();
            Ranking rankingDelModo = getRanking(modoJuego);
            if (rankingDelModo.entraEnTop5(puntajeFinal))
                controladorGrafico.pedirNombre(puntajeFinal);
            else
                controladorGrafico.mostrarRanking(rankingDelModo, modoJuego.getNombre());
        }
    }

    /**
     * Muestra el tiempo y avisa al modo que pasó un segundo.
     */
    @Override
    public synchronized void tic(int segundos) {
        controladorGrafico.actualizarTiempo(segundos);
        modoJuego.alPasarTiempo(this, segundos);
    }

    /**
     * Agrega una entrada al ranking Clásico.
     */
    @Override
    public void agregarAlRankingClasico(EntradaRanking e) {
        agregar(0, e);
    }

    /**
     * Agrega una entrada al ranking Contrarreloj.
     */
    @Override
    public void agregarAlRankingContrarreloj(EntradaRanking e) {
        agregar(1, e);
    }

    /**
     * Agrega una entrada al ranking NoHit.
     */
    @Override
    public void agregarAlRankingNoHit(EntradaRanking e) {
        agregar(2, e);
    }

    /**
     * Inserta la entrada en un ranking y lo guarda si entró.
     */
    private void agregar(int i, EntradaRanking e) {
        Ranking ranking = rankings[i];
        boolean entro = ranking.insertar(e);
        if (entro)
            persistencia.guardar(ranking, "ranking" + i + ".txt");
    }

    /**
     * Genera el nivel actual, ubica a Link en el sector inicial y lo activa.
     */
    private void cargarNivel() {
        Sector sectorAnterior = jugador.getSector();
        if (sectorAnterior != null)
            sectorAnterior.retirar(jugador);
        nivel = generadorNivel.generar(numeroNivel, fabricaEntidades);
        Sector sectorInicial = nivel.getSectorInicial();
        jugador.setPosicion(nivel.getPosicionInicial());
        sectorInicial.agregar(jugador);
        modoJuego.alIniciarNivel();
        controladorGrafico.actualizarNivel(numeroNivel);
        activarSector(sectorInicial);
    }

    /**
     * Hace visible un sector y crea la vista de sus entidades, con Link al final.
     */
    private void activarSector(Sector s) {
        colisiones.setSector(s);
        controladorGrafico.limpiarEscena();
        for (Entidad entidad : s.getEntidades())
            if (entidad != jugador)
                entidad.registrarObserver(controladorGrafico.mostrarEntidad(entidad));
        jugador.registrarObserver(controladorGrafico.mostrarJugador(jugador));
    }

    /**
     * Hace aparecer una bellota en (x, y).
     */
    private void aparecerBellota(int x, int y) {
        Entidad bellota = fabricaEntidades.crearBellota(x, y);
        agregarEntidad(bellota);
    }

    // Consultas

    /**
     * Devuelve el ranking de un modo.
     */
    @Override
    public Ranking getRanking(ModoJuego m) {
        Ranking rankingDelModo = m.getRanking(this);
        return rankingDelModo;
    }

    /**
     * Devuelve a Link como control del jugador, o null si no hay partida.
     */
    @Override
    public ControlJugador getControlJugador() {
        return jugador;
    }

    /**
     * Devuelve el ranking Clásico.
     */
    @Override
    public Ranking getRankingClasico() {
        return rankings[0];
    }

    /**
     * Devuelve el ranking Contrarreloj.
     */
    @Override
    public Ranking getRankingContrarreloj() {
        return rankings[1];
    }

    /**
     * Devuelve el ranking NoHit.
     */
    @Override
    public Ranking getRankingNoHit() {
        return rankings[2];
    }

    /**
     * Devuelve a Link como entidad, solo para saber dónde está.
     */
    @Override
    public Entidad getJugador() {
        return jugador;
    }

    /**
     * Devuelve la fábrica de entidades de la partida.
     */
    @Override
    public FabricaEntidades getFabricaEntidades() {
        return fabricaEntidades;
    }
}
