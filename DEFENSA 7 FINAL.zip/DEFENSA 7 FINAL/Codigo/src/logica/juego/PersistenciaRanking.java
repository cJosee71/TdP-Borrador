package logica.juego;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;

/**
 * Guarda y carga los rankings en archivos de texto.
 */
public class PersistenciaRanking {

    // Constructores

    /**
     * Crea la persistencia.
     */
    public PersistenciaRanking() { }

    // Comandos

    /**
     * Guarda el ranking en un archivo, una entrada por línea.
     */
    public void guardar(Ranking r, String archivo) {
        try (PrintWriter salida = new PrintWriter(new FileWriter(archivo, StandardCharsets.UTF_8))) {
            for (EntradaRanking e : r.getEntradas())
                salida.println(e.getNombre().replace(";", " ") + ";" + e.getPuntaje());
        } catch (IOException ex) {
            System.err.println("No se pudo guardar el ranking: " + ex.getMessage());
        }
    }

    // Consultas

    /**
     * Carga un ranking desde un archivo; si no existe o está dañado, lo devuelve vacío.
     */
    public Ranking cargar(String archivo) {
        Ranking r = new Ranking();
        File f = new File(archivo);
        if (!f.exists())
            return r;
        try (BufferedReader lector = new BufferedReader(new FileReader(f, StandardCharsets.UTF_8))) {
            String linea;
            while ((linea = lector.readLine()) != null) {
                String[] partes = linea.split(";");
                if (partes.length == 2)
                    r.insertar(new EntradaRanking(partes[0], Integer.parseInt(partes[1].trim())));
            }
        } catch (IOException | NumberFormatException ex) {
            System.err.println("Ranking dañado, se empieza vacío: " + ex.getMessage());
        }
        return r;
    }
}
