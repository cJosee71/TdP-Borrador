package logica.juego;

/**
 * Nombre y puntaje de una partida en el ranking.
 */
public class EntradaRanking {

    // Atributos de instancia

    protected String nombre;
    protected int puntaje;

    // Constructores

    /**
     * Crea la entrada con su nombre y su puntaje.
     */
    public EntradaRanking(String nombre, int puntaje) {
        this.nombre = nombre;
        this.puntaje = puntaje;
    }

    // Consultas

    /**
     * Devuelve el nombre del jugador.
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Devuelve el puntaje.
     */
    public int getPuntaje() {
        return puntaje;
    }
}
