package logica.juego;

/**
 * Modo clásico: se juegan los niveles sin límite de tiempo.
 */
public class Clasico extends ModoJuego {

    // Atributos de clase

    private static final int CANTIDAD_NIVELES = 2;

    // Constructores

    /**
     * Crea el modo con CANTIDAD_NIVELES niveles.
     */
    public Clasico() {
        super(CANTIDAD_NIVELES);
    }

    // Comandos

    /**
     * Agrega la entrada al ranking de este modo.
     */
    @Override
    public void registrarPuntaje(TablaRankings t, EntradaRanking e) {
        t.agregarAlRankingClasico(e);
    }

    // Consultas

    /**
     * Devuelve el nombre del modo.
     */
    @Override
    public String getNombre() {
        return "Clasico";
    }

    /**
     * Devuelve el ranking de este modo.
     */
    @Override
    public Ranking getRanking(TablaRankings t) {
        return t.getRankingClasico();
    }
}
