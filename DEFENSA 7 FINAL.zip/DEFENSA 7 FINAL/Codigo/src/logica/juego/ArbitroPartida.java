package logica.juego;

/**
 * Lo que un modo de juego puede pedirle a la partida.
 */
public interface ArbitroPartida {

    // Comandos

    /**
     * Termina la partida.
     */
    public void terminarPartida();
}
