package logica.juego;

import java.util.ArrayList;
import java.util.List;

/**
 * Los MAXIMO mejores puntajes de un modo, de mayor a menor.
 */
public class Ranking {

    // Atributos de clase

    private static final int MAXIMO = 5;

    // Atributos de instancia

    protected List<EntradaRanking> entradas;

    // Constructores

    /**
     * Crea un ranking vacío.
     */
    public Ranking() {
        entradas = new ArrayList<>();
    }

    // Comandos

    /**
     * Inserta la entrada si entra entre los MAXIMO mejores; devuelve true si entró.
     * Un mismo nombre figura una sola vez, con su mayor puntaje (mayúsculas y minúsculas distinguen jugadores).
     */
    public boolean insertar(EntradaRanking e) {
        EntradaRanking mismoJugador = null;
        for (EntradaRanking existente : entradas)
            if (existente.getNombre().equals(e.getNombre()))
                mismoJugador = existente;
        if (mismoJugador != null) {
            if (mismoJugador.getPuntaje() >= e.getPuntaje())
                return false;
            entradas.remove(mismoJugador);
        }
        if (!entraEnTop5(e.getPuntaje()))
            return false;
        int posicion = 0;
        while (posicion < entradas.size() && entradas.get(posicion).getPuntaje() >= e.getPuntaje())
            posicion++;
        entradas.add(posicion, e);
        if (entradas.size() > MAXIMO)
            entradas.remove(MAXIMO);
        return true;
    }

    // Consultas

    /**
     * Indica si un puntaje entra entre los MAXIMO mejores.
     */
    public boolean entraEnTop5(int puntaje) {
        return entradas.size() < MAXIMO || puntaje > entradas.get(entradas.size() - 1).getPuntaje();
    }

    /**
     * Devuelve una copia de las entradas.
     */
    public List<EntradaRanking> getEntradas() {
        return new ArrayList<>(entradas);
    }

    /**
     * Devuelve la cantidad de entradas.
     */
    public int cantidad() {
        return entradas.size();
    }
}
