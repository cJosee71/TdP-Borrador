# Estrategia 2: `bloqueaPasoA(quien)` sin Visitor

Esta estrategia sigue la observación 4 del ayudante en la Defensa 6: *"no intenten modelar con Visitor el tema de los obstáculos y el bloqueo"*. Extiende el `bloqueaPaso()` que ya existía en la defensa 6, sin interfaces ni relaciones nuevas. **Es la estrategia recomendada.**

## Qué hay en la carpeta

| Archivo | Contenido |
|---|---|
| `Codigo/` | Copia de `defensa 7/Codigo` con los cambios de esta estrategia. Compila. |
| `Diagrama-reducido-bloqueaPasoA.drawio` / `.pdf` | Reducido puntuable de la defensa 6. Por el bloqueo no cambia; suma las 4 interfaces de las correcciones de la defensa 6 (cambio 17). |
| `Diagrama-extendido-bloqueaPasoA.drawio` / `.pdf` | Extendido puntuable de la defensa 6 con los métodos nuevos. |
| `Explicativo-bloqueaPasoA.md` | Este archivo. |
| `Cambios-desde-defensa-6.md` | Todos los cambios respecto de la defensa 6, para esta versión. |
| `imagenes-cambio-17/` | Diagramas ilustrativos del cambio 17 (correcciones de la defensa 6). |

Los diagramas parten de los `.drawio` de `Defensa 6/`, con el estilo de `Defensa 6/Diagramas Puntuables/`.

> **Correcciones de la defensa 6 (cambio 17).** Además de la estrategia de bloqueo, esta carpeta tiene las correcciones que pidió el ayudante en la devolución de la defensa 6: `Juego` implementa `OyenteReloj`, `ArbitroPartida`, `TablaRankings` y `EntornoJuego`, y cada colaborador (`Reloj`, los modos, `FabricaEntidades` y las entidades) recibe solo su interfaz; `terminarPartida()` usa `partidaEnCurso`; `getJugador()` devuelve `Entidad` y se borran `getNumeroNivel()` y `getTiempo()`. Está explicado, con diagramas antes y después y diagramas de secuencia, en la sección 17 de `Cambios-desde-defensa-6.md`.

### Vista previa de las correcciones (opción B)

Resumen de las clases y relaciones que cambian por la devolución del ayudante. Azul = se agrega, rojo tachado = se quita, negro = queda igual.

![Diagrama extendido: clases que cambian (opción B)](imagenes-cambio-17/vista-previa-extendido-opcion-B.png)

![Diagrama reducido: fragmento que cambia (opción B)](imagenes-cambio-17/vista-previa-reducido-opcion-B.png)

En los diagramas, el reducido tiene color solo en los patrones. El extendido también está en blanco y negro, con los patrones en los mismos colores que el reducido y una leyenda arriba a la izquierda. Lo que cambió respecto de la defensa 6 se detalla en `Cambios-desde-defensa-6.md`.

Este archivo explica la estrategia de bloqueo. La lista completa de cambios desde la defensa 6 (celdas, niveles, cuerpos, capas, trampa, imágenes y parpadeo) está en `Cambios-desde-defensa-6.md`.

## Qué resuelve

1. Los enemigos tratan las **caídas al vacío** como una pared y no caen. Link sí las pisa y cae.
2. **Link y los enemigos se frenan** al chocarse y avanzan solo cuando el paso queda libre. Dos enemigos también se frenan entre sí. El enemigo cambia de dirección al frenarse, porque `MovimientoAleatorio` ya elige otra dirección cuando `mover` devuelve `false`.
3. El **daño por contacto** sigue funcionando, aunque ahora no lleguen a superponerse: al frenarse se dispara el Visitor de efectos que ya existe (`aceptarColision`).

## Idea

`bloqueaPaso()` pasa a recibir a quién se mueve: `bloqueaPasoA(quien : EntidadAnimada)`. El que bloquea le hace una pregunta simple al que camina:

- `CaidasAlVacio` → `quien.esquivaVacios()`
- `Enemigo*` y `Link` → `quien.esFrenadoPorPersonajes()`
- `Roca` y `Agua` → `true`, siempre.

| Quién camina \ qué hay adelante | Roca | Agua | CaidasAlVacio | Enemigo | Link |
|---|---|---|---|---|---|
| `EntidadAnimada*` (por defecto, p. ej. `Proyectil`) | frena | frena | pasa | pasa | pasa |
| `Enemigo*` (`esquivaVacios` y `esFrenadoPorPersonajes` en `true`) | frena | frena | **frena** | **frena** | **frena** |
| `Link` (`esFrenadoPorPersonajes` en `true`) | frena | frena | pasa (y cae) | **frena** | — |

## Cambios en el diagrama reducido

**Ninguno por el bloqueo.** El reducido no muestra métodos y esta estrategia no agrega clases ni relaciones. Las únicas novedades del reducido son las del cambio 17 (4 interfaces y sus relaciones), que dejan 94 clases/interfaces y 131 relaciones (124 dibujadas), y la clase `AtaqueRafaga` del cambio 41 con su herencia (95 clases/interfaces y 132 relaciones, 125 dibujadas).

## Cambios en el diagrama extendido

| Clase | Se quita | Se agrega |
|---|---|---|
| `Entidad*` | `+ bloqueaPaso() : boolean` | `+ bloqueaPasoA(quien : EntidadAnimada) : boolean` (devuelve `false`) |
| `Roca`, `Agua` | `+ bloqueaPaso() : boolean` | `+ bloqueaPasoA(quien : EntidadAnimada) : boolean` (devuelve `true`) |
| `CaidasAlVacio` | — | `«consultas» + bloqueaPasoA(quien : EntidadAnimada) : boolean` |
| `EntidadAnimada*` | — | `+ esquivaVacios() : boolean`, `+ esFrenadoPorPersonajes() : boolean` (los dos `false`) |
| `Enemigo*` | — | `+ bloqueaPasoA(quien : EntidadAnimada)`, `+ esquivaVacios()`, `+ esFrenadoPorPersonajes()` |
| `Link` | — | `+ bloqueaPasoA(quien : EntidadAnimada)`, `+ esFrenadoPorPersonajes()` |
| `AdministradorColisiones` | `- puedeMoverA(...) : boolean` | `- buscarBloqueo(e : EntidadAnimada, d : Direccion, pasos : int) : Entidad` |

Las cajas que crecieron empujan hacia abajo a las de su columna, así que no se pisan.

## Cambios en el código (`Codigo/src/logica/entidades/`)

| Archivo | Cambio |
|---|---|
| `Entidad.java` | `bloqueaPaso()` pasa a ser `bloqueaPasoA(EntidadAnimada quien)` y devuelve `false`. |
| `fijas/Roca.java`, `fijas/Agua.java` | `bloqueaPasoA` devuelve `true`. |
| `fijas/CaidasAlVacio.java` | `bloqueaPasoA` devuelve `quien.esquivaVacios()`. |
| `EntidadAnimada.java` | `esquivaVacios()` y `esFrenadoPorPersonajes()`, los dos `false`. |
| `enemigos/Enemigo.java` | `bloqueaPasoA` devuelve `quien.esFrenadoPorPersonajes()`. `esquivaVacios()` y `esFrenadoPorPersonajes()` devuelven `true`. |
| `Link.java` | `bloqueaPasoA` devuelve `quien.esFrenadoPorPersonajes()`. `esFrenadoPorPersonajes()` devuelve `true`. `colisionarCon(Enemigo e)` pasa a hacer `e.colisionarCon(this)`, para que Link reciba daño también cuando es él quien se frena contra el enemigo. El segundo de invulnerabilidad evita el daño doble. |
| `AdministradorColisiones.java` | Ver abajo. |

```java
public boolean mover(EntidadAnimada e, Direccion d, int pasos) {
    Entidad bloqueo = buscarBloqueo(e, d, pasos);
    boolean avanzo = bloqueo == null;
    if (avanzo) {
        e.avanzar(d, pasos);
        if (estaFuera(e.getHitbox()))
            e.alSalirDelSector(d);
    } else {
        bloqueo.aceptarColision(e);   // efecto del choque (Visitor de efectos que ya existía)
        e.alChocarConBloqueo();
    }
    return avanzo;
}

private Entidad buscarBloqueo(EntidadAnimada e, Direccion d, int pasos) {
    // devuelve la primera entidad que:
    //  - no es e ni está eliminada,
    //  - se superpone con el paso siguiente y no con la posición actual (si ya estaban encima, no la traba),
    //  - y le bloquea el paso: entidadDelSector.bloqueaPasoA(e)
}
```

## Comparación con la estrategia Visitor

| | Visitor (`Transitable` / `Caminante`) | `bloqueaPasoA` |
|---|---|---|
| Reducido | +2 interfaces, +2 realizaciones | sin cambios |
| Extendido | 2 cajas nuevas (6 métodos), 12 métodos nuevos en clases existentes y `bloqueaPaso` reemplazado | `bloqueaPaso` renombrado y 8 métodos nuevos |
| Observación 4 del ayudante | la contradice | la respeta |
| Comportamiento en el juego | igual | igual |

## Cómo probarlo

En el nivel 1, los enemigos rebotan contra las caídas al vacío. Link las pisa y cae. Si Link camina contra un enemigo, se frena y pierde corazones. El enemigo cambia de dirección.

## Agregado: trampa de cuchillas

Este cambio es aparte del bloqueo y vale para las dos estrategias. `TrampaDeCuchillas` sale hacia **el lugar donde estaba Link** cuando lo vio en línea. Al llegar, vuelve despacio a su lugar (`MovimientoInducido(posicionOriginal, 4)`). Si choca antes con una roca, el agua, el borde o Link, vuelve desde ahí.

| Clase | Se agrega |
|---|---|
| `TrampaDeCuchillas` | `# destino : Posicion` y `- llegoAlDestino() : boolean` |

`vigilarJugador()` calcula el destino al salir y, cuando `llegoAlDestino()` da `true`, llama a `volver()`. El reducido no cambia.

## Agregado: no abalanzarse a través de obstáculos

Este cambio vale para las dos estrategias y también para `defensa 7/Codigo`. Los enemigos que se abalanzan al detectar a Link (`TrampaDeCuchillas` y `MoblinConEspadaYEscudo`) no lo hacen si hay roca, agua o vacío entre ellos y Link. Se usa una consulta propia, separada de la de bloqueo, para que el vacío tape a Link aunque no frene el paso.

| Clase | Se agrega |
|---|---|
| `Entidad*` | `+ impideAbalanzarse() : boolean` (`false`) |
| `Roca`, `Agua`, `CaidasAlVacio` | `+ impideAbalanzarse() : boolean` (`true`) |
| `Hitbox` | `+ caminoHasta(otra : Hitbox) : Hitbox`: la franja entre los dos cuerpos |
| `EntidadAnimada*` | `+ hayObstaculoHastaJugador() : boolean`: busca en el sector algo que impida abalanzarse dentro de esa franja |

`TrampaDeCuchillas.vigilarJugador()` pide `estaEnLineaCon(...) && !hayObstaculoHastaJugador()`. `MoblinConEspadaYEscudo.vigilarJugador()` pide `linkEstaEnfrente() && !hayObstaculoHastaJugador()`. El reducido no cambia.

Desde el cambio 29 los que disparan usan la misma consulta: `AtaquePorProyectil.puedeAtacar` pide `pasoElIntervalo() && a.linkEstaEnfrente() && !a.hayObstaculoHastaJugador()`. Así el Octorok, el Wizzrobe y las rocas del StoneHinox no disparan si hay roca, agua o vacío entre ellos y Link. `AtaqueAvalancha` redefine `puedeAtacar` y no cambia.

## Agregado: constantes con nombre, ranking y pantallas

Este cambio es aparte del bloqueo y vale para las dos estrategias (no está en `defensa 7/Codigo`). Viene del código de la PC de Ani:

- Los números sueltos pasan a ser constantes de clase con nombre, con los mismos valores (por ejemplo `Moblin.VIDA = 2` y `Moblin.PUNTOS = 100`).
- `Ranking.insertar` deja un solo puntaje por nombre, el mejor.
- Las pantallas tienen un estilo nuevo, con los colores como constantes de `PanelVista*`.

En el extendido, las constantes nuevas están subrayadas (son de clase). El reducido no cambia. El detalle clase por clase está en el cambio 15 de `Cambios-desde-defensa-6.md`.

## Agregado: abalanzada del Moblin con espada y escudo

Estos cambios son aparte del bloqueo; usan la condición de la sección anterior (`linkEstaEnfrente() && !hayObstaculoHastaJugador()`). El detalle está en los cambios 26, 27 y 28 de `Cambios-desde-defensa-6.md`.

- **Una abalanzada por vez (cambio 26).** Antes empezaba otra en cada vuelta mientras veía a Link: se juntaban acciones pendientes y el Moblin temblaba al terminar. Ahora el atributo `abalanzandose` lo evita y `terminarAbalanzada()` vuelve a caminar al azar.
- **Más lenta (cambio 27).** `VELOCIDAD_ABALANZADA` pasa de 6 a 3 y `DURACION_ABALANZADA` de 800 a 1600 ms: recorre lo mismo, a la mitad de velocidad.
- **Suave (cambio 28).** Se queda quieto `PREPARACION_ABALANZADA` = 300 ms, sale a velocidad 1, 2 y 3 (cada `DURACION_CAMBIO_VELOCIDAD` = 100 ms) y al terminar frena a su velocidad de caminar, siguiendo derecho `DURACION_FRENADO` = 500 ms.

| Clase | Se agrega o cambia |
|---|---|
| `MoblinConEspadaYEscudo` | `# abalanzandose : boolean`, `- terminarAbalanzada()`, `- PREPARACION_ABALANZADA : long = 300`, `- DURACION_CAMBIO_VELOCIDAD : long = 100`, `- DURACION_FRENADO : long = 500`; `VELOCIDAD_ABALANZADA = 3` y `DURACION_ABALANZADA = 1600` |

En el extendido está todo en la clase `MoblinConEspadaYEscudo`. El reducido no cambia, porque ahí la clase aparece solo con el nombre.
