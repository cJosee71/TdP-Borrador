# Explicaciones del proyecto Zelda

**Defensa 7** · Documento completo, actualizado con el código y los diagramas de `DEFENSA 7 FINAL` (estrategia `bloqueaPasoA`) y con los cambios 1 a 35 de `Cambios-desde-defensa-6.md`.

## Índice

- **Integrante 1**
  - [Implementación del modelo de entidades](#implementación-del-modelo-de-entidades)
- **Integrante 2**
  - [Niveles, fábricas y recursos](#niveles-fábricas-y-recursos)
- **Integrante 3**
  - [Vista y modos del juego](#vista-y-modos-del-juego)
- **Integrante 4 · logica.comportamientos**
  - [DefensaLimitada: explicación simple (Defensa 7)](#defensalimitada-explicación-simple-defensa-7)
  - [Explicación de la clase AtaquePorContacto (Defensa 7)](#explicación-de-la-clase-ataqueporcontacto-defensa-7)
  - [Explicación de la clase MovimientoInducido (Defensa 7)](#explicación-de-la-clase-movimientoinducido-defensa-7)
- **Integrante 4 · logica.entidades**
  - [Explicación de la clase AdministradorColisiones (Defensa 7)](#explicación-de-la-clase-administradorcolisiones-defensa-7)
  - [Explicación de la clase EntidadAnimada (Defensa 7)](#explicación-de-la-clase-entidadanimada-defensa-7)
  - [Explicación de la clase Link (Defensa 7)](#explicación-de-la-clase-link-defensa-7)
- **Integrante 4 · logica.hilos**
  - [Explicación de la clase AccionProgramada (Defensa 7)](#explicación-de-la-clase-accionprogramada-defensa-7)
  - [Explicación de la clase HiloJuego (Defensa 7)](#explicación-de-la-clase-hilojuego-defensa-7)
  - [Explicación de la clase HiloJugador (Defensa 7)](#explicación-de-la-clase-hilojugador-defensa-7)
  - [Explicación de la clase HiloMundo (Defensa 7)](#explicación-de-la-clase-hilomundo-defensa-7)
  - [Explicación de la clase Reloj (Defensa 7)](#explicación-de-la-clase-reloj-defensa-7)
- **Integrante 4 · logica.juego**
  - [Explicación de la clase Juego (Defensa 7)](#explicación-de-la-clase-juego-defensa-7)
- **Cambios generales**
  - [Cambios generales: cuerpos de colisión (Defensa 7)](#cambios-generales-cuerpos-de-colisión-defensa-7)
- **Diagramas de secuencia**
  - [Diagramas de secuencia (Defensa 7)](#diagramas-de-secuencia-defensa-7)
- **Niveles**
  - [Niveles: archivo nivel1.txt (Defensa 7)](#niveles-archivo-nivel1txt-defensa-7)
- **Referencia**
  - [Miembros que no se explican en otras secciones (Defensa 7)](#miembros-que-no-se-explican-en-otras-secciones-defensa-7)

---

*Integrante 1*

# Implementación del modelo de entidades

## 1. La idea general

Todo lo que aparece en un sector del juego es una `Entidad`. De ahí salen tres ramas:

- **Fijas:** obstáculos, power-ups y objetos, que no se mueven solas.
- **Animadas:** enemigos, jefes y proyectiles, que heredan de `EntidadAnimada`.
- **Link.**

La regla que más condiciona el diseño es que está prohibido usar `instanceof`. Se reemplaza con cuatro mecanismos:

1. **Doble despacho** (`Colisionable` / `Colisionador`). Cuando dos entidades chocan, una llama a `c.colisionarCon(this)`
   y Java elige la versión según el tipo real. Link nunca pregunta "¿esto es una rupia?".
2. **Ganchos vacíos** en las superclases. Por ejemplo, `Entidad.recibirGolpeDeEspada` no hace nada, y solo `Pasto` y
   `Enemigo` lo redefinen.
3. **Strategy.** Cada entidad animada tiene un movimiento, un ataque y una defensa intercambiables. Un enemigo cambia de
   comportamiento cambiando de estrategia, sin ningún `if` sobre su tipo.
4. **Preguntas polimórficas** (defensa 7). Para saber si algo frena el paso, la entidad que está adelante responde
   `bloqueaPasoA(quien)` y, si hace falta, le hace una pregunta simple al que camina (`quien.esquivaVacios()`,
   `quien.esFrenadoPorPersonajes()`). Así los enemigos esquivan el vacío y Link cae, sin preguntar el tipo.

## 2. Paso 1: las interfaces

| Interfaz | Paquete | Para qué sirve |
|---|---|---|
| `Colisionable` | `logica.entidades` | Algo con lo que se puede chocar: `aceptarColision(c)`, el primer despacho |
| `Colisionador` | `logica.entidades` | Quien reacciona al choque: un `colisionarCon` por cada tipo (Link, Enemigo, Proyectil, Obstaculo, PowerUP, Objeto) |
| `EntidadLogica` | `logica` | Lo único que la vista puede ver de una entidad: posición, imagen, si fue eliminada y, desde la defensa 7, en qué **capa** se dibuja (`getCapa()`) y si se ve en este momento (`esVisible()`, para el parpadeo) (Integrante 3) |
| `EntornoJuego` | `logica.entidades` | **Nueva en la defensa 7.** Lo único que las entidades ven de la partida: los avisos (`enemigoDerrotado`, `jugadorDaniado`, …), `agregarEntidad`, `cambiarDeSector`, `getFabricaEntidades()` y `getJugador() : Entidad`. La implementa `Juego` (Integrante 4) |
| `GeneradorDrop` | `logica.entidades.enemigos` | Factory Method: quién crea el premio al morir |
| `GeneradorProyectil` | `logica.entidades.enemigos` | Factory Method: quién crea el proyectil que se dispara |

`EntidadLogica` define las capas como constantes: `CAPA_SUELO = 0`, `CAPA_OBJETOS = 1`, `CAPA_OBSTACULOS = 2`,
`CAPA_PERSONAJES = 3` y `CAPA_JUGADOR = 4`. Cada rama responde la suya, y la vista pone arriba a las de número mayor.

## 3. Paso 2 y 3: Hitbox y Entidad

`Hitbox` es el rectángulo en píxeles con el que choca una entidad: su **cuerpo**. Tiene seis operaciones:

- `intersecta`: ¿chocan?
- `desplazada`: ¿está libre el lugar al que voy?
- `adelante`: la zona que corta la espada.
- `estaDentroDe`: ¿salió del sector?
- `estaEnLineaCon`: ¿comparten fila o columna?
- `caminoHasta` (defensa 7): la franja entre dos cuerpos que están en línea. La usan los enemigos que se abalanzan para
  ver si hay una roca, agua o vacío en el medio.

Un detalle importante: `intersecta` usa menor estricto. Dos rectángulos que solo se tocan en el borde no chocan; si no,
Link pegado a una roca quedaría chocando siempre y no podría despegarse.

**Hitbox con margen (defensa 6).** La hitbox guarda la esquina de la entidad (donde se dibuja la imagen) y además un
margen (`margenX`, `margenY`) hasta la esquina del cuerpo. `getX()`/`getY()` de la hitbox devuelven la esquina del
cuerpo, así que todas las operaciones comparan cuerpos. Hay dos consultas para pasar de un sistema al otro:

- `posicionParaCuerpoEn(x, y)`: dónde tiene que estar la entidad para que su cuerpo quede en `(x, y)`.
- `getCentro()`: el centro del cuerpo.

`Entidad` es la base de todo: guarda el hitbox, el sprite, los observadores, el entorno de la partida (`miJuego`) y el
sector. Su método `eliminar()` marca la entidad como eliminada, la saca sola de su sector y avisa a la vista. La lista de
observadores es una `CopyOnWriteArrayList` porque la recorren varios hilos mientras `Juego` agrega celdas.

Lo que tiene `Entidad`, con lo que se sumó en las defensas 6 y 7:

| Elemento | Qué hace |
|---|---|
| `# LADO : int = 48` | Constante de clase: el cuerpo por defecto es de `LADO` × `LADO`, sin margen |
| `# miJuego : EntornoJuego` | Defensa 7: antes era `Juego`. Ahora la entidad solo ve la interfaz chica `EntornoJuego`. `setJuego` y `getJuego` también usan `EntornoJuego` |
| `getX()`, `getY()`, `getPosicion()` | La esquina de la **imagen**. También la usa la lógica para mover la entidad |
| `getXImagen()`, `getYImagen()` | Defensa 7 (cambio 25): dónde dibuja la vista la imagen. En `Entidad` devuelven `getX()`, `getY()`; las redefinen `Link` y `MasterStalfos` (cambio 44) |
| `getHitbox()`, `getAncho()`, `getAlto()` | El **cuerpo** y su tamaño: lo usan las colisiones |
| `# setCuerpo(margenX, margenY, ancho, alto)` | Reemplaza el cuerpo por uno propio. Lo llaman los constructores de las clases cuyo dibujo no ocupa toda la imagen |
| `+ ubicarCuerpoEn(x, y)` | Mueve la entidad para que la esquina de su cuerpo quede en `(x, y)` |
| `+ getCentro()` | El centro del cuerpo |
| `+ bloqueaPasoA(quien : EntidadAnimada) : boolean` | Defensa 7: reemplaza a `bloqueaPaso()`. Devuelve `false`: por defecto nada frena |
| `+ impideAbalanzarse() : boolean` | Defensa 7: devuelve `false`. Roca, agua y vacío responden `true` |
| `+ esVisible() : boolean` | Defensa 7: devuelve `true`. Las fijas siempre se ven; `EntidadAnimada` lo redefine para el parpadeo |

Los tamaños y valores nunca van como números sueltos: cada clase los declara como constantes de clase (`static final`).

## 4. Paso 4: obstáculos

Los obstáculos tienen un método `afectar(l)` que empieza vacío en la base. Cuando Link choca con uno, simplemente llama
`o.afectar(this)` y no sabe cuál es. Cada hijo decide qué le pasa:

| Clase | Qué hace | Capa | Cuerpo |
|---|---|---|---|
| `Roca` | Bloquea a todos (`bloqueaPasoA` devuelve `true`) e impide abalanzarse. `afectar` queda vacío porque Link nunca llega a superponerse | `CAPA_OBSTACULOS` | 4, 4, 42, 42 |
| `Agua` | Igual que la roca, pero se dibuja en el suelo | `CAPA_SUELO` | 48 × 48 |
| `Pasto` | Ralentiza a Link. La espada lo corta (`eliminar()`) | `CAPA_SUELO` | 48 × 48 |
| `CaidasAlVacio` | Hace caer a Link cuando el centro de su cuerpo está sobre el pozo (cambio 31: pisar el borde no alcanza). `bloqueaPasoA(quien)` devuelve `quien.esquivaVacios()`: frena a los enemigos y deja pasar a Link. Impide abalanzarse | `CAPA_SUELO` | 8, 8, 32, 32 |
| `SuelosQuebradizo` | La primera vez que se pisa, marca `pisado` y le pide a Link que programe la rotura | `CAPA_SUELO` | 48 × 48 |

`Obstaculo*` responde `CAPA_SUELO` y solo la roca la redefine. Los cuerpos de la roca y del vacío son más chicos que la
imagen (defensa 7): así Link no cae al vacío ni choca con la roca sin tocar el dibujo. Los números son margen X, margen
Y, ancho y alto.

## 5. Paso 5: power-ups y objetos

Acá el patrón es parecido, pero con `serRecogidoPor(l)`. En los power-ups el orden importa: primero el efecto propio y
después `super.serRecogidoPor(l)`, que suma los puntos y elimina la entidad. Power-ups y objetos se dibujan en
`CAPA_OBJETOS`.

| Clase | Efecto | Constantes (defensa 7) | Cuerpo |
|---|---|---|---|
| `PowerUP` | Base. Avisa a Link (`powerUpRecogido`, que suma `getPuntos()`) y se elimina | `PUNTOS = 300` | — |
| `Rupia` | Suma de 1 a 5 rupias al azar. Vale 10 por la cantidad | `CANTIDAD_MINIMA = 1`, `CANTIDAD_MAXIMA = 5`, `PUNTOS_POR_RUPIA = 10` | 13, 3, 21, 42 |
| `Bellota` | Los próximos 3 golpes a Link hacen como mucho ½ corazón | `DANIO_MAXIMO = 1`, `GOLPES_PROTEGIDOS = 3` | 12, 1, 24, 45 |
| `Corazon` | Cura 2 medios corazones | `MEDIOS_CURADOS = 2` | 3, 6, 42, 36 |
| `FragmentoDeCorazon` | Suma un fragmento; cada 4, un corazón máximo más | — | 1, 3, 45, 42 |
| `Objeto`, `Espada`, `Escudo` | Lo que Link lleva en el inventario. Cada objeto decide qué hace cada tecla, así Link no pregunta "¿tengo la espada?". La espada carga al apretar y dispara al soltar; el escudo se activa mientras se mantiene la tecla | — | 48 × 48 (por defecto) |

**Cuerpo de los power-ups:** cada uno declara la parte visible de su imagen de 48 × 48 como constantes de clase y la usa
en su constructor. Así Link lo agarra cuando toca lo que se ve, no el borde transparente de la imagen.

```java
public class Rupia extends PowerUP {
    private static final int CANTIDAD_MINIMA = 1;
    private static final int CANTIDAD_MAXIMA = 5;
    private static final int PUNTOS_POR_RUPIA = 10;
    private static final int CUERPO_MARGEN_X = 13;
    private static final int CUERPO_MARGEN_Y = 3;
    private static final int CUERPO_ANCHO = 21;
    private static final int CUERPO_ALTO = 42;

    protected int cantidad;

    public Rupia(Sprite sprite, int x, int y) {
        super(sprite, x, y);
        setCuerpo(CUERPO_MARGEN_X, CUERPO_MARGEN_Y, CUERPO_ANCHO, CUERPO_ALTO);
        cantidad = CANTIDAD_MINIMA + new Random().nextInt(CANTIDAD_MAXIMA - CANTIDAD_MINIMA + 1);
    }

    @Override
    public int getPuntos() {
        return PUNTOS_POR_RUPIA * cantidad;
    }
    ...
}
```

## 6. Paso 6: las estrategias

Antes de los enemigos se implementaron las siete estrategias, porque sus constructores las usan. Las tres interfaces
(`Comportamiento*`) y `MovimientoInducido`, `AtaquePorContacto` y `DefensaLimitada` son del Integrante 4.

| Estrategia | Qué hace |
|---|---|
| `MovimientoAleatorio` | Cada cierto tiempo elige una dirección al azar; si `mover` devuelve `false` (algo lo frenó), elige otra. |
| `MovimientoTeletransporte` | Cada cierto tiempo aparece en un lugar libre al azar (Wizzrobe). El lugar libre es para el cuerpo, así que lo ubica con `ubicarCuerpoEn`. |
| `AtaqueEspada` | Si el atacante quiere atacar, golpea la zona de adelante y llama al gancho `ataqueRealizado()` (MasterStalfos). |
| `AtaqueRecargado` | Hereda de `AtaqueEspada`. Al soltar golpea; si se cargó 3 s, daño y alcance se multiplican por `FACTOR_CARGA = 2`, golpea **alrededor** con `golpearAlrededor` (cambio 38) y Link gira mostrando `ataque-recargado-<dir>` en las cuatro direcciones. |
| `AtaquePorProyectil` | Template Method: si puede atacar, crea proyectiles, los ubica y los agrega al juego. Los pasos `puedeAtacar`, `cantidadDeProyectiles`, `ubicar` y `alTerminar` se pueden redefinir. `ubicar` centra el cuerpo del proyectil en el centro del atacante. `puedeAtacar` pide que pasó el intervalo, que Link está enfrente y, desde el cambio 29, que no hay roca, agua ni vacío en el medio (`!hayObstaculoHastaJugador()`). |
| `AtaqueRafaga` | Defensa 7 (cambio 41). Hereda de `AtaquePorProyectil`. La usa el StoneHinox para lanzar rocas: tira **de a una** (`cantidadDeProyectiles()` devuelve 1), separadas por `intervalo` (400 ms), hasta completar `cantidad` (3). Cuenta las que lleva en `# lanzados` (lo suma el gancho `alTerminar`) y `puedeAtacar` es `lanzados < cantidad && pasoElIntervalo()`: no pide que Link esté alineado. `+ reiniciar()` pone `lanzados` y `ultimoAtaque` en 0; el StoneHinox la llama cada vez que elige este ataque. Cada roca sale hacia el lado de Link (`direccionHaciaJugador()`) en el momento del disparo. |
| `AtaqueAvalancha` | Hereda de `AtaquePorProyectil`. Cuando el jefe llega al centro (su centro contra el del sector, con `TOLERANCIA_CENTRO = 4`), hace caer de `ROCAS_MINIMAS = 5` a `ROCAS_MAXIMAS = 10` rocas, ubicando el cuerpo de cada una. |
| `DefensaPorEscudo` | Bloquea el daño (todo, o solo el de frente); si no bloquea, delega en una defensa normal. |

## 7. Paso 7 y 8: Proyectil, enemigos y jefes

`Proyectil` es una entidad animada con `VIDA = 1`, movimiento recto a `VELOCIDAD = 6` px y defensa invulnerable.
Desaparece al chocar con un bloqueo o al salir del sector, y con `setDestino` puede ir hacia un punto (las rocas de la
avalancha). Al llegar a ese punto queda `aterrizada` y desaparece a los `PERMANENCIA_EN_PISO = 3000` ms (lo
programa en su `actualizarEstado`), así las rocas no se acumulan. No redefine `esquivaVacios()` ni `esFrenadoPorPersonajes()`, así que solo lo frenan la roca y el agua: pasa
por encima del vacío y llega hasta Link o el enemigo, donde el choque lo resuelve el Visitor.

El constructor recibe `lado`, el lado de su cuerpo cuadrado, centrado en la imagen. Las constantes son
`LADO_IMAGEN = 48`, `LADO_DISPARO = 30` (disparo del Octorok y del Wizzrobe, que se ve de 30 × 30) y
`LADO_ROCA_GRANDE = 48`. `FabricaEntidades` pasa la que corresponde.

Después vienen los enemigos. `Enemigo` es la base: recibe la espada pasando por su defensa, al morir se elimina y avisa a
la partida (`EntornoJuego`), y `vigilarJugador()` es un gancho vacío. Desde la defensa 7 también responde las preguntas
del bloqueo: `bloqueaPasoA(quien)` devuelve `quien.esFrenadoPorPersonajes()`, y `esquivaVacios()` y
`esFrenadoPorPersonajes()` devuelven `true`. Así un enemigo frena a Link y a otros enemigos, y no cae al vacío. Si sale
del sector, retrocede `DISTANCIA_RETROCESO = 8` px y da la vuelta.

`EnemigoConDrop` suma el premio: al morir, con cierta probabilidad suelta una rupia (`PROBABILIDAD_RUPIA = 0.5`) o un
corazón. De ahí salen los seis enemigos comunes y los dos jefes:

| Clase | Resumen | Puntos / drop |
|---|---|---|
| `Moblin` | 2 golpes, camina al azar a 2 px, lastima al tocar. Camina con un GIF y, al morir, muestra una nube 300 ms antes de desaparecer (cambio 34) | 100 / 20 % |
| `MoblinConEspadaYEscudo` | Escudo contra la espada de frente; si ve a Link enfrente **y no hay roca, agua ni vacío en el medio**, se prepara 300 ms, sale acelerando hasta 3 px, se abalanza 1600 ms y frena caminando derecho 500 ms (cambios 27 y 28), una vez por vez (`abalanzandose`, cambio 26) | 300 / 50 % |
| `ErizoDeMar` | 1 golpe, quieto, lastima al tocar. Al morir, la nube 300 ms (cambio 48) | 50 / 20 % |
| `Octorok` | 1 golpe, camina al azar, dispara cada 2 s si Link está enfrente **y no hay roca, agua ni vacío en el medio** (cambio 29). Al morir, la nube 300 ms (cambio 48) | 150 / 40 % |
| `Wizzrobe` | 2 golpes, se teletransporta cada 3 s y dispara hacia Link si está enfrente y no hay obstáculos en el medio (cambio 29). Al recibir un golpe queda quieto e invulnerable **1 s** (parpadeando) y después vuelve a teletransportarse. Al saltar muestra un GIF de desaparecer (el cuerpo parpadea y el gorrito sube) y al llegar uno de aparecer (cambio 30). Al morir, la nube 300 ms, sin teletransportarse (cambio 48) | 500 / 100 % |
| `TrampaDeCuchillas` | Indestructible y quieta. Si Link queda en su fila o columna sin obstáculos en el medio, sale a 8 px **hasta donde estaba Link** y vuelve despacio, a 4 px. Si choca antes, vuelve desde ahí | 0 / no suelta |
| `MasterStalfos` | Jefe de 5 golpes; alterna cada 2 s espada y contacto; invulnerable 800 ms tras un golpe (parpadeando); camina y golpea con GIFs en las 4 direcciones (cambio 44); al morir muestra su animación de muerte 1,53 s antes de desaparecer (cambio 47) | 5000 / no suelta |
| `StoneHinox` | Jefe de 10 golpes; encadena al azar embestida, lanzar rocas (3 rocas de a una, cada 400 ms, con `AtaqueRafaga`, cambio 41) y avalancha. Cambia de imagen: golpea el suelo al hacer la avalancha y se pone naranja mientras está vulnerable (cambio 20); todas sus imágenes son GIF animados: camina, embiste con pasos rápidos (atributo `embistiendo`), queda vulnerable en naranja y levanta los brazos para golpear el suelo (cambio 50). Al morir, la nube agrandada (96 × 96) 300 ms (cambio 48) | 5000 / no suelta |

**Constantes con nombre (defensa 7).** Cada enemigo declara sus números como constantes de clase: `VIDA`, `PUNTOS`,
`PROBABILIDAD_DROP`, `DANIO_CONTACTO`, `VELOCIDAD`, `INTERVALO_CAMBIO_DIRECCION`, `INTERVALO_DISPARO`,
`DURACION_INVULNERABILIDAD`, etc. Por ejemplo:

```java
public class Moblin extends EnemigoConDrop {
    private static final int VIDA = 2;
    private static final int PUNTOS = 100;
    private static final double PROBABILIDAD_DROP = 0.2;
    private static final int DANIO_CONTACTO = 1;
    protected static final int VELOCIDAD = 2;                      // la usa MoblinConEspadaYEscudo
    protected static final long INTERVALO_CAMBIO_DIRECCION = 1500; // también
    private static final int CUERPO_MARGEN_X = 4;
    private static final int CUERPO_MARGEN_Y = 4;
    private static final int CUERPO_ANCHO = 40;
    private static final int CUERPO_ALTO = 40;

    public Moblin(Sprite sprite, int x, int y) {
        super(sprite, x, y, VIDA);
        setCuerpo(CUERPO_MARGEN_X, CUERPO_MARGEN_Y, CUERPO_ANCHO, CUERPO_ALTO);
        setMovimiento(new MovimientoAleatorio(VELOCIDAD, INTERVALO_CAMBIO_DIRECCION));
        setAtaque(new AtaquePorContacto(DANIO_CONTACTO));
        setDefensa(new DefensaLimitada(DefensaLimitada.SIN_LIMITE, DefensaLimitada.SIEMPRE));
    }
    ...
}
```

**Muerte animada de los enemigos (cambios 34 y 48).** Ningún enemigo desaparece en el mismo instante en que muere:
se queda quieto e invulnerable mostrando su animación de muerte y recién después desaparece. El cambio 34 lo hizo solo
para el Moblin; desde el cambio 48 está en `Enemigo` y lo heredan todos (la trampa de cuchillas no muere). Es un
**Template Method**: `morir()` es el algoritmo fijo y `desaparecer()` es el gancho que cada rama redefine.

```java
// Enemigo
protected void morir() {
    if (!muriendo) {
        muriendo = true;
        cancelarProgramadas();                                      // ninguna acción pendiente lo mueve
        setMovimiento(new MovimientoInducido((Direccion) null, 0)); // quieto
        setDefensa(new DefensaLimitada(0, DefensaLimitada.SIEMPRE)); // invulnerable
        setAtaque(new AtaquePorContacto(0));                        // no dispara ni golpea
        notificarObservers();                                       // la vista muestra la muerte
        programar(getDuracionMuerte(), this::desaparecer);
    }
}

protected void desaparecer() {          // Enemigo: eliminar y sumar los puntos
    eliminar();
    miJuego.enemigoDerrotado(this);
}
```

| Clase | `desaparecer()` | Duración y GIF de muerte |
|---|---|---|
| `Enemigo*` | `eliminar()` y `enemigoDerrotado(this)` | `DURACION_MUERTE` = 300 ms y el estado `muerte` del sprite |
| `EnemigoConDrop*` | Lo mismo y, si no apareció la bellota, `soltarDrop()` | Heredada. Moblin, Octorok, Erizo y Wizzrobe usan la misma nube (`<nombre>-muerte.gif`, 48 × 48, 2 cuadros de 150 ms); el Moblin con espada y escudo, la suya de 126 × 126 |
| `Jefe*` | `eliminar()` y `jefeDerrotado(this)` | El StoneHinox usa la nube agrandada (96 × 96, 300 ms). El MasterStalfos redefine `getDuracionMuerte()` (1530 ms) y su `getRutaImagen()` usa `muerte-<dir>` (cambio 47) |

Mientras `muriendo`:

- `colisionarCon(Link)` no llama a la estrategia de ataque: no lastima a Link aunque lo toque.
- El ataque pasa a `AtaquePorContacto(0)`: el Octorok, el Wizzrobe y el StoneHinox no disparan, y el MasterStalfos no golpea con la espada (su `AtaqueEspada` ya no se usa).
- `getRutaImagen()` de `Enemigo` devuelve el estado `muerte`. El Wizzrobe y el StoneHinox redefinen `getRutaImagen()`, así que miran `muriendo` antes que sus otras imágenes (aparecer, desaparecer, vulnerable, avalancha).
- El `if (!muriendo)` es una protección: si `morir()` se llamara dos veces, la segunda no vuelve a programar `desaparecer()`, que sumaría los puntos dos veces. Hasta el cambio 46 se escribía `if (muriendo) return;` (ver la sección 10, "Sin `return` anticipado").
- `alSerGolpeado()`: el golpe que lo mata llama a `morir()` y después a `alSerGolpeado()` (ver `EntidadAnimada.recibirDanio`). Los que lo redefinen (Wizzrobe y MasterStalfos) ponen su cuerpo dentro de `if (!muriendo)`, así no parpadean, ni se teletransportan, ni vuelven a ser vulnerables durante la animación.

El `MovimientoInducido` con dirección `null` y velocidad 0 es la forma de dejar quieta una entidad que ya usa el
proyecto (Link al caer al vacío, el Moblin con escudo antes de abalanzarse). El cast `(Direccion) null` elige el
constructor `(Direccion, int)` en vez de `(Posicion, int)`.

**Cuerpos de los enemigos.** En la defensa 6 solo los jefes tenían cuerpo propio. En la defensa 7 todos los enemigos lo
tienen, ajustado al dibujo (margen X, margen Y, ancho, alto):

| Clase | Imagen | Cuerpo |
|---|---|---|
| `Moblin` | 48 × 48 | 4, 4, 40, 40 |
| `MoblinConEspadaYEscudo` | 126 × 126 (cambio 35; en el 19 era 96 × 96 con 28, 28) | 43, 43, 40, 40 |
| `Octorok` | 48 × 48 | 4, 4, 40, 40 |
| `Wizzrobe` | 48 × 48 | 4, 2, 40, 44 |
| `ErizoDeMar` | 48 × 48 | 8, 8, 32, 32 |
| `TrampaDeCuchillas` | 48 × 48 | 8, 8, 32, 32 |
| `MasterStalfos` | 171 × 216, dibujada 12 px a la izquierda y 36 px arriba (cambio 44) | 13, 12, 117, 120 |
| `StoneHinox` | 96 × 96 | 6, 4, 84, 88 (en la defensa 6 era `CUERPO_LADO = 96`) |

`MasterStalfos.quiereAtacar()` mira si Link toca la zona de su espada (`ALCANCE_ESPADA = 40`), la misma que corta el
golpe. El `StoneHinox`, en la embestida y al ir al centro, apunta con su centro (al de Link o al del sector), usando
`posicionParaCuerpoEn`.

**La trampa de cuchillas (defensa 7).** Antes se teletransportaba de vuelta a su lugar, y si Link seguía en línea salía de
nuevo sin que se la viera volver. Ahora:

```java
protected void vigilarJugador() {
    boolean enReposo = getX() == posicionOriginal.getX() && getY() == posicionOriginal.getY();
    if (enReposo && getHitbox().estaEnLineaCon(miJuego.getJugador().getHitbox()) && !hayObstaculoHastaJugador()) {
        Direccion d = direccionHaciaJugador();
        Posicion posicionDeLink = miJuego.getJugador().getPosicion();
        int destinoX = d.getDx() != 0 ? posicionDeLink.getX() : getX();
        int destinoY = d.getDy() != 0 ? posicionDeLink.getY() : getY();
        destino = new Posicion(destinoX, destinoY);       // hasta donde estaba Link, sobre su línea
        setDireccion(d);
        setMovimiento(new MovimientoInducido(d, VELOCIDAD_SALIDA));      // sale a 8 px
    } else if (destino != null && llegoAlDestino()) {
        volver();
    }
}

private void volver() {
    destino = null;
    setMovimiento(new MovimientoInducido(posicionOriginal, VELOCIDAD_VUELTA)); // vuelve a 4 px
}
```

Si choca antes de llegar, `alChocarConBloqueo()` también llama a `volver()`. Es Strategy: la trampa no tiene un `if`
sobre su estado de movimiento, cambia de estrategia.

**GIFs del MasterStalfos (cambio 44).** Camina con `masterstalfos-<dir>.gif` (3 cuadros de 200 ms, en bucle) y golpea
con `masterstalfos-ataque-<dir>.gif` (4 cuadros, 750 ms, sin repetir). Igual que Link (ver la sección de `Link`), usa un
contador de vueltas: `ataqueRealizado()` lo pone en `VUELTAS_IMAGEN_GOLPE = 25` (25 × 30 ms = 750 ms) y guarda la
dirección en `direccionGolpe`; `actualizarEstado` lo descuenta y avisa a la vista al llegar a 0; y `getRutaImagen()`
devuelve `ataque-<direccionGolpe>` mientras el contador es mayor que 0. Se guarda la dirección porque el jefe puede girar
en medio del golpe (`MovimientoAleatorio` cambia cada 1,2 s) y el GIF se cortaría. Los GIFs miden 171 × 216 para que entren
la espada levantada y el arco, así que `getXImagen()` y `getYImagen()` corren la imagen `MARGEN_IMAGEN_X = 12` y
`MARGEN_IMAGEN_Y = 36`; el cuerpo no se mueve.

**Muerte del MasterStalfos (cambios 47 y 48).** Usa la muerte animada de `Enemigo` (ver "Muerte animada de los
enemigos", más arriba) con su propio GIF y su propia duración: `masterstalfos-muerte-<dir>.gif` (171 × 216, sin repetir)
durante `DURACION_MUERTE` = 1530 ms. El GIF muestra el cuadro de golpeado parpadeando (480 ms), el esqueleto desarmado
en el piso (450 ms) y la nube de muerte agrandada (600 ms).

| Miembro | Qué hace |
|---|---|
| `# getDuracionMuerte() : long` | Redefine el de `Enemigo`: devuelve 1530 ms, lo que dura su GIF |
| `+ getRutaImagen()` | Mientras `muriendo` (heredado de `Enemigo`), devuelve `muerte-` + la dirección en que mira |
| `# alSerGolpeado()` | Su cuerpo va dentro de `if (!muriendo)`: sin eso, la muerte parpadearía y a los 800 ms volvería a la defensa normal |

Al terminar, `Jefe.desaparecer()` hace `eliminar()` y `miJuego.jefeDerrotado(this)`, que suma los 5000 puntos y pasa
de nivel o termina la partida. Por eso el cambio de nivel llega 1,5 s después del último golpe.

```java
public void ataqueRealizado() {
    if (vueltasMostrandoGolpe == 0) {
        vueltasMostrandoGolpe = VUELTAS_IMAGEN_GOLPE;
        direccionGolpe = getDireccion();
        notificarObservers();
    }
}

public String getRutaImagen() {
    String ruta = null;
    if (vueltasMostrandoGolpe > 0)
        ruta = sprite.getRuta("ataque-" + direccionGolpe.name().toLowerCase());
    return ruta != null ? ruta : super.getRutaImagen();
}
```

## 8. El ataque por contacto (defensa 6)

Hasta la defensa 5, el daño por tocar a un enemigo lo guardaba el propio enemigo (`danioContacto`) y lo aplicaba Link.
En la defensa 6 eso se invirtió: el Visitor detecta el choque y la estrategia de ataque decide qué pasa.

Qué modifiqué en mis clases:

- `Enemigo` ya no tiene `danioContacto` ni `getDanioContacto()`; su constructor es `(sprite, x, y, vida)` y ahora
  redefine `colisionarCon(Link)`, que delega en `ataque.ataqueAlContactar(this, l)`. `EnemigoConDrop` y `Jefe`
  perdieron el parámetro también.
- El daño vive en `AtaquePorContacto(danio)`: Moblin, erizo y trampa usan 1; la embestida de StoneHinox usa 2.
- `AtaqueEspada` y `AtaquePorProyectil` suman un `ataqueAlContactar` vacío (lo heredan `AtaqueRecargado` y
  `AtaqueAvalancha`): tocar a quien usa espada o proyectiles no lastima.
- Octorok y Wizzrobe no lastiman al tocar; solo lastiman sus proyectiles (decisión del equipo).
- `MasterStalfos` alterna cada 2 segundos entre dos estrategias: `faseEspada()` (`AtaqueEspada`) y
  `faseContacto()` (`AtaquePorContacto(1)`), encadenadas con `programar()`. Es Strategy cambiando en tiempo de ejecución.

**Lo que cambió en la defensa 7.** Con `bloqueaPasoA`, Link y los enemigos se frenan al chocarse y ya no llegan a
superponerse. Para que el daño por contacto siga funcionando, `AdministradorColisiones.mover`, cuando algo frena el paso,
dispara a mano el choque: `bloqueo.aceptarColision(e)`. Y `Link.colisionarCon(Enemigo e)`, que en la defensa 6 estaba
vacío, ahora hace `e.colisionarCon(this)`. Así el daño termina siempre en el mismo lugar, la estrategia del enemigo, sea
quien sea el que caminó contra el otro:

```
Moblin camina contra Link (HiloMundo):
  mover(moblin) -> buscarBloqueo devuelve link -> link.aceptarColision(moblin)
    -> moblin.colisionarCon(link) -> ataque.ataqueAlContactar(moblin, link) -> link.recibirDanio(1, dir)

Link camina contra el Moblin (HiloJugador):
  mover(link) -> buscarBloqueo devuelve moblin -> moblin.aceptarColision(link)
    -> link.colisionarCon(moblin) -> moblin.colisionarCon(link) -> ataque.ataqueAlContactar(moblin, link) -> ...
```

Si los dos se empujan en la misma vuelta, el segundo golpe no hace nada: Link queda invulnerable 1 s después del
primero.

## 9. La hitbox con margen (defensa 6) y los cuerpos ajustados (defensa 7)

**El problema:** la vista dibuja cada imagen en la esquina de la entidad, y hasta la defensa 5 la hitbox era siempre de
48 × 48 en esa misma esquina. Fallaba cuando el dibujo no ocupa la imagen: Link atravesaba casi todo el Master Stalfos
(144 × 144) y el StoneHinox (96 × 96), y el disparo del Octorok (30 × 30 visibles) lo lastimaba a 9 px de distancia.

**La solución:** separar dónde se dibuja la entidad (`getX()`, `getY()`) de qué parte choca (`getHitbox()`). Cada
clase declara su cuerpo con `setCuerpo(...)` y constantes de clase; por defecto es 48 × 48 sin margen. Es una regla del
juego, así que el cuerpo no sale de `FabricaSprites`: es igual en los dos dominios.

En la defensa 6 se ajustaron los power-ups, el proyectil y los jefes. En la defensa 7 se ajustaron también Link, los seis
enemigos comunes, la roca y la caída al vacío (las tablas de las secciones 4 y 7). El caso que más se notaba era el
vacío: Link caía apenas tocaba el borde transparente de la imagen.

`AdministradorColisiones` no cambia por esto: ya comparaba hitboxes, y esas hitboxes son los cuerpos.

## 10. Sin `return` anticipado (cambio 46)

Ningún método del proyecto corta con `return;` en el medio. Cuando un método no tiene que hacer nada en cierto caso, el
cuerpo va dentro de un `if` con la condición para hacerlo, y el método tiene una sola salida, al final:

```java
// antes                            // ahora
if (muriendo)                       if (!muriendo) {
    return;                             muriendo = true;
muriendo = true;                        ...
...                                 }
```

| Método | Condición del `if` | Para qué |
|---|---|---|
| `Link.alSerGolpeado()` | `!muriendo` | No parpadear ni restaurar la defensa durante la animación de muerte |
| `Link.morir()`, `Enemigo.morir()` | `!muriendo` | Si se llamara dos veces, la segunda no vuelve a programar la muerte |
| `Link.caerAlVacio()` | `!cayendo` | Pisar otra caída mientras cae no le saca otra vida |
| `AtaquePorProyectil.atacar(...)` | `puedeAtacar(atacante)` | Disparar solo si pasó el intervalo y Link está enfrente |
| `AtaqueRecargado.atacar(...)` | `atacante.soltoElAtaque()` | Golpear recién al soltar A |
| `GUI.procesarTecla(...)` | `controlJugador != null` | Ignorar las teclas si no hay partida en curso (todavía no empezó o ya terminó, cambio 51) |
| `CeldaGrafica.actualizar()` | `getParent() != null`, y adentro `estaEliminada()` | Ignorar celdas viejas; quitar la celda o `redibujar()` |
| `PanelPantallaNivel.desplazar(d)` | En el `for`: `!Thread.currentThread().isInterrupted()` | Cortar la animación si interrumpen el hilo |


---

*Integrante 2*

# Niveles, fábricas y recursos

Proyecto Zelda: Link's Awakening · Defensa 7 · Integrante 2

## 1. Visión general: qué hace esta parte y cómo encaja

El Integrante 2 arma el escenario del juego. Lee los niveles desde archivos de texto, crea las entidades con sus
imágenes (con dos dominios gráficos intercambiables) y guarda los rankings en disco.

| Paquete | Clases |
|---|---|
| `logica.util` | `Posicion`, `Direccion` |
| `logica.fabricas` | `Sprite`, `FabricaSprites*`, `FabricaSpritesOriginal`, `FabricaSpritesAlternativa`, `FabricaEntidades` |
| `logica.mapa` | `Sector`, `Escena`, `Nivel`, `GeneradorNivel` y el documento `Formateo-de-niveles.pdf` |
| `logica.juego` | `Ranking`, `EntradaRanking`, `PersistenciaRanking` |
| `Recursos/` | `Niveles/` (`nivel1.txt`, `nivel2.txt`), `Imagenes/original/`, `Imagenes/alternativa/` |

Requisitos del enunciado que cubre:

- **Estructura de paquetes:** `logica.mapa`, `logica.fabricas`, `logica.juego` y `logica.util`, con los mismos
  atributos y métodos que el diagrama extendido.
- **Carga de niveles desde archivo:** `GeneradorNivel` lee `nivel1.txt` y `nivel2.txt`. El formato está documentado
  en `Formateo-de-niveles.pdf`, dentro del paquete `logica.mapa`.
- **Dos dominios gráficos:** el menú elige `FabricaSpritesOriginal` o `FabricaSpritesAlternativa`, y la lógica no
  cambia.

**Lo que cambió en la defensa 7 en esta parte:**

| Cambio | Clases |
|---|---|
| El archivo del nivel dice el lado de la celda (`CELDAS 32 22 24`): celdas de 24 px para ubicar las entidades | `GeneradorNivel` |
| Niveles 1 y 2 de cuatro sectores en fila, con un solo jefe al final de cada uno | `nivel1.txt`, `nivel2.txt` |
| Imágenes nuevas y corregidas (roca sin fondo, Wizzrobe por dirección, ataque y escudo de Link, ataque del MasterStalfos) | `FabricaSprites*`, `Recursos/Imagenes/` |
| `FabricaEntidades` ve la partida como `EntornoJuego` y no como `Juego` | `FabricaEntidades` |
| Constantes con nombre para los daños de los proyectiles | `FabricaEntidades` |
| `Ranking.insertar` guarda un solo puntaje por nombre | `Ranking` |
| `Sector.getCentro()` es de instancia en el extendido (estaba subrayado por error) | `Sector` (solo el diagrama) |

## 2. Detalle de clases por paquete

### 2.1 Paquete `logica.util`

**`Direccion` (enum).** Los cuatro sentidos de movimiento: `ARRIBA`, `ABAJO`, `IZQUIERDA` y `DERECHA`. Cada valor
guarda su desplazamiento (`dx`, `dy`): `ARRIBA` es `(0, -1)` y `DERECHA` es `(1, 0)`.

| Miembro | Qué hace |
|---|---|
| `+ getDx() : int`, `+ getDy() : int` | El desplazamiento en x y en y (-1, 0 o 1) |
| `+ opuesta() : Direccion` | La dirección contraria. La usan el cambio de sector y el retroceso de los enemigos |

**`Posicion`.** Un punto `(x, y)` en píxeles dentro del sector. `(0, 0)` es la esquina de arriba a la izquierda. Es
inmutable: moverse devuelve una posición nueva.

| Miembro | Qué hace |
|---|---|
| `- x : int`, `- y : int` | Las coordenadas (`final`) |
| `+ Posicion(x : int, y : int)` | Constructor |
| `+ getX() : int`, `+ getY() : int` | Consultas |
| `+ desplazada(d : Direccion, pasos : int) : Posicion` | La posición corrida `pasos` píxeles hacia `d` |
| `+ distancia(otra : Posicion) : double` | Distancia en línea recta. La usa `AtaqueAvalancha` para saber si el jefe llegó al centro |
| `+ direccionHacia(otra : Posicion) : Direccion` | Hacia dónde está el otro punto, por el eje en que está más lejos. Con esto los enemigos miran a Link |

### 2.2 Paquete `logica.fabricas`

Separa qué es cada entidad (la lógica) de qué imagen tiene (el dominio gráfico).

**`Sprite`.** El juego de imágenes de una entidad: un mapa de estado a ruta.

| Miembro | Qué hace |
|---|---|
| `# rutas : Map<String, String>` | Cada estado (`"abajo"`, `"ataque-abajo"`, `"escudo-izquierda"`, `"muerte"`, `"normal"`) con su ruta en el classpath |
| `# estadoActual : String` | El estado que se muestra. El primero que se agrega queda como actual |
| `+ agregar(estado, ruta)` | Registra un estado |
| `+ setEstado(estado)` | Cambia el estado, solo si existe |
| `+ getRutaActual() : String` | La ruta del estado actual |
| `+ getRuta(estado) : String` | La ruta de cualquier estado, o `null` si no existe. La usan `Link` y `MasterStalfos` para la imagen del ataque |
| `+ tieneEstado(estado) : boolean` | Si el estado existe |

**`FabricaSprites*` (abstracta).** Es el Abstract Factory de las imágenes. Tiene un método `crearSpritesX()` por cada
entidad (22 en total) y un método plantilla:

```java
protected Sprite armar(String nombre, String... estados) {
    Sprite s = new Sprite();
    for (String estado : estados)
        s.agregar(estado, carpeta() + "/" + nombre + "-" + estado + ".png");
    return s;
}

protected abstract String carpeta();
```

Ejemplos de lo que arma cada `crearSpritesX()`:

| Método | Estados |
|---|---|
| `crearSpritesLink()` | `abajo`, `arriba`, `izquierda`, `derecha`, `ataque-<dir>` (GIF del golpe, cambio 39), `ataque-recargado-<dir>`, `escudo-<dir>`, `caida` y las 16 de caminata `caminar-[escudo-|ataque-|recargado-]<dir>` (cambio 36) (defensa 7: los estados de escudo y de ataque recargado son nuevos; cambio 31: `caida` es el GIF `link-caida.gif`) |
| `crearSpritesWizzrobe()` | `abajo`, `arriba`, `izquierda`, `derecha` (defensa 7: antes pedía `wizzrobe-normal.png`, que no existe) y `aparecer-<dir>` y `desaparecer-<dir>`, que son GIF (cambio 30), y `muerte` (`wizzrobe-muerte.gif`) (cambio 48) |
| `crearSpritesMasterStalfos()` | `new Sprite()` con `agregar`: `<dir>` con `masterstalfos-<dir>.gif` y `ataque-<dir>` con `masterstalfos-ataque-<dir>.gif` (cambio 44), y `muerte-<dir>` con `masterstalfos-muerte-<dir>.gif` (cambio 47) |
| `crearSpritesStoneHinox()` | `normal`, `embestida`, `vulnerable`, `avalancha` y `muerte`, todos con `stonehinox-<estado>.gif` a 96 × 96 (cambios 20, 48 y 50) |
| `crearSpritesOctorok()`, `crearSpritesErizoDeMar()` | las direcciones (o `normal`) y `muerte` (`octorok-muerte.gif`, `erizodemar-muerte.gif`) (cambio 48) |
| `crearSpritesMoblin()` | `abajo`, `arriba`, `izquierda`, `derecha`, que son GIF de caminar (2 cuadros de 250 ms), y `muerte` (`moblin-muerte.gif`) (cambio 34) |
| `crearSpritesMoblinConEspadaYEscudo()` | las 4 direcciones, que son GIF de caminar de 126 × 126 (cambio 35), y `muerte` (`moblinconespadayescudo-muerte.gif`, 126 × 126) (cambio 34) |
| `crearSpritesRoca()`, etc. | `normal` |

**`FabricaSpritesOriginal` y `FabricaSpritesAlternativa`.** Solo redefinen `carpeta()`:
`"/Recursos/Imagenes/original"` y `"/Recursos/Imagenes/alternativa"`. Por eso cada imagen tiene que estar en las dos
carpetas.

**`FabricaEntidades`.** Crea las entidades de la lógica, les da su `Sprite` (de la fábrica de sprites que se eligió en
el menú) y les pasa el entorno de la partida.

| Miembro | Qué hace |
|---|---|
| `# fabricaSprites : FabricaSprites` | El dominio gráfico elegido |
| `# entorno : EntornoJuego` | Defensa 7: antes era `# juego : Juego`. Es lo que la fábrica le pasa a cada entidad con `setJuego(entorno)` |
| `+ FabricaEntidades(entorno : EntornoJuego, fabricaSprites : FabricaSprites)` | Constructor. `Juego` lo llama con `this` |
| `+ crearLink(x, y) : Link` | Crea a Link y le pone el escudo en el inventario |
| `+ crearMoblin(x, y) : Moblin`, … | Un `crearX(x, y)` por entidad: 22 en total |
| `+ crearProyectil(x, y, d, danio) : Proyectil` | Disparo con el daño que recibe y cuerpo `Proyectil.LADO_DISPARO` |
| `+ crearRocaGrande(x, y, d, danio) : Proyectil` | Roca del StoneHinox con el daño que recibe y cuerpo `Proyectil.LADO_ROCA_GRANDE` |

**Quién decide el daño (cambio 42).** La fábrica no guarda daños: los decide el enemigo que dispara, en su `generarProyectil()`, igual que cada enemigo decide su daño por contacto. `Octorok` y `Wizzrobe` tienen `- DANIO_DISPARO : int = 1` (medio corazón) y `StoneHinox` tiene `- DANIO_ROCA : int = 2` (1 corazón, como su `DANIO_EMBESTIDA`). Por ejemplo, el Octorok hace `crearProyectil(getX(), getY(), getDireccion(), DANIO_DISPARO)`. `Proyectil` guarda el daño en `# danio` y `Link.colisionarCon(Proyectil)` lo aplica con `recibirDanio(p.getDanio(), p.getDireccion())`.

Los obstáculos (roca, agua, pasto, vacío y suelo quebradizo) no reciben el entorno, porque nunca avisan nada a la
partida.

Con `EntornoJuego` la fábrica ya no importa `logica.juego.Juego`. Solo ve lo que necesitan las entidades: los avisos,
`agregarEntidad`, `getFabricaEntidades()` y `getJugador() : Entidad`.

### 2.3 Paquete `logica.mapa`

**`Sector`.** Una pantalla del juego, de 768 × 528 píxeles. Guarda todas sus entidades en una sola lista.

| Miembro | Qué hace |
|---|---|
| `+ ANCHO : int = 768`, `+ ALTO : int = 528` | Tamaño de la pantalla (32 × 22 celdas de 24 px, o 16 × 11 entidades de 48 px) |
| `# entidades : List<Entidad>` | Todo lo que hay en el sector, fijo o animado |
| `# fila : int`, `# columna : int` | Dónde está en la escena |
| `+ agregar(e)` | Agrega la entidad y le avisa en qué sector está (`setSector`). Es `synchronized` |
| `+ quitar(e)`, `+ retirar(e)` | La saca. `quitar` lo usa `eliminar()`; `retirar` lo usa `Juego` para mover a Link de sector |
| `+ actualizarEntidades(c)` | Le pide a cada entidad no eliminada `actualizarPorMundo(c)`. Lo llama `HiloMundo` en cada vuelta |
| `+ getEntidades() : List<Entidad>` | Una **copia** de la lista, para recorrerla sin trabar a los otros hilos |
| `+ posicionLibreAlAzar(ancho, alto) : Posicion` | Busca, en hasta 200 intentos, un lugar donde entre un cuerpo de ese tamaño sin tocar a nadie. Si no encuentra, devuelve el centro |
| `+ getCentro() : Posicion` | El centro del sector. Es de instancia (en el extendido de la defensa 6 estaba subrayado por error; se corrigió en la defensa 7) |

**`Escena`.** La grilla de sectores de un nivel.

| Miembro | Qué hace |
|---|---|
| `# sectores : Sector[][]`, `# filas`, `# columnas` | La grilla |
| `+ agregarSector(fila, columna, s)` | Ubica un sector, si la posición existe |
| `+ getSector(fila, columna) : Sector` | El sector, o `null` si está fuera de la grilla |
| `+ getVecino(s, d) : Sector` | El sector de al lado en la dirección `d`, usando `d.getDx()` y `d.getDy()`. Devuelve `null` en el borde del mapa |

**`Nivel`.** Junta la escena, los jefes y dónde arranca Link.

| Miembro | Qué hace |
|---|---|
| `# mapa : Escena`, `# jefes : List<Jefe>` | La escena y los jefes que hay que derrotar |
| `# filaInicial`, `# columnaInicial`, `# posicionInicial : Posicion` | Sector y lugar donde aparece Link |
| `+ getSectorInicial() : Sector`, `+ getPosicionInicial() : Posicion`, `+ getMapa() : Escena`, `+ getJefes()` | Consultas |
| `+ jefesDerrotados() : boolean` | `true` si todos los jefes fueron eliminados |

**`GeneradorNivel`.** Lee el archivo del nivel y arma el `Nivel` con sus sectores y entidades.

| Miembro | Qué hace |
|---|---|
| `- LADO_ENTIDAD : int = 48` | Defensa 7: reemplaza a `CELDA = 48`. Ahora solo sirve para buscar lugar a los fragmentos de corazón. El lado de la celda se lee del archivo |
| `# carpetaNiveles : String` | `"/Recursos/Niveles/"` |
| `+ generar(numero, fabrica) : Nivel` | Lee `nivel<numero>.txt` y arma el nivel |
| `- leerArchivo(numero) : List<String>` | Lee las líneas con `getResourceAsStream` (funciona igual en el IDE y en el `.jar`) y saltea las vacías |
| `- crearEntidad(simbolo, x, y, fabrica) : Entidad` | Traduce un carácter a un `fabrica.crearX(x, y)` |
| `- colocarFragmentosDeCorazon(e, fabrica)` | Elige 4 sectores al azar y pone un fragmento en un lugar libre de cada uno |

### 2.4 Paquete `logica.juego` (ranking)

**`EntradaRanking`.** Un renglón del ranking: `# nombre : String` y `# puntaje : int`, con sus consultas.

**`Ranking`.** Los 5 mejores puntajes de un modo, ordenados de mayor a menor.

| Miembro | Qué hace |
|---|---|
| `- MAXIMO : int = 5` | Cuántas entradas guarda |
| `# entradas : List<EntradaRanking>` | La lista ordenada |
| `+ entraEnTop5(puntaje) : boolean` | `true` si hay menos de 5 o si supera al último |
| `+ insertar(e) : boolean` | Defensa 7: un solo puntaje por nombre (ver abajo) |
| `+ getEntradas()` | Una copia de la lista |
| `+ cantidad() : int` | Cuántas hay |

`insertar` en la defensa 7:

1. Si el nombre ya está (se distinguen mayúsculas y minúsculas) con un puntaje **igual o mayor**, no se guarda y
   devuelve `false`.
2. Si estaba con un puntaje menor, se quita la entrada vieja.
3. Si el puntaje no entra en el top 5, devuelve `false`.
4. La nueva se inserta en su lugar, recorriendo la lista hasta el primer puntaje menor (ya no se ordena la lista entera).
5. Si quedan más de 5, se quita la última.

```java
public boolean insertar(EntradaRanking e) {
    EntradaRanking mismoJugador = null;
    for (EntradaRanking existente : entradas)
        if (existente.getNombre().equals(e.getNombre()))
            mismoJugador = existente;
    if (mismoJugador != null) {
        if (mismoJugador.getPuntaje() >= e.getPuntaje())
            return false;
        entradas.remove(mismoJugador);
    }
    if (!entraEnTop5(e.getPuntaje()))
        return false;
    int posicion = 0;
    while (posicion < entradas.size() && entradas.get(posicion).getPuntaje() >= e.getPuntaje())
        posicion++;
    entradas.add(posicion, e);
    if (entradas.size() > MAXIMO)
        entradas.remove(MAXIMO);
    return true;
}
```

**`PersistenciaRanking`.** Guarda y lee cada ranking en un archivo de texto, una línea `nombre;puntaje` por entrada.

| Miembro | Qué hace |
|---|---|
| `+ guardar(r, archivo)` | Escribe el archivo. Si el nombre tiene `;`, lo cambia por un espacio |
| `+ cargar(archivo) : Ranking` | Lee el archivo. Si no existe, devuelve un ranking vacío; si está dañado, avisa y sigue con lo que pudo leer |

`Juego` usa los archivos `ranking0.txt` (Clásico), `ranking1.txt` (Contrarreloj) y `ranking2.txt` (NoHit).

## 3. Patrones de diseño

| Patrón | Dónde | Para qué |
|---|---|---|
| Abstract Factory | `FabricaSprites*` y sus dos subclases | Cambiar el dominio gráfico sin tocar la lógica |
| Template Method | `armar(...)` en `FabricaSprites*`, con el paso `carpeta()` | El armado de las rutas es siempre igual; solo cambia la carpeta |
| Factory | `FabricaEntidades` | Un solo lugar crea las entidades y les conecta el sprite y el entorno |
| Doble despacho | `ModoJuego*` y `TablaRankings` | Cada modo elige su ranking sin `instanceof` (sección 5) |

## 4. Carga de un nivel

```
Juego.cargarNivel()
  └─ generadorNivel.generar(numeroNivel, fabricaEntidades)
       ├─ leerArchivo: getResourceAsStream("/Recursos/Niveles/nivel1.txt")
       ├─ cabeceras: MAPA, CELDAS, INICIO
       ├─ por cada SECTOR: new Sector(f, c) y una entidad por carácter
       │     'S' y 'H' → jefes (se guardan en la lista de jefes)
       │     el resto → crearEntidad(simbolo, x, y, fabrica)
       ├─ colocarFragmentosDeCorazon
       └─ new Nivel(escena, jefes, filaInicial, columnaInicial, posicionInicial)
```

### Formato del archivo de nivel (defensa 7)

```
MAPA 1 4
CELDAS 32 22 24
INICIO 0 0 4 10
SECTOR 0 0
..............................T.
................................
..............V.....O...........
...                (22 líneas de 32 caracteres)
SECTOR 0 1
...
```

| Línea | Qué dice |
|---|---|
| `MAPA <filas> <columnas>` | Tamaño de la grilla de sectores. `MAPA 1 4` son cuatro sectores en fila |
| `CELDAS <ancho> <alto> <lado>` | Defensa 7: cada sector tiene 32 × 22 celdas de 24 px. Antes eran 16 × 11 de 48 px |
| `INICIO <fila> <columna> <x> <y>` | Sector donde arranca Link y su celda. La posición en píxeles es `x * lado`, `y * lado` |
| `SECTOR <fila> <columna>` | Empieza un sector. Lo siguen `alto` líneas de `ancho` caracteres |

Cada carácter distinto de `.` crea una entidad con su esquina en `x = columna * lado`, `y = fila * lado`. **Las celdas
sirven solo para ubicar.** Las entidades siguen midiendo 48 px (o más, los jefes) y se mueven en píxeles. Con celdas de
24 px se pueden poner las cosas en medias posiciones, por ejemplo una roca entre dos columnas de 48.

| Símbolo | Entidad | Símbolo | Entidad |
|---|---|---|---|
| `R` | Roca | `O` | Octorok |
| `A` | Agua | `T` | Trampa de cuchillas |
| `P` | Pasto | `W` | Wizzrobe |
| `V` | Caída al vacío | `S` | MasterStalfos (jefe) |
| `Q` | Suelo quebradizo | `H` | StoneHinox (jefe) |
| `M` | Moblin | `$` | Rupia |
| `N` | Moblin con espada y escudo | `C` | Corazón |
| `E` | Erizo de mar | `X` | Espada |
| `.` | Nada | | |

Un símbolo desconocido corta la carga con un `IllegalArgumentException`, para que el error se vea enseguida.

### Los niveles de la defensa 7

`nivel1.txt` y `nivel2.txt` tienen cuatro sectores en fila (`MAPA 1 4`). Link arranca en el sector 0 0.

| Sector | Nivel 1 | Nivel 2 |
|---|---|---|
| 0 0 a 0 2 | 4 enemigos comunes y una trampa por sector, rotando Moblin, Moblin con espada y escudo, Erizo, Octorok y Wizzrobe. Además rocas, agua, pasto, vacíos, suelos quebradizos, una rupia y un corazón | Igual, con otro reparto de enemigos |
| 0 0 | La espada en el piso (`X`), cerca de donde arranca Link | Sin espada: Link la trae del nivel 1 |
| 0 3 | MasterStalfos solo, en el centro | StoneHinox solo, en el centro |

Cada nivel tiene un solo jefe, como pide el enunciado. Al derrotarlo se pasa de nivel o termina la partida. Además, el
generador reparte 4 fragmentos de corazón en sectores al azar.

## 5. El ranking y el doble despacho con los modos

Hay un ranking por modo de juego, y los tres viven en `Juego` (`# rankings : Ranking[3]`). Desde la defensa 7, los modos
no reciben el `Juego` entero sino la interfaz `TablaRankings`, que solo tiene los métodos de los rankings:

```java
public interface TablaRankings {
    void agregarAlRankingClasico(EntradaRanking e);
    void agregarAlRankingContrarreloj(EntradaRanking e);
    void agregarAlRankingNoHit(EntradaRanking e);
    Ranking getRankingClasico();
    Ranking getRankingContrarreloj();
    Ranking getRankingNoHit();
}
```

1. **Consultar el ranking.** Al terminar la partida, `Juego` llama a `modoJuego.getRanking(this)`, pasándose como
   `TablaRankings`. El modo activo responde con el suyo; por ejemplo, `Contrarreloj` hace
   `t.getRankingContrarreloj()`.
2. **¿Entra en el top 5?** `Juego` pregunta `ranking.entraEnTop5(puntaje)`. Si entra, le pide el nombre a la vista
   (`controladorGrafico.pedirNombre(puntaje)`); si no, muestra el ranking.
3. **Guardar.** Con el nombre, `Juego` llama a `modoJuego.registrarPuntaje(this, entrada)`. El modo hace
   `t.agregarAlRankingContrarreloj(e)`, y `Juego` inserta en `rankings[1]` y, si entró, guarda `ranking1.txt`.

Así no hay `instanceof` ni `if` sobre el modo: cada modo sabe cuál es su ranking.

## 6. Recursos gráficos

Las imágenes son PNG con fondo transparente, en `Recursos/Imagenes/original/` y `Recursos/Imagenes/alternativa/`, con
los mismos nombres en las dos carpetas (58 en cada una). El nombre es `<entidad>-<estado>.png`, en minúsculas y con
guiones:

| Entidad | Archivos |
|---|---|
| Link (48 × 48) | `link-abajo.png`, …, `link-ataque-abajo.gif`, … (GIF de 156 × 150 con el golpe del juego original, cambio 39), `link-ataque-recargado-abajo.png`, …, `link-escudo-abajo.png`, …; caminando: `link-caminar-abajo.gif`, `link-caminar-escudo-abajo.gif`, `link-caminar-ataque-abajo.gif`, `link-caminar-recargado-abajo.gif`, … (cambio 36, 150 ms por cuadro); `link-caida.gif` (cambio 31), `link-muerte.gif` (última vida, cambio 43) y `link-pierde-vida.gif` (le quedan vidas, cambio 45) |
| Enemigos con dirección | `moblin-<dir>`, `moblinconespadayescudo-<dir>` (GIF de 126 × 126 con espada y escudo, cambio 35), `octorok-<dir>`, `wizzrobe-<dir>` |
| MasterStalfos (171 × 216) | `masterstalfos-<dir>.gif` (caminar) y `masterstalfos-ataque-<dir>.gif` (golpe de espada), cambio 44; `masterstalfos-muerte-<dir>.gif` (muerte), cambio 47 |
| StoneHinox (96 × 96) | `stonehinox-normal.gif` (camina, 2 × 300 ms), `stonehinox-embestida.gif` (pasos rápidos, 2 × 110 ms), `stonehinox-vulnerable.gif` (naranja, 2 × 300 ms), `stonehinox-avalancha.gif` (brazos arriba y golpe al suelo, 150 + 450 ms, sin repetir) y `stonehinox-muerte.gif` (cambio 50) |
| Resto | `<nombre>-normal.png`: `roca`, `agua`, `pasto`, `vacio`, `suelo-quebradizo`, `rupia`, `corazon`, `bellota`, `fragmentodecorazon`, `espada`, `escudo`, `erizodemar`, `trampadecuchillas`, `proyectil`, `rocagrande` |

En la defensa 7, `roca-normal.png` pasó a tener el fondo transparente (tenía un fondo amarillo), y se agregaron las
imágenes de escudo de Link, de espada y escudo en el piso y las del ataque del MasterStalfos (con el cambio 44, los GIFs de
caminar y de golpe).

`Formateo-de-niveles.pdf` está en `src/logica/mapa/`, junto al generador, como pide el enunciado.

---

*Integrante 3*

# Vista y modos del juego

Defensa 7 · Integrante 3 · Qué hace cada una de mis 17 clases, cómo está programada y cómo funciona

## 1. Qué hace mi parte y cómo encaja en el juego

Mi parte tiene dos trabajos. El primero es la **vista**: dibujar en pantalla lo que pasa en el juego (el nivel, las
entidades y el HUD de Link) y mandarle al juego lo que hace el jugador (teclas y botones). El segundo son los **modos de
juego** (Clásico, Contrarreloj y NoHit): las reglas que cambian según lo que se elija en el menú.

La idea central es que la vista nunca conoce a `Link`, a `Juego` ni a ninguna entidad concreta. Solo conoce
interfaces. Eso separa las capas: la lógica no sabe que existe Swing, y la vista no sabe cómo está hecha la lógica.

La información viaja en dos sentidos:

- **Del jugador a la lógica:** una tecla llega a `GUI.procesarTecla`, que llama a `ControlJugador` (que realiza
  `Link`). Un clic en Jugar llega a `ControladorJuego.iniciar`.
- **De la lógica a la pantalla:** cuando una entidad cambia, avisa a su `Observer` (una `CeldaGrafica`). Cuando `Juego`
  necesita algo más (limpiar la escena, mostrar el tiempo, pedir el nombre), usa `ControladorGrafico`, que realiza
  `GUI`.

| Paquete | Clases |
|---|---|
| `principal` | `Principal` |
| `vista` | `GUI`, `Ventana`, `PanelVista*`, `PanelPantallaPrincipal`, `PanelPantallaRanking`, `PanelPantallaNivel`, `CeldaGrafica`, `CeldaJugador`, `AnimadorTransicion`, `ControladorDeVistas` |
| `logica` | `Observer`, `ControladorGrafico` |
| `logica.juego` | `ModoJuego*`, `Clasico`, `Contrarreloj`, `NoHit` |

**Lo que cambió en la defensa 7 en mi parte:**

| Cambio | Clases |
|---|---|
| **Dibujo por capas:** cada entidad dice en qué capa va y el panel la ubica según ese número | `PanelPantallaNivel` (usa `EntidadLogica.getCapa()`) |
| **Parpadeo:** la celda se muestra u oculta según `esVisible()` de la entidad | `CeldaGrafica` |
| **Estilo nuevo de las pantallas:** colores como constantes, HUD con corazones y tiempo `mm:ss`, menú y ranking rediseñados | `GUI`, `PanelVista*`, los tres paneles |
| **Los modos reciben interfaces chicas** en vez del `Juego` entero: `TablaRankings` para el ranking y `ArbitroPartida` para terminar la partida | `ModoJuego*`, `Clasico`, `Contrarreloj`, `NoHit` |
| Constante `CANTIDAD_NIVELES = 2` en cada modo | `Clasico`, `Contrarreloj`, `NoHit` |
| En el extendido, `getRanking` de los tres modos ya no va en cursiva (no es abstracto en ellos) | solo el diagrama |

## 2. Cuatro ideas que sostienen todo el código

### 2.1 Interfaces como contratos entre capas

`Observer`, `ControladorGrafico` y `ControladorDeVistas` son interfaces. Gracias a eso `Juego` solo ve un
`ControladorGrafico` (no ve la clase `GUI`), y los paneles solo ven un `ControladorDeVistas` (no ven `GUI` ni `Juego`).
Se pueden cambiar las clases de la vista sin tocar la lógica.

La misma idea se usa ahora del lado de los modos: un modo no ve el `Juego`, sino solo `TablaRankings` y
`ArbitroPartida`, las dos cosas que necesita (principio de segregación de interfaces).

### 2.2 Patrón Observer

Cada entidad de la lógica tiene una lista de observadores. Cuando cambia (se mueve, la eliminan, Link suma una rupia,
parpadea) llama a `notificarObservers()`, que ejecuta `actualizar()` en cada uno. En la vista el observador es la
`CeldaGrafica`. La entidad no sabe qué hace la celda con el aviso: solo avisa. Así se logra el "mapeo 1 a 1" entre
entidad lógica y entidad gráfica.

### 2.3 El hilo de Swing (EDT) e `invokeLater`

Swing solo se puede tocar desde un hilo especial, el EDT (Event Dispatch Thread). Pero la lógica corre en otros hilos
(`HiloJugador`, `HiloMundo`, `Reloj`) y es quien llama a la vista. Por eso, cada vez que un hilo de la lógica pide un
cambio de pantalla, el cambio se mete dentro de `SwingUtilities.invokeLater(...)`, que lo encola para que lo ejecute el
EDT. Además `invokeLater` respeta el orden de llegada, y eso se aprovecha (ver `CeldaGrafica`).

### 2.4 Polimorfismo en lugar de `instanceof`

El enunciado prohíbe `instanceof` y `getClass()` para decidir. Los modos de juego lo resuelven con herencia: `Juego` le
avisa a su `ModoJuego` "empezó un nivel", "Link recibió daño", "pasó un segundo", y cada modo reacciona a su manera sin
que `Juego` pregunte de qué modo se trata. Las capas de dibujo también: cada entidad responde su `getCapa()`, sin que la
vista pregunte qué es.

## 3. Los contratos

### `Observer` (`logica`)

Tiene un único método, `actualizar()`. Lo realiza `CeldaGrafica` y lo referencia `Entidad*` (`#observadores 0..*`).

### `ControladorGrafico` (`logica`)

Lo que la lógica le puede pedir a la vista. Lo realiza `GUI` y lo referencia `Juego`.

| Método | Cuándo lo llama `Juego` |
|---|---|
| `mostrarEntidad(e) : Observer` | Por cada entidad al activar un sector y por cada entidad nueva |
| `mostrarJugador(j) : Observer` | Al activar un sector |
| `limpiarEscena()` | Antes de mostrar un sector |
| `transicion(d)` | Al cambiar de sector |
| `actualizarTiempo(segundos)` | Cada segundo |
| `actualizarNivel(numero)` | Al cargar un nivel |
| `terminarControl()` | Al terminar la partida, después de frenar los hilos (cambio 51) |
| `pedirNombre(puntaje)` | Al terminar, si el puntaje entra al top 5 |
| `mostrarRanking(r, nombreModo)` | Al terminar la partida |

Los dos primeros devuelven un `Observer`: `Juego` lo registra en la entidad para que la entidad pueda avisarle a su
celda.

### `ControladorDeVistas` (`vista`)

Lo que los paneles le pueden pedir a la navegación: `mostrarPantallaPrincipal()`, `mostrarPantallaRanking(m)` e
`iniciarPartida(modo, dominio)`. Lo realiza `GUI`. Los paneles guardan una referencia a este contrato
(`#controladorVistas`), así cambian de pantalla sin conocer a `GUI` ni a `Juego`.

### `EntidadLogica` y `EntidadJugador` (`logica`, del Integrante 1)

Es lo que la vista ve de una entidad. Desde la defensa 7 tiene, además de posición, imagen y si fue eliminada:

- `getCapa() : int`, con las constantes `CAPA_SUELO = 0`, `CAPA_OBJETOS = 1`, `CAPA_OBSTACULOS = 2`,
  `CAPA_PERSONAJES = 3` y `CAPA_JUGADOR = 4`.
- `esVisible() : boolean`, que es `false` en los instantes apagados de un parpadeo.

`EntidadJugador` la extiende con lo que muestra el HUD: vidas, corazones, corazones máximos, puntaje, rupias y objeto
equipado.

## 4. Arranque y ventana

### `Principal`

Es la clase con `main`. Hace cuatro cosas, todas dentro de `invokeLater` para que Swing nazca en el EDT:

```java
GUI gui = new GUI();
Juego juego = new Juego(gui);        // Juego conoce a la vista como ControladorGrafico
gui.setControladorJuego(juego);      // la vista conoce a Juego como ControladorJuego
gui.mostrarPantallaPrincipal();
```

El orden importa. `Juego` necesita la vista en su constructor, y la vista necesita a `Juego`, pero uno de los dos tiene
que existir primero. Por eso la `GUI` se crea primero y recibe a `Juego` después por un setter. Así se rompe la
dependencia circular. `Principal` es la única clase que conoce a `Juego` con su tipo concreto.

### `Ventana`

Hereda de `JFrame`. En el constructor pone el título, `EXIT_ON_CLOSE` y no redimensionable. Su único método,
`mostrarPanel(p)`, cambia el panel visible: `setContentPane(p)`; la primera vez además hace `pack()` (ajusta el tamaño al
del panel), `setLocationRelativeTo(null)` (centra) y `setVisible(true)`; siempre termina con `revalidate()` y
`repaint()`. Como los tres paneles miden lo mismo, la ventana no cambia de tamaño al navegar.

### `GUI`

Es la fachada de la capa gráfica. Realiza dos interfaces y por eso tiene tres tipos de métodos:

- **Constructor.** Crea la `Ventana` con el título *"The Legend of Zelda: Link's Awakening"* (defensa 7) y los tres
  paneles pasándose a sí misma (`this`) como `ControladorDeVistas`, y registra un `KeyEventDispatcher` global. Se eligió
  un dispatcher y no un `KeyListener` porque el `KeyListener` deja de funcionar si el foco pasa a otro componente (por
  ejemplo un botón). El dispatcher devuelve `false` para que el evento siga su camino normal.
- **Métodos de `ControladorDeVistas`** (los llaman los paneles, en el EDT). `mostrarPantallaRanking(m)` le pide el
  ranking a `Juego` con `getRanking(m)` y el nombre con `m.getNombre()`. `iniciarPartida` hace tres cosas en este orden:
  muestra el panel del nivel, le pide a `Juego` que inicie y recién después pide `getControlJugador()`. El orden es
  porque el panel debe estar listo antes de que lleguen las primeras entidades, y Link se crea dentro de `iniciar`
  (antes de eso sería `null`).
- **Métodos de `ControladorGrafico`** (los llama la lógica, desde otros hilos). Todos meten el cambio de Swing en
  `invokeLater`. `mostrarEntidad` es especial: crea la `CeldaGrafica` en el momento (para poder devolverla como
  `Observer` enseguida) pero la agrega al panel mediante `invokeLater`. `transicion(d)` arranca un `Thread` con un
  `AnimadorTransicion`. `pedirNombre` abre un `JOptionPane` y, si el jugador cancela o deja vacío, registra
  "Anónimo". `terminarControl()` (cambio 51) es lo opuesto de `iniciarPartida`: pone `controlJugador = null` y las
  cuatro flechas en `false`. No usa `invokeLater` porque no toca Swing, solo atributos de la `GUI`.

`procesarTecla(codigo, presionada)` traduce el teclado a acciones de `ControlJugador`. Las flechas (cambio 49) solo
anotan si están apretadas en `arribaPresionada`, `abajoPresionada`, `izquierdaPresionada` y `derechaPresionada`; después
Link se mueve hacia una que siga apretada (en ese orden) o, si no queda ninguna, `detenerMovimiento()` (que avisa a la
vista para que Link pase al PNG quieto, cambio 36). Así, si se mantiene → y se toca y suelta ↑, Link sigue hacia la
derecha. `iniciarPartida` pone las cuatro en `false` para no arrastrar flechas de antes. A ataca (y `soltarAtaque()` al soltar); S usa el escudo (y `soltarEscudo()`
al soltar); D cambia de objeto (solo al apretar). Si no hay partida en curso (`controlJugador == null`) no hace nada:
antes de la primera partida y después de `terminarControl()`.

**Por qué `terminarControl()` (cambio 51).** Antes, cuando Link moría del todo, `Juego` frenaba los hilos pero la `GUI`
le seguía mandando las teclas al Link muerto: no avanzaba (su hilo estaba detenido), pero cada tecla le cambiaba la
imagen, giraba, sacaba la espada o levantaba el escudo, incluso mientras se escribía el nombre del ranking y en el menú,
hasta empezar otra partida. Ahora `Juego.terminarPartida()` le avisa a la vista y la `GUI` suelta el control. Queda
simétrico: `iniciarPartida` toma el control del Link nuevo y `terminarControl` lo suelta. Sirve para cualquier forma de
terminar (sin vidas, Contrarreloj, NoHit o ganar el último nivel), porque todas pasan por `terminarPartida()`.
Estas llamadas corren en el EDT, así que tienen que ser cortas: Link solo anota la intención y el trabajo real lo hace
`HiloJugador` en su próxima vuelta.

## 5. Los paneles

### `PanelVista*` (abstracta)

Hereda de `JPanel`. Guarda el `controladorVistas`, fija el tamaño preferido (`Sector.ANCHO` × `Sector.ALTO` más 56 px de
franja para el HUD; en la defensa 6 eran 40) y llama a `armarComponentes()`, que cada panel hijo implementa. Es un caso
de **Template Method**: la base fija los pasos y los hijos completan uno.

**Defensa 7: colores del estilo nuevo.** `PanelVista*` declara cuatro constantes que usan los tres paneles, así el
estilo se cambia en un solo lugar:

| Constante | Color | Para qué |
|---|---|---|
| `# COLOR_FONDO : Color` | azul muy oscuro (`#141C2B`) | Fondo de las pantallas |
| `# COLOR_SUPERFICIE : Color` | azul oscuro (`#222D42`) | Botones, HUD y tabla |
| `# COLOR_DORADO : Color` | dorado (`#E0B84C`) | Títulos, bordes y lo elegido |
| `# COLOR_TEXTO : Color` | blanco hueso (`#EEEADC`) | Texto |

Son `protected static final`, así que en el extendido van subrayadas.

**Trampa clásica de Java:** `armarComponentes()` se ejecuta desde el constructor de la clase base, antes de que se
inicialicen los atributos del hijo. Por eso en los hijos los atributos se asignan dentro de `armarComponentes()` y no en
su declaración. Si se escribiera `private JLabel titulo = new JLabel()` se pisaría el valor, y si se usara antes de
tiempo daría `NullPointerException`.

### `PanelPantallaPrincipal` (el menú)

Tiene dos atributos: `dominio` (la `FabricaSprites` elegida) y `modo` (el `ModoJuego` elegido). Arrancan en Original y
Clásico.

`armarComponentes()` crea los botones: dos de dominio (Original / Alternativo) y tres de modo (Clásico / Contrarreloj /
NoHit) como `JToggleButton` dentro de un `ButtonGroup` (así solo uno queda marcado), más JUGAR y VER RANKING. Cada botón
tiene un *listener* en forma de lambda que llama al método correspondiente.

- `elegirDominio(d)` y `elegirModo(m)` solo guardan la elección. Al elegir Contrarreloj se crea
  `new Contrarreloj(120)`.
- `jugar()` llama a `controladorVistas.iniciarPartida(modo, dominio)` y `verRanking()` a
  `controladorVistas.mostrarPantallaRanking(modo)`.

**Estilo de la defensa 7:** título "THE LEGEND OF ZELDA / LINK'S AWAKENING" en dorado; botones con borde dorado, y el
elegido relleno de dorado (un `ItemListener` repinta cada botón al cambiar la selección); debajo de los modos, una
descripción del modo elegido ("Superá los dos niveles y derrotá a sus jefes.", "Tenés 120 segundos por nivel.", "Un
solo golpe y la partida termina."); y al pie una línea de ayuda con las teclas. Los componentes se acomodan con un
`GridBagLayout`, uno por fila.

Es aceptable que este panel conozca las tres clases concretas de modo, porque es justamente la vista la que ofrece los
botones. Para agregar un modo nuevo basta una subclase de `ModoJuego` y un botón.

### `PanelPantallaRanking`

Tiene un `JTable` (`tabla`) y un `JLabel` (`titulo`). `mostrarRanking(r, nombreModo)` pone el título ("RANKING
CLASICO"), arma un `DefaultTableModel` con las columnas PUESTO / NOMBRE / PUNTAJE, recorre `r.getEntradas()` agregando
una fila por entrada y se lo asigna a la tabla. Si el ranking está vacío, agrega la fila "Todavía no hay puntajes". La
tabla se deshabilita (`setEnabled(false)`) para que sea solo de lectura. `volver()` llama a
`mostrarPantallaPrincipal()`.

**Estilo de la defensa 7:** el encabezado es dorado, las filas alternan dos tonos y el puesto de los tres primeros va en
dorado, plata y bronce. Lo hace un `DefaultTableCellRenderer` propio.

### `PanelPantallaNivel` (la pantalla de juego)

Es el más importante de la vista. Tiene una lista `celdas` y seis `JLabel` del HUD (nivel, tiempo, puntaje, vidas,
rupias, objeto).

- **Layout nulo** (`setLayout(null)`): cada celda se ubica con `setBounds(x, y, ancho, alto)` en píxeles, los mismos
  que usa la lógica. Por eso el juego trabaja en píxeles. El fondo es verde, el suelo del sector.
- **HUD:** las seis etiquetas van en un `JPanel` con `GridLayout(2, 3)` ubicado debajo del sector (en
  `y = Sector.ALTO`), con fondo `COLOR_SUPERFICIE` y una línea dorada arriba.
- **`agregarCelda(c)` por capas (defensa 7).** En Swing, dentro de un mismo panel, el componente de índice más bajo se
  dibuja arriba. Antes se hacía `add(c, 0)`: la última celda agregada quedaba siempre arriba, y por eso un enemigo
  agregado antes que una roca quedaba debajo de ella. Ahora cada celda va debajo de las que tienen una capa mayor:

```java
public void agregarCelda(CeldaGrafica c) {
    int capa = c.entidadObservada.getCapa();
    int celdasQueLaTapan = 0;
    for (CeldaGrafica otra : celdas)
        if (otra.entidadObservada.getCapa() > capa)
            celdasQueLaTapan++;
    celdas.add(c);
    add(c, celdasQueLaTapan);   // índice = cantidad de celdas que deben quedar encima
    c.actualizar();
    repaint();
}
```

  Así el orden es siempre suelo (agua, pasto, vacío, suelo quebradizo) → objetos y power-ups → rocas → enemigos, jefes y
  proyectiles → Link, sin importar en qué orden se agregaron.

- `quitarCelda(c)` la saca de la lista y del panel. `limpiar()` quita todas, recorriendo una copia de la lista para no
  modificarla mientras se recorre.
- **`actualizarHUD(j)` (defensa 7).** Lee de `EntidadJugador` vidas, corazones (en medios corazones), puntaje, rupias y
  objeto equipado. Los corazones se dibujan: llenos en rojo, el medio en rosa y los vacíos en gris, hasta
  `getCorazonesMaximos() / 2`. Cada etiqueta se arma con la consulta de clase
  `- etiqueta(titulo : String, valor : String) : String`, que pone el título en dorado y el valor en negrita (es HTML
  de Swing).
- `actualizarTiempo(s)` muestra el tiempo como `mm:ss` y `actualizarNivel(n)` el número de nivel.
- `desplazar(d)` hace la animación de cambio de sector: 30 pasos con una pausa de 15 ms cada uno (unos 450 ms). En cada
  paso calcula cuánto correr (`-d.getDx() * getWidth() * paso / pasos`) y, dentro de un `invokeLater`, reubica todas
  las celdas en su posición de dibujo (`getXImagen()`, `getYImagen()`) más ese desplazamiento. El `Thread.sleep` va fuera del `invokeLater` y corre en el
  hilo del animador: si se durmiera el EDT, la ventana se congelaría.

## 6. Las celdas y la animación

### `CeldaGrafica`

Hereda de `JLabel` y realiza `Observer`. Es la imagen de una entidad en el panel. Guarda la entidad observada
(`EntidadLogica`) y el panel donde está: `CeldaGrafica(e : EntidadLogica, p : PanelPantallaNivel)`, igual que en el
extendido. Su método `actualizar()` es el corazón del Observer:

1. Lo llama un hilo de la lógica, así que lo primero es hacer `invokeLater`.
2. En el EDT, solo hace algo si `getParent() != null`. Si no tiene padre, la celda es vieja (de un sector anterior que
   `limpiar()` ya sacó) y se ignora.
3. Si `estaEliminada()` es verdadero, la celda se saca del panel con `quitarCelda(this)`.
4. Si no, llama al método privado `redibujar()` (cambio 46), que mira la ruta que devuelve `getRutaImagen()`. Si cambió desde la última vez (`rutaMostrada`, cambio 30), carga
   el ícono nuevo y lo asigna con `setIcon`; si es un GIF, antes le hace `flush()`. Después se muestra u oculta con
   `setVisible(entidadObservada.esVisible())` (defensa 7, para el parpadeo) y se ubica con
   `setBounds(x, y, anchoDelIcono, altoDelIcono)` en `getXImagen()`, `getYImagen()` (defensa 7, cambio 25).

```java
public void actualizar() {
    SwingUtilities.invokeLater(() -> {
        if (getParent() != null) {
            if (entidadObservada.estaEliminada())
                panelNivel.quitarCelda(this);
            else
                redibujar();
        }
    });
}

private void redibujar() {
    String ruta = entidadObservada.getRutaImagen();
    if (!ruta.equals(rutaMostrada)) {
        ImageIcon nuevo = new ImageIcon(CeldaGrafica.class.getResource(ruta));
        if (ruta.endsWith(".gif"))
            nuevo.getImage().flush();
        setIcon(nuevo);
        rutaMostrada = ruta;
    }
    Icon icono = getIcon();
    setVisible(entidadObservada.esVisible());
    setBounds(entidadObservada.getXImagen(), entidadObservada.getYImagen(), icono.getIconWidth(), icono.getIconHeight());
}
```

Hasta el cambio 46, `actualizar()` cortaba con dos `return` (si no tenía padre y después de quitar la celda). Ahora
`actualizar()` solo decide qué hacer, y `redibujar()` tiene, sin cambios, lo que estaba después de los `return`.

El tamaño de la celda es el de la **imagen** (48 × 48, o 171 × 216 el MasterStalfos), no el del cuerpo con el que choca
la entidad. La vista dibuja la imagen entera en `getXImagen()`, `getYImagen()`; el cuerpo, más chico, lo usa solo la lógica.

**Por qué `getXImagen()` y no `getX()` (cambio 25).** Casi siempre son lo mismo. La excepción es Link atacando: sus
imágenes de ataque miden 96 × 48 o 48 × 96, con Link de un lado y la espada del otro. Hacia la derecha y hacia abajo
la espada sale para el lado en que crece la imagen, así que se dibuja en `getX()`, `getY()`. Hacia la izquierda y hacia
arriba la espada tiene que salir por delante de Link, así que `Link` corre la imagen `LARGO_IMAGEN_ESPADA = 48` px. No se
cambia `getX()`/`getY()` porque la lógica los usa para moverse y para que los jefes apunten a Link.
El MasterStalfos (cambio 44) también las redefine: sus GIFs de 171 × 216 tienen lugar para la espada levantada y el arco,
así que siempre se dibujan `MARGEN_IMAGEN_X = 12` px a la izquierda y `MARGEN_IMAGEN_Y = 36` px arriba de `getX()`, `getY()`.

**El parpadeo (defensa 7).** La lógica decide si la entidad se ve y la vista solo obedece. Mientras parpadea, la entidad
avisa a su celda en cada vuelta del hilo del mundo, y `esVisible()` alterna cada 100 ms. La celda no necesita un hilo ni
un timer propio: reutiliza el Observer que ya existía.

Detalles que conviene saber: la celda lee la entidad en el EDT, en el momento de dibujar, así que puede ver una posición
un poco más nueva que la del aviso (no importa, siempre muestra lo último). Como `invokeLater` respeta el orden, la
primera `actualizar()` siempre encuentra a la celda ya dentro del panel. Y `new ImageIcon(URL)` usa el caché interno de
Java, por lo que no vuelve a leer el archivo cuando cambia la imagen.

**Los GIF (cambio 30).** El Wizzrobe muestra GIF al teletransportarse. Un `JLabel` anima solo un GIF, pero si se le pone
un `ImageIcon` nuevo en cada actualización el GIF vuelve a empezar y nunca pasa del primer cuadro. Por eso la celda
guarda `rutaMostrada` y solo cambia el ícono cuando cambia la ruta. Como Java guarda una sola imagen por archivo, a los GIF
se les hace `flush()` al mostrarlos, para que arranquen desde el primer cuadro cada vez. A los PNG no se les hace, así
que las demás entidades se ven igual que antes.

### `CeldaJugador`

Hereda de `CeldaGrafica` y agrega `jugadorObservado` (la misma entidad, vista como `EntidadJugador`). Su `actualizar()`
hace lo de la celda común (`super.actualizar()`) y además, con otro `invokeLater`, llama a
`panelNivel.actualizarHUD(jugadorObservado)`. Así el HUD se actualiza solo cada vez que Link cambia, sin que nadie se lo
pida: eso cumple el requisito "el estado de Link se ve en todo momento".

### `AnimadorTransicion`

Realiza `Runnable`. Guarda el panel, la dirección y el `ControladorJuego`. Su `run()` hace dos cosas:
`panel.desplazar(direccion)` y, al terminar, `controlador.transicionTerminada()`, para que `Juego` active el sector
nuevo y reanude los hilos. Lo crea `GUI.transicion(d)` dentro de un `Thread` propio, porque el enunciado pide
animaciones con hilos (nunca con `Timer`).

## 7. Los modos de juego

### `ModoJuego*` (abstracta)

Guarda `cantidadNiveles`. Define el "menú" de sucesos que `Juego` puede avisar:

| Tipo | Métodos |
|---|---|
| Abstractos (cada modo los define) | `registrarPuntaje(t : TablaRankings, e : EntradaRanking)`, `getNombre() : String`, `getRanking(t : TablaRankings) : Ranking` |
| Ganchos vacíos (un gancho es un método que no hace nada para que el hijo lo redefina si le interesa) | `alIniciarNivel()`, `alRecibirDanio(a : ArbitroPartida)`, `alPasarTiempo(a : ArbitroPartida, segundos : int)` |
| Concreto | `esUltimoNivel(numero) : boolean`, que devuelve `numero == cantidadNiveles` |

**Defensa 7: interfaces chicas en vez de `Juego`.** En la defensa 6 los modos recibían `j : Juego`, y con eso podían
llamar a cualquier método público del juego (iniciar, pausar hilos, cargar niveles…). El ayudante lo marcó en la
devolución. Ahora reciben solo lo que usan:

- **`TablaRankings`** (`logica.juego`): los tres `agregarAlRankingX(e)` y los tres `getRankingX()`. La usan
  `registrarPuntaje` y `getRanking`.
- **`ArbitroPartida`** (`logica.juego`): solo `terminarPartida()`. La usan `alRecibirDanio` y `alPasarTiempo`.

`Juego` realiza las dos, así que en `Juego` las llamadas no cambian de forma: `modoJuego.alRecibirDanio(this)` pasa
`this` como `ArbitroPartida`. El compilador impide que un modo haga algo que no le corresponde.

`getRanking(t)` evita un `if` o `switch`: `Juego.getRanking(m)` le pregunta al modo y cada modo devuelve el suyo
(doble despacho).

### `Clasico`

`CANTIDAD_NIVELES = 2`. No redefine ganchos. Solo manda el puntaje al ranking clásico
(`t.agregarAlRankingClasico(e)`), se llama "Clasico" y devuelve `t.getRankingClasico()`. Se juega hasta vencer al
último jefe o quedarse sin vidas.

### `Contrarreloj`

`CANTIDAD_NIVELES = 2`. Tiene `tiempoLimite` (se pasa por constructor; el menú usa 120 segundos) y `tiempoRestante`.
`alIniciarNivel()` hace `tiempoRestante = tiempoLimite` (el tiempo es por nivel). `alPasarTiempo(a, segundos)` resta uno
y, si llega a 0 o menos, llama a `a.terminarPartida()`. También tiene `getTiempoLimite()` y `getTiempoRestante()`, y su
propio ranking.

```java
@Override
public void alPasarTiempo(ArbitroPartida a, int segundos) {
    tiempoRestante--;
    if (tiempoRestante <= 0)
        a.terminarPartida();
}
```

### `NoHit`

`CANTIDAD_NIVELES = 2`. Redefine `alRecibirDanio(a)`: el primer daño que recibe Link llama a `a.terminarPartida()`.
Tiene su propio ranking.

## 8. Recorridos completos

### Del menú al nivel

Clic en JUGAR → `PanelPantallaPrincipal.jugar()` → `GUI.iniciarPartida(modo, dominio)` → muestra el panel del nivel →
`Juego.iniciar(...)` crea a Link, los hilos y carga el nivel → por cada entidad, `Juego` llama a `GUI.mostrarEntidad`,
registra el `Observer` devuelto y la celda aparece en pantalla, en su capa → `GUI` guarda `getControlJugador()` para el
teclado.

### Un enemigo se mueve

`HiloMundo` hace avanzar al Moblin → el Moblin cambia su posición y llama a `notificarObservers()` →
`CeldaGrafica.actualizar()` (todavía en el hilo del mundo) → encola un `invokeLater` → el EDT lee `getX`, `getY`,
`getRutaImagen` y `esVisible`, hace `setIcon`, `setVisible` y `setBounds` → el panel se repinta.

### Link le pega a un Moblin y el Moblin parpadea

La espada le saca 1 de vida al Moblin (le queda 1) → `aplicarDanio` marca el fin del parpadeo en 600 ms y avisa → en
cada vuelta del hilo del mundo el Moblin vuelve a avisar → la celda hace `setVisible(esVisible())`, que alterna cada
100 ms → a los 600 ms la entidad deja de avisar y queda visible.

### Link recoge una rupia y el HUD cambia

Link suma rupias y puntos → llama a `notificarObservers()` → como su observador es una `CeldaJugador`, se ejecuta
`actualizar()`: redibuja la celda y encola `actualizarHUD(link)` → el EDT cambia las etiquetas de rupias y puntos. La
rupia, además, se elimina, y su propia celda se saca del panel.

### Una tecla

El dispatcher global (EDT) recibe `KEY_PRESSED` → `procesarTecla(codigo, true)` → `controlJugador.atacar()` (por
ejemplo) → Link solo marca que quiere atacar → en su próxima vuelta, `HiloJugador` realiza el ataque.

### Cambio de sector

Link sale del sector → `Juego` pausa los hilos y llama a `GUI.transicion(d)` → se crea un `Thread` con
`AnimadorTransicion` → `panel.desplazar(d)` anima 30 pasos → `controlador.transicionTerminada()` → `Juego` activa el
sector nuevo (`limpiarEscena()` y nuevas llamadas a `mostrarEntidad`) y reanuda los hilos.

### Fin de partida

`Juego.terminarPartida()` (una sola vez, por `partidaEnCurso`) → frena el reloj y los hilos → `terminarControl()`: la
`GUI` deja de mandarle teclas a Link (cambio 51) → si el puntaje entra al top 5, `pedirNombre(puntaje)`
abre el cuadro de diálogo → `registrarNombre(nombre)` guarda la entrada → `mostrarRanking(r, nombreModo)` muestra el
ranking del modo jugado.

## 9. Qué hilo ejecuta cada cosa

La vista no tiene `synchronized`: no lo necesita, porque todo lo que toca Swing pasa por una sola cola (la del EDT).

| Hilo | Qué corre de mi parte |
|---|---|
| EDT (Swing) | Constructores de ventana y paneles, clics de botones, `procesarTecla`, y todo lo que está dentro de un `invokeLater`: `agregarCelda`, `quitarCelda`, `limpiar`, `actualizarHUD`, `actualizarTiempo`, `actualizarNivel`, el dibujo de las celdas |
| `HiloJugador` / `HiloMundo` | Solo llaman a `Observer.actualizar()` (que apenas encola un `invokeLater`) y a `mostrarEntidad` / `mostrarJugador`. El que lastima a Link (cualquiera de los dos) termina llamando a `ModoJuego.alRecibirDanio` (NoHit) |
| `Reloj` | `GUI.actualizarTiempo` y `ModoJuego.alPasarTiempo` (descontar el segundo en Contrarreloj) |
| Hilo del animador | `PanelPantallaNivel.desplazar` (con sus `sleep`) y `transicionTerminada()` |

## 10. Preguntas probables en la defensa

**¿Por qué todo va dentro de `invokeLater`?** Porque Swing no es seguro para varios hilos y solo el EDT puede tocar sus
componentes. La lógica corre en otros hilos, así que sus pedidos se encolan para que los ejecute el EDT.

**¿Por qué `mostrarEntidad` crea la celda fuera del EDT pero la agrega con `invokeLater`?** Crear el objeto no toca la
pantalla y hay que devolverlo en el momento como `Observer`. Agregarlo al panel sí es un cambio de Swing.

**¿Qué patrón es la relación entidad–celda?** Observer. Las entidades son los sujetos y las celdas los observadores. La
entidad no conoce a la celda, solo la interfaz `Observer`.

**¿Cómo se evita `instanceof` en los modos?** Con herencia y ganchos: `Juego` avisa el suceso y cada modo lo redefine
o lo ignora.

**¿Por qué los modos reciben `TablaRankings` y `ArbitroPartida` y no `Juego`?** Porque un cliente no debería depender
de métodos que no usa. Con el `Juego` entero, un modo podía pausar hilos o cargar niveles. Con las interfaces, el
compilador solo le deja guardar o leer su ranking y terminar la partida.

**¿Cómo agregarías un modo nuevo?** Una subclase de `ModoJuego` que defina `registrarPuntaje`, `getNombre` y
`getRanking`, y un botón en `PanelPantallaPrincipal`. `Juego` no cambia, salvo que haga falta un ranking nuevo (en ese
caso se agregan sus dos métodos a `TablaRankings`).

**¿Cómo decide la vista qué se dibuja arriba?** Con la capa de cada entidad (`getCapa()`). `agregarCelda` cuenta
cuántas celdas tienen una capa mayor y agrega la nueva debajo de ellas. Antes se usaba `add(c, 0)`, que dejaba arriba la
última agregada, y un enemigo podía quedar debajo de una roca.

**¿Cómo parpadea una entidad si la vista no tiene timer?** La lógica guarda hasta cuándo parpadea y avisa en cada vuelta
del hilo del mundo. La celda solo hace `setVisible(esVisible())`. Es el Observer de siempre.

**¿Para qué sirve `getParent() != null` en `CeldaGrafica`?** Para ignorar avisos de celdas de un sector viejo (las que
`limpiar()` ya sacó), que podrían llegar tarde.

**¿Por qué un `KeyEventDispatcher`?** Para que el teclado funcione siempre, aunque el foco esté en otro componente.

**¿Por qué la animación tiene su propio hilo?** Si el `sleep` corriera en el EDT, la ventana se congelaría. Además el
enunciado pide hilos y no `javax.swing.Timer`.

**¿Por qué la vista no tiene referencia a Link?** Para respetar las capas. Solo ve `EntidadJugador` (lo que muestra el
HUD) y `ControlJugador` (lo que manda el teclado).

## 11. Qué se probó

- Las 17 clases están integradas con el código real del equipo (`Juego`, `Link`, las entidades y las imágenes de
  `FabricaSprites`), y compilan con `javac`.
- El juego se corrió en una pantalla virtual (Xvfb): el menú y el nivel 1 se ven con el estilo nuevo, con los
  corazones en el HUD.
- Con un programa de prueba sin interfaz se verificó que los tres modos terminan la partida una sola vez (por
  `ArbitroPartida`) y que cada uno usa su ranking (por `TablaRankings`).
- El constructor `CeldaGrafica(e, p)` coincide con el extendido. El límite de 120 segundos del Contrarreloj es el que
  usa el menú.

---

*Integrante 4 · logica.comportamientos*

# DefensaLimitada: explicación simple (Defensa 7)

**Paquete:** `logica.comportamientos` · **Implementa:** `ComportamientoDefensa` · **Patrón:** Strategy

## 1. Qué hace

Decide **cuánto daño recibe una entidad** cuando la golpean. La entidad no lo decide: se lo pregunta a su defensa.

Usa dos datos:

- **`danioMaximo`**: lo máximo que puede sacar un golpe.
- **`golpesRestantes`**: cuántos golpes dura ese máximo.

## 2. Los tres casos

| Caso | Cómo se crea | Qué pasa | Quién lo usa |
|---|---|---|---|
| Normal | `new DefensaLimitada(SIN_LIMITE, SIEMPRE)` | El golpe saca todo su daño | Link, Moblin, Octorok, Erizo, Wizzrobe (después de teletransportarse), MasterStalfos, StoneHinox (1 s después de la embestida), y la parte "sin escudo" de `DefensaPorEscudo` |
| Invulnerable | `new DefensaLimitada(0, SIEMPRE)` | El golpe no saca nada | Trampa y proyectiles (siempre), StoneHinox (casi siempre), Link 1 s, Wizzrobe 1 s y MasterStalfos 800 ms después de un golpe |
| Bellota | `new DefensaLimitada(DANIO_MAXIMO, GOLPES_PROTEGIDOS)`, o sea `(1, 3)` | Los próximos 3 golpes sacan como máximo medio corazón; después vuelve a ser normal | Solo Link |

**Defensa 7: los tiempos de invulnerabilidad son constantes con nombre** en cada clase (`DURACION_INVULNERABILIDAD`
en `Link`, `Wizzrobe` y `MasterStalfos`), y los de la bellota también (`Bellota.DANIO_MAXIMO = 1` y
`Bellota.GOLPES_PROTEGIDOS = 3`). `DefensaLimitada` no cambió.

## 3. Atributos

### De clase (`static`)

Pertenecen a la clase, no a cada objeto. Hay una sola copia y se usan sin crear objetos: `DefensaLimitada.SIN_LIMITE`. Son `final`, o sea, constantes.

| Atributo | Valor | Para qué sirve |
|---|---|---|
| `SIN_LIMITE` | `Integer.MAX_VALUE` | La entidad recibe **todo** el daño. Es el número más grande que entra en un `int`; como ningún golpe hace tanto daño, `Math.min` siempre devuelve el daño completo. |
| `SIEMPRE` | `-1` | La defensa **dura para siempre**. Se pone en lugar de una cantidad de golpes para que el método no descuente. Es -1 porque ninguna defensa puede durar -1 golpes. |

### De instancia

Cada objeto tiene los suyos. La defensa de Link puede tener `danioMaximo = 1` y la del Moblin `SIN_LIMITE` al mismo tiempo.

| Atributo | Para qué sirve |
|---|---|
| `danioMaximo` | Lo máximo que puede sacar un golpe. `0` = no saca nada. |
| `golpesRestantes` | Cuántos golpes más dura el máximo, o `SIEMPRE`. |

## 4. Cómo funciona recibirDanio

Usa una variable auxiliar **`recibioDanio`** para guardar el resultado y tiene **un solo `return`** al final.

1. **Arranca en `false`:** `recibioDanio = false` (todavía no se hizo daño).
2. **Calcula el daño:** `Math.min(danio, danioMaximo)` se queda con el menor de los dos.
3. **Si el daño es mayor que 0:**
   - Le resta la vida a la entidad con `aplicarDanio`.
   - Pone `recibioDanio = true`.
   - Si la defensa tiene golpes contados (`golpesRestantes != SIEMPRE`), descuenta uno.
   - Si llegó a 0, vuelve a ser normal: `danioMaximo = SIN_LIMITE` y `golpesRestantes = SIEMPRE`.
4. **Si el daño es 0** (invulnerable), no entra al `if` y `recibioDanio` sigue en `false`.
5. **Devuelve `recibioDanio`.** Si es `true`, la entidad reacciona al golpe (`alSerGolpeado`).

**Defensa 7: el parpadeo sale de acá.** `aplicarDanio` es el que, si la entidad sigue viva, la hace parpadear 600 ms.
Como `aplicarDanio` solo se llama cuando `real > 0`, un golpe frenado por el escudo o por la invulnerabilidad **no hace
parpadear**. Después, `alSerGolpeado()` de Link, Wizzrobe y MasterStalfos estira el parpadeo para que dure lo mismo que
su invulnerabilidad.

## 5. Ejemplos

**La unidad depende de quién recibe el golpe.** La clase solo trabaja con números:

- **Link:** su vida está en **medios corazones** (`vida = 6` son 3 corazones).
- **Enemigos:** su vida está en **golpes** (la espada de Link saca 1).

### Un golpe de 2 con cada defensa

| `danioMaximo` | `Math.min(2, danioMaximo)` | Daño que recibe |
|---|---|---|
| `SIN_LIMITE` | 2 | 2 (todo) |
| 1 | 1 | 1 |
| 0 | 0 | 0 (nada) |

### Bellota: Link tiene 6, el Moblin pega 2

| Golpe | Vida de Link | Golpes restantes |
|---|---|---|
| — | 6 | 3 |
| 1 | 5 | 2 |
| 2 | 4 | 1 |
| 3 | 3 | 0 → vuelve a normal |
| 4 | 1 | `SIEMPRE` |

### Link le pega al Moblin (vida 2)

`Math.min(1, SIN_LIMITE) = 1` → vida 1. Con el segundo golpe llega a 0 y muere.

## 6. Cómo maneja la bellota

Con la bellota Link **sigue recibiendo daño, pero menos**. El enunciado pide que los próximos 3 golpes saquen **como máximo medio corazón**. No lo vuelve invulnerable: solo achica los golpes fuertes.

**Paso a paso:**

1. Al agarrar la bellota se ejecuta `link.setDefensaBase(new DefensaLimitada(DANIO_MAXIMO, GOLPES_PROTEGIDOS))`, con
   `DANIO_MAXIMO = 1` y `GOLPES_PROTEGIDOS = 3`.
2. Cada golpe pasa por `Math.min(danio, 1)`: si el enemigo pega 2, Link pierde 1 en vez de 2.
3. Cada golpe que hace daño descuenta 1 de `golpesRestantes`: 3, 2, 1, 0.
4. Al llegar a 0, la misma defensa pasa a `SIN_LIMITE` y los golpes vuelven a sacar todo. Link no tiene que hacer nada.

**¿Hace daño todo el tiempo?** No.

- `recibirDanio` solo se llama cuando hay un golpe, es decir, cuando un enemigo o un proyectil choca con Link.
- Después de cada golpe Link queda **1 segundo invulnerable** (`DURACION_INVULNERABILIDAD = 1000`): `alSerGolpeado()` pone `DefensaLimitada(0, SIEMPRE)`, lo hace parpadear ese segundo y a los 1000 ms `restaurarDefensa()` vuelve a la defensa base (la bellota).
- Durante ese segundo los golpes no sacan nada y **no gastan** la bellota, porque la defensa activa es otra.

| Momento | Defensa activa | Golpe de 2 saca | Golpes de bellota |
|---|---|---|---|
| Golpe 1 | Bellota | 1 | 3 → 2 |
| Durante 1 s | Invulnerable | 0 | 2 (no gasta) |
| Golpe 2 | Bellota | 1 | 2 → 1 |
| Golpe 3 | Bellota | 1 | 1 → 0, vuelve a normal |
| Golpe 4 | Normal | 2 | — |

## 7. Código completo

```java
package logica.comportamientos;

import logica.entidades.EntidadAnimada;
import logica.util.Direccion;

/**
 * Defensa que limita el daño por golpe: normal, invulnerable o bellota, según cómo se construya.
 */
public class DefensaLimitada implements ComportamientoDefensa {

    // Atributos de clase

    public static final int SIN_LIMITE = Integer.MAX_VALUE;
    public static final int SIEMPRE = -1;

    // Atributos de instancia

    protected int danioMaximo;
    protected int golpesRestantes;

    // Constructores

    /**
     * Crea la defensa con el daño máximo por golpe y los golpes que dura.
     */
    public DefensaLimitada(int danioMaximo, int golpes) {
        this.danioMaximo = danioMaximo;
        golpesRestantes = golpes;
    }

    // Comandos

    /**
     * Aplica el daño sin pasarse del máximo y descuenta un golpe si la defensa es limitada.
     */
    @Override
    public boolean recibirDanio(EntidadAnimada e, int danio, Direccion origen) {
        boolean recibioDanio = false;
        int real = Math.min(danio, danioMaximo);
        if (real > 0) {
            e.aplicarDanio(real);
            recibioDanio = true;
            if (golpesRestantes != SIEMPRE) {
                golpesRestantes--;
                if (golpesRestantes == 0) {
                    danioMaximo = SIN_LIMITE;
                    golpesRestantes = SIEMPRE;
                }
            }
        }
        return recibioDanio;
    }

    // Consultas

    /**
     * Devuelve los golpes que le quedan, o SIEMPRE.
     */
    public int getGolpesRestantes() {
        return golpesRestantes;
    }
}
```

---

# Explicación de la clase AtaquePorContacto (Defensa 7)

Basado en los diagramas extendido y reducido de la defensa 7 (estrategia `bloqueaPasoA`) y en el código de `DEFENSA 7 FINAL/Codigo`. La clase no cambió desde la defensa 6; lo que cambió es **cómo se llega a ella** cuando Link y un enemigo se frenan al chocarse (sección 5).

## 1. Qué es

`AtaquePorContacto` es una de las estrategias de ataque del juego. Implementa la interfaz `ComportamientoAtaque` (patrón **Strategy**). Representa a los enemigos que **lastiman solo al tocar** a Link: no tiran espadazos ni proyectiles.

## 2. Por qué cambió en la Defensa 6

| | Defensa 5 | Defensa 6 |
|---|---|---|
| Atributos | Ninguno | `# danio : int` |
| Constructor | `AtaquePorContacto()` | `AtaquePorContacto(danio : int)` |
| `atacar` | Vacío | Vacío (sin cambios) |
| `ataqueAlContactar` | No existía | Aplica `tocado.recibirDanio(danio, atacante.getDireccion())` |
| Quién aplicaba el daño al tocar | El enemigo, con su propio `danioContacto` | La estrategia |

Antes la clase no hacía nada y el daño lo ponía cada enemigo. Ahora el daño al tocar es **responsabilidad de la estrategia**. Por eso:

- El nombre de la clase ya no confunde: es la que hace el daño al tocar.
- Los enemigos no necesitan `danioContacto`.
- Un enemigo puede lastimar o no al tocar según la estrategia que tenga en ese momento. Por ejemplo, el MasterStalfos la cambia con `setAtaque` y el StoneHinox la usa solo mientras embiste.

## 3. Miembros

### Atributo

| Miembro | Visibilidad | Para qué |
|---|---|---|
| `danio : int` | `#` protegido | Daño que recibe la entidad tocada, en **medios corazones**: 1 es medio corazón y 2 es un corazón. Con 0 no lastima. |

### Constructor

| Miembro | Qué hace |
|---|---|
| `+ AtaquePorContacto(danio : int)` | Guarda el daño. |

### Comandos (los dos de `ComportamientoAtaque`)

| Método | Qué hace | Quién lo llama |
|---|---|---|
| `+ atacar(atacante : EntidadAnimada, c : AdministradorColisiones)` | **Nada.** Este ataque no actúa en cada vuelta: solo cuando hay contacto. | `EntidadAnimada.actualizarEstado`, en cada vuelta del hilo |
| `+ ataqueAlContactar(atacante : EntidadAnimada, tocado : EntidadAnimada)` | `tocado.recibirDanio(danio, atacante.getDireccion())` | `Enemigo.colisionarCon(Link l)` |

## 4. Código

```java
public class AtaquePorContacto implements ComportamientoAtaque {
    protected int danio;                    // en medios corazones

    public AtaquePorContacto(int danio) { this.danio = danio; }

    public void atacar(EntidadAnimada atacante, AdministradorColisiones c) { }   // nada por turno

    public void ataqueAlContactar(EntidadAnimada atacante, EntidadAnimada tocado) {
        tocado.recibirDanio(danio, atacante.getDireccion());
    }
}
```

La interfaz que implementa:

```java
public interface ComportamientoAtaque {
    void atacar(EntidadAnimada atacante, AdministradorColisiones c);
    void ataqueAlContactar(EntidadAnimada atacante, EntidadAnimada tocado);   // defensa 6
}
```

## 5. Recorrido de un choque

Desde la defensa 7, Link y los enemigos **se frenan** al chocarse (`bloqueaPasoA`): ya no llegan a superponerse. Por
eso el choque no lo encuentra `verificarColisiones` (que busca cuerpos superpuestos), sino `mover`, que al frenarse
dispara a mano el Visitor de efectos: `bloqueo.aceptarColision(e)`.

**Ejemplo 1: un Moblin camina contra Link** (hilo del mundo).

1. `HiloMundo` le pide al Moblin `actualizarEstado`, y su `MovimientoAleatorio` llama a `c.mover(moblin, d, 2)`.
2. `buscarBloqueo` encuentra a Link adelante y le pregunta `link.bloqueaPasoA(moblin)`, que devuelve
   `moblin.esFrenadoPorPersonajes()`, o sea `true`. El Moblin no avanza.
3. `mover` dispara el choque: `link.aceptarColision(moblin)` → `moblin.colisionarCon(link)` (Visitor).
4. `Enemigo.colisionarCon(Link l)` → `ataque.ataqueAlContactar(this, l)`.
5. `AtaquePorContacto.ataqueAlContactar` → `link.recibirDanio(1, direccion)`.
6. `Link.recibirDanio` (`synchronized`) le pasa el golpe a su defensa. Si el daño pasa, corta la racha, avisa
   `jugadorDaniado()` y llama a `alSerGolpeado()`, que lo deja invulnerable 1 segundo y lo hace parpadear.
7. `mover` devuelve `false` y el Moblin elige otra dirección.

**Ejemplo 2: Link camina contra el Moblin** (hilo del jugador).

1. `HiloJugador` le pide a Link `actualizarEstado`, y su `MovimientoInducido` llama a `c.mover(link, d, 4)`.
2. `buscarBloqueo` encuentra al Moblin: `moblin.bloqueaPasoA(link)` devuelve `link.esFrenadoPorPersonajes()`, `true`.
3. `mover` dispara `moblin.aceptarColision(link)` → `link.colisionarCon(moblin)`.
4. **Defensa 7:** `Link.colisionarCon(Enemigo e)` hace `e.colisionarCon(this)`, y de ahí se sigue igual que en el
   ejemplo 1, desde el paso 4.

En la defensa 6, `Link.colisionarCon(Enemigo e)` era vacío para que el daño no se aplicara dos veces. Ahora delega en el
enemigo, porque si no, Link podría caminar contra un enemigo sin recibir daño. El daño doble lo evita la invulnerabilidad
de 1 s: si los dos se empujan en la misma vuelta, el segundo golpe encuentra a Link con `DefensaLimitada(0, SIEMPRE)`.

**Enemigos quietos.** El erizo no se mueve y la trampa está quieta hasta que ve a Link. Funciona igual: el que camina es
Link (ejemplo 2), o la trampa que sale y se frena contra Link (ejemplo 1).

## 6. Quién la usa

| Entidad | Estrategia | Daño al tocar |
|---|---|---|
| Moblin, MoblinConEspadaYEscudo, ErizoDeMar, TrampaDeCuchillas | `AtaquePorContacto(DANIO_CONTACTO)`, con `DANIO_CONTACTO = 1` en cada clase | ½ corazón |
| StoneHinox, solo mientras embiste | `embestida = new AtaquePorContacto(DANIO_EMBESTIDA)`, con `DANIO_EMBESTIDA = 2` | 1 corazón |
| MasterStalfos, en su fase de contacto | `contacto = new AtaquePorContacto(DANIO_CONTACTO)`, con `DANIO_CONTACTO = 1` | ½ corazón |
| Toda `EntidadAnimada`, por defecto | `new AtaquePorContacto(0)` | No lastima |
| Octorok, Wizzrobe | `AtaquePorProyectil` (`ataqueAlContactar` vacío) | No lastiman al tocar |

### MasterStalfos: alterna dos estrategias

Cambia de estrategia en tiempo de ejecución con `setAtaque`, cada `DURACION_FASE = 2000` ms:

- `faseEspada()` → `setAtaque(espada)` con `AtaqueEspada(DANIO_ESPADA, ALCANCE_ESPADA)`, o sea `(2, 40)`. Da espadazos y no lastima al tocar, porque el `ataqueAlContactar` de `AtaqueEspada` es vacío. Desde la defensa 7, cada espadazo muestra la imagen de ataque.
- `faseContacto()` → `setAtaque(contacto)` con `AtaquePorContacto(DANIO_CONTACTO)`. No da espadazos y lastima al tocar.

El constructor llama a `faseEspada()`, y cada fase programa la siguiente con `programar`.

## 7. Patrones y decisiones

- **Strategy:** el comportamiento al tocar está en la estrategia, no en el enemigo. Cambiar `setAtaque` cambia también si lastima al tocar.
- **Visitor:** detecta **quién** chocó con **quién**, y la estrategia decide **qué** pasa.
- **`bloqueaPasoA` (defensa 7):** decide si el choque **frena**. Es una pregunta aparte del Visitor: primero se decide si se frena y, si se frena, se dispara el Visitor de efectos.
- **Sin `instanceof`:** el doble despacho y la estrategia evitan preguntar qué enemigo es (sección 8 del CONTEXTO).
- **`atacar` vacío:** no se puede sacar, porque es parte de la interfaz `ComportamientoAtaque`.

## 8. Hilos

- El choque Link–enemigo lo puede disparar cualquiera de los dos hilos: `HiloMundo` cuando camina el enemigo y `HiloJugador` cuando camina Link. Por eso `recibirDanio` y `aplicarDanio` de `EntidadAnimada` (y la redefinición en `Link`) son `synchronized`.
- `AtaquePorContacto` no guarda estado que cambie: `danio` se fija en el constructor. Por eso la clase no necesita sincronización propia.
- El orden de bloqueo es Entidad → Juego → Sector.

## 9. En los diagramas

- **Extendido:** la caja de `AtaquePorContacto` no cambia en la defensa 7: tiene `# danio : int`, `+ AtaquePorContacto(danio : int)`, `+ atacar(...)` y `+ ataqueAlContactar(...)`. En el extendido de la defensa 7, el naranja marca solo lo que cambió desde la defensa 6; acá eso está en `Link` (`colisionarCon(Enemigo)`, `bloqueaPasoA`, `esFrenadoPorPersonajes`) y en `AdministradorColisiones` (`buscarBloqueo`).
- **Reducido:** no cambia, porque no muestra métodos ni atributos y no hay clases ni relaciones nuevas.

---

# Explicación de la clase MovimientoInducido (Defensa 7)

Basado en los diagramas extendido y reducido de la defensa 7 (estrategia `bloqueaPasoA`) y en el código de `DEFENSA 7 FINAL/Codigo`.

## 1. Qué es

`MovimientoInducido` es una de las tres estrategias de movimiento. Implementa la interfaz `ComportamientoMovimiento` (patrón **Strategy**). Se llama "inducido" porque la entidad **no decide sola** hacia dónde ir: se lo indica alguien de afuera. Puede ser el teclado (Link), quien crea un proyectil o la propia entidad cuando cambia de fase (trampa, StoneHinox, Wizzrobe).

Las otras dos estrategias son:
- `MovimientoAleatorio`: elige la dirección al azar.
- `MovimientoTeletransporte`: salta a un lugar libre.

**La clase no cambió ni en la defensa 6 ni en la 7**, y en el extendido está en negro. Lo que cambió en la defensa 7 es **quién la usa**: la trampa de cuchillas vuelve a su lugar con un `MovimientoInducido` hacia su posición original, y el Wizzrobe se queda quieto un segundo después de un golpe con un `MovimientoInducido((Direccion) null, 0)`.

## 2. Miembros (según el extendido)

### Atributos

| Miembro | Tipo | Para qué | Relación en el reducido |
|---|---|---|---|
| `# direccion` | `Direccion` | Hacia dónde avanza. `null` si está quieta o va a un objetivo. Es `volatile`. | `#direccion 0..1` → `Direccion` |
| `# objetivo` | `Posicion` | A qué posición va. `null` si se mueve por dirección. | `#objetivo 0..1` → `Posicion` |
| `# velocidad` | `int` | Píxeles por vuelta del hilo. | |

### Constructores

| Constructor | Uso |
|---|---|
| `+ MovimientoInducido(d : Direccion, velocidad : int)` | Movimiento por dirección. Con `(Direccion) null` la entidad queda quieta. |
| `+ MovimientoInducido(objetivo : Posicion, velocidad : int)` | Movimiento hacia una posición fija. |

### Comandos

| Método | Qué hace | Quién lo llama |
|---|---|---|
| `+ setDireccion(d : Direccion)` | Cambia la dirección. Con `null` se detiene. | `Link.mover(d)` y `Link.detenerMovimiento()` |
| `+ mover(e : EntidadAnimada, c : AdministradorColisiones)` | Mueve la entidad una vuelta (ver sección 3). | `EntidadAnimada.actualizarEstado(c)` en cada vuelta |

### Consultas

| Método | Qué devuelve |
|---|---|
| `+ getDireccion() : Direccion` | La dirección actual. |

## 3. Cómo decide `mover`

```java
public void mover(EntidadAnimada e, AdministradorColisiones c) {
    if (objetivo != null) e.avanzarHacia(objetivo, velocidad);
    else if (direccion != null) c.mover(e, direccion, velocidad);
}
```

| Caso | Qué hace | ¿Controla bloqueos? |
|---|---|---|
| Tiene objetivo | `e.avanzarHacia(objetivo, velocidad)`: avanza en x y en y a la vez, sin pasarse del destino | **No**, a propósito |
| Tiene dirección | `c.mover(e, direccion, velocidad)` | **Sí**: lo decide `AdministradorColisiones`, que llama `alChocarConBloqueo()` si choca |
| Ninguno | Nada: queda quieta | — |

**Por qué el objetivo no controla bloqueos:** las rocas de la avalancha tienen que atravesar las rocas del borde superior al caer. La regla general es que *toda decisión de bloqueo pasa por `c.mover`* (y, desde la defensa 7, por `bloqueaPasoA`), y `avanzarHacia` es la única excepción buscada. La trampa de cuchillas también vuelve con un objetivo, así que en la vuelta no se frena: si Link se cruza, el choque lo resuelve `verificarColisiones` y lo lastima.

## 4. Quién la usa

| Entidad | Cómo la crea | Velocidad | Forma |
|---|---|---|---|
| `Link` | `caminar = new MovimientoInducido((Direccion) null, VELOCIDAD_CAMINANDO)` | 4 | Dirección, la pone el teclado |
| `Proyectil` (disparos y rocas) | `MovimientoInducido(d, VELOCIDAD)` en el constructor | 6 | Dirección |
| `Proyectil.setDestino(p)` (avalancha) | `MovimientoInducido(p, VELOCIDAD)` | 6 | Objetivo |
| `ErizoDeMar` | `MovimientoInducido((Direccion) null, VELOCIDAD)` | 0 | Quieto |
| `TrampaDeCuchillas` (en reposo y al salir) | `((Direccion) null, VELOCIDAD_SALIDA)`; al ver a Link `(d, VELOCIDAD_SALIDA)` | 8 | Quieta / dirección |
| `TrampaDeCuchillas` (al volver, defensa 7) | `MovimientoInducido(posicionOriginal, VELOCIDAD_VUELTA)` | 4 | Objetivo |
| `MoblinConEspadaYEscudo` | Al abalanzarse `MovimientoInducido(getDireccion(), VELOCIDAD_ABALANZADA)` | 3 (cambio 27; antes 6) | Dirección |
| `Wizzrobe` (al ser golpeado, defensa 7) | `MovimientoInducido((Direccion) null, 0)` durante 1 s | 0 | Quieto |
| `StoneHinox` (embestida) | `MovimientoInducido(objetivo, VELOCIDAD_EMBESTIDA)`: la posición que deja su centro sobre el centro de Link | 6 | Objetivo |
| `StoneHinox` (ir al centro) | `MovimientoInducido(objetivo, VELOCIDAD_AVALANCHA)`: la posición que deja su centro sobre el centro del sector | 3 | Objetivo |
| `EntidadAnimada*` (por defecto) | `MovimientoInducido((Direccion) null, 0)` | 0 | Quieta |

Desde la defensa 7 las velocidades son constantes de clase con nombre en cada entidad.

## 5. Link y el teclado

Link guarda la estrategia con su tipo concreto en `# caminar : MovimientoInducido`. Así le puede cambiar la dirección **sin cast** (no se permite `instanceof`):

```java
public void mover(Direccion d) {          // ControlJugador, flecha apretada
    caminar.setDireccion(d);
    setDireccion(d);                      // hacia dónde mira y el sprite
}
public void detenerMovimiento() { caminar.setDireccion(null); }   // flecha soltada
```

Recorrido: la GUI recibe la flecha (EDT) → `Link.mover(d)` → `caminar.setDireccion(d)`. Después, en la vuelta de `HiloJugador` → `actualizarEstado(c)` → `caminar.mover(link, c)` → `c.mover(link, d, 4)`.

## 6. Hilos

- `direccion` la **escribe** el EDT (teclado) y la **lee** `HiloJugador`. Por eso es `volatile`: así el hilo ve el cambio enseguida.
- `objetivo` y `velocidad` se fijan en el constructor y no cambian. No necesitan `volatile`.
- Para cambiar de forma (de quieta a objetivo, por ejemplo) se crea **otra** estrategia con `setMovimiento(new MovimientoInducido(...))`, en lugar de modificar la que hay.

## 7. Cuidados

- ⚠️ `new MovimientoInducido(null, 0)` **no compila**: `null` sirve para los dos constructores. Hay que escribir `(Direccion) null`.
- **El objetivo es la posición de la entidad (la esquina de la imagen), no la de su cuerpo** (defensa 6, hitbox con
  margen). Quien quiere llevar el cuerpo a un lugar convierte con `getHitbox().posicionParaCuerpoEn(x, y)`. Así lo
  hacen el StoneHinox (apunta con su centro) y las rocas de la avalancha (`setDestino`).
- ⚠️ El objetivo se toma **al crearla**. En la embestida, el StoneHinox va a donde **estaba** Link, no lo persigue.
- ⚠️ **Rocas de la avalancha:** como `avanzarHacia` no pasa por `c.mover`, nadie llama `alChocarConBloqueo()` al llegar al objetivo. `Proyectil` no redefine `avanzarHacia`, así que la roca **queda quieta** en su destino hasta que Link la toca: `Link.colisionarCon(Proyectil)` le saca vida y la elimina.
- **La trampa no usa el objetivo para saber si llegó** (defensa 7): sale con una dirección, y `llegoAlDestino()` compara su posición con `destino`. Recién al volver usa un objetivo.
- `getDireccion()` no tiene quién la llame en la guía (ver el informe de métodos obsoletos), pero está en el extendido y se mantiene.

## 8. Patrones y decisiones

- **Strategy:** el mismo `mover(e, c)` de la interfaz sirve para el teclado, los proyectiles y los jefes. La entidad no pregunta qué tipo de movimiento tiene.
- **Cambio en tiempo de ejecución:** `setMovimiento(...)` en `EntidadAnimada` (trampa, Moblin con escudo, Wizzrobe, StoneHinox).
- **Sin `instanceof`:** Link guarda el tipo concreto en `caminar` en vez de hacer un cast.
- **Separación con el sector:** la estrategia elige hacia dónde ir; si puede avanzar lo decide `AdministradorColisiones`, preguntándole a cada entidad de adelante `bloqueaPasoA(e)`.

## 9. En los diagramas

- **Extendido:** caja `MovimientoInducido` con los tres atributos, dos constructores, `setDireccion`, `mover` y `getDireccion`. Realiza `ComportamientoMovimiento`. En negro, porque no cambió desde la defensa 6.
- **Reducido:** aparece como una de las implementaciones de `ComportamientoMovimiento`, sin métodos, con las asociaciones a `Direccion` (`#direccion 0..1`) y a `Posicion` (`#objetivo 0..1`).

---

*Integrante 4 · logica.entidades*

# Explicación de la clase AdministradorColisiones (Defensa 7)

Basado en los diagramas extendido y reducido de la defensa 7 (estrategia `bloqueaPasoA`) y en el código de
`DEFENSA 7 FINAL/Codigo`.

**Lo que cambió en la defensa 7:** el bloqueo ya no se decide con `bloqueaPaso()`, sino con
`bloqueaPasoA(quien)`, que recibe a la entidad que camina. Con eso:

- los enemigos esquivan las caídas al vacío y Link las pisa y cae;
- Link y los enemigos se frenan al chocarse (también dos enemigos entre sí);
- cuando algo frena el paso, `mover` dispara el choque a mano (`bloqueo.aceptarColision(e)`), para que el daño por
  contacto siga funcionando aunque ya no se superpongan.

En el código, `- puedeMoverA(...) : boolean` se reemplazó por `- buscarBloqueo(...) : Entidad`, que devuelve **quién**
frena el paso (o `null`). Esta versión sigue la observación 4 del ayudante: el bloqueo es una pregunta polimórfica y no
un segundo Visitor.

---

## 1. Qué es y para qué sirve

`AdministradorColisiones` resuelve **todo lo espacial durante el movimiento**. Siempre trabaja sobre el **sector
visible**, que es la única pantalla del nivel que se está jugando. Contesta cuatro preguntas:

| Pregunta | Método | Cuándo se hace |
|---|---|---|
| ¿La entidad puede dar este paso? ¿Quién la frena? | `mover` (usa `buscarBloqueo`) | **Antes** de moverse |
| ¿Con qué se está tocando? | `verificarColisiones` | **Después** de moverse y atacar |
| ¿A quién alcanza un golpe de espada? | `golpearEn` | Cuando una espada golpea |
| ¿Salió de la pantalla? | `estaFuera` | Después de avanzar |

**Idea central:** ni las entidades ni las estrategias recorren el sector ni comparan rectángulos por su cuenta. Las
estrategias deciden **hacia dónde** ir o **cuándo** atacar, y el administrador decide **si se puede** y **a quién
afecta**. Así ese código está en un solo lugar.

---

## 2. Ubicación, imports y relaciones

### Paquete

```java
package logica.entidades;
```

Tiene que estar en el **mismo paquete que `EntidadAnimada`**. Llama a dos ganchos **protegidos** (`#`) de
`EntidadAnimada`, `alChocarConBloqueo()` y `alSalirDelSector(d)`, y en Java un método `protected` solo se ve desde las
subclases y desde el mismo paquete. Desde otro paquete **no compila**.

### Imports

```java
import java.util.List;          // la copia de entidades que devuelve Sector.getEntidades()
import logica.mapa.Sector;      // el sector visible
import logica.util.Direccion;   // la dirección de cada paso
import logica.util.Hitbox;      // los rectángulos que se comparan
```

`Entidad` y `EntidadAnimada` están en el mismo paquete y no hace falta importarlas.

### Relaciones (reducido y extendido)

| Relación | Con | En el diagrama | Qué significa |
|---|---|---|---|
| Composición | `Juego` | ◆ `#colisiones 1` | `Juego` lo crea y es su dueño. Hay un solo administrador por partida. |
| Asociación | `HiloJugador`, `HiloMundo` | `#colisiones 1` | Los dos hilos usan el mismo administrador. |
| Asociación | `Sector` | `#sector 1` | El sector visible sobre el que trabaja. |
| Dependencia (no se dibuja) | Estrategias de movimiento y ataque, `EntidadAnimada.actualizarEstado(c)` | — | Lo reciben por parámetro (`c`). |

`Juego` lo crea en su constructor (`colisiones = new AdministradorColisiones()`) y le cambia el sector en
`activarSector` y en `cambiarDeSector`.

---

## 3. Miembros (según el extendido)

### Atributo

| Miembro | Tipo | Para qué |
|---|---|---|
| `# sector` | `Sector` | El sector visible. Es **`volatile`** porque lo cambia `Juego` (al cambiar de sector o recargar el nivel) mientras los hilos lo leen. Así todos ven el cambio enseguida. |

### Constructor

| Miembro | Qué hace |
|---|---|
| `+ AdministradorColisiones()` | Nada. El sector se asigna después con `setSector`, cuando `Juego` activa el primer sector. |

### Comandos

| Método | Qué hace | Quién lo llama |
|---|---|---|
| `+ setSector(s : Sector)` | Cambia el sector visible | `Juego.activarSector`, `Juego.cambiarDeSector` |
| `+ mover(e, d, pasos) : boolean` | Mueve si nada lo frena; si algo lo frena, dispara el choque y avisa. Devuelve si avanzó. | `MovimientoInducido` (con dirección), `MovimientoAleatorio` |
| `+ verificarColisiones(quien)` | Avisa a cada entidad que se superpone con la actualizada (Visitor) | `EntidadAnimada.actualizarEstado(c)` |
| `+ golpearEn(atacante, alcance, danio)` | Golpea a todo lo que está adelante del atacante | `AtaqueEspada.golpear` (y `AtaqueRecargado` sin cargar) |
| `+ golpearAlrededor(atacante, alcance, danio)` | Golpea a todo lo que está alrededor del atacante, hacia los cuatro lados (cambio 38) | `AtaqueRecargado`, con la espada cargada |

### Consultas

| Método | Qué devuelve | Quién lo llama |
|---|---|---|
| `+ getSector() : Sector` | El sector visible | `MovimientoTeletransporte`, `AtaqueAvalancha`, `HiloMundo`, `Juego` |
| `- buscarBloqueo(e, d, pasos) : Entidad` | **Defensa 7.** La entidad que no deja dar el paso, o `null` si está libre | Solo `mover` (es privado) |
| `+ estaFuera(h : Hitbox) : boolean` | Si la hitbox no está completa dentro de la pantalla | `mover` |

> En el extendido el parámetro de `verificarColisiones` se llama `quien`. En el código se llama `entidadActualizada`.
> El nombre del parámetro no cambia la firma en Java, así que coinciden igual.

---

## 4. Conceptos que usa la clase

### 4.1 Hitbox

Cada entidad tiene un rectángulo (`getHitbox()`): su **cuerpo**. La clase usa cuatro operaciones de `Hitbox`:

| Método de `Hitbox` | Qué hace | Lo usa |
|---|---|---|
| `intersecta(otra)` | Si los dos rectángulos se superponen | `buscarBloqueo`, `verificarColisiones`, `golpearEn` |
| `desplazada(d, pasos)` | Una copia corrida `pasos` px en la dirección `d` | `buscarBloqueo` |
| `adelante(d, alcance)` | El rectángulo pegado al borde, hacia donde se mira, de largo `alcance` | `golpearEn` |
| `alrededor(alcance)` | El cuerpo agrandado `alcance` px hacia los cuatro lados (cambio 38) | `golpearAlrededor` |
| `estaDentroDe(ancho, alto)` | Si está completo dentro de la zona | `estaFuera` |
| `contiene(p)` | Si el punto `p` cae dentro del rectángulo (cambio 31) | `CaidasAlVacio.afectar` |

**Hitbox con margen.** El cuerpo puede ser más chico que la imagen y estar corrido un margen respecto de la esquina
donde se dibuja la entidad. Por ejemplo, Link se dibuja en 48 × 48 pero su cuerpo es de 36 × 44, a 6 px del borde
izquierdo y 2 px del de arriba; el vacío tiene un cuerpo de 32 × 32 en el medio de su imagen (defensa 7). Lo declara
cada clase con `setCuerpo(...)` y constantes de clase. Por defecto es 48 × 48 sin margen.

Esta clase no tuvo que cambiar por eso: trabaja solo con `getHitbox()`, y `Hitbox.getX()`/`getY()` devuelven la
esquina del cuerpo. Así todas las comparaciones son entre cuerpos, no entre imágenes.

### 4.2 `bloqueaPasoA(quien)` (defensa 7)

Es una consulta de `Entidad` que responde si esa entidad **le impide el paso a la que camina**. Reemplaza a
`bloqueaPaso()`, que no sabía quién caminaba: por eso el vacío no podía frenar a los enemigos sin frenar también a Link.

La entidad de adelante decide, y si hace falta le hace una pregunta simple al que camina:

```java
// Entidad*: por defecto nada bloquea
public boolean bloqueaPasoA(EntidadAnimada quien) { return false; }

// Roca y Agua: bloquean a todos
public boolean bloqueaPasoA(EntidadAnimada quien) { return true; }

// CaidasAlVacio: frena a quien esquiva vacíos
public boolean bloqueaPasoA(EntidadAnimada quien) { return quien.esquivaVacios(); }

// Enemigo* y Link: frenan a quien es frenado por personajes
public boolean bloqueaPasoA(EntidadAnimada quien) { return quien.esFrenadoPorPersonajes(); }
```

Y del lado del que camina:

| Pregunta | `EntidadAnimada*` (p. ej. `Proyectil`) | `Enemigo*` | `Link` |
|---|---|---|---|
| `esquivaVacios()` | `false` | `true` | `false` (hereda) |
| `esFrenadoPorPersonajes()` | `false` | `true` | `true` |

El resultado:

| Quién camina \ qué hay adelante | Roca | Agua | Vacío | Enemigo | Link |
|---|---|---|---|---|---|
| `Proyectil` (y cualquier `EntidadAnimada*` por defecto) | frena | frena | pasa | pasa | pasa |
| `Enemigo*` | frena | frena | **frena** | **frena** | **frena** |
| `Link` | frena | frena | pasa (y cae) | **frena** | — |

- **Polimorfismo en vez de `instanceof`:** el administrador no pregunta "¿es una roca?", pregunta "¿le bloqueás el paso
  a este?". Si se agrega un muro, alcanza con que redefina `bloqueaPasoA` en `true`, sin tocar esta clase.
- **Por qué no es un Visitor:** el Visitor resuelve efectos **después** de tocarse (daño, recoger una rupia). El
  bloqueo se decide **antes** de moverse, para que la entidad nunca quede encima de la roca. Usar un segundo Visitor
  para el bloqueo (otra estrategia que se evaluó) agregaba 2 interfaces y 12 métodos; esta solución agrega 8 métodos y
  ninguna clase, y sigue la observación 4 del ayudante.
- **Por qué el proyectil pasa por encima de Link y de los enemigos:** si los frenara, nunca se superpondrían y el
  choque solo se dispararía desde `mover`. Así el disparo llega hasta Link y lo resuelve el Visitor de siempre, desde la
  vuelta de Link (`Link.colisionarCon(Proyectil)`).

### 4.3 Ganchos de `EntidadAnimada`

Son métodos vacíos que cada subclase redefine si los necesita. `mover` los llama sin saber qué entidad es:

```java
// EntidadAnimada*
protected void alChocarConBloqueo() { }
protected void alSalirDelSector(Direccion d) { }
```

| Entidad | `alChocarConBloqueo()` | `alSalirDelSector(d)` |
|---|---|---|
| Link | Vacío (se frena) | `miJuego.cambiarDeSector(d)` |
| `Enemigo*` | Vacío (`MovimientoAleatorio` elige otra dirección) | Retrocede 8 px, se da vuelta y llama a `alChocarConBloqueo()` |
| `TrampaDeCuchillas` | `volver()` | Lo de `Enemigo*`, que termina en `volver()` |
| `Proyectil` | `desaparecer()` | `desaparecer()` |

### 4.4 Visitor (doble despacho)

- `aceptarColision(c : Colisionador)` está en `Entidad*` (lo declara `Colisionable`). Cada clase concreta lo implementa
  en una línea: `c.colisionarCon(this)`.
- Como adentro `this` tiene el **tipo concreto** (Rupia, Moblin, Roca…), Java elige el `colisionarCon` correcto **sin
  `instanceof`**.
- Desde la defensa 7 el Visitor se dispara desde dos lugares: `verificarColisiones` (cuando los cuerpos se superponen)
  y `mover` (cuando algo frena el paso).

### 4.5 La copia de `getEntidades()`

`Sector.getEntidades()` es `synchronized` y devuelve una **copia** de la lista (`new ArrayList<>(entidades)`). Los tres
recorridos usan esa copia. Por eso:

- si durante el recorrido alguien se agrega o se elimina, no salta `ConcurrentModificationException`;
- el administrador no necesita `synchronized`;
- la copia puede traer una entidad que se eliminó hace un instante. Por eso se pregunta `estaEliminada()`.

---

## 5. Cada método en detalle

### 5.1 `setSector` y `getSector`

```java
public void setSector(Sector s) { sector = s; }
public Sector getSector() { return sector; }
```

`Juego` le asigna el sector cuando empieza un nivel o cuando Link cambia de sector. `getSector` lo usan:

- `MovimientoTeletransporte`, para que el Wizzrobe salte a `posicionLibreAlAzar(...)`;
- `AtaqueAvalancha`, para elegir dónde caen las rocas;
- `HiloMundo`, para actualizar las entidades del sector visible;
- `Juego`, para agregar entidades nuevas, cambiar de sector y reactivar el sector después de la animación.

### 5.2 `mover`: toda decisión de bloqueo pasa por acá

```java
public boolean mover(EntidadAnimada e, Direccion d, int pasos) {
    Entidad bloqueo = buscarBloqueo(e, d, pasos);
    boolean avanzo = bloqueo == null;
    if (avanzo) {
        e.avanzar(d, pasos);
        if (estaFuera(e.getHitbox()))
            e.alSalirDelSector(d);
    } else {
        bloqueo.aceptarColision(e);   // efecto del choque (Visitor de efectos)
        e.alChocarConBloqueo();
    }
    return avanzo;
}
```

Paso a paso:

1. **`bloqueo = buscarBloqueo(e, d, pasos)`**: la entidad que frena el paso, o `null`.
2. **Si no hay bloqueo (`avanzo` es `true`):**
   - `e.avanzar(d, pasos)` cambia la posición. Link lo redefine: si pisó pasto en la vuelta anterior, avanza la mitad.
   - `estaFuera(e.getHitbox())`: si quedó fuera de la pantalla, llama al gancho `e.alSalirDelSector(d)`. Link cambia
     de sector, el proyectil desaparece y el enemigo retrocede.
3. **Si hay bloqueo (defensa 7):**
   - `bloqueo.aceptarColision(e)`: dispara el efecto del choque, como si se hubieran tocado. Como se frenan, nunca
     llegan a superponerse y `verificarColisiones` no lo encontraría. Así un Moblin lastima a Link aunque se frenen.
   - `e.alChocarConBloqueo()`: la trampa vuelve, el proyectil desaparece y Link y el Moblin se frenan.
4. **`return avanzo;`**: le dice a la estrategia si avanzó. `MovimientoAleatorio` lo usa: si devuelve `false`, elige
   otra dirección al azar. Así el enemigo cambia de dirección al chocar con Link o con un vacío.

**Ejemplos:**

| Situación | `buscarBloqueo` | Qué pasa | Devuelve |
|---|---|---|---|
| Link camina por el pasto | `null` | Avanza (la mitad, por el pasto) | `true` |
| Link contra una roca | la roca | `roca.aceptarColision(link)` → `afectar` vacío; se frena | `false` |
| Link pisa un vacío | `null` (`vacio.bloqueaPasoA(link)` es `false`) | Avanza; `verificarColisiones` lo hace caer | `true` |
| Moblin contra un vacío | el vacío (`moblin.esquivaVacios()` es `true`) | `vacio.aceptarColision(moblin)` → vacío; elige otra dirección | `false` |
| Moblin contra Link | Link | `link.aceptarColision(moblin)` → `moblin.colisionarCon(link)` → daño; elige otra dirección | `false` |
| Link contra un Moblin | el Moblin | `moblin.aceptarColision(link)` → `link.colisionarCon(moblin)` → `moblin.colisionarCon(link)` → daño | `false` |
| Trampa contra una roca | la roca | `volver()` a su lugar | `false` |
| Disparo contra una roca | la roca | `desaparecer()` | `false` |
| Link cruza el borde derecho | `null` | Avanza y `alSalirDelSector(DERECHA)` → `Juego.cambiarDeSector` | `true` |

**Excepción a propósito:** `MovimientoInducido` con objetivo usa `e.avanzarHacia(...)`, que **no** pasa por `mover`.
Así las rocas de la avalancha y la embestida del StoneHinox atraviesan las rocas del borde, y la trampa vuelve a su lugar
aunque algo se cruce.

### 5.3 `buscarBloqueo` (defensa 7)

```java
private Entidad buscarBloqueo(EntidadAnimada e, Direccion d, int pasos) {
    Hitbox siguiente = e.getHitbox().desplazada(d, pasos);   // dónde quedaría después del paso
    List<Entidad> entidades = sector.getEntidades();          // copia de la lista
    Entidad bloqueo = null;
    int i = 0;
    while (i < entidades.size() && bloqueo == null) {
        Entidad entidadDelSector = entidades.get(i);
        boolean bloquea = entidadDelSector != e
                && !entidadDelSector.estaEliminada()
                && entidadDelSector.getHitbox().intersecta(siguiente)
                && !entidadDelSector.getHitbox().intersecta(e.getHitbox())
                && entidadDelSector.bloqueaPasoA(e);
        if (bloquea)
            bloqueo = entidadDelSector;
        i++;
    }
    return bloqueo;
}
```

Paso a paso:

1. **`siguiente`**: la hitbox de la entidad **como quedaría** si diera el paso. Todavía no se movió nada.
2. **`bloqueo = null`**: arranca suponiendo que el paso está libre.
3. **`while (i < entidades.size() && bloqueo == null)`**: recorre mientras queden entidades **y** no haya encontrado un
   bloqueo. En cuanto encuentra uno, termina.
4. **`bloquea`** se cumple si:
   - `entidadDelSector != e`: no es la misma entidad;
   - `!estaEliminada()`: sigue en juego;
   - `intersecta(siguiente)`: está justo donde quedaría la entidad;
   - `!intersecta(e.getHitbox())`: **no** estaban ya superpuestas. Si ya estaban encima (por ejemplo, un enemigo que
     apareció sobre Link, o la trampa que volvió por encima de él), no la traba: la deja separarse;
   - `bloqueaPasoA(e)`: la de adelante dice que le bloquea el paso a esta.
5. **`return bloqueo;`**: la que frena, o `null`.

Devuelve la entidad y no un `boolean` porque `mover` la necesita para disparar `bloqueo.aceptarColision(e)`. Es
**privado** porque solo lo usa `mover`.

### 5.4 `verificarColisiones`: el Visitor

```java
public void verificarColisiones(EntidadAnimada entidadActualizada) {
    Sector s = sector;                                  // siempre el mismo sector
    List<Entidad> entidades = s.getEntidades();         // copia de la lista
    int i = 0;
    while (i < entidades.size() && !entidadActualizada.estaEliminada() && entidadActualizada.getSector() == s) {
        Entidad entidadDelSector = entidades.get(i);
        boolean seTocan = entidadDelSector != entidadActualizada
                && !entidadDelSector.estaEliminada()
                && entidadDelSector.getHitbox().intersecta(entidadActualizada.getHitbox());
        if (seTocan)
            entidadDelSector.aceptarColision(entidadActualizada);   // Visitor
        i++;
    }
}
```

Se lee así: **mientras queden entidades, y la entidad actualizada siga viva y en este sector, se fija si toca a la
siguiente y, si se tocan, le avisa.**

**Nombres:**

- `entidadActualizada`: la entidad que se acaba de mover o atacar en esta vuelta del hilo.
- `entidadDelSector`: cada una de las demás entidades del sector con las que se la compara.

Paso a paso:

1. **`Sector s = sector;`**: `Juego` puede cambiar `sector` desde otro hilo en cualquier momento. Con la copia local,
   todo el recorrido usa **siempre el mismo sector**.
2. **`entidades = s.getEntidades()`**: la copia de la lista (ver 4.5).
3. **Condición del `while`.** Sigue mientras se cumplan las tres:
   - `i < entidades.size()`: quedan entidades por revisar.
   - `!entidadActualizada.estaEliminada()`: sigue viva. Si un choque anterior del mismo recorrido la eliminó (un
     proyectil que tocó a Link), no tiene sentido seguir.
   - `entidadActualizada.getSector() == s`: sigue en este sector. Cuando Link cae al vacío, pierde la última vida o
     mata al último jefe, `Juego` recarga el nivel y Link pasa a otro sector. Sin este corte, se compararía la
     posición nueva de Link con entidades del sector viejo y aparecerían choques falsos.
4. **`seTocan`** se cumple si no es la misma entidad, la otra sigue viva y los cuerpos se superponen.
5. **`entidadDelSector.aceptarColision(entidadActualizada)`**: no decide qué pasa, solo avisa. El doble despacho elige
   la reacción.

**Ejemplos del doble despacho** (con `bloqueaPasoA`, los choques entre Link y los enemigos llegan por `mover`; acá
quedan los que sí se superponen):

| Choque | Llamadas | Resultado |
|---|---|---|
| Link pisa una rupia (vuelta de Link) | `rupia.aceptarColision(link)` → `link.colisionarCon(rupia como PowerUP)` → `p.serRecogidoPor(link)` | Suma rupias y la rupia desaparece |
| Link pisa el pasto | `pasto.aceptarColision(link)` → `link.colisionarCon(pasto como Obstaculo)` → `o.afectar(link)` | `ralentizar()` |
| Link pisa un vacío | `vacio.aceptarColision(link)` → `link.colisionarCon(vacio como Obstaculo)` → `o.afectar(link)` → si `getHitbox().contiene(link.getCentro())`, `l.caerAlVacio()` | Se queda quieto e invulnerable mientras se ve el GIF de caída (400 ms); después pierde una vida y reinicia el nivel |
| Link toca un disparo (vuelta de Link) | `proyectil.aceptarColision(link)` → `link.colisionarCon(proyectil)` | `recibirDanio(p.getDanio(), p.getDireccion())` y `p.eliminar()` |
| La trampa vuelve por encima de Link (vuelta de la trampa) | `link.aceptarColision(trampa)` → `trampa.colisionarCon(link)` → `ataque.ataqueAlContactar(trampa, link)` | `link.recibirDanio(1, direccion)` |

**Se llama en cada vuelta, aunque la entidad no se haya movido.** `actualizarEstado(c)` lo llama después de mover y
atacar:

```java
public void actualizarEstado(AdministradorColisiones c) {
    if (!estaEliminada()) {
        vigilarJugador();
        movimiento.mover(this, c);
        ataque.atacar(this, c);
        if (!estaEliminada())
            c.verificarColisiones(this);
        ejecutarPendientes();
        avisarParpadeo();          // defensa 7
    }
}
```

### 5.5 `golpearEn`: la espada

```java
public void golpearEn(EntidadAnimada atacante, int alcance, int danio) {
    Hitbox zona = atacante.getHitbox().adelante(atacante.getDireccion(), alcance);
    for (Entidad otra : sector.getEntidades())
        if (otra != atacante && !otra.estaEliminada() && otra.getHitbox().intersecta(zona))
            otra.recibirGolpeDeEspada(atacante, danio);
}
```

1. **`zona`**: el rectángulo pegado al cuerpo del atacante, hacia donde mira, de largo `alcance`.
2. Recorre las entidades y, a cada una que está viva y dentro de la zona, le llama
   **`recibirGolpeDeEspada(atacante, danio)`**.
3. `recibirGolpeDeEspada` es un **gancho vacío** en `Entidad`. Lo redefinen:
   - `Pasto`: `eliminar()`, la espada corta el pasto.
   - `Enemigo*` y `Link`: `recibirDanio(danio, atacante.getDireccion())`, que pasa por su defensa.
   - El resto no hace nada.

**Quién golpea:**

| Atacante | Estrategia | Daño | Alcance |
|---|---|---|---|
| Link | `AtaqueRecargado(DANIO_ESPADA, ALCANCE_ESPADA)` = `(1, 32)` | 1 (doble si está cargado) | 32 px adelante (cargado: 64 px alrededor) |
| MasterStalfos, fase espada | `AtaqueEspada(DANIO_ESPADA, ALCANCE_ESPADA)` = `(2, 40)` | 2 (1 corazón) | 40 px |

Cadena: `AtaqueEspada.atacar` → `golpear(a, danio, alcance, c)` → `c.golpearEn(a, alcance, danio)`, y después
`atacante.ataqueRealizado()`, que desde la defensa 7 también cambia la imagen al espadazo.

**`golpearAlrededor` (cambio 38).** Es igual, pero la zona es `atacante.getHitbox().alrededor(alcance)`: el cuerpo agrandado `alcance` px hacia los cuatro lados. La usa el ataque recargado, que es un giro.

```java
// AtaqueRecargado.atacar
if (estaCargado())
    c.golpearAlrededor(atacante, alcance * FACTOR_CARGA, danio * FACTOR_CARGA);
else
    golpear(atacante, danio, alcance, c);
```

⚠️ Golpea a **todo** lo que está adelante, también a otros enemigos. En el sector del jefe no hay otros, así que no pasa
nada.

### 5.6 `estaFuera`

```java
public boolean estaFuera(Hitbox h) {
    return !h.estaDentroDe(Sector.ANCHO, Sector.ALTO);
}
```

Devuelve `true` si la hitbox no está **completamente** dentro de la pantalla del sector, que mide
`Sector.ANCHO × Sector.ALTO` (768 × 528 px). Basta con que un borde del cuerpo salga.

---

## 6. Recorrido completo: Link camina contra un Moblin

**En `HiloJugador` (vuelta de Link):**

1. `link.actualizarEstado(c)`.
2. `caminar.mover(link, c)` → `c.mover(link, DERECHA, 4)`.
3. `buscarBloqueo` encuentra al Moblin: `moblin.bloqueaPasoA(link)` → `link.esFrenadoPorPersonajes()` → `true`.
4. `moblin.aceptarColision(link)` → `link.colisionarCon(moblin)` → `moblin.colisionarCon(link)`.
5. `ataque.ataqueAlContactar(moblin, link)` → `AtaquePorContacto` → `link.recibirDanio(1, direccion)`.
6. `Link.recibirDanio` (`synchronized`) le pasa el golpe a su defensa. Si el daño pasa, corta la racha, avisa
   `jugadorDaniado()` y llama a `alSerGolpeado()`, que lo deja invulnerable y parpadeando 1 segundo.
7. `link.alChocarConBloqueo()` es vacío: Link no avanza. `mover` devuelve `false`.

**En `HiloMundo` (vuelta del Moblin), poco después:**

8. `moblin.actualizarEstado(c)` → `MovimientoAleatorio` llama a `c.mover(moblin, IZQUIERDA, 2)`.
9. `buscarBloqueo` encuentra a Link: `link.bloqueaPasoA(moblin)` → `true`.
10. `link.aceptarColision(moblin)` → `moblin.colisionarCon(link)` → `link.recibirDanio(1, ...)`. Link sigue
    invulnerable, así que la defensa no saca nada.
11. `mover` devuelve `false` y el Moblin elige otra dirección.

El daño se aplica **una vez por segundo como máximo**, y siempre lo decide la estrategia del enemigo.

---

## 7. Hilos y concurrencia

- **Una sola instancia, dos hilos:** `HiloJugador` (Link) y `HiloMundo` (el resto) usan el mismo administrador al mismo
  tiempo.
- **`sector` es `volatile`:** cuando `Juego` cambia de sector, los dos hilos lo ven enseguida.
- **`Sector s = sector` en `verificarColisiones`:** el recorrido no cambia de sector a mitad de camino.
- **Ningún método es `synchronized`.** Todos recorren la **copia** de `getEntidades()`, y eso alcanza.
- **El choque desde `mover` corre en el hilo del que camina.** Si camina Link, el daño se lo aplica `HiloJugador`; si
  camina el enemigo, `HiloMundo`. Por eso `recibirDanio` y `aplicarDanio` son `synchronized`.
- **Por qué no sincronizar el administrador (abrazo mortal):** si `mover` o `verificarColisiones` tomaran la llave del
  sector, podría pasar esto:
  1. `HiloMundo` tiene la llave del sector y, al tocar a Link, necesita la llave de Link (`recibirDanio`).
  2. `HiloJugador` tiene la llave de Link (`recibirDanio`) y, al morir o recoger algo, necesita la del sector
     (`sector.quitar`).
  3. Cada hilo espera al otro y el juego se traba.
- **Regla:** el orden de llaves es Entidad → `Juego` → `Sector`, y nunca se ejecuta código de entidades con la llave del
  sector tomada.

---

## 8. Patrones y decisiones

| Patrón / decisión | Dónde | Para qué |
|---|---|---|
| **Visitor (doble despacho)** | `verificarColisiones` y `mover` → `aceptarColision` / `colisionarCon` | Elegir la reacción según los dos tipos, sin `instanceof` |
| **Polimorfismo en `bloqueaPasoA(quien)`** (defensa 7) | `buscarBloqueo` | Saber qué frena a quién sin preguntar el tipo. La de adelante le pregunta al que camina `esquivaVacios()` o `esFrenadoPorPersonajes()` |
| **Ganchos (Template Method)** | `alChocarConBloqueo`, `alSalirDelSector`, `recibirGolpeDeEspada` | Que cada entidad reaccione distinto con el mismo código del administrador |
| **Strategy** | Las estrategias reciben `c` por parámetro | Delegar lo espacial al administrador |
| **Una sola salida (variable de retorno)** | `mover`, `buscarBloqueo` | Código más fácil de seguir: un solo `return` al final |
| **`while` con condición de corte** | `verificarColisiones`, `buscarBloqueo` | Que la condición diga cuándo seguir, sin `return` en el medio |

---

## 9. Cuidados

- ⚠️ **Paquete:** si se mueve a otro paquete, no compila por los ganchos `protected`.
- ⚠️ **No agregar `synchronized`** a ningún método (sección 7).
- ⚠️ **`avanzarHacia` no pasa por `mover`:** al llegar a su destino nadie llama `alChocarConBloqueo()`. Las rocas de la
  avalancha quedan quietas hasta que Link las toca, y la trampa que vuelve no se frena contra nada.
- ⚠️ **La espada golpea a todos** los que están adelante, también a otros enemigos.
- ⚠️ **`!intersecta(e.getHitbox())` en `buscarBloqueo`:** sin esa condición, dos entidades que ya estuvieran
  superpuestas quedarían trabadas para siempre, porque cualquier paso seguiría tocando a la otra.
- Para que compile, las demás clases tienen que tener:
  - `Entidad`: `getHitbox()`, `estaEliminada()`, `bloqueaPasoA(quien)`, `aceptarColision(c)`,
    `recibirGolpeDeEspada(a, d)`, `getSector()`.
  - `EntidadAnimada`: `avanzar(d, p)`, `getDireccion()`, `alChocarConBloqueo()`, `alSalirDelSector(d)`,
    `esquivaVacios()`, `esFrenadoPorPersonajes()`.
  - `Hitbox`: `intersecta`, `desplazada`, `adelante`, `estaDentroDe`.
  - `Sector`: `ANCHO`, `ALTO`, `getEntidades()`.

---

## 10. En los diagramas

- **Extendido:** la caja `AdministradorColisiones` tiene:
  - el atributo `# sector : Sector`;
  - el constructor;
  - `setSector`, `mover`, `verificarColisiones(quien)` y `golpearEn` (comandos);
  - `getSector`, `- buscarBloqueo(e : EntidadAnimada, d : Direccion, pasos : int) : Entidad` y `estaFuera` (consultas).

  `buscarBloqueo` reemplaza a `- puedeMoverA(...) : boolean` de la defensa 6. También se agregaron
  `bloqueaPasoA(quien)` en `Entidad*`, `Roca`, `Agua`, `CaidasAlVacio`, `Enemigo*` y `Link`, y
  `esquivaVacios()` y `esFrenadoPorPersonajes()` en `EntidadAnimada*`, `Enemigo*` y `Link`.
- **Reducido:** no cambia por el bloqueo. Aparece con sus relaciones (◆ `#colisiones 1` desde `Juego`, `#colisiones 1`
  desde los dos hilos y `#sector 1` al `Sector`), sin métodos.

---

# Explicación de la clase EntidadAnimada (Defensa 7)

Explicativo completo de `EntidadAnimada*`: usos, relaciones, atributos, comandos, consultas y ejemplos paso a paso. Se basa en los diagramas extendido y reducido de la defensa 7 (estrategia `bloqueaPasoA`) y en el código de `DEFENSA 7 FINAL/Codigo`.

**Lo que cambió en la defensa 7:**

| Cambio | Miembros nuevos o modificados |
|---|---|
| Bloqueo con `bloqueaPasoA(quien)`: la entidad que camina responde dos preguntas | `+ esquivaVacios() : boolean`, `+ esFrenadoPorPersonajes() : boolean` (los dos `false`) |
| Parpadeo al recibir daño y durante la invulnerabilidad | `- DURACION_PARPADEO : long = 600`, `# finParpadeo : long`, `- avisarParpadeo()`, `# parpadearDurante(ms : long)`, `+ esVisible() : boolean` |
| Dibujo por capas | `+ getCapa() : int` → `CAPA_PERSONAJES` |
| No abalanzarse a través de obstáculos | `+ hayObstaculoHastaJugador() : boolean` |
| Correcciones de la defensa 6: la entidad ve la partida como `EntornoJuego` | `linkEstaEnfrente()` y `hayObstaculoHastaJugador()` guardan a Link como `Entidad`, no como `Link` |


## 1. Qué es

`EntidadAnimada` es la **clase abstracta de todo lo que se mueve, ataca o recibe daño**: Link, los enemigos, los jefes y los proyectiles. Las entidades fijas (rocas, agua, pasto, power-ups, objetos) heredan directamente de `Entidad` y no pasan por acá.

Junta en un solo lugar lo que todas esas entidades tienen en común:

| Lo que resuelve | Cómo |
|---|---|
| Cómo se mueve, ataca y se defiende | Lo delega en tres estrategias intercambiables (Strategy) |
| Qué hace en cada instante del juego | Un método `actualizarEstado(c)` que hace "una vuelta" completa |
| Cómo reacciona a lo que toca | Realiza `Colisionador`, con los seis `colisionarCon(...)` vacíos (Visitor) |
| Cómo recibe daño | `recibirDanio` (pasa por la defensa) y `aplicarDanio` (resta vida y, desde la defensa 7, la hace parpadear) |
| Qué la frena al caminar (defensa 7) | Responde `esquivaVacios()` y `esFrenadoPorPersonajes()` cuando lo que está adelante se lo pregunta (`bloqueaPasoA`) |
| Cómo espera ("dentro de 1 segundo hacé tal cosa") | Una lista de `AccionProgramada`, sin crear hilos |
| Lo que cada subclase hace distinto | **Ganchos**: métodos vacíos que la subclase redefine si los necesita |

**No tiene hilo propio.** Desde la defensa 5 ninguna entidad es un `Thread`. Las actualiza un hilo de afuera: a Link lo mueve `HiloJugador` y al resto `HiloMundo`, cada 30 ms.

**Es abstracta** porque no existe una "entidad animada" a secas. Siempre es un Link, un Moblin, un proyectil, etcétera. Además no implementa `aceptarColision(c)`, que queda pendiente para cada subclase concreta.

## 2. Herencia, interfaces y patrones

```java
public abstract class EntidadAnimada extends Entidad implements Colisionador
```

```mermaid
classDiagram
    Entidad <|-- EntidadAnimada
    Colisionador <|.. EntidadAnimada
    EntidadAnimada <|-- Link
    EntidadAnimada <|-- Proyectil
    EntidadAnimada <|-- Enemigo
    Enemigo <|-- EnemigoConDrop
    Enemigo <|-- TrampaDeCuchillas
    Enemigo <|-- Jefe
    EnemigoConDrop <|-- Moblin
    EnemigoConDrop <|-- ErizoDeMar
    EnemigoConDrop <|-- Octorok
    EnemigoConDrop <|-- Wizzrobe
    Moblin <|-- MoblinConEspadaYEscudo
    Jefe <|-- MasterStalfos
    Jefe <|-- StoneHinox
    class EntidadAnimada {
        <<abstract>>
    }
    class Colisionador {
        <<interface>>
    }
```

| Relación | Con | Qué aporta |
|---|---|---|
| Hereda de | `Entidad*` | Posición, `hitbox`, `sprite`, observadores, `miJuego : EntornoJuego`, `eliminar()`, `estaEliminada()`, `getSector()`, `notificarObservers()`, el gancho `actualizarPorMundo(c)` y, desde la defensa 7, `bloqueaPasoA(quien)` e `impideAbalanzarse()` |
| Realiza | `Colisionador` | Los seis `colisionarCon(...)`: Link, Enemigo, Proyectil, Obstaculo, PowerUP y Objeto |
| La heredan | `Link`, `Proyectil`, `Enemigo*` | Y por medio de `Enemigo*`, los seis enemigos comunes, la trampa y los dos jefes |

| Patrón | Dónde aparece |
|---|---|
| **Strategy** | `movimiento`, `ataque` y `defensa`. La entidad llama `movimiento.mover(this, c)` sin saber si patrulla, persigue o se teletransporta |
| **Visitor** (doble despacho) | Realiza `Colisionador`. Cuando dos entidades se tocan, una llama `aceptarColision(otra)` y esa responde `otra.colisionarCon(this)`, así cada una sabe con qué tipo chocó sin usar `instanceof` |
| **Template Method** (en chico) | `actualizarEstado` fija el orden de la vuelta y deja pasos que cambian según la subclase: `vigilarJugador()` y las estrategias |
| **Observer** | `setDireccion` y `aplicarDanio` llaman `notificarObservers()` para que la vista se redibuje. Desde la defensa 7, mientras parpadea avisa en cada vuelta |

## 3. Relaciones en el diagrama

Así aparece `EntidadAnimada*` en el extendido y en el reducido de la defensa 7 (no cambiaron sus relaciones). Cada relación es un atributo en el código.

| Relación | Tipo | Multiplicidad | Atributo | Por qué ese tipo |
|---|---|---|---|---|
| `EntidadAnimada* ◇ ComportamientoMovimiento` | Agregación | `1` | `# movimiento` | La estrategia se cambia en tiempo de ejecución. Por ejemplo, el Moblin con escudo pasa de aleatorio a inducido |
| `EntidadAnimada* ◇ ComportamientoAtaque` | Agregación | `1` | `# ataque` | Ídem. MasterStalfos alterna entre espada y contacto |
| `EntidadAnimada* ◇ ComportamientoDefensa` | Agregación | `1` | `# defensa` | Ídem. Link alterna entre normal, escudo e invulnerable |
| `EntidadAnimada* → Direccion` | Asociación | `1` | `# direccion` | Hacia dónde mira |
| `EntidadAnimada* ◆ AccionProgramada` | Composición | `0..*` | `# pendientes` | Las acciones las crea `programar` y no existen fuera de la entidad |
| `EntidadAnimada* ⋯▷ Colisionador` | Realización | — | — | Visitor |
| `EntidadAnimada* ──▷ Entidad*` | Herencia | — | — | — |

**Relaciones que ya no están** (por si preguntan):

- `EntidadAnimada* → Sector` como relación propia salió en las correcciones finales: **la entidad animada no usa su sector para moverse**. El administrador de colisiones le llega por parámetro (`actualizarEstado(c)`). La referencia `# miSector` vive en `Entidad` (la usan `eliminar()` y `hayObstaculoHastaJugador()`).
- `ubicarseEn(s)` salió en las correcciones de la defensa 4.
- El hilo propio de cada entidad salió en la defensa 5 y lo reemplazaron `HiloJugador`, `HiloMundo` y `AccionProgramada`.

## 4. Atributos

Todos son `protected` (`#`), así las subclases los pueden usar directamente.

| Atributo | Tipo | Para qué | Valor al crear |
|---|---|---|---|
| `movimiento` | `ComportamientoMovimiento` | Cómo se mueve en cada vuelta | `MovimientoInducido(null, 0)`: quieta |
| `ataque` | `ComportamientoAtaque` | Cómo ataca en cada vuelta y, desde la defensa 6, si lastima al tocar | `AtaquePorContacto(0)`: no lastima |
| `defensa` | `ComportamientoDefensa` | Cuánto daño deja pasar | `DefensaLimitada(SIN_LIMITE, SIEMPRE)`: deja pasar todo |
| `direccion` | `Direccion` | Hacia dónde mira. Lo usan la espada, el escudo, `linkEstaEnfrente` y el sprite | `ABAJO` |
| `vida` | `int` | Lo que le queda | La que pasa la subclase |
| `pendientes` | `List<AccionProgramada>` | Lo que tiene que hacer "dentro de un rato" | Lista vacía |
| `finParpadeo` (defensa 7) | `long`, `volatile` | Hasta qué instante parpadea (en ms). `0` si no parpadea | `0` |

Y dos constantes de clase (privadas, subrayadas en el extendido): `DURACION_PARPADEO : long = 600`, lo que parpadea una
entidad que recibe daño y sigue viva, y `PERIODO_PARPADEO : long = 100`, cada cuántos ms se prende y se apaga durante el
parpadeo (lo usa `esVisible()`).

**`vida` se mide distinto según quién sea:**

| Entidad | Unidad | Ejemplo |
|---|---|---|
| Link | Medios corazones | `vida = 6` son 3 corazones. Un golpe de Moblin le saca 1, o sea medio corazón |
| Enemigos y jefes | Golpes | Moblin con `vida = 2` muere con dos espadazos normales (daño 1) o con uno recargado (daño 2) |
| Proyectiles | 1 | Tienen defensa con tope 0, así que nunca pierden esa vida por un golpe |

**Ejemplo de cómo quedan los atributos en algunas subclases** (después de su constructor):

| Subclase | `vida` | `movimiento` | `ataque` | `defensa` |
|---|---|---|---|---|
| `Link` | `MEDIOS_CORAZONES_INICIALES` = 6 | `MovimientoInducido(null, VELOCIDAD_CAMINANDO)` (`caminar`, 4 px) | `AtaqueRecargado(DANIO_ESPADA, ALCANCE_ESPADA)` = `(1, 32)` | `DefensaLimitada(SIN_LIMITE, SIEMPRE)` |
| `Moblin` | `VIDA` = 2 | `MovimientoAleatorio(VELOCIDAD, INTERVALO_CAMBIO_DIRECCION)` = `(2, 1500)` | `AtaquePorContacto(DANIO_CONTACTO)` = `(1)` | `DefensaLimitada(SIN_LIMITE, SIEMPRE)` |
| `Octorok` | `VIDA` = 1 | `MovimientoAleatorio(2, 1500)` | `AtaquePorProyectil(this, 1, 2000)` | `DefensaLimitada(SIN_LIMITE, SIEMPRE)` |
| `TrampaDeCuchillas` | `VIDA` = 1 | `MovimientoInducido(null, VELOCIDAD_SALIDA)` (8 px) | `AtaquePorContacto(1)` | `DefensaLimitada(0, SIEMPRE)`: indestructible |
| `Proyectil` | `VIDA` = 1 | `MovimientoInducido(d, VELOCIDAD)` (6 px) | La heredada: no lastima al tocar (el daño lo aplica Link) | `DefensaLimitada(0, SIEMPRE)` |

Desde la defensa 7 los valores son constantes de clase con nombre en cada subclase, y cada una declara también su cuerpo
(`CUERPO_MARGEN_X`, `CUERPO_MARGEN_Y`, `CUERPO_ANCHO`, `CUERPO_ALTO`).

## 5. El constructor

```java
protected EntidadAnimada(Sprite sprite, int x, int y, int vida) {
    super(sprite, x, y);
    this.vida = vida;
    direccion = Direccion.ABAJO;
    pendientes = new ArrayList<>();
    movimiento = new MovimientoInducido((Direccion) null, 0);                  // quieta
    ataque = new AtaquePorContacto(0);                                          // no lastima al tocar
    defensa = new DefensaLimitada(DefensaLimitada.SIN_LIMITE, DefensaLimitada.SIEMPRE);   // defensa normal
}
```

Paso por paso:

1. **`super(sprite, x, y)`**: el constructor de `Entidad` guarda el sprite, la posición y arma el `hitbox` de `Entidad.LADO` × `LADO` (48 × 48) sin margen. Una subclase cuyo dibujo no ocupa toda la imagen lo reemplaza después con `setCuerpo(...)` (ver [hitbox con margen](#hitbox-con-margen-lo-que-hereda-de-entidad)).
2. **`this.vida = vida`**: la vida la decide cada subclase (Link 6, Moblin 2, StoneHinox 10...).
3. **`direccion = ABAJO`**: todas arrancan mirando hacia la cámara, como en el juego original.
4. **`pendientes = new ArrayList<>()`**: sin acciones programadas.
5. **Estrategias por defecto**: ninguna queda en `null`, así la vuelta nunca tira `NullPointerException`. Si una subclase no pone su estrategia, se queda quieta, no lastima y recibe todo el daño.

**Por qué es `protected`:** solo lo pueden llamar las subclases (con `super(...)`). Además la clase es abstracta, así que `new EntidadAnimada(...)` no compila.

**Ejemplo, cómo la usa `Proyectil`:**

```java
public Proyectil(Sprite sprite, int x, int y, Direccion d, int danio, int lado) {
    super(sprite, x, y, VIDA);                                 // EntidadAnimada con VIDA = 1
    int margen = (LADO_IMAGEN - lado) / 2;                     // el dibujo está centrado en la imagen
    setCuerpo(margen, margen, lado, lado);                     // cuerpo de lado x lado (LADO_DISPARO = 30, LADO_ROCA_GRANDE = 48)
    this.danio = danio;
    setDireccion(d);                                           // cambia ABAJO por la dirección del disparo
    setMovimiento(new MovimientoInducido(d, VELOCIDAD));       // reemplaza el "quieta" (VELOCIDAD = 6)
    setDefensa(new DefensaLimitada(0, DefensaLimitada.SIEMPRE)); // reemplaza la defensa normal
}
```

El ataque no se cambia: queda el `AtaquePorContacto(0)` por defecto, porque el daño del proyectil lo aplica Link en `Link.colisionarCon(Proyectil)`.

## 6. Usos: quién usa a EntidadAnimada

| Quién | Qué usa | Para qué |
|---|---|---|
| `HiloJugador` | `link.actualizarEstado(colisiones)` | La vuelta de Link, cada 30 ms |
| `HiloMundo` → `Sector.actualizarEntidades(c)` | `entidad.actualizarPorMundo(c)` | La vuelta del resto. En las fijas no hace nada; en las animadas llama a `actualizarEstado(c)` |
| `AdministradorColisiones.mover` | `avanzar(d, pasos)`, `alChocarConBloqueo()`, `alSalirDelSector(d)` | Mueve si no hay bloqueo y avisa si chocó o salió de la pantalla |
| `Roca`, `Agua`, `CaidasAlVacio`, `Enemigo*`, `Link` (en `bloqueaPasoA`) | `quien.esquivaVacios()`, `quien.esFrenadoPorPersonajes()` | Decidir si le frenan el paso (defensa 7) |
| `AdministradorColisiones.verificarColisiones` | Recibe la entidad y llama `aceptarColision` de lo que toca | Visitor |
| `MovimientoInducido`, `MovimientoAleatorio` | `c.mover(e, ...)`, `avanzarHacia`, `setDireccion` | Mover a la entidad |
| `MovimientoTeletransporte` | `ubicarCuerpoEn`, `teletransportarse()` | El salto del Wizzrobe |
| `AtaqueEspada`, `AtaqueRecargado` | `quiereAtacar()`, `soltoElAtaque()`, `getDireccion()`, `ataqueRealizado()` | Saber cuándo y hacia dónde golpear |
| `AtaquePorProyectil`, `AtaqueAvalancha` | `linkEstaEnfrente()`, `hayObstaculoHastaJugador()` (cambio 29, solo `AtaquePorProyectil`), `getCentro()`, `getJuego()`, `getSector()`, `ataqueTerminado()` | Saber si disparar, desde dónde, y avisar que terminó la avalancha |
| `AtaquePorContacto.ataqueAlContactar` | `tocado.recibirDanio(danio, ...)` | Lastimar al tocar (defensa 6) |
| `DefensaLimitada`, `DefensaPorEscudo` | `e.aplicarDanio(real)`, `e.getDireccion()` | Restar la vida que dejan pasar |
| `Enemigo.recibirGolpeDeEspada` | `recibirDanio(danio, atacante.getDireccion())` | El espadazo de Link |
| `PanelPantallaNivel` (HUD) | `getCorazones()` de Link, que devuelve su `vida` | Mostrar los corazones |
| `CeldaGrafica` (Observer) | Se entera por `notificarObservers()` y pregunta `esVisible()` | Redibujar posición, dirección o vida, y parpadear (defensa 7) |
| `PanelPantallaNivel.agregarCelda` | `getCapa()` | Dibujarla por encima del suelo, los objetos y las rocas (defensa 7) |
| `TrampaDeCuchillas`, `MoblinConEspadaYEscudo` | `hayObstaculoHastaJugador()` | No abalanzarse si hay roca, agua o vacío en el medio (defensa 7) |
| `AtaquePorProyectil` (Octorok y Wizzrobe; las rocas del StoneHinox usan `AtaqueRafaga`, que no lo pide) | `hayObstaculoHastaJugador()` | No disparar si hay roca, agua o vacío en el medio (cambio 29) |

## 7. Comandos, uno por uno, con ejemplo

### 7.1 Estrategias (Strategy)

| Método | Qué hace | Ejemplo |
|---|---|---|
| `setMovimiento(m)` | Cambia cómo se mueve | El Moblin con escudo ve a Link: `setMovimiento(new MovimientoInducido(getDireccion(), VELOCIDAD_ABALANZADA))` y se abalanza. La trampa vuelve con `MovimientoInducido(posicionOriginal, VELOCIDAD_VUELTA)` |
| `setAtaque(a)` | Cambia cómo ataca | MasterStalfos en `faseEspada()`: `setAtaque(espada)`; en `faseContacto()`: `setAtaque(contacto)` |
| `setDefensa(d)` | Cambia cuánto daño deja pasar | Link golpeado: `setDefensa(new DefensaLimitada(0, SIEMPRE))` queda invulnerable |

Los tres solo reemplazan el atributo. El cambio se nota en la **próxima** llamada a la estrategia.

### 7.2 Dirección

```java
public void setDireccion(Direccion d) {
    direccion = d;
    sprite.setEstado(d.name().toLowerCase());
    notificarObservers();
}
```

1. Guarda la dirección nueva.
2. `d.name()` devuelve el nombre de la constante (`"IZQUIERDA"`), `toLowerCase()` lo pasa a minúsculas (`"izquierda"`) y con eso el sprite elige la imagen de esa dirección. No hace falta un `switch`.
3. Avisa a los observadores para que la celda se redibuje con la imagen nueva.

**Ejemplo:** Link aprieta la flecha izquierda → `setDireccion(IZQUIERDA)` → `sprite.setEstado("izquierda")` → la celda muestra a Link mirando a la izquierda.

**Cuidado:** las claves con las que se cargan las imágenes del sprite tienen que ser exactamente `"arriba"`, `"abajo"`, `"izquierda"` y `"derecha"`.

### 7.3 La vuelta

| Método | Qué hace | Ejemplo |
|---|---|---|
| `actualizarEstado(c)` | Una vuelta completa: vigilar, mover, atacar, colisiones y pendientes (ver sección 9) | `HiloJugador` la llama sobre Link cada 30 ms |
| `actualizarPorMundo(c)` | Redefine el gancho de `Entidad`: llama a `actualizarEstado(c)` | `HiloMundo` recorre el sector y cada Moblin hace su vuelta. Link lo redefine **vacío** para no moverse dos veces |

### 7.4 Movimiento

| Método | Qué hace | Ejemplo |
|---|---|---|
| `avanzar(d, pasos)` | Mueve `pasos` píxeles en la dirección `d`. **No** mira bloqueos | Link en (100, 100) hace `avanzar(DERECHA, 4)` → queda en (104, 100) |
| `avanzarHacia(destino, pasos)` | Se acerca a `destino`, hasta `pasos` píxeles en x **y** en y a la vez, sin pasarse | Roca de avalancha en (200, 0) con destino (210, 150) y 6 pasos: queda en (206, 6), después (210, 12) (en x ya llegó), luego (210, 18)... |

**¿Quién controla las rocas, el agua y los demás bloqueos?** `AdministradorColisiones.mover(e, d, pasos)`, que con `buscarBloqueo` le pregunta a cada entidad de adelante `bloqueaPasoA(e)` **antes** de llamar `avanzar`. Así `avanzar` queda simple y cualquiera que necesite mover sin chocar (la avalancha) usa `avanzarHacia`.

**Detalle de `avanzarHacia`:** el `Math.max(-pasos, Math.min(pasos, diferencia))` "recorta" la diferencia entre `-pasos` y `pasos`. Si faltan 2 píxeles y `pasos` es 6, avanza 2 y no se pasa.

### 7.5 Daño

| Método | Qué hace | Ejemplo |
|---|---|---|
| `recibirDanio(danio, origen)` | Pasa el golpe por la defensa; si hizo daño, llama `alSerGolpeado()` | Moblin recibe espadazo de 1: la defensa normal deja pasar 1 → `aplicarDanio(1)` → vida 2 → 1 |
| `aplicarDanio(danio)` | Resta la vida; si sigue viva, la hace parpadear 600 ms; notifica y, si llega a 0, `morir()` | Moblin con vida 2 recibe 1 → vida 1 → parpadea. Con vida 1 recibe 1 → vida 0 → `morir()` → muestra la nube 300 ms (cambio 34) y después se elimina, suma 100 puntos y quizás suelta un drop |

Detalle completo con diagrama en la sección 10.

### 7.6 Acciones programadas

| Método | Qué hace | Ejemplo |
|---|---|---|
| `programar(ms, accion)` | Anota la acción para dentro de `ms` milisegundos | Link golpeado: `programar(DURACION_INVULNERABILIDAD, this::restaurarDefensa)` (1000 ms) |
| `cancelarProgramadas()` | Descarta las acciones anotadas que no vencieron (cambio 34) | El Moblin al morir: si estaba por abalanzarse, esas acciones ya no se ejecutan |
| `ejecutarPendientes()` (privado) | Ejecuta las vencidas. Último paso de la vuelta | 1000 ms después, en una vuelta de `HiloJugador`, se ejecuta `restaurarDefensa()` |
| `sacarVencidas(ahora)` (privado) | Saca de la lista las vencidas y las devuelve | Si hay tres anotadas y una venció, devuelve una y quedan dos |

Detalle en la sección 11.

### 7.7 Ganchos vacíos

Son métodos que en `EntidadAnimada` **no hacen nada**. Existen para que la superclase o las estrategias los puedan llamar siempre, sin preguntar qué tipo de entidad es. La subclase que los necesita los redefine. La tabla completa de quién los llama y quién los redefine está en la sección 12.

`alChocarConBloqueo()`, `alSalirDelSector(d)`, `vigilarJugador()`, `morir()`, `alSerGolpeado()`, `ataqueRealizado()`, `restaurarDefensa()`, `teletransportarse()`, `ataqueTerminado()`.

### 7.8 Colisiones (Visitor)

Los seis `colisionarCon(...)` están **vacíos**: por defecto, tocar algo no hace nada. Cada subclase redefine solo los que le importan:

| Subclase | Redefine | Qué hace |
|---|---|---|
| `Enemigo*` | `colisionarCon(Link l)` | Defensa 6: `ataque.ataqueAlContactar(this, l)`. Si su ataque es por contacto, lastima a Link. Desde el cambio 48, mientras muere no hace nada |
| `Link` | `colisionarCon(Enemigo)`, `(Proyectil)`, `(Obstaculo)`, `(PowerUP)`, `(Objeto)` | Defensa 7: `colisionarCon(Enemigo e)` hace `e.colisionarCon(this)`, así el daño lo pone el enemigo también cuando es Link el que camina contra él. Además recibe el daño del proyectil, cae al vacío, junta rupias, levanta la espada... |
| `Proyectil` | Ninguno | Atraviesa a los enemigos sin hacerles nada |

**Ejemplo de doble despacho:** el Moblin hace su vuelta y camina contra Link.

1. `c.mover(moblin, d, 2)` encuentra a Link adelante y `link.bloqueaPasoA(moblin)` da `true`: el Moblin no avanza.
2. Como se frenaron, `mover` llama `link.aceptarColision(moblin)`.
3. `Link.aceptarColision` responde `moblin.colisionarCon(this)`. Como `this` es un `Link`, Java elige `colisionarCon(Link)`.
4. `Enemigo.colisionarCon(Link)` → `ataque.ataqueAlContactar(this, link)` → `link.recibirDanio(1, ...)`.

### 7.9 Bloqueo: las dos preguntas del que camina (defensa 7)

Cuando la entidad camina, lo que está adelante decide si la frena con `bloqueaPasoA(quien)`. Para no preguntar el tipo,
le hace a la entidad una de dos preguntas:

| Consulta | `EntidadAnimada*` | La redefinen | Quién pregunta |
|---|---|---|---|
| `esquivaVacios()` | `false` | `Enemigo*`: `true` | `CaidasAlVacio.bloqueaPasoA` |
| `esFrenadoPorPersonajes()` | `false` | `Enemigo*` y `Link`: `true` | `Enemigo.bloqueaPasoA` y `Link.bloqueaPasoA` |

Resultado: un enemigo no cae al vacío y se frena contra Link y contra otros enemigos; Link pisa el vacío (y cae) pero se
frena contra los enemigos; un proyectil, que no redefine ninguna, solo se frena con rocas y agua.

### 7.10 Parpadeo (defensa 7)

| Método | Qué hace |
|---|---|
| `aplicarDanio(danio)` | Si después del daño sigue viva, `finParpadeo = ahora + DURACION_PARPADEO` (600 ms) |
| `# parpadearDurante(ms)` | Estira el parpadeo hasta `ahora + ms`, sin acortarlo (`Math.max`), y avisa a la vista. Lo llaman `Link`, `Wizzrobe` y `MasterStalfos` en su `alSerGolpeado()`, con su tiempo de invulnerabilidad |
| `- avisarParpadeo()` | Último paso de la vuelta. Si está parpadeando, avisa a la vista; cuando se pasa `finParpadeo`, lo pone en `0` y avisa una última vez |
| `+ esVisible()` | `true` si no parpadea; mientras parpadea, alterna cada 100 ms: `ahora >= finParpadeo \|\| (ahora / 100) % 2 == 0` |

```java
private void avisarParpadeo() {
    if (finParpadeo != 0) {
        if (System.currentTimeMillis() >= finParpadeo)
            finParpadeo = 0;
        notificarObservers();
    }
}

@Override
public boolean esVisible() {
    long ahora = System.currentTimeMillis();
    return ahora >= finParpadeo || (ahora / 100) % 2 == 0;
}
```

La lógica decide si la entidad se ve, y la vista (`CeldaGrafica`) solo hace `setVisible(esVisible())`. No hay hilos ni
timers nuevos: se reutilizan la vuelta del hilo y el Observer.

| Quién | Parpadea |
|---|---|
| Moblin, Moblin con escudo, Octorok, Erizo | 600 ms al recibir daño (para que se vea que el golpe entró) |
| Link | 1 s, lo mismo que su invulnerabilidad |
| Wizzrobe | 1 s, hasta que se teletransporta |
| MasterStalfos | 800 ms, lo mismo que su invulnerabilidad |
| StoneHinox | 600 ms cuando recibe daño |
| Trampa y proyectiles | Nunca (son invulnerables, la defensa no deja pasar el daño) |

## 8. Consultas, una por una, con ejemplo

| Consulta | Devuelve | Ejemplo |
|---|---|---|
| `getDireccion()` | Hacia dónde mira | `AtaqueEspada` la usa para saber dónde golpear: Link mira a la derecha → golpea a la derecha |
| `getVida()` | La vida que le queda | Link con `vida = 5` → el HUD muestra 2 corazones y medio |
| `quiereAtacar()` | `false` por defecto | Link la redefine: devuelve `true` mientras se mantiene la tecla de ataque. MasterStalfos: `true` si Link toca la zona de su espada, `getHitbox().adelante(getDireccion(), ALCANCE_ESPADA)` |
| `soltoElAtaque()` | `false` por defecto | Link la redefine: `true` cuando soltó la tecla, para que `AtaqueRecargado` sepa si cargó 3 s o más |
| `linkEstaEnfrente()` | `true` si Link está en línea y en la dirección en la que mira | Moblin en (100, 100) mirando a la DERECHA y Link en (200, 100): misma franja horizontal y Link está a la derecha → `true`. Si el Moblin mirara a la IZQUIERDA → `false` |
| `direccionHaciaJugador()` | La dirección en la que está Link, comparando **centros** (`getCentro().direccionHacia(link.getCentro())`) | Wizzrobe en (300, 50) y Link en (300, 200): centros (324, 75) y (324, 224) → `ABAJO`. El Wizzrobe dispara hacia ahí |
| `hayObstaculoHastaJugador()` (defensa 7) | `true` si en la franja entre su cuerpo y el de Link hay algo que `impideAbalanzarse()` (roca, agua o vacío) | Trampa en la fila de Link con una roca en el medio → `true`: no sale |
| `esquivaVacios()`, `esFrenadoPorPersonajes()` (defensa 7) | `false` por defecto | Ver 7.9 |
| `esVisible()` (defensa 7) | Si se ve en este instante | Ver 7.10 |
| `getCapa()` (defensa 7) | `CAPA_PERSONAJES` (3). Link lo redefine con `CAPA_JUGADOR` (4) | La vista dibuja a los personajes encima de las rocas |

**Cómo trabaja `linkEstaEnfrente`:**

```java
Entidad link = miJuego.getJugador();     // defensa 7: Entidad, no Link
boolean estaEnLinea = getHitbox().estaEnLineaCon(link.getHitbox());
boolean estaEnfrente = estaEnLinea && direccionHaciaJugador() == direccion;
```

Pide dos cosas a la vez: que compartan una franja horizontal o vertical (`estaEnLineaCon`) y que la dirección hacia Link sea la misma hacia la que mira la entidad.

**Defensa 7: `getJugador()` devuelve `Entidad`.** El ayudante marcó que devolver `Link` deshacía el encapsulamiento:
cualquier entidad podía hacer `getJugador().sumarPuntos(...)`. Las entidades solo lo usan para ubicar a Link
(`getHitbox()`, `getCentro()`, `getPosicion()`, `getX()`), y todo eso está en `Entidad`.

**Cómo trabaja `hayObstaculoHastaJugador`:**

```java
public boolean hayObstaculoHastaJugador() {
    Entidad link = miJuego.getJugador();
    Hitbox camino = getHitbox().caminoHasta(link.getHitbox());   // la franja entre los dos cuerpos
    boolean hayObstaculo = false;
    for (Entidad otra : miSector.getEntidades())
        if (otra != this && otra != link && !otra.estaEliminada()
                && otra.impideAbalanzarse() && otra.getHitbox().intersecta(camino))
            hayObstaculo = true;
    return hayObstaculo;
}
```

Es una pregunta aparte de `bloqueaPasoA`: el vacío **tapa** a Link (la trampa no sale) aunque a Link no le **frene** el
paso.

## 9. La vuelta: actualizarEstado en detalle

```java
public void actualizarEstado(AdministradorColisiones c) {
    if (!estaEliminada()) {
        vigilarJugador();                       // gancho
        movimiento.mover(this, c);              // Strategy
        ataque.atacar(this, c);                 // Strategy
        if (!estaEliminada())
            c.verificarColisiones(this);        // Visitor
        ejecutarPendientes();                   // acciones programadas vencidas
        avisarParpadeo();                       // defensa 7
    }
}
```

| Paso | Qué hace | Por qué en ese orden |
|---|---|---|
| `if (!estaEliminada())` | Si ya murió, no hace nada en toda la vuelta | Una entidad muerta no se mueve, no ataca y sus pendientes no se ejecutan |
| `vigilarJugador()` | Mira dónde está Link y puede cambiar su estrategia | Va primero para que el movimiento de **esta** vuelta use la decisión nueva |
| `movimiento.mover(this, c)` | La estrategia de movimiento la mueve (o no) | Antes de atacar, para atacar desde la posición nueva |
| `ataque.atacar(this, c)` | La estrategia de ataque golpea o dispara si le toca | — |
| `if (!estaEliminada())` (otra vez) | Se vuelve a preguntar | Pudo morir en los pasos anteriores: un proyectil que chocó con una roca ya se eliminó |
| `c.verificarColisiones(this)` | Busca lo que se superpone y aplica el Visitor | Se hace **aunque no se haya movido**. Desde la defensa 7 los choques que frenan (Link contra un enemigo) llegan por `mover`; acá quedan los que se pisan (vacío, pasto, power-ups, proyectiles) |
| `ejecutarPendientes()` | Ejecuta las acciones vencidas | Al final, para no cambiar estrategias a mitad de la vuelta |
| `avisarParpadeo()` (defensa 7) | Si parpadea, avisa a la vista | Último, así la celda se actualiza con todo lo que pasó en la vuelta |

```mermaid
sequenceDiagram
    participant H as HiloMundo
    participant E as Moblin
    participant M as MovimientoAleatorio
    participant A as AtaquePorContacto
    participant C as AdministradorColisiones
    H->>E: actualizarPorMundo(c)
    E->>E: actualizarEstado(c)
    E->>E: vigilarJugador() (vacío)
    E->>M: mover(this, c)
    M->>C: mover(moblin, d, 2)
    C->>C: buscarBloqueo: Link adelante, bloqueaPasoA(moblin) = true
    C->>E: link.aceptarColision(moblin) → colisionarCon(link)
    E->>A: ataqueAlContactar(moblin, link)
    C-->>M: false (no avanzó)
    M->>E: setDireccion(otra al azar)
    E->>A: atacar(this, c) (no hace nada por vuelta)
    E->>C: verificarColisiones(this)
    E->>E: ejecutarPendientes()
    E->>E: avisarParpadeo()
```

## 10. El daño: recibirDanio y aplicarDanio

El daño está partido en dos métodos para que **la defensa decida** cuánto pasa sin que la entidad tenga que saber cómo:

```java
public synchronized void recibirDanio(int danio, Direccion origen) {
    boolean recibioDanio = defensa.recibirDanio(this, danio, origen);
    if (recibioDanio)
        alSerGolpeado();
}

public synchronized void aplicarDanio(int danio) {
    vida -= danio;
    if (vida > 0)
        finParpadeo = System.currentTimeMillis() + DURACION_PARPADEO;   // defensa 7
    notificarObservers();
    if (vida <= 0)
        morir();
}
```

```mermaid
sequenceDiagram
    participant X as Quien golpea
    participant E as EntidadAnimada
    participant D as Defensa
    X->>E: recibirDanio(danio, origen)
    E->>D: recibirDanio(this, danio, origen)
    D->>D: real = min(danio, danioMaximo)
    D->>E: aplicarDanio(real) (si real > 0)
    E->>E: vida -= real, parpadeo de 600 ms, notificarObservers()
    E->>E: morir() (si vida <= 0)
    D-->>E: true / false
    E->>E: alSerGolpeado() (si true)
```

**Tres ejemplos con la misma espada (daño 1):**

| Caso | Defensa | Qué pasa |
|---|---|---|
| Moblin con vida 2 | `DefensaLimitada(SIN_LIMITE, SIEMPRE)` | Pasa 1 → vida 1 → parpadea 600 ms → `alSerGolpeado()` (vacío en Moblin) |
| Trampa de cuchillas | `DefensaLimitada(0, SIEMPRE)` | `min(1, 0) = 0` → no pasa nada, devuelve `false`, no parpadea. Es indestructible |
| Moblin con escudo, golpeado de frente | `DefensaPorEscudo(true)` | El escudo bloquea según `origen` → no pasa nada, no parpadea |

**Ejemplo con Link (que redefine `recibirDanio` y `alSerGolpeado`):** Link tiene 6. Un Moblin lo toca → pasa 1 → vida 5 (parpadeo de 600 ms) → `alSerGolpeado()` pone `DefensaLimitada(0, SIEMPRE)`, `parpadearDurante(1000)` (el parpadeo se estira a 1 s) y `programar(1000, this::restaurarDefensa)`. Durante ese segundo, los toques del Moblin dan `min(1, 0) = 0` y no le hacen nada.

## 11. Acciones programadas: esperar sin hilos

Antes, para "esperar 1 segundo", cada entidad dormía su propio hilo. Ahora se **anota** lo que hay que hacer y el hilo que ya actualiza a la entidad lo ejecuta cuando vence.

```java
protected synchronized void programar(long ms, Runnable accion) {
    long instanteDeVencimiento = System.currentTimeMillis() + ms;
    pendientes.add(new AccionProgramada(instanteDeVencimiento, accion));
}

private void ejecutarPendientes() {
    List<AccionProgramada> accionesVencidas = sacarVencidas(System.currentTimeMillis());
    for (AccionProgramada accion : accionesVencidas)
        accion.ejecutar();
}
```

**Ejemplo con números:** a las 10:00:00.000 Link recibe un golpe y se llama `programar(1000, this::restaurarDefensa)`.

| Instante | Qué pasa |
|---|---|
| .000 | Se anota una acción que vence a las .000 + 1000 = 01.000 |
| .030, .060, ... .990 | En cada vuelta, `sacarVencidas` mira la lista y no hay nada vencido |
| 01.020 | La acción ya venció: se saca de la lista y se ejecuta `restaurarDefensa()`. Link vuelve a la defensa normal |

**Por qué se ejecutan fuera de la llave** (`ejecutarPendientes` no es `synchronized`, `sacarVencidas` sí): una acción puede volver a llamar a `programar`. MasterStalfos, por ejemplo, en `faseEspada()` programa `faseContacto()`, y esa a su vez vuelve a programar `faseEspada()`. Si se ejecutaran con la llave tomada, mientras dura la acción ningún otro hilo podría anotar nada en esa entidad y el juego se podría trabar.

**Quién programa qué:**

| Entidad | Espera | Para qué |
|---|---|---|
| `Link` | `DURACION_INVULNERABILIDAD` = 1000 ms | Termina la invulnerabilidad después de un golpe |
| `Link` | `DEMORA_ROTURA_SUELO` = 800 ms | Suelo quebradizo: se rompe un rato después de pisarlo; si Link sigue caminando, sale a tiempo (cambio 33) |
| `Enemigo` | `DURACION_MUERTE` = 300 ms | Muestra la nube de muerte antes de desaparecer (cambio 34 para el Moblin; desde el 48, todos) |
| `Link` | `DURACION_CAIDA` = 400 ms | Caída al vacío: lo que dura el GIF antes de perder la vida (cambios 31 y 32) |
| `MoblinConEspadaYEscudo` | `PREPARACION_ABALANZADA` = 300 ms, de a `DURACION_CAMBIO_VELOCIDAD` = 100 ms, `DURACION_ABALANZADA` = 1600 ms, `DURACION_FRENADO` = 500 ms | Sale acelerando, frena y `terminarAbalanzada()` vuelve a caminar al azar |
| `Wizzrobe` | `DURACION_INVULNERABILIDAD` = 1000 ms | Defensa 7: después de un golpe, vuelve a `MovimientoTeletransporte` |
| `Wizzrobe` | `DURACION_APARECER` = 500 ms y `INTERVALO_TELETRANSPORTE - DURACION_DESAPARECER` = 2500 ms | Cambio 30: deja de mostrar el GIF de aparecer y, medio segundo antes del próximo salto, muestra el de desaparecer |
| `MasterStalfos` | `DURACION_FASE` = 2000 ms | Alterna espada y contacto |
| `MasterStalfos` | `DURACION_INVULNERABILIDAD` = 800 ms | Vuelve a ser vulnerable después de un golpe |
| `MasterStalfos` | `DURACION_MUERTE` = 1530 ms | Muestra la animación de muerte antes de desaparecer (cambio 47; la devuelve `getDuracionMuerte()`, cambio 48) |
| `StoneHinox` | `DEMORA_PRIMER_ATAQUE` = 3000 ms, `DURACION_EMBESTIDA` = 1500 ms, `DURACION_VULNERABILIDAD` = 1000 ms, `DURACION_LANZAMIENTO_ROCAS` = 3000 ms, `DURACION_GOLPE_AVALANCHA` = 600 ms | Primer ataque, fin de la embestida, fin de la vulnerabilidad, fin del golpe de la avalancha y siguiente ataque |

## 12. Mapa de ganchos: quién los llama y quién los redefine

| Gancho | Quién lo llama | Quién lo redefine | Qué hace en esa subclase |
|---|---|---|---|
| `alChocarConBloqueo()` | `AdministradorColisiones.mover`, si algo le bloquea el paso (`bloqueaPasoA`) | `Proyectil` | `desaparecer()` |
| | | `TrampaDeCuchillas` | `volver()` a su posición original |
| `alSalirDelSector(d)` | `AdministradorColisiones.mover`, si quedó fuera de la pantalla | `Link` | Cambia de sector (`miJuego.cambiarDeSector(d)`) |
| | | `Enemigo*` | Retrocede 8 px, se da vuelta y llama a `alChocarConBloqueo()` |
| | | `Proyectil` | `desaparecer()` |
| `vigilarJugador()` | `actualizarEstado`, primer paso | `TrampaDeCuchillas` | Si está en reposo y Link queda en línea sin obstáculos en el medio, sale hasta donde estaba Link; si ya llegó, vuelve |
| | | `MoblinConEspadaYEscudo` | Si no se está abalanzando y Link está enfrente sin obstáculos en el medio, se prepara 300 ms, sale acelerando, se abalanza 1600 ms y frena |
| `morir()` | `aplicarDanio`, si la vida llega a 0 | `Link` | Si le quedan vidas, cae para atrás y se levanta (1,3 s, cambio 45); si es la última, muestra la animación de muerte (2,1 s, cambio 43). Después pierde la vida o termina la partida |
| | | `Enemigo*` | Quieto, invulnerable y sin atacar con su animación de muerte durante `getDuracionMuerte()` y después `desaparecer()` (cambios 34 y 48) |
| | | `Proyectil` | `desaparecer()` |
| `desaparecer()` | La acción que programa `Enemigo.morir()` | `Enemigo*` | `eliminar()` y `miJuego.enemigoDerrotado(this)` (cambio 48) |
| | | `EnemigoConDrop*` | Lo de `Enemigo` y además `soltarDrop()` |
| | | `Jefe*` | `eliminar()` y `miJuego.jefeDerrotado(this)` |
| `getDuracionMuerte()` | `Enemigo.morir()` | `MasterStalfos` | 1530 ms en lugar de 300 (cambio 48) |
| `alSerGolpeado()` | `recibirDanio`, si el golpe hizo daño | `Link` | Invulnerable y parpadeando 1 s |
| | | `MasterStalfos` | Tope 0, parpadea y `programar(800, ...)`; mientras muere, nada (cambio 47) |
| | | `Wizzrobe` | Defensa 7: invulnerable, quieto y parpadeando 1 s; después vuelve a teletransportarse |
| `ataqueRealizado()` | `AtaqueEspada` / `AtaqueRecargado` después de golpear | `Link` | `atacando = false`, `soltoAtaque = false` y 8 vueltas con la imagen del golpe (cambio 39) |
| | | `MasterStalfos` | 25 vueltas con el GIF del golpe en `direccionGolpe` (cambio 44) |
| `restaurarDefensa()` | La acción programada de Link | `Link` | Vuelve a `defensaBase` si no usa el escudo |
| `teletransportarse()` | `MovimientoTeletransporte` después del salto | `Wizzrobe` | Vulnerable otra vez y mirando a Link |
| `ataqueTerminado()` | `AtaqueAvalancha.alTerminar` | `StoneHinox` | Se queda quieto `DURACION_GOLPE_AVALANCHA` (600 ms) con la imagen de golpear el suelo (un GIF que dura esos 600 ms, cambio 50) y después `siguienteAtaque()` (cambio 20) |

**Por qué ganchos y no `instanceof`:** `AdministradorColisiones` llama `e.alChocarConBloqueo()` sin preguntar si `e` es un proyectil o una trampa. Cada uno responde a su manera y al resto no le pasa nada. Si mañana se agrega una entidad que tiene que rebotar, se redefine el gancho y no se toca el administrador.

## 13. Ejemplos completos, paso a paso

### 13.1 Un proyectil del Octorok choca con una roca

1. `HiloMundo` → `proyectil.actualizarPorMundo(c)` → `actualizarEstado(c)`.
2. `vigilarJugador()`: vacío.
3. `movimiento.mover(this, c)`: `MovimientoInducido(DERECHA, 6)` llama `c.mover(proyectil, DERECHA, 6)`.
4. `buscarBloqueo` devuelve la roca (`roca.bloqueaPasoA(proyectil)` es `true`) → `roca.aceptarColision(proyectil)` →
   `proyectil.colisionarCon(roca como Obstaculo)`, vacío → `proyectil.alChocarConBloqueo()` → `desaparecer()` →
   `eliminar()`.
5. `ataque.atacar(...)`: no hace nada.
6. `if (!estaEliminada())`: ahora es `true` que está eliminado → **no** se verifican colisiones. Así no lastima a Link "después de muerto".
7. `ejecutarPendientes()`: no tiene nada.
8. En la próxima vuelta, el primer `if` ya corta todo.

### 13.2 El erizo de mar quieto y Link que camina contra él

1. Link camina hacia el erizo. En la vuelta de Link (`HiloJugador`), `c.mover(link, d, 4)` encuentra al erizo
   adelante: `erizo.bloqueaPasoA(link)` → `link.esFrenadoPorPersonajes()` → `true`. Link no avanza.
2. `mover` dispara el choque: `erizo.aceptarColision(link)` → `link.colisionarCon(erizo)` → `erizo.colisionarCon(link)`
   (defensa 7).
3. `Enemigo.colisionarCon(Link)` → `AtaquePorContacto(1).ataqueAlContactar(erizo, link)` → `link.recibirDanio(1, ...)`.
4. Link pasa de 6 a 5 y queda invulnerable y parpadeando 1 s.
5. Si Link sigue empujando, cada vuelta se dispara el choque otra vez, pero la defensa con tope 0 no deja pasar nada.
   Cuando termina el segundo, el siguiente empujón le saca otro medio corazón.

### 13.3 La trampa de cuchillas se abalanza y vuelve (defensa 7)

1. La trampa está quieta en su posición original (`MovimientoInducido(null, VELOCIDAD_SALIDA)`).
2. Link se para en la misma fila. En la vuelta de la trampa, `vigilarJugador()` ve que está en reposo, en línea con Link
   y que **no hay roca, agua ni vacío en el medio** (`!hayObstaculoHastaJugador()`).
3. Guarda en `destino` el lugar de Link sobre esa fila, hace `setDireccion(d)` y
   `setMovimiento(new MovimientoInducido(d, VELOCIDAD_SALIDA))`.
4. En esa misma vuelta, `mover` ya la mueve 8 px hacia Link (por eso `vigilarJugador` va primero).
5. Si Link sigue ahí, la trampa se frena contra él (`link.bloqueaPasoA(trampa)` es `true`): `mover` dispara el choque, le
   saca medio corazón, y `alChocarConBloqueo()` llama a `volver()`.
6. Si Link se corrió, la trampa sigue hasta `destino`. En cada vuelta `vigilarJugador()` pregunta `llegoAlDestino()`;
   cuando da `true`, llama a `volver()`.
7. `volver()` pone `destino = null` y `MovimientoInducido(posicionOriginal, VELOCIDAD_VUELTA)`: vuelve despacio, a 4 px.
   Cuando llega, queda otra vez en reposo.

### 13.4 Link mata a un Moblin y aparece una rupia

1. Link suelta la espada mirando a la derecha. `AtaqueRecargado` golpea al Moblin: `moblin.recibirGolpeDeEspada(link, 1)`.
2. → `recibirDanio(1, DERECHA)` → la defensa deja pasar 1 → `aplicarDanio(1)`.
3. El Moblin tenía 1 (el primer espadazo lo dejó en 1 y lo hizo parpadear) → 0 → no parpadea → `notificarObservers()` → `morir()`.
   **Cambios 34 y 48:** `Enemigo.morir()` prende `muriendo`, cancela lo programado, lo deja quieto, invulnerable y sin atacar, la vista muestra la nube y programa `desaparecer()` para dentro de 300 ms. Mientras tanto no lastima a Link.
4. A los 300 ms, `EnemigoConDrop.desaparecer()` → `eliminar()` y `miJuego.enemigoDerrotado(this)` (suma 100 puntos). Si devuelve `true` (con esta muerte apareció la bellota) no hay drop, así no la tapa; si no, → `soltarDrop()`.
5. Con 20 % de probabilidad, `miJuego.agregarEntidad(generarDrop())`: aparece una rupia o un corazón donde estaba el cuerpo del Moblin (esquina de su `Hitbox`).
6. En la próxima vuelta de `HiloMundo`, el Moblin ya está eliminado y no hace nada.

### 13.5 MasterStalfos cambia de fase con acciones programadas

1. En su constructor, el jefe arranca en `faseEspada()`: `setAtaque(espada)` y `programar(DURACION_FASE, this::faseContacto)`.
2. Durante esa fase, en cada vuelta: si `quiereAtacar()` (Link toca la zona de la espada, de `ALCANCE_ESPADA` = 40 px delante de su cuerpo), la espada golpea y llama a `ataqueRealizado()`, que desde la defensa 7 muestra la imagen del espadazo durante 16 vueltas (unos 480 ms).
3. Cuando vence `DURACION_FASE`, en el último paso de una vuelta, `ejecutarPendientes()` ejecuta `faseContacto()`: `setAtaque(contacto)` y programa `faseEspada()`.
4. A partir de la vuelta siguiente, el jefe lastima al tocar en vez de usar la espada.
5. Así sigue alternando. Como `setAtaque` lo llama el mismo `HiloMundo` que lo actualiza, no compite con otro hilo.

### 13.6 El Wizzrobe se teletransporta

1. `MovimientoTeletransporte(3000)` cuenta el tiempo. Cuando pasan 3 s, busca `c.getSector().posicionLibreAlAzar(e.getAncho(), e.getAlto())`, lo ubica con `e.ubicarCuerpoEn(...)` (el lugar libre es para el cuerpo) y llama `e.teletransportarse()`.
2. `Wizzrobe.teletransportarse()` le pone defensa normal (vulnerable otra vez) y `setDireccion(direccionHaciaJugador())`: aparece mirando a Link.
3. `ataque.atacar` (`AtaquePorProyectil`) dispara hacia donde está Link.
4. Si Link lo golpea, `alSerGolpeado()` (defensa 7) le pone `DefensaLimitada(0, SIEMPRE)`, lo deja quieto con
   `MovimientoInducido(null, 0)`, lo hace parpadear 1 s y programa, para dentro de 1 s, volver a
   `MovimientoTeletransporte(3000)`.
5. Como la estrategia de teletransporte es nueva, salta en la vuelta siguiente, y `teletransportarse()` lo vuelve
   vulnerable. Así queda invulnerable exactamente un segundo, como dice el enunciado. En la defensa 6 quedaba
   invulnerable hasta el próximo salto, que podía tardar de 0 a 3 s.

### 13.7 Link sale por el borde de la pantalla

1. `HiloJugador` → `link.actualizarEstado(c)` → `caminar.mover(link, c)` → `c.mover(link, DERECHA, 4)`.
2. No hay bloqueo: `link.avanzar(DERECHA, 4)`. El hitbox queda afuera del sector → `link.alSalirDelSector(DERECHA)`.
3. `Link.alSalirDelSector` → `miJuego.cambiarDeSector(DERECHA)`: el juego carga el sector de al lado y ubica a Link en el borde opuesto.
4. `verificarColisiones` corta el recorrido porque `getSector()` de Link ya no es el mismo sector.

## 14. Hilos y sincronización

Una misma entidad la pueden tocar **dos hilos** a la vez: `HiloJugador` (Link y su espada) y `HiloMundo` (los enemigos y los proyectiles).

| Método | `synchronized` | Por qué |
|---|---|---|
| `recibirDanio` | Sí | La espada de Link (`HiloJugador`) y una roca de la avalancha (`HiloMundo`) pueden lastimar al mismo enemigo a la vez. Sin la llave, los dos leen `vida = 2`, los dos escriben `1` y se pierde un golpe |
| `aplicarDanio` | Sí | Lo mismo. Además, lo llama la defensa desde adentro de `recibirDanio`, y como la llave es la misma (la de la entidad), Java deja volver a entrar |
| `programar` | Sí | MasterStalfos (`HiloMundo`) golpea a Link y Link programa en **su** lista, mientras `HiloJugador` puede estar recorriéndola |
| `finParpadeo` (atributo) | `volatile` | Lo escribe el hilo que lastima (`aplicarDanio`, `parpadearDurante`) y lo leen el hilo de la entidad (`avisarParpadeo`) y el EDT (`esVisible`) |
| `sacarVencidas` | Sí | Recorre y modifica la lista |
| `ejecutarPendientes` | **No** | Ejecuta las acciones afuera de la llave (ver sección 11) |
| `actualizarEstado` | No | Cada entidad la actualiza un solo hilo |
| `setMovimiento`, `setAtaque`, `setDefensa` | No | Los llama el hilo que actualiza a la entidad, desde sus ganchos o acciones programadas |

**Orden de las llaves:** Entidad → Juego → Sector. Por ejemplo, `aplicarDanio` (llave de la entidad) puede llamar a `morir()` → `miJuego.enemigoDerrotado` (llave del juego). Nunca se toma al revés, así no hay deadlock.

## 15. Paquete e imports

```java
package logica.entidades;

import java.util.ArrayList;
import java.util.List;

import logica.comportamientos.AtaquePorContacto;
import logica.comportamientos.ComportamientoAtaque;
import logica.comportamientos.ComportamientoDefensa;
import logica.comportamientos.ComportamientoMovimiento;
import logica.comportamientos.DefensaLimitada;
import logica.comportamientos.MovimientoInducido;
import logica.entidades.enemigos.Enemigo;
import logica.entidades.fijas.Objeto;
import logica.entidades.fijas.Obstaculo;
import logica.entidades.fijas.PowerUP;
import logica.fabricas.Sprite;
import logica.hilos.AccionProgramada;
import logica.util.Direccion;
import logica.util.Hitbox;
import logica.util.Posicion;
```

- `Link`, `Proyectil`, `Colisionador`, `Entidad`, `EntornoJuego` y `AdministradorColisiones` están en el mismo paquete y no se importan. `Hitbox` se importa desde la defensa 7, para `hayObstaculoHastaJugador`.
- **`AdministradorColisiones` tiene que estar en `logica.entidades`**: llama a `alChocarConBloqueo()` y `alSalirDelSector(d)`, que son `protected`. Desde otro paquete no compilaría.
- Los ganchos que llaman las **estrategias** (`ataqueRealizado`, `restaurarDefensa`, `teletransportarse`, `ataqueTerminado`) son `public` por la misma razón: las estrategias están en `logica.comportamientos`. Lo mismo `esquivaVacios()` y `esFrenadoPorPersonajes()`, que las llaman `Roca`, `CaidasAlVacio`, etc., desde `logica.entidades.fijas` y `logica.entidades.enemigos`.

## 16. Cuidados y detalles conocidos

### Hitbox con margen: lo que hereda de Entidad

Desde la defensa 6 la posición y el cuerpo están separados (lo hereda de `Entidad*`), y desde la defensa 7 todos los personajes tienen su cuerpo ajustado al dibujo:

| Método heredado | Qué devuelve | Lo usa `EntidadAnimada` en |
|---|---|---|
| `getX()`, `getY()`, `getPosicion()` | La esquina de la **imagen** (donde se dibuja) | `avanzar` y `avanzarHacia`: mueven la posición, y el cuerpo la sigue con su margen |
| `getHitbox()`, `getAncho()`, `getAlto()` | El **cuerpo** y su tamaño | `linkEstaEnfrente` (`estaEnLineaCon`) y todas las colisiones |
| `getCentro()` | El centro del cuerpo | `direccionHaciaJugador` |
| `setCuerpo(mx, my, ancho, alto)` | — | Constructores de Link, los seis enemigos comunes, los dos jefes y `Proyectil`, con constantes de clase |
| `ubicarCuerpoEn(x, y)` | — | Teletransporte, proyectiles, avalancha y entrada de Link al sector |

Por eso `direccionHaciaJugador` compara centros: con el Master Stalfos (cuerpo de 117 × 120) la esquina queda lejos
de su centro, y la dirección hacia Link saldría corrida.


- **`vida` sin tope:** `aplicarDanio` puede dejarla negativa (vida 1 y daño 2 → −1). No es un problema porque se pregunta `vida <= 0`, pero si se muestra en pantalla conviene mostrar `Math.max(0, vida)`.
- **`morir()` se podría llamar dos veces** si una entidad con vida ≤ 0 recibe otro golpe antes de eliminarse. En los enemigos no pasa, porque `morir()` llama `eliminar()` y una entidad eliminada ya no aparece en `verificarColisiones`. Pero si una subclase redefine `morir()` sin eliminar, hay que tenerlo en cuenta (Link lo maneja con sus vidas).
- **`avanzarHacia` no mira bloqueos a propósito** (las rocas de la avalancha atraviesan las rocas del borde, y la trampa vuelve aunque algo se cruce). Por eso nadie llama `alChocarConBloqueo()` cuando la roca llega a su destino: queda quieta hasta que Link la toca.
- **`parpadearDurante` usa `Math.max`:** nunca acorta un parpadeo. En un golpe, `aplicarDanio` arranca 600 ms y después `alSerGolpeado()` lo estira; si fuera al revés, igual quedaría el más largo.
- **El sprite necesita las cuatro claves** `"arriba"`, `"abajo"`, `"izquierda"`, `"derecha"` para que `setDireccion` funcione.
- **Las acciones pendientes de una entidad eliminada nunca se ejecutan**, porque el primer `if` de la vuelta corta todo. Eso está bien para un enemigo muerto, pero no hay que programar en una entidad algo que tenga que pasar "después de morir".

## 17. Preguntas que pueden hacer en la defensa

| Pregunta | Respuesta |
|---|---|
| ¿Por qué es abstracta? | Porque no existe una entidad animada a secas, y además no implementa `aceptarColision(c)`: cada subclase concreta responde con su tipo (Visitor) |
| ¿Por qué las estrategias son agregación y no composición? | Porque se reemplazan en tiempo de ejecución (`setMovimiento`, `setAtaque`, `setDefensa`): la entidad no es dueña de una estrategia fija |
| ¿Por qué `pendientes` es composición? | Las acciones las crea `programar` adentro de la entidad y no tienen sentido sin ella |
| ¿Por qué el constructor pone estrategias por defecto? | Para que nunca haya `null` en la vuelta. Si una subclase no pone la suya, queda quieta, no lastima y recibe todo el daño |
| ¿Quién llama a `actualizarEstado`? | `HiloJugador` para Link y `actualizarPorMundo` para el resto, desde `HiloMundo` |
| ¿Por qué Link redefine `actualizarPorMundo` vacío? | Para que `HiloMundo` no lo mueva otra vez: Link ya lo mueve `HiloJugador` |
| ¿Por qué se verifica dos veces `estaEliminada()`? | La entidad pudo morir en el movimiento o el ataque (un proyectil que chocó con una roca). No tiene que seguir chocando con nada |
| ¿Por qué se verifican colisiones aunque no se mueva? | Para los choques que se superponen: si Link pisa un vacío o la trampa vuelve por encima de él. Los choques que frenan llegan por `mover` |
| ¿Cómo hace un enemigo para no caer al vacío sin `instanceof`? | `CaidasAlVacio.bloqueaPasoA(quien)` devuelve `quien.esquivaVacios()`. `Enemigo*` responde `true` y Link `false`. Cada uno responde por sí mismo |
| ¿Por qué Link y los enemigos se frenan y igual hay daño? | Porque `mover`, al frenarse, dispara el Visitor de efectos (`bloqueo.aceptarColision(e)`), y `Link.colisionarCon(Enemigo e)` delega en `e.colisionarCon(this)` |
| ¿Cómo parpadea una entidad sin timer? | Guarda `finParpadeo`; en cada vuelta `avisarParpadeo()` avisa a la vista, y `esVisible()` alterna cada 100 ms. La vista solo hace `setVisible(esVisible())` |
| ¿Por qué `getJugador()` devuelve `Entidad`? | Corrección de la defensa 6: las entidades solo necesitan ubicar a Link. Con `Link` podían sumarle puntos o sacarle vidas |
| ¿Cómo espera sin dormir el hilo? | `programar(ms, accion)` anota una `AccionProgramada` y `ejecutarPendientes` la ejecuta cuando vence, en el mismo hilo que actualiza a la entidad |
| ¿Por qué `recibirDanio` y `aplicarDanio` son `synchronized`? | Dos hilos pueden lastimar a la misma entidad a la vez. Sin la llave se pierde un golpe |
| ¿Por qué hay dos métodos de daño? | `recibirDanio` deja que la defensa decida cuánto pasa; `aplicarDanio` solo resta. Así cambiar la defensa (escudo, invulnerable) no toca la entidad |
| ¿Qué es un gancho? | Un método vacío en la superclase que la superclase o las estrategias llaman siempre, y que redefine solo la subclase que lo necesita. Evita `instanceof` |
| ¿Usa su sector para moverse? | No: el `AdministradorColisiones` le llega por parámetro (`actualizarEstado(c)`). El `miSector` que hereda de `Entidad` solo se usa para eliminarse y, desde la defensa 7, en `hayObstaculoHastaJugador` |

---

# Explicación de la clase Link (Defensa 7)

Explicativo detallado, con ejemplos de cada método y escenarios completos paso a paso. Basado en los diagramas extendido y
reducido de la defensa 7 (estrategia `bloqueaPasoA`) y en el código de `DEFENSA 7 FINAL/Codigo/src/logica/entidades/Link.java`.

**Lo que cambió en la defensa 7:**

- Los números sueltos pasaron a **constantes de clase con nombre** (`VIDAS_INICIALES`, `VELOCIDAD_CAMINANDO`,
  `DURACION_INVULNERABILIDAD`, etc.).
- Link tiene un **cuerpo ajustado** de 36 × 44 dentro de su imagen de 48 × 48 (`setCuerpo(6, 2, 36, 44)`).
- **Parpadea** el segundo que queda invulnerable (`parpadearDurante`).
- Muestra **imágenes de ataque y de escudo** (`getRutaImagen`), y la del espadazo dura unas vueltas
  (`vueltasMostrandoGolpe`).
- Decide a quién le bloquea el paso con **`bloqueaPasoA(quien)`** y avisa que lo frenan los enemigos con
  **`esFrenadoPorPersonajes()`**.
- `colisionarCon(Enemigo e)` ya no está vacío: **le delega al enemigo** (`e.colisionarCon(this)`).
- Se dibuja en la capa de arriba de todo (`getCapa()` devuelve `CAPA_JUGADOR`).
- `miJuego` es de tipo **`EntornoJuego`** (la interfaz que Juego le ofrece a las entidades).


## 1. Qué es

`Link` es el **personaje del jugador**. Guarda el estado de la partida que se ve en el HUD (vidas, corazones, puntaje, rupias, objeto equipado) y reacciona a todo lo que toca.

| Lo que hace | Cómo |
|---|---|
| Responde al teclado | Realiza `ControlJugador`; los métodos solo anotan la intención |
| Se mueve, ataca y se defiende | Con tres estrategias (Strategy) heredadas de `EntidadAnimada` |
| Reacciona a lo que toca | Doble despacho (Visitor) con los `colisionarCon(...)` |
| Muestra su estado | Realiza `EntidadJugador` (lo que lee el HUD) |
| Avisa a la partida | Llama a `miJuego`, que ve como `EntornoJuego` (daño, caída, cambio de sector, sin vidas, power-ups) |
| Frena a los enemigos | `bloqueaPasoA(quien)`: le bloquea el paso a quien `esFrenadoPorPersonajes()` |

**Lo mueve solo `HiloJugador`.** `actualizarPorMundo` está vacío para que `HiloMundo` no lo mueva dos veces.

**La vida se mide en medios corazones:** `vida = 6` son 3 corazones.

## 2. Herencia, interfaces y patrones

```java
public class Link extends EntidadAnimada implements EntidadJugador, ControlJugador
```

| Relación | Con | Para qué |
|---|---|---|
| Hereda | `EntidadAnimada*` | La vuelta (`actualizarEstado`), las estrategias, el daño, las acciones programadas |
| Realiza | `EntidadJugador` | Lo que lee el HUD: `getVidas`, `getCorazones`, `getCorazonesMaximos`, `getPuntaje`, `getRupias`, `getNombreObjetoEquipado` |
| Realiza | `ControlJugador` | Lo que manda el teclado: `mover`, `detenerMovimiento`, `atacar`, `soltarAtaque`, `usarEscudo`, `soltarEscudo`, `cambiarObjeto` |

| Patrón | Dónde aparece en Link |
|---|---|
| **Strategy** | `caminar` (MovimientoInducido), `recargado` (AtaqueRecargado), `defensaBase` / `DefensaPorEscudo` / invulnerable |
| **Visitor** | `aceptarColision(c)` y los cinco `colisionarCon(...)` |
| **Polimorfismo en el bloqueo** | `bloqueaPasoA(quien)` le pregunta al que camina `esFrenadoPorPersonajes()`, sin `instanceof` |
| **Observer** | `notificarObservers()` cada vez que cambia algo que se ve (posición, vida, puntaje, objeto) |
| **Template Method** | No en Link: lo usa `HiloJugador`, que lo actualiza |

## 3. Atributos

| Atributo | Tipo | Para qué | Relación |
|---|---|---|---|
| `# vidas` | `int` | Vidas que le quedan (empieza con 3) | |
| `# corazonesMaximos` | `int` | Tope de `vida`, en medios corazones (empieza en 6) | |
| `# puntaje` | `int` | Puntos de la partida | |
| `# rupias` | `int` | Rupias juntadas | |
| `# fragmentos` | `int` | Fragmentos de corazón (cada 4, un corazón más) | |
| `# racha` | `int` | Enemigos seguidos sin recibir daño (a los 4, bellota) | |
| `# inventario` | `List<Objeto>` | Espada y escudo | ◇ `#inventario 1..2` |
| `# objetoEquipado` | `Objeto` | El que usan las teclas | → `#objetoEquipado 0..1` |
| `# caminar` | `MovimientoInducido` | Su estrategia de movimiento, con tipo concreto | (es `#movimiento`) |
| `# recargado` | `AtaqueRecargado` | Su estrategia de ataque, con tipo concreto | (es `#ataque`) |
| `# defensaBase` | `ComportamientoDefensa` | La defensa a la que vuelve | (es `#defensa`) |
| `# escudoActivo` | `boolean` (`volatile`) | Está usando el escudo | |
| `# atacando` | `boolean` (`volatile`) | Apretó la tecla de ataque (está cargando) | |
| `# vueltasMostrandoGolpe` | `int` | **Defensa 7.** Vueltas que le quedan mostrando la imagen del espadazo | |
| `# soltoAtaque` | `boolean` (`volatile`) | Soltó la tecla: el próximo `atacar` de la estrategia golpea | |
| `# ralentizado` | `boolean` | Tocó pasto: el próximo paso avanza la mitad | |
| `# cayendo` | `boolean` (`volatile`) | **Cambio 31.** Está cayendo al vacío: se ve el GIF, no se mueve, no ataca ni usa el escudo | |
| `# muriendo` | `boolean` (`volatile`) | **Cambio 43.** Se quedó sin corazones y se ve la animación de muerte: no se mueve, no ataca, no usa el escudo y no recibe daño | |

### Constantes de clase (defensa 7)

Son `private static final`: una sola copia para la clase, que no cambia.

| Constante | Valor | Para qué |
|---|---|---|
| `VIDAS_INICIALES` | 3 | Vidas al empezar |
| `MEDIOS_CORAZONES_INICIALES` | 6 | Vida al empezar (3 corazones) |
| `VELOCIDAD_CAMINANDO` | 4 | Píxeles por vuelta |
| `FACTOR_RALENTIZACION` | 2 | En el pasto avanza `pasos / 2` |
| `DANIO_ESPADA` | 1 | Medio corazón por espadazo |
| `ALCANCE_ESPADA` | 32 | Píxeles delante de Link |
| `DURACION_INVULNERABILIDAD` | 1000 | Milisegundos invulnerable (y parpadeando) después de un golpe |
| `DEMORA_ROTURA_SUELO` | 800 | Milisegundos hasta que el suelo quebradizo se rompe |
| `DURACION_MUERTE` | 2100 | Milisegundos de la animación de muerte (`link-muerte.gif`: 3 vueltas y tirado en el piso) antes de perder la última vida (cambio 43; desde el 45, solo en la última) |
| `DURACION_PERDER_VIDA` | 1300 | Milisegundos de `link-pierde-vida.gif` (cae sentado para atrás y se levanta) cuando le quedan vidas (cambio 45) |
| `FRAGMENTOS_POR_CORAZON` | 4 | Fragmentos para sumar un corazón |
| `AUMENTO_VIDA_MAXIMA` | 2 | Medios corazones que suma ese corazón |
| `CUERPO_MARGEN_X`, `CUERPO_MARGEN_Y` | 6, 2 | Dónde empieza el cuerpo dentro de la imagen |
| `CUERPO_ANCHO`, `CUERPO_ALTO` | 36, 44 | Tamaño del cuerpo |
| `VUELTAS_IMAGEN_GOLPE` | 8 | Vueltas (≈ 240 ms) que se ve la imagen del espadazo; alcanza para el GIF del golpe, de 233 ms (cambio 39) |
| `LARGO_IMAGEN_ESPADA` | 48 | Cuánto se corre la imagen del ataque recargado hacia la izquierda o hacia arriba (cambio 25) |
| `MARGEN_X_GOLPE`, `MARGEN_Y_GOLPE` | 54, 51 | Dónde queda Link dentro del GIF del golpe normal (156 × 150): la imagen se corre eso (cambio 39) |

Además hereda de `EntidadAnimada`: `movimiento`, `ataque`, `defensa`, `direccion`, `vida` y `pendientes`; y de `Entidad`: la posición, el sprite, `miJuego`, el sector, etc.

**Por qué `caminar`, `recargado` y `defensaBase` aparte**, si ya están en `movimiento`, `ataque` y `defensa`:

| Atributo | Lo que necesita que la interfaz no tiene |
|---|---|
| `caminar` | `setDireccion(d)`, cuando se aprieta o suelta una flecha |
| `recargado` | `cargar()`, cuando empieza a cargar la espada |
| `defensaBase` | Recordar la defensa "normal" mientras `defensa` es el escudo o la invulnerabilidad |

Guardándolos con su tipo concreto, Link los usa **sin *cast***. Apuntan a los mismos objetos que los atributos heredados.

## 4. El constructor

```java
public Link(Sprite sprite, int x, int y) {
    super(sprite, x, y, MEDIOS_CORAZONES_INICIALES);
    setCuerpo(CUERPO_MARGEN_X, CUERPO_MARGEN_Y, CUERPO_ANCHO, CUERPO_ALTO);
    vidas = VIDAS_INICIALES;
    corazonesMaximos = vida;
    inventario = new ArrayList<>();
    caminar = new MovimientoInducido((Direccion) null, VELOCIDAD_CAMINANDO);
    recargado = new AtaqueRecargado(DANIO_ESPADA, ALCANCE_ESPADA);
    defensaBase = new DefensaLimitada(DefensaLimitada.SIN_LIMITE, DefensaLimitada.SIEMPRE);
    movimiento = caminar;
    ataque = recargado;
    defensa = defensaBase;
}
```

| Línea | Qué hace |
|---|---|
| `super(sprite, x, y, MEDIOS_CORAZONES_INICIALES)` | Constructor de `EntidadAnimada`: imagen, posición y `vida = 6` (3 corazones). Además pone dirección `ABAJO`, la lista de pendientes vacía y estrategias por defecto |
| `setCuerpo(6, 2, 36, 44)` | **Defensa 7.** El cuerpo (hitbox) es más chico que la imagen: empieza 6 px a la derecha y 2 px abajo de la esquina, y mide 36 × 44. Así Link pasa por pasillos de una celda y no choca con el aire transparente de su dibujo |
| `vidas = VIDAS_INICIALES` | Empieza con 3 vidas |
| `corazonesMaximos = vida` | El tope empieza igual a la vida inicial (6). **No son lo mismo:** `vida` es lo que tiene ahora (baja con los golpes) y `corazonesMaximos` es el tope (sube con los fragmentos); solo arrancan iguales |
| `inventario = new ArrayList<>()` | Sin objetos. El escudo lo agrega la fábrica en `crearLink`, con `agregarAlInventario` |
| `new MovimientoInducido((Direccion) null, VELOCIDAD_CAMINANDO)` | Empieza quieto y avanza 4 píxeles por vuelta cuando se aprieta una flecha. El `(Direccion)` hace falta: hay dos constructores y `null` solo no compila |
| `new AtaqueRecargado(DANIO_ESPADA, ALCANCE_ESPADA)` | La espada hace 1 de daño (medio corazón) con 32 píxeles de alcance |
| `new DefensaLimitada(SIN_LIMITE, SIEMPRE)` | Defensa normal: recibe todo el daño |
| `movimiento = caminar`, `ataque = recargado`, `defensa = defensaBase` | Reemplaza las estrategias por defecto de `EntidadAnimada` por las de Link |

**Por qué se asignan los atributos directo y no con `setMovimiento`, `setAtaque` y `setDefensa`:**

- Se puede, porque `movimiento`, `ataque` y `defensa` son `protected` en `EntidadAnimada` y Link es subclase.
- Evita llamar desde el constructor a métodos que una subclase podría redefinir. Java lo avisa con el *warning* `this-escape`: si un `set` estuviera redefinido, se ejecutaría antes de que el objeto esté completo.
- El resultado es exactamente el mismo que con los `set`.

**Por qué constantes de clase (defensa 7).** En la defensa 6 eran variables locales del constructor. El ayudante pidió
que no quedaran números sueltos en el código, así que ahora todos los valores fijos de Link son constantes con nombre y
están dibujadas en la caja de Link del extendido.

**La posición `x, y` es provisoria.** `Juego.iniciar` crea a Link con `crearLink(0, 0)`, y `cargarNivel` lo ubica en la posición `INICIO` del archivo del nivel antes de que arranquen los hilos.

## 5. El teclado: ControlJugador

Estos métodos los llama la `GUI` desde el **EDT** (el hilo de Swing). Tienen que ser cortos y **no** `synchronized`: solo anotan la intención, y el trabajo lo hace `HiloJugador` en su próxima vuelta.

| Tecla | Método | Qué hace |
|---|---|---|
| Flecha apretada | `mover(d)` | `caminar.setDireccion(d)` y `setDireccion(d)` (mira hacia ahí) |
| Flecha soltada | `detenerMovimiento()` | `caminar.setDireccion(null)` |
| A (apretar / soltar) | `atacar()` / `soltarAtaque()` | Le delega al objeto equipado: `atacarCon(this)` / `soltarAtaqueCon(this)` |
| S (apretar / soltar) | `usarEscudo()` / `soltarEscudo()` | Le delega al objeto equipado: `protegerCon(this)` / `soltarProteccionCon(this)` |
| D o Espacio | `cambiarObjeto()` | Equipa el siguiente objeto del inventario |

```java
public void cambiarObjeto() {
    if (!inventario.isEmpty() && !atacando) {
        if (escudoActivo)
            desactivarEscudo();                     // cambio 37: no deja el escudo levantado
        int indiceSiguiente = (inventario.indexOf(objetoEquipado) + 1) % inventario.size();
        objetoEquipado = inventario.get(indiceSiguiente);
        notificarObservers();                       // el HUD muestra el nombre nuevo
    }
}
```

El `% inventario.size()` lo hace circular: después del último vuelve al primero. No cambia de objeto mientras carga un ataque. Si el escudo estaba levantado, primero lo baja (cambio 37): si no, al soltar S se llamaría a `soltarProteccionCon` de la espada, que no hace nada, y el escudo quedaría activo para siempre.

**Por qué delega en el objeto equipado.** Link no pregunta "¿tengo la espada?". Si el objeto es la espada, `atacarCon` carga el ataque; si es el escudo, no hace nada. Cada objeto decide (polimorfismo, sin `instanceof`).

## 6. Espada y escudo

### La espada (ataque recargado)

| Paso | Hilo | Método | Efecto |
|---|---|---|---|
| Aprieta A | EDT | `atacar()` → `Espada.atacarCon(link)` → `cargarAtaque()` | `atacando = true`, `soltoAtaque = false`, `recargado.cargar()` |
| Suelta A | EDT | `soltarAtaque()` → `Espada.soltarAtaqueCon(link)` → `liberarAtaque()` | `soltoAtaque = true` |
| Próxima vuelta | `HiloJugador` | `AtaqueRecargado.atacar(link, c)` | Ve `soltoElAtaque()`, golpea con `c.golpearEn(...)`, o con `c.golpearAlrededor(...)` si está cargado (cambio 38) |
| Después del golpe | `HiloJugador` | `ataqueRealizado()` | `atacando = false`, `soltoAtaque = false` y `vueltasMostrandoGolpe = 8` (`VUELTAS_IMAGEN_GIRO = 16` si fue recargado: el giro) |
| 8 vueltas después | `HiloJugador` | `actualizarEstado(c)` | `vueltasMostrandoGolpe` llega a 0 y avisa: vuelve la imagen de caminar |

```java
public void cargarAtaque() {
    if (!atacando) {                                // la tecla repetida no reinicia la carga
        atacando = true;
        soltoAtaque = false;
        recargado.cargar();
        notificarObservers();                       // defensa 7: muestra la imagen de ataque
    }
}
```

**Por qué el `if (!atacando)`.** Al mantener una tecla, el sistema operativo repite el evento muchas veces por segundo. Sin el `if`, cada repetición reiniciaría la carga y el ataque recargado nunca llegaría a cargarse.

```mermaid
sequenceDiagram
    participant G as GUI (EDT)
    participant L as Link
    participant E as Espada
    participant AR as AtaqueRecargado
    participant HJ as HiloJugador
    participant AC as AdministradorColisiones
    G->>L: atacar()
    L->>E: atacarCon(link)
    E->>L: cargarAtaque()
    L->>AR: cargar()
    G->>L: soltarAtaque()
    L->>E: soltarAtaqueCon(link)
    E->>L: liberarAtaque()
    HJ->>L: actualizarEstado(c)
    L->>AR: atacar(link, c)
    AR->>L: soltoElAtaque() → true
    AR->>AC: golpearEn(link, alcance, danio)
    AR->>L: ataqueRealizado()
```

### La imagen del espadazo (defensa 7)

```java
public void ataqueRealizado() {
    atacando = false;
    soltoAtaque = false;
    vueltasMostrandoGolpe = recargado.estaCargado() ? VUELTAS_IMAGEN_GIRO : VUELTAS_IMAGEN_GOLPE;
    notificarObservers();
}

public void actualizarEstado(AdministradorColisiones c) {
    super.actualizarEstado(c);                      // la vuelta normal de EntidadAnimada
    if (atacando && recargado.estaCargado())
        notificarObservers();                       // la espada recargada se ve apenas termina la carga
    if (vueltasMostrandoGolpe > 0) {
        vueltasMostrandoGolpe--;
        if (vueltasMostrandoGolpe == 0 || girando())
            notificarObservers();                   // cada paso del giro, o vuelve a la imagen de caminar
    }
}
```

**El giro del ataque recargado (cambio 38).** Dos consultas privadas deciden qué imagen se ve mientras gira:

```java
private boolean girando() {
    return !escudoActivo && !atacando && vueltasMostrandoGolpe > 0 && recargado.estaCargado();
}

private Direccion direccionImagen() {
    if (!girando())
        return getDireccion();
    int paso = (VUELTAS_IMAGEN_GIRO - vueltasMostrandoGolpe) * ORDEN_GIRO.length / VUELTAS_IMAGEN_GIRO;
    int inicio = java.util.Arrays.asList(ORDEN_GIRO).indexOf(getDireccion()) + 1;
    return ORDEN_GIRO[(inicio + paso) % ORDEN_GIRO.length];
}
```

`girando()` es verdadero en las 16 vueltas que siguen a un golpe recargado. Durante ese tiempo `direccionImagen()` avanza una dirección cada 4 vueltas (120 ms) siguiendo `ORDEN_GIRO = { ABAJO, IZQUIERDA, ARRIBA, DERECHA }`, empezando por la que sigue a la de Link y terminando en la suya. Fuera del giro devuelve `getDireccion()`. La usan `getRutaImagen()`, `getXImagen()` y `getYImagen()`.

Sin esto, un golpe rápido (apretar y soltar A enseguida) mostraría la imagen de ataque una sola vuelta y no se vería.
Con `VUELTAS_IMAGEN_GOLPE = 8` la imagen del espadazo queda unos 240 ms (8 vueltas de 30 ms), lo justo para el GIF del golpe (cambio 39).

**El golpe animado (cambio 39).** `ataque-<dir>` es un GIF armado con los cuadros del juego original: el cuerpo de `link0.ani` (`attack_<d>`) y la espada de `Objects/sword.ani` (`attack_<d>`), 3 cuadros de 50, 50 y 133 ms. La espada barre en arco (por ejemplo, hacia abajo: del costado, en diagonal, abajo). El arco no entra en 48 × 96, así que los 4 GIF tienen un lienzo de 156 × 150 con Link siempre en (54, 51). Se reproduce una vez y queda en el último cuadro.

```java
private boolean mostrandoGolpeNormal() {
    return mostrandoAtaque() && !recargado.estaCargado() && caminar.getDireccion() == null;
}

public int getXImagen() {
    int x = getX();
    if (mostrandoGolpeNormal())
        x -= MARGEN_X_GOLPE;                        // el GIF del golpe
    else if (mostrandoAtaque() && direccionImagen() == Direccion.IZQUIERDA)
        x -= LARGO_IMAGEN_ESPADA;                   // el PNG del ataque recargado
    return x;
}
```

`getYImagen()` es igual con `MARGEN_Y_GOLPE` y `Direccion.ARRIBA`. El cuerpo (hitbox) y el alcance no cambian: solo se corre la imagen.

```java
public String getRutaImagen() {
    String dir = getDireccion().name().toLowerCase();
    String estado = dir;
    if (muriendo)                                  // cambios 43 y 45
        estado = vidas > 1 ? "pierde-vida" : "muerte";
    else if (cayendo)                              // cambio 31
        estado = "caida";
    else if (escudoActivo)
        estado = "escudo-" + dir;
    else if (mostrandoAtaque())
        estado = (recargado.estaCargado() ? "ataque-recargado-" : "ataque-") + dir;
    String ruta = sprite.getRuta(estado);
    return ruta != null ? ruta : super.getRutaImagen();
}

private boolean mostrandoAtaque() {
    return !escudoActivo && (atacando || vueltasMostrandoGolpe > 0);
}

@Override
public int getXImagen() {
    int x = getX();
    if (mostrandoAtaque() && getDireccion() == Direccion.IZQUIERDA)
        x -= LARGO_IMAGEN_ESPADA;
    return x;
}
```

`getYImagen()` es igual, con `Direccion.ARRIBA` (cambio 25). Así, en las cuatro direcciones, la espada se dibuja
justo sobre la zona que golpea (`getHitbox().adelante(direccion, alcance)`).

El sprite de Link tiene imágenes para cada estado y dirección (`abajo`, `escudo-abajo`, `ataque-abajo`,
`ataque-recargado-abajo`, …). Si el sprite no tiene la imagen pedida, usa la de `Entidad` (la de caminar).

**Imagen del golpe recargado.** Si `recargado.estaCargado()` da `true`, Link muestra `ataque-recargado-<dir>` (la
espada negra con amarillo) en vez de `ataque-<dir>`. `AtaqueRecargado` no borra la hora de carga al golpear: la
pisa recién en el próximo `cargar()`. Así, durante las vueltas de `vueltasMostrandoGolpe` se sigue viendo si
el golpe fue recargado.

**La espada se pone recargada apenas termina la carga.** La vista solo redibuja a Link cuando él avisa. Por eso
`actualizarEstado` pregunta en cada vuelta: si está atacando y `recargado.estaCargado()` da `true`, llama a
`notificarObservers()`. Así, a los 3 s de mantener A, la espada pasa a negra con amarillo aunque Link esté quieto.

### El escudo y la defensa base

| Método | Qué hace |
|---|---|
| `activarEscudo()` | `escudoActivo = true`, `setDefensa(new DefensaPorEscudo(false))` y avisa (imagen con escudo) |
| `desactivarEscudo()` | `escudoActivo = false`, vuelve a `defensaBase` y avisa |
| `setDefensaBase(d)` | Cambia la defensa base (la bellota pone `DefensaLimitada(1, 3)`). Si no usa el escudo, la aplica enseguida |
| `restaurarDefensa()` | Vuelve a `defensaBase` si no usa el escudo. Lo programa `alSerGolpeado` |

## 7. Movimiento y cambio de sector

```java
public void avanzar(Direccion d, int pasos) {
    int pasosReales = ralentizado ? pasos / FACTOR_RALENTIZACION : pasos;
    ralentizado = false;
    super.avanzar(d, pasosReales);
}
```

- **Pasto:** al tocarlo, el pasto llama `ralentizar()` (`ralentizado = true`). El próximo paso avanza la mitad y la marca se apaga. Si Link sigue sobre el pasto, en la vuelta siguiente lo vuelve a tocar y se vuelve a ralentizar.
- **Bloqueos:** `avanzar` no controla rocas. Eso lo decide `AdministradorColisiones.mover` antes de llamarlo: busca si alguna entidad le bloquea el paso con `bloqueaPasoA(link)`. A Link lo frenan las rocas, el agua y los enemigos; las caídas al vacío **no** (Link no las esquiva: cae).

| Método | Quién lo llama | Qué hace |
|---|---|---|
| `alSalirDelSector(d)` | `AdministradorColisiones.mover`, cuando Link sale de la pantalla | `miJuego.cambiarDeSector(d)` |
| `entrarPorBordeOpuesto(d)` | `Juego.cambiarDeSector` | Ubica su **cuerpo** en el borde por el que entra al sector nuevo |
| `actualizarPorMundo(c)` | `Sector.actualizarEntidades` (HiloMundo) | **Vacío**: a Link lo mueve solo `HiloJugador` |

```java
public void entrarPorBordeOpuesto(Direccion d) {
    Hitbox cuerpo = getHitbox();      // ubica el cuerpo (no la imagen) pegado al borde
    switch (d) {
        case DERECHA:   ubicarCuerpoEn(0, cuerpo.getY()); break;
        case IZQUIERDA: ubicarCuerpoEn(Sector.ANCHO - getAncho(), cuerpo.getY()); break;
        case ABAJO:     ubicarCuerpoEn(cuerpo.getX(), 0); break;
        default:        ubicarCuerpoEn(cuerpo.getX(), Sector.ALTO - getAlto()); break;
    }
}
```

Si salió por la derecha, entra por el borde izquierdo del sector nuevo, a la misma altura.

**Por qué ubica el cuerpo.** `getX()`/`getY()` son la esquina de la imagen y `getHitbox()` es el cuerpo, que en Link
está corrido 6 px a la derecha y 2 px abajo. `AdministradorColisiones.estaFuera` mira el cuerpo, así que la entrada
también pega el cuerpo al borde. `ubicarCuerpoEn(x, y)` (de `Entidad`) mueve a Link para que la esquina de su cuerpo quede
en `(x, y)`, y `getAncho()`/`getAlto()` devuelven el tamaño del cuerpo (36 × 44). Por ejemplo, al entrar por la izquierda
el cuerpo queda en x = 0 y la imagen en x = −6: los 6 px transparentes del dibujo quedan fuera de la pantalla.

Si no hay sector vecino, Juego lo llama con la dirección opuesta y Link vuelve a entrar por el mismo borde.

## 8. Colisiones (Visitor)

El doble despacho tiene dos pasos: `entidad.aceptarColision(otra)` → `otra.colisionarCon(entidad)`, con el tipo concreto de cada una, sin `instanceof`.

```java
public void aceptarColision(Colisionador c) { c.colisionarCon(this); }
```

| Choca con | Método | Efecto |
|---|---|---|
| Enemigo o jefe | `colisionarCon(Enemigo e)` | **Defensa 7: le delega al enemigo**, `e.colisionarCon(this)` → `ataque.ataqueAlContactar(enemigo, link)`. Así el daño lo decide siempre la estrategia de ataque del enemigo |
| Proyectil | `colisionarCon(Proyectil p)` | `recibirDanio(p.getDanio(), p.getDireccion())` y `p.eliminar()` (desaparece aunque Link tenga el escudo) |
| Obstáculo | `colisionarCon(Obstaculo o)` | `o.afectar(this)`: pasto ralentiza, caída hace caer, suelo quebradizo se rompe |
| Power-up | `colisionarCon(PowerUP p)` | `p.serRecogidoPor(this)` |
| Objeto | `colisionarCon(Objeto o)` | `o.serRecogidoPor(this)` (espada o escudo) |
| Espada de un jefe | `recibirGolpeDeEspada(atacante, danio)` | `recibirDanio(danio, atacante.getDireccion())` (MasterStalfos) |

**La regla de la defensa 7.** Como Link y los enemigos se frenan entre ellos (`bloqueaPasoA`), casi nunca llegan a
superponerse: el choque aparece cuando **uno no puede dar el paso** contra el otro. `AdministradorColisiones.mover`
dispara entonces el Visitor con la entidad que bloquea:

| Quién camina | Lo que pasa en `mover` | Termina en |
|---|---|---|
| Link contra un Moblin (`HiloJugador`) | `moblin.aceptarColision(link)` → `link.colisionarCon(moblin)` | `moblin.colisionarCon(link)` → ataque del Moblin |
| Un Moblin contra Link (`HiloMundo`) | `link.aceptarColision(moblin)` → `moblin.colisionarCon(link)` | ataque del Moblin |

Por los dos caminos el daño lo pone **la estrategia de ataque del enemigo**, y después del golpe Link queda 1 s
invulnerable, así que dos avisos casi juntos sacan **un solo golpe** (ver *secuencia-dos-avisos* en
`imagenes-cambio-17/`). En la defensa 6 `link.colisionarCon(enemigo)` estaba vacío porque solo `HiloMundo` resolvía el
choque; con el bloqueo, si Link camina contra un enemigo quieto, el choque lo detecta `HiloJugador` y tiene que llegar al
enemigo.

## 9. Daño, invulnerabilidad, vidas y obstáculos

```java
public synchronized void recibirDanio(int danio, Direccion origen) {
    boolean recibioDanio = defensa.recibirDanio(this, danio, origen);
    if (recibioDanio) {
        reiniciarRacha();
        miJuego.jugadorDaniado();                   // NoHit termina la partida acá
        alSerGolpeado();
    }
}

protected void alSerGolpeado() {
    if (!muriendo) {                                                   // cambios 43 y 46
        setDefensa(new DefensaLimitada(0, DefensaLimitada.SIEMPRE));   // invulnerable
        parpadearDurante(DURACION_INVULNERABILIDAD);                   // defensa 7
        programar(DURACION_INVULNERABILIDAD, this::restaurarDefensa);
    }
}
```

| Paso | Qué pasa |
|---|---|
| 1 | La defensa decide cuánto daño pasa (y lo resta con `aplicarDanio`). Con el escudo o invulnerable, no pasa nada |
| 2 | Si pasó daño: la racha vuelve a 0 |
| 3 | Le avisa a Juego (`jugadorDaniado`): en NoHit termina la partida |
| 4 | Queda **invulnerable 1 segundo**: defensa `(0, SIEMPRE)` y una `AccionProgramada` que a los 1000 ms llama `restaurarDefensa()`, sin crear un hilo |
| 5 | **Defensa 7:** parpadea ese mismo segundo (`parpadearDurante(1000)`). La vista lo dibuja visible o invisible según `esVisible()` |

### Vidas

| Método | Cuándo | Qué hace |
|---|---|---|
| `morir()` | `aplicarDanio` cuando la vida llega a 0 | **Cambio 43.** Marca `muriendo`, se queda quieto e invulnerable, avisa a la vista y programa `terminarMuerte()`. **Cambio 45:** si le quedan vidas (`vidas > 1`), la vista muestra `link-pierde-vida.gif` y espera `DURACION_PERDER_VIDA` = 1300 ms; si es la última, `link-muerte.gif` y `DURACION_MUERTE` = 2100 ms. `vidas` se resta recién en `terminarMuerte()`, así que no hace falta otro atributo. Si ya está muriendo, no hace nada |
| `terminarMuerte()` | **Cambio 43.** 1300 ms (le quedan vidas) o 2100 ms (última vida) después de `morir()` | Apaga `muriendo`, devuelve el movimiento y pierde una vida. Sin vidas: avisa a la vista (el HUD muestra 0) y `jugadorSinVidas()`. Con vidas: llena los corazones y llama a `alSerGolpeado()`, así queda 1 s invulnerable y parpadeando; sigue en el mismo lugar |
| `caerAlVacio()` | La caída al vacío cuando su centro está sobre el pozo | Marca `cayendo`, se queda quieto e invulnerable y muestra el GIF `caida`; a los 400 ms `terminarCaida()` pierde una vida y corta la racha. Sin vidas: avisa a la vista (el HUD muestra 0) y `jugadorSinVidas()`. Con vidas: llena los corazones y `jugadorCayoAlVacio()` (Juego reinicia el nivel). La caída no pasa por `morir()`, así que no muestra la animación de muerte |
| `terminarCaida()` | **Cambios 31 y 32.** 400 ms después de `caerAlVacio()` | Apaga `cayendo`, devuelve el movimiento y la defensa base, y aplica la pérdida de vida descripta arriba |

### Suelo quebradizo

```java
public void romperSuelo(SuelosQuebradizo s) {
    programar(DEMORA_ROTURA_SUELO, () -> {
        Sector sectorDelSuelo = s.getSector();
        Entidad caida = miJuego.getFabricaEntidades().crearCaidasAlVacio(s.getX(), s.getY());
        s.eliminar();
        if (sectorDelSuelo == getSector())
            miJuego.agregarEntidad(caida);          // la agrega al sector visible y la muestra
        else
            sectorDelSuelo.agregar(caida);
    });
}
```

A los 800 ms (cambio 33) el suelo se rompe y aparece una caída al vacío en su lugar. Si Link siguió caminando ya no está encima; si se frenó, su centro queda sobre el pozo y cae. **Si Link ya salió del sector** antes de los 800 ms, la caída se agrega al sector del suelo (no al visible) y se ve cuando Link vuelva a entrar. 

## 10. Estado de la partida y power-ups

| Método | Lo llama | Qué hace |
|---|---|---|
| `agregarAlInventario(o)` | Espada y escudo al ser recogidos | Lo agrega y lo equipa |
| `sumarPuntos(p)` | Juego | `puntaje += p` |
| `reiniciarPuntaje()` | — | `puntaje = 0` |
| `sumarRupias(n)` | Rupia | `rupias += n` |
| `curar(medios)` | Corazón | Suma vida sin pasarse de `corazonesMaximos` |
| `sumarFragmento()` | Fragmento de corazón | Cada 4: `corazonesMaximos += 2` y vida llena |
| `incrementarRacha()` / `reiniciarRacha()` | Juego / Link | Racha para la bellota |
| `reiniciarVidas()` | — | 3 vidas y corazones llenos |
| `powerUpRecogido(p)` | Power-ups | `miJuego.powerUpRecogido(p)`, para que Juego sume sus puntos |

Todos los que cambian algo del HUD llaman `notificarObservers()`, y la `CeldaJugador` actualiza la pantalla.

`reiniciarPuntaje()` y `reiniciarVidas()` sirven si se reutiliza el mismo Link en otra partida. Con el diseño actual `Juego.iniciar` crea un Link nuevo, pero el extendido los tiene y se escriben.

## 11. Consultas y HUD

| Consulta | Devuelve | La usa |
|---|---|---|
| `getVidas()` | Vidas | HUD |
| `getCorazones()` | `vida`, en medios corazones | HUD |
| `getCorazonesMaximos()` | Tope de la vida | HUD |
| `getPuntaje()` | Puntaje | HUD, Juego (ranking) |
| `getRupias()` | Rupias | HUD |
| `getNombreObjetoEquipado()` | El nombre del objeto, o `"Ninguno"` | HUD |
| `getRacha()` | Racha | `Juego.enemigoDerrotado` |
| `getRutaImagen()` | La imagen según escudo, ataque o caminar | `CeldaEntidad` (vista) |
| `getCapa()` | `CAPA_JUGADOR` (4) | La vista, para dibujarlo arriba de todo |
| `bloqueaPasoA(quien)` | `quien.esFrenadoPorPersonajes()` | `AdministradorColisiones.buscarBloqueo` |
| `esFrenadoPorPersonajes()` | `true` | Los enemigos, en su `bloqueaPasoA` |
| `getInventario()` | Los objetos | — |
| `quiereAtacar()` | `atacando` | `AtaqueRecargado` |
| `soltoElAtaque()` | `soltoAtaque` | `AtaqueRecargado` |
| `tieneEscudoActivo()` | `escudoActivo` | — |

Las seis primeras son las de `EntidadJugador`: el HUD solo ve a Link a través de esa interfaz.

## 12. Usos: quién usa a Link en el proyecto

Link es la clase con más "clientes" del proyecto. Cada uno lo ve de una forma distinta: algunos como `Link`, otros solo a través de una interfaz.

| Quién | Lo ve como | Para qué | Métodos que usa |
|---|---|---|---|
| `FabricaEntidades` | `Link` | Lo crea con su sprite y le da el escudo | `new Link(...)`, `setJuego`, `agregarAlInventario(crearEscudo(...))` |
| `Juego` | `Link` (`#jugador 1`) | Árbitro de la partida | `setPosicion`, `getSector`, `entrarPorBordeOpuesto`, `sumarPuntos`, `incrementarRacha`, `getRacha`, `reiniciarRacha`, `getPuntaje`, `registrarObserver` |
| `Juego` → `GUI` | `ControlJugador` | Le pasa Link a la vista para el teclado | `getControlJugador()` |
| `GUI` | `ControlJugador` (`#controlJugador 1`) | Teclado | `mover`, `detenerMovimiento`, `atacar`, `soltarAtaque`, `usarEscudo`, `soltarEscudo`, `cambiarObjeto` |
| `CeldaJugador` / HUD | `EntidadJugador` | Mostrar el estado | `getVidas`, `getCorazones`, `getCorazonesMaximos`, `getPuntaje`, `getRupias`, `getNombreObjetoEquipado` |
| `HiloJugador` | `Link` (`#jugador 1`) | Darle una vuelta cada 30 ms | `actualizarEstado(colisiones)` |
| `AdministradorColisiones` | `EntidadAnimada` | Mover, chocar, golpear | `avanzar`, `alSalirDelSector`, `aceptarColision`, `bloqueaPasoA`, `recibirGolpeDeEspada` |
| `AtaqueRecargado` | `EntidadAnimada` | La espada | `soltoElAtaque`, `ataqueRealizado`, `getDireccion` |
| `Espada` / `Escudo` | `Link` | Las teclas de cada objeto | `cargarAtaque`, `liberarAtaque`, `activarEscudo`, `desactivarEscudo` |
| Power-ups | `Link` | Su efecto | `sumarRupias`, `curar`, `sumarFragmento`, `setDefensaBase`, `powerUpRecogido` |
| Obstáculos | `Link` | Su efecto | `ralentizar`, `caerAlVacio`, `romperSuelo` |
| Enemigos | `Entidad` (vía `miJuego.getJugador()`) y `Link` en `colisionarCon(Link)` | Saber dónde está Link y lastimarlo | `getCentro`, `getHitbox`, `recibirDanio` (desde la estrategia de ataque), `esFrenadoPorPersonajes` |
| Defensas (`DefensaLimitada`, `DefensaPorEscudo`) | `EntidadAnimada` | Restar la vida que pasa | `aplicarDanio` |

**Por qué interfaces.** La `GUI` solo puede mover y atacar (no puede sumarle puntos), y el HUD solo puede leer (no puede cambiar nada). Así cada parte del programa ve solo lo que necesita de Link.

## 13. Referencia de métodos, uno por uno, con ejemplo

Todos los ejemplos parten de un Link recién creado por la fábrica: `vida = 6`, `corazonesMaximos = 6`, `vidas = 3`, `puntaje = 0`, `rupias = 0`, `fragmentos = 0`, `racha = 0`, inventario `[Escudo]` y equipado el escudo.

### Teclado (ControlJugador)

| Método | Ejemplo | Resultado |
|---|---|---|
| `mover(d)` | Aprieta → | `caminar.direccion = DERECHA`, Link mira a la derecha. En la próxima vuelta avanza 4 px |
| `detenerMovimiento()` | Suelta → | `caminar.direccion = null`. En la próxima vuelta no se mueve |
| `atacar()` | Aprieta A con la espada equipada | `Espada.atacarCon` → `cargarAtaque()`: `atacando = true` |
| `atacar()` | Aprieta A con el escudo equipado | `Escudo.atacarCon` es vacío: no pasa nada |
| `soltarAtaque()` | Suelta A con la espada | `liberarAtaque()`: `soltoAtaque = true`. Golpea en la próxima vuelta |
| `usarEscudo()` | Aprieta S con el escudo equipado | `activarEscudo()`: no recibe daño mientras lo mantenga |
| `soltarEscudo()` | Suelta S | `desactivarEscudo()`: vuelve a `defensaBase` |
| `cambiarObjeto()` | Inventario `[Escudo, Espada]`, equipado el escudo | Equipa la espada; el HUD muestra "Espada". Otra vez: vuelve al escudo |
| `cambiarObjeto()` | Inventario `[Escudo]` | Queda el escudo (siguiente de uno es él mismo) |
| `cambiarObjeto()` | Cargando la espada | No cambia (`atacando == true`) |

### Espada y escudo

| Método | Ejemplo | Resultado |
|---|---|---|
| `cargarAtaque()` | Primer llamado | `atacando = true`, `soltoAtaque = false`, `recargado.cargar()` guarda la hora y se ve la imagen de ataque |
| `cargarAtaque()` | Tecla repetida (ya cargando) | No hace nada: la carga sigue contando desde el primer llamado |
| `liberarAtaque()` | Soltó A a los 1,5 s | `soltoAtaque = true`. Golpe normal: daño 1, alcance 32 |
| `liberarAtaque()` | Soltó A a los 3 s o más | Golpe recargado: `AtaqueRecargado` duplica daño y alcance (2 y 64) y se ve `ataque-recargado-<dir>` |
| `ataqueRealizado()` | Después del golpe | `atacando = false`, `soltoAtaque = false`, `vueltasMostrandoGolpe = 8` (cambio 39) |
| `activarEscudo()` | Con escudo, un Moblin le pega 2 | `DefensaPorEscudo(false)` bloquea: `vida` sigue en 6 |
| `desactivarEscudo()` | Baja el escudo | `defensa = defensaBase` |
| `setDefensaBase(d)` | Bellota: `DefensaLimitada(1, 3)` sin escudo | Se aplica enseguida |
| `setDefensaBase(d)` | Bellota con el escudo levantado | Se guarda; se aplica al bajar el escudo |
| `restaurarDefensa()` | 1000 ms después de un golpe, sin escudo | Vuelve a `defensaBase` |

### Movimiento

| Método | Ejemplo | Resultado |
|---|---|---|
| `avanzar(d, 4)` | Sin pasto | Avanza 4 px |
| `ralentizar()` + `avanzar(d, 4)` | Tocó pasto en la vuelta anterior | Avanza 2 px y apaga la marca |
| `alSalirDelSector(DERECHA)` | Cruzó el borde derecho | `miJuego.cambiarDeSector(DERECHA)` |
| `entrarPorBordeOpuesto(DERECHA)` | Cuerpo en (740, 200), sector de 768 × 528 | Cuerpo en (0, 200) del sector nuevo (imagen en (−6, 198)) |
| `entrarPorBordeOpuesto(IZQUIERDA)` | Cuerpo en (−3, 200), ancho del cuerpo 36 | Cuerpo en (732, 200): `768 − 36` |
| `entrarPorBordeOpuesto(ABAJO)` | Cuerpo en (300, 510) | Cuerpo en (300, 0) |
| `entrarPorBordeOpuesto(ARRIBA)` | Cuerpo en (300, −2), alto del cuerpo 44 | Cuerpo en (300, 484): `528 − 44` |
| `actualizarPorMundo(c)` | `HiloMundo` recorre el sector | No hace nada |

### Colisiones

| Método | Ejemplo | Resultado |
|---|---|---|
| `aceptarColision(c)` | Un proyectil se superpone con Link | `c.colisionarCon(link)` (doble despacho) |
| `colisionarCon(Enemigo)` | Link camina contra un Moblin quieto | `moblin.colisionarCon(link)`: el ataque del Moblin le saca 1 |
| `colisionarCon(Proyectil)` | Proyectil de daño 1, sin escudo | `vida` 6 → 5 y el proyectil desaparece |
| `colisionarCon(Proyectil)` | Mismo proyectil, con escudo | `vida` sigue en 6, pero el proyectil desaparece igual |
| `colisionarCon(Obstaculo)` | Pasto | `pasto.afectar(link)` → `ralentizar()` |
| `colisionarCon(Obstaculo)` | Caída al vacío | `caida.afectar(link)` → `caerAlVacio()` |
| `colisionarCon(Obstaculo)` | Suelo quebradizo (primera vez) | `suelo.afectar(link)` → `romperSuelo(suelo)` |
| `colisionarCon(PowerUP)` | Rupia de 3 | `rupias` 0 → 3, `puntaje` 0 → 30 |
| `colisionarCon(Objeto)` | Espada en el piso | Inventario `[Escudo, Espada]`, equipada la espada |
| `recibirGolpeDeEspada(m, 2)` | MasterStalfos con la espada | `recibirDanio(2, direccion de MasterStalfos)` |

### Daño y vidas

| Método | Ejemplo | Resultado |
|---|---|---|
| `recibirDanio(2, d)` | Defensa normal, `vida = 6`, `racha = 2` | `vida = 4`, `racha = 0`, avisa a Juego, invulnerable 1 s |
| `recibirDanio(2, d)` | Invulnerable (golpe hace menos de 1 s) | No pasa nada: la defensa `(0, SIEMPRE)` devuelve `false` |
| `recibirDanio(2, d)` | Modo NoHit | `jugadorDaniado()` → la partida termina |
| `alSerGolpeado()` | Después de un golpe | Defensa `(0, SIEMPRE)`, parpadea 1 s y `programar(1000, restaurarDefensa)` |
| `morir()` | `vida` llega a 0 con `vidas = 3` | Gira y cae durante 2,1 s, quieto e invulnerable; después `vidas = 2`, `vida = corazonesMaximos` (6), sigue en el lugar y queda 1 s invulnerable parpadeando |
| `morir()` | `vida` llega a 0 con `vidas = 1` | La misma animación; después `vidas = 0`, el HUD muestra 0 y `jugadorSinVidas()`: fin de la partida |
| `alSerGolpeado()` | Lo llama `recibirDanio` justo después del golpe que lo mató | No hace nada: está `muriendo`, así no parpadea durante la animación |
| `caerAlVacio()` | `vidas = 3`, `vida = 2` | Durante 400 ms se ve el GIF de caída; después `vidas = 2`, `vida = 6`, `racha = 0`, Juego reinicia el nivel |
| `caerAlVacio()` | `vidas = 1` | Después del GIF, `vidas = 0` → fin de la partida |
| `caerAlVacio()` | Ya está `cayendo` | No pasa nada: no puede caer dos veces |
| `caerAlVacio()` | Solo el borde de Link pisa el pozo | No se llama: el centro no está dentro del pozo |
| `romperSuelo(s)` | Pisa el suelo en t = 0 | En t ≈ 800 ms el suelo desaparece y aparece una caída en su lugar |

### Estado de la partida

| Método | Ejemplo | Resultado |
|---|---|---|
| `agregarAlInventario(o)` | Recoge la espada | Inventario `[Escudo, Espada]`, equipada la espada |
| `sumarPuntos(p)` | Juego suma 100 por un Moblin | `puntaje` 0 → 100 |
| `reiniciarPuntaje()` | — | `puntaje = 0` |
| `sumarRupias(n)` | Rupia de 5 | `rupias += 5` |
| `curar(2)` | `vida = 3`, máximo 6 | `vida = 5` |
| `curar(2)` | `vida = 5`, máximo 6 | `vida = 6` (no se pasa del máximo) |
| `sumarFragmento()` | 3er fragmento | `fragmentos = 3`, nada más |
| `sumarFragmento()` | 4to fragmento, `vida = 4` | `corazonesMaximos` 6 → 8, `vida = 8` |
| `incrementarRacha()` | 4to enemigo seguido | `racha = 4` → Juego da la bellota y llama `reiniciarRacha()` |
| `reiniciarVidas()` | — | `vidas = 3`, `vida = corazonesMaximos` |
| `powerUpRecogido(p)` | Corazón (300 puntos) | `miJuego.powerUpRecogido(p)` → `puntaje += 300` |

### Consultas

| Método | Ejemplo | Devuelve |
|---|---|---|
| `getVidas()` | Recién creado | 3 |
| `getCorazones()` | Después de un golpe de 2 | 4 (dos corazones) |
| `getCorazonesMaximos()` | Después de 4 fragmentos | 8 (cuatro corazones) |
| `getPuntaje()` | Un Moblin y una rupia de 3 | 130 |
| `getRupias()` | Rupias de 3 y 5 | 8 |
| `getNombreObjetoEquipado()` | Equipada la espada | `"Espada"` |
| `getNombreObjetoEquipado()` | Sin objetos | `"Ninguno"` |
| `getRacha()` | Dos enemigos sin recibir daño | 2 |
| `getInventario()` | Con los dos objetos | `[Escudo, Espada]` |
| `quiereAtacar()` | Manteniendo A | `true` |
| `soltoElAtaque()` | Acaba de soltar A | `true` (hasta el próximo `ataqueRealizado`) |
| `tieneEscudoActivo()` | Manteniendo S con el escudo | `true` |
| `getRutaImagen()` | Mirando a la izquierda con el escudo | La ruta de `escudo-izquierda` |
| `getCapa()` | Siempre | 4 (`CAPA_JUGADOR`) |
| `bloqueaPasoA(moblin)` | Un Moblin quiere dar un paso hacia Link | `true` (al Moblin lo frenan los personajes) |
| `bloqueaPasoA(proyectil)` | Un proyectil vuela hacia Link | `false`: lo deja pasar, y al superponerse se dispara `colisionarCon(Proyectil)` |

## 14. Ejemplos completos, paso a paso

### Ejemplo 1: Link recibe un golpe y queda invulnerable

Link tiene `vida = 6`, `racha = 3`. A los 10 000 ms del reloj del sistema, un Moblin camina hacia él y Link le bloquea el paso (daño 1).

| Instante | Hilo | Qué pasa | Estado de Link |
|---|---|---|---|
| 10 000 | `HiloMundo` | `mover`: `link.bloqueaPasoA(moblin)` es `true` → `link.aceptarColision(moblin)` → `moblin.colisionarCon(link)` → `AtaquePorContacto.ataqueAlContactar` → `link.recibirDanio(1, d)` | |
| 10 000 | `HiloMundo` | La defensa normal deja pasar 1: `aplicarDanio(1)` | `vida = 5` |
| 10 000 | `HiloMundo` | `reiniciarRacha()`, `miJuego.jugadorDaniado()` | `racha = 0` |
| 10 000 | `HiloMundo` | `alSerGolpeado()`: defensa `(0, SIEMPRE)`, parpadeo hasta las 11 000 y acción para las 11 000 | Invulnerable y parpadeando |
| 10 300 | `HiloMundo` | Otro Moblin lo toca: la defensa devuelve `false` | `vida = 5` (sin cambios) |
| 11 010 | `HiloJugador` | `ejecutarPendientes()`: vence la acción → `restaurarDefensa()` | Vuelve a la defensa normal |

```mermaid
sequenceDiagram
    participant HM as HiloMundo
    participant M as Moblin
    participant APC as AtaquePorContacto
    participant L as Link
    participant J as Juego
    participant HJ as HiloJugador
    HM->>M: actualizarEstado(c)
    M->>L: (mover) bloqueaPasoA(moblin) → true
    M->>L: aceptarColision(moblin)
    L->>M: colisionarCon(link)
    M->>APC: ataqueAlContactar(moblin, link)
    APC->>L: recibirDanio(1, d)
    L->>L: defensa.recibirDanio → aplicarDanio(1)
    L->>L: reiniciarRacha()
    L->>J: jugadorDaniado()
    L->>L: alSerGolpeado() → parpadearDurante(1000), programar(1000, restaurarDefensa)
    Note over L: 1 segundo después
    HJ->>L: actualizarEstado(c)
    L->>L: ejecutarPendientes() → restaurarDefensa()
```

### Ejemplo 2: la bellota

Link derrota 4 enemigos seguidos sin recibir daño.

| Paso | Qué pasa | Estado |
|---|---|---|
| Enemigos 1 a 3 | `Juego.enemigoDerrotado` → `incrementarRacha()` | `racha` 1, 2, 3 |
| Enemigo 4 | `incrementarRacha()` → `racha == 4` → `reiniciarRacha()` y `aparecerBellota(x, y)`; `enemigoDerrotado` devuelve `true`, así que el enemigo no suelta drop encima | `racha = 0`, aparece una bellota |
| Toca la bellota | `Bellota.serRecogidoPor(link)` → `setDefensaBase(new DefensaLimitada(1, 3))` | `defensaBase` limitada |
| Golpe de 2 | La defensa recorta a 1 | `vida` 6 → 5 (le quedan 2 golpes limitados) |
| Golpes 2 y 3 de 2 | Cada uno saca 1 | `vida` 5 → 4 → 3. La defensa vuelve sola a "sin límite" |
| Golpe 4 de 2 | Defensa normal otra vez | `vida` 3 → 1 |

Entre golpe y golpe, Link pasa 1 s invulnerable y después `restaurarDefensa()` vuelve a `defensaBase`, que es la misma `DefensaLimitada(1, 3)` (con los golpes que le queden).

### Ejemplo 3: carga de la espada

| Instante | Acción | Estado |
|---|---|---|
| 0 ms | Aprieta A (espada equipada) | `cargarAtaque()`: `atacando = true`, `recargado.cargar()` guarda 0 |
| 0 a 3000 ms | Mantiene A: el sistema repite el evento | `cargarAtaque()` no hace nada (ya está cargando) |
| 3500 ms | Suelta A | `liberarAtaque()`: `soltoAtaque = true` |
| 3530 ms | Vuelta de `HiloJugador` | `AtaqueRecargado.atacar`: cargado (≥ 3000 ms) → `golpearAlrededor(link, 64, 2)` y `ataqueRealizado()`; Link gira con la espada recargada (cambio 38) |

Si hubiera soltado a los 1000 ms, el golpe sería normal: `golpearEn(link, 32, 1)`.

### Ejemplo 4: fragmentos de corazón

| Fragmento | `fragmentos` | `corazonesMaximos` | `vida` (si tenía 4) | HUD |
|---|---|---|---|---|
| 1 | 1 | 6 | 4 | 2 de 3 corazones |
| 2 | 2 | 6 | 4 | 2 de 3 |
| 3 | 3 | 6 | 4 | 2 de 3 |
| 4 | 4 | 8 | 8 | 4 de 4 corazones |

### Ejemplo 5: pasto

Link camina a la derecha (4 px por vuelta) y entra en una zona de pasto.

| Vuelta | ¿Tocó pasto en la vuelta anterior? | `avanzar` | Avanza |
|---|---|---|---|
| 1 | No | 4 px | Entra al pasto; `verificarColisiones` → `ralentizar()` |
| 2 | Sí | `pasosReales = 2` | 2 px; sigue sobre el pasto → `ralentizar()` |
| 3 | Sí | 2 px | Sale del pasto; no se vuelve a ralentizar |
| 4 | No | 4 px | Velocidad normal |

Si Link corta el pasto con la espada (`Pasto.recibirGolpeDeEspada` → `eliminar()`), deja de ralentizarlo.

### Ejemplo 6: suelo quebradizo y cambio de sector

| Instante | Qué pasa |
|---|---|
| 0 ms | Link pisa el suelo: `suelo.afectar(link)` → `pisado = true` y `romperSuelo(suelo)` programa la rotura para los 800 ms |
| 200 ms | Link sale por la derecha: `cambiarDeSector(DERECHA)` |
| ~800 ms | Vence la acción. `sectorDelSuelo != getSector()` → la caída se agrega al sector viejo con `sectorDelSuelo.agregar(caida)` |
| Más tarde | Link vuelve al sector viejo: `activarSector` crea las celdas de todo el sector, y la caída se ve |

Si Link se queda en el sector, la caída se agrega con `miJuego.agregarEntidad(caida)`, que además la muestra enseguida.

### Ejemplo 7: perder vidas

| Situación | Antes | Después | Qué hace Juego |
|---|---|---|---|
| Un golpe deja `vida = 0` | `vidas = 3` | `vidas = 2`, `vida = 6` | Nada: Link sigue en el lugar |
| Cae al vacío | `vidas = 2` | `vidas = 1`, `vida = 6`, `racha = 0` | `jugadorCayoAlVacio()`: reinicia el nivel (Link vuelve al `INICIO`) |
| Un golpe deja `vida = 0` | `vidas = 1` | `vidas = 0` | `jugadorSinVidas()` → `terminarPartida()` |

### Ejemplo 8: el HUD

Después de: recoger la espada, una rupia de 3, un Moblin (100 puntos), recibir un golpe de 2 y juntar 4 fragmentos.

| Consulta | Valor | Se muestra |
|---|---|---|
| `getVidas()` | 3 | ♥ × 3 vidas |
| `getCorazones()` | 8 | 4 corazones llenos |
| `getCorazonesMaximos()` | 8 | de 4 |
| `getPuntaje()` | 130 | 130 |
| `getRupias()` | 3 | 3 |
| `getNombreObjetoEquipado()` | `"Espada"` | Espada |

(El golpe dejó `vida = 4`; el cuarto fragmento subió el máximo a 8 y llenó la vida.)

## 15. Hilos y sincronización

| Hilo | Qué hace con Link |
|---|---|
| EDT (Swing) | Los métodos de `ControlJugador`: solo escriben atributos `volatile` |
| `HiloJugador` | `actualizarEstado`: mover, atacar, chocar, ejecutar pendientes |
| `HiloMundo` | Lo daña: un enemigo choca contra él, un proyectil lo alcanza o la espada de MasterStalfos |
| `Reloj` | Nada directo |

| Dato | Protección | Por qué |
|---|---|---|
| `atacando`, `soltoAtaque`, `escudoActivo` | `volatile` | Los escribe el EDT y los lee `HiloJugador` |
| Dirección de `caminar` | `volatile` (en `MovimientoInducido`) | Misma razón |
| Vida y defensa | `recibirDanio` y `aplicarDanio` `synchronized` | Las pueden tocar `HiloJugador` y `HiloMundo` a la vez |
| `pendientes` | `programar` y `sacarVencidas` `synchronized` (en `EntidadAnimada`) | Al dañar a Link desde `HiloMundo` se programa el fin de la invulnerabilidad |

**Por qué los métodos del teclado no son `synchronized`.** Si el EDT tuviera que esperar una llave, la ventana entera se congelaría.

**Orden de llaves.** `Link.recibirDanio` (llave de Link) → `Juego.jugadorDaniado` (llave de Juego). Respeta el orden Entidad → Juego → Sector. Los métodos de Link que llama Juego (`sumarPuntos`, `incrementarRacha`, `reiniciarRacha`) no son `synchronized`, para no pedir la llave de Link teniendo la de Juego.

## 16. Paquete e imports

```java
package logica.entidades;

import java.util.ArrayList;
import java.util.List;

import logica.ControlJugador;
import logica.EntidadJugador;
import logica.comportamientos.AtaqueRecargado;
import logica.comportamientos.ComportamientoDefensa;
import logica.comportamientos.DefensaLimitada;
import logica.comportamientos.DefensaPorEscudo;
import logica.comportamientos.MovimientoInducido;
import logica.entidades.enemigos.Enemigo;
import logica.entidades.fijas.Objeto;
import logica.entidades.fijas.Obstaculo;
import logica.entidades.fijas.PowerUP;
import logica.entidades.fijas.SuelosQuebradizo;
import logica.fabricas.Sprite;
import logica.mapa.Sector;
import logica.util.Direccion;
import logica.util.Hitbox;
import logica.util.Posicion;
```

- Va en `logica.entidades`, junto a `Entidad`, `EntidadAnimada`, `Proyectil`, `Colisionable`, `Colisionador` y `AdministradorColisiones` (esos no se importan).
- Las interfaces con la vista (`EntidadJugador`, `ControlJugador`) están en el paquete `logica`.
- **Defensa 7:** los paquetes van en minúscula (`logica`, `vista`), como pide la convención de Java.

## 17. Cuidados y detalles conocidos

| Tema | Detalle |
|---|---|
| **Perder una vida sin caer** | Link sigue en el lugar con los corazones llenos (decisión del equipo). |
| **Escudo durante la invulnerabilidad** | Si levanta y baja el escudo durante el segundo de invulnerabilidad, vuelve a la defensa base antes de tiempo. Detalle menor, se acepta. |
| **Bellota** | Después de la bellota, `defensaBase` es `DefensaLimitada(1, 3)`. Al gastar los 3 golpes, esa misma defensa pasa sola a "sin límite": Link no hace nada. |
| **Caída al vacío** | Corre en `HiloJugador`, en medio de `verificarColisiones`. `verificarColisiones` corta el recorrido si Link cambió de sector. |
| **`cambiarObjeto()` sin espada** | Al empezar solo tiene el escudo: el cambio no hace nada. |
| **Constructor** | Asigna las estrategias directo a los atributos heredados (no con los `set`), para no llamar métodos redefinibles desde el constructor. `setCuerpo` es `protected` en `Entidad` y no se redefine. |
| **Parpadeo y escudo** | Si levanta el escudo mientras parpadea, sigue parpadeando hasta que termine el segundo: el parpadeo no depende de la defensa. |

## 18. En los diagramas

| Diagrama | Cómo aparece |
|---|---|
| **Reducido** | Hereda de `EntidadAnimada*`, realiza `EntidadJugador` y `ControlJugador`. ◇ `#inventario 1..2` con `Objeto`, → `#objetoEquipado 0..1`. Lo referencian `Juego` (`#jugador 1`), `HiloJugador` (`#jugador 1`) y `GUI` (como `ControlJugador`). |
| **Extendido** | Las 15 constantes de clase (subrayadas), los 16 atributos de instancia, el constructor `+ Link(sprite : Sprite, x : int, y : int)`, los comandos y las consultas, con `bloqueaPasoA(quien : EntidadAnimada) : boolean`, `esFrenadoPorPersonajes() : boolean`, `getRutaImagen() : String` y `getCapa() : int` desde la defensa 7. El código coincide uno a uno. |

## 19. Preguntas que pueden hacer en la defensa

| Pregunta | Respuesta corta |
|---|---|
| ¿Quién mueve a Link? | Solo `HiloJugador`. `actualizarPorMundo` está vacío para que `HiloMundo` no lo mueva dos veces. |
| ¿Cómo llega una tecla a Link? | La `GUI` llama un método de `ControlJugador` en el EDT, que solo anota la intención (`volatile`). `HiloJugador` la usa en su próxima vuelta. |
| ¿Por qué Link no atraviesa a los enemigos? | Porque en `buscarBloqueo` el Moblin responde `bloqueaPasoA(link)` con `link.esFrenadoPorPersonajes()`, que es `true`. Y al revés: `link.bloqueaPasoA(moblin)` pregunta `moblin.esFrenadoPorPersonajes()`. |
| ¿Por qué parpadea? | `alSerGolpeado` llama `parpadearDurante(1000)`: mientras dura la invulnerabilidad, `esVisible()` alterna y la vista lo dibuja o no. |
| ¿Por qué guarda `caminar` y `recargado` aparte? | Para usarlos con su tipo concreto (`setDireccion`, `cargar`) sin *cast*. |
| ¿Por qué el constructor no usa los `set`? | Para no llamar métodos redefinibles desde un constructor. Los atributos son `protected` y el resultado es el mismo. |
| ¿Qué pasa cuando un Moblin choca con Link? | Quien camina no puede dar el paso; `mover` dispara el Visitor con el que bloquea. Por cualquiera de los dos lados termina en `moblin.colisionarCon(link)`, o sea en la estrategia de ataque del Moblin. |
| ¿Cómo queda invulnerable sin un hilo? | `alSerGolpeado` pone una defensa `(0, SIEMPRE)` y programa `restaurarDefensa` a los `DURACION_INVULNERABILIDAD` (1000) ms con una `AccionProgramada`. |
| ¿Por qué `recibirDanio` es `synchronized`? | Porque lo pueden llamar `HiloJugador` y `HiloMundo` a la vez. |
| ¿Cómo sabe el HUD qué mostrar? | Lee a Link como `EntidadJugador`, y Link avisa con `notificarObservers()` cada vez que cambia algo. |
| ¿Dónde empieza Link en un nivel? | En la línea `INICIO` del archivo del nivel (sector y celda); la pone Juego en `cargarNivel` con `setPosicion`. |
| ¿Qué pasa al tocar pasto? | `ralentizar()`: el próximo paso avanza la mitad. |

---

*Integrante 4 · logica.hilos*

# Explicación de la clase AccionProgramada (Defensa 7)

Basado en los diagramas extendido y reducido de la defensa 7 (estrategia `bloqueaPasoA`) y en el código de
`DEFENSA 7 FINAL/Codigo/src/logica/hilos/AccionProgramada.java`.

**Lo que cambió en la defensa 7:** la clase no cambió. Cambió quién la usa: las esperas ahora son **constantes con
nombre** (`DURACION_INVULNERABILIDAD`, `DEMORA_ROTURA_SUELO`, `DURACION_FASE`…), el **Wizzrobe** la usa para su
segundo quieto después de un golpe, y la **trampa de cuchillas ya no la usa** (vuelve sola a su lugar cuando llega a la
pared). Además, `actualizarEstado` termina con `avisarParpadeo()` después de ejecutar los pendientes.


## 1. Qué es

`AccionProgramada` representa **algo que una entidad tiene que hacer dentro de un rato**, por ejemplo "dentro de 1000 ms, volvé a ser vulnerable". Funciona como una **alarma anotada**: guarda *cuándo* vence y *qué* hay que hacer, y nada más.

No es un hilo. No duerme ni espera por su cuenta. Es el hilo que ya actualiza a la entidad (`HiloJugador` para Link, `HiloMundo` para el resto) el que, en cada vuelta, revisa si la alarma venció y, si venció, la ejecuta.

Es una clase muy chica (dos atributos, un constructor y dos métodos), pero es la que permite que el juego tenga **solo los hilos que dibujamos** en el diagrama, sin crear uno nuevo por cada espera.

## 2. Qué problema resuelve

En la Defensa 4, `EntidadAnimada.programar(ms, accion)` creaba un `Thread` que dormía `ms` milisegundos y después ejecutaba la acción. Eso traía dos problemas:

| Problema | Por qué es malo |
|---|---|
| **Muchos hilos** | Cada golpe a Link, cada fase de un jefe y cada trampa creaba un hilo nuevo. Los diagramas no los mostraban. |
| **Carreras** | La acción corría **al mismo tiempo** que la vuelta de la entidad. Por ejemplo, el hilo de la espera podía cambiar la defensa de Link mientras `HiloJugador` la estaba usando. |

Desde la Defensa 5 (y se mantiene en la 6), `programar` **no crea un hilo**: anota una `AccionProgramada` en la lista `pendientes` de la entidad. La firma de `programar(ms, accion)` es la misma, así que las clases que la usan (Link, los jefes, la trampa) no tuvieron que cambiar.

| | Defensa 4 | Defensa 5 y 6 |
|---|---|---|
| Qué hace `programar(ms, accion)` | Crea un `Thread` que duerme y ejecuta | Agrega una `AccionProgramada` a `pendientes` |
| Quién ejecuta la acción | Un hilo nuevo | El hilo que ya actualiza a la entidad |
| Corre al mismo tiempo que la vuelta | Sí | No: corre **dentro** de la vuelta |
| Hilos del juego | Variables | Siempre los mismos (`HiloJugador`, `HiloMundo`, `Reloj`, más `AnimadorTransicion` en la vista) |

## 3. Miembros (según el extendido)

### Atributos

| Miembro | Tipo | Para qué |
|---|---|---|
| `# instante` | `long` | Cuándo vence, en milisegundos del reloj del sistema: `System.currentTimeMillis() + ms`. |
| `# accion` | `Runnable` | Qué hay que hacer. Casi siempre es una *lambda* o una referencia a método: `() -> restaurarDefensa()` o `this::restaurarDefensa`. |

Los dos son `protected` (`#` en el diagrama), como el resto de los atributos del proyecto.

### Constructor

| Constructor | Uso |
|---|---|
| `+ AccionProgramada(instante : long, accion : Runnable)` | Lo llama **solo** `EntidadAnimada.programar(ms, accion)`. |

### Comandos

| Método | Qué hace | Quién lo llama |
|---|---|---|
| `+ ejecutar()` | `accion.run()`, en el hilo que la llama. **No** crea un `Thread`. | `EntidadAnimada.ejecutarPendientes()` |

### Consultas

| Método | Qué devuelve | Quién lo llama |
|---|---|---|
| `+ estaVencida(ahora : long) : boolean` | `true` si `ahora >= instante`. | `EntidadAnimada.sacarVencidas(ahora)` |

## 4. El código, método por método

```java
package logica.hilos;

public class AccionProgramada {

    protected long instante;
    protected Runnable accion;

    public AccionProgramada(long instante, Runnable accion) {
        this.instante = instante;
        this.accion = accion;
    }

    public void ejecutar() {
        accion.run();
    }

    public boolean estaVencida(long ahora) {
        boolean vencida = ahora >= instante;
        return vencida;
    }
}
```

(La versión del archivo `.java` tiene además todo el javadoc.)

### El constructor

Recibe el **instante absoluto** en el que vence, no la espera. La cuenta `System.currentTimeMillis() + ms` la hace `EntidadAnimada.programar`. Así la acción no necesita saber cuándo fue creada: solo compara contra la hora actual.

### `ejecutar()`

Llama a `accion.run()`. Es importante entender que **`run()` llamado así es un método común**: se ejecuta en el mismo hilo, de principio a fin, y recién después sigue el código siguiente. Un hilo nuevo solo arranca con `new Thread(r).start()`, y eso esta clase no lo hace nunca.

### `estaVencida(ahora)`

Compara con `>=` y no con `==`. Los hilos duermen entre vuelta y vuelta, así que casi nunca se revisa justo en el milisegundo exacto. Con `>=`, si la acción venció en el 11 000 y la vuelta pasa en el 11 010, igual se ejecuta. Sigue la regla del equipo de un solo `return` con variable de retorno (`vencida`).

El parámetro `ahora` lo pasa quien llama, en lugar de pedir la hora adentro. Así todas las acciones de una misma vuelta se comparan contra **la misma hora**, y es más fácil de probar.

## 5. Cómo la usa EntidadAnimada

`AccionProgramada` no hace nada sola: depende de tres métodos de `EntidadAnimada` y de su lista `pendientes`.

```java
protected List<AccionProgramada> pendientes;   // ◆ #pendientes 0..*, se crea en el constructor

// 1. Anotar
protected synchronized void programar(long ms, Runnable accion) {
    long instanteDeVencimiento = System.currentTimeMillis() + ms;
    pendientes.add(new AccionProgramada(instanteDeVencimiento, accion));
}

// 2. Al final de cada vuelta: ejecutar las vencidas
private void ejecutarPendientes() {
    for (AccionProgramada a : sacarVencidas(System.currentTimeMillis()))
        a.ejecutar();                          // fuera de la llave
}

// 3. Sacar de la lista las vencidas (con la llave tomada)
private synchronized List<AccionProgramada> sacarVencidas(long ahora) {
    List<AccionProgramada> vencidas = new ArrayList<>();
    for (AccionProgramada a : pendientes)
        if (a.estaVencida(ahora)) vencidas.add(a);
    pendientes.removeAll(vencidas);
    return vencidas;
}
```

Y la vuelta de la entidad, donde `ejecutarPendientes()` es el último paso:

```java
public void actualizarEstado(AdministradorColisiones c) {   // UNA vuelta
    if (!estaEliminada()) {            // muerta: sus pendientes ya no se ejecutan
        vigilarJugador();              // gancho
        movimiento.mover(this, c);     // Strategy
        ataque.atacar(this, c);        // Strategy
        if (!estaEliminada())
            c.verificarColisiones(this);
        ejecutarPendientes();          // esperas vencidas
        avisarParpadeo();              // defensa 7: si cambió el parpadeo, avisa a la vista
    }
}
```

**Resumen del recorrido de una acción:**

1. Alguien llama `programar(1000, this::restaurarDefensa)`.
2. Se crea `new AccionProgramada(ahora + 1000, this::restaurarDefensa)` y entra en `pendientes`.
3. En cada vuelta, `ejecutarPendientes()` pide las vencidas. Mientras no venció, `estaVencida` da `false` y queda en la lista.
4. Cuando vence, `sacarVencidas` la saca de la lista y `ejecutarPendientes` llama `a.ejecutar()`.
5. `ejecutar()` llama `restaurarDefensa()`. La acción ya no está en ninguna lista y la recoge el recolector de basura.

## 6. Ejemplo paso a paso: Link recibe un golpe

Supongamos que el reloj del sistema marca 10 000 ms cuando un Moblin toca a Link. `HiloJugador` da una vuelta cada 30 ms aproximadamente.

| Instante | Qué pasa (todo en `HiloJugador`) |
|---|---|
| 10 000 ms | `alSerGolpeado()` hace `setDefensa(new DefensaLimitada(0, DefensaLimitada.SIEMPRE))` (invulnerable) y `programar(1000, this::restaurarDefensa)`. Se guarda una acción con `instante = 11 000`. |
| 10 030, 10 060, … | En cada vuelta, `sacarVencidas(ahora)` pregunta `estaVencida(ahora)`: da `false`. Link sigue invulnerable. |
| 11 010 ms | `estaVencida(11 010)` da `true`: la acción sale de la lista y se ejecuta `restaurarDefensa()`. Link vuelve a poder recibir daño. |

Diagrama de secuencia del mismo ejemplo:

```mermaid
sequenceDiagram
    participant HJ as HiloJugador
    participant L as Link
    participant A as AccionProgramada
    HJ->>L: actualizarEstado(c) [10 000 ms]
    L->>L: alSerGolpeado()
    L->>L: programar(1000, restaurarDefensa)
    L->>A: new AccionProgramada(11 000, restaurarDefensa)
    HJ->>L: actualizarEstado(c) [10 030 ms]
    L->>L: ejecutarPendientes()
    L->>A: estaVencida(10 030)
    A-->>L: false
    HJ->>L: actualizarEstado(c) [11 010 ms]
    L->>L: ejecutarPendientes()
    L->>A: estaVencida(11 010)
    A-->>L: true
    L->>A: ejecutar()
    A->>L: restaurarDefensa()
```

Todo pasa en **un solo hilo**: no hay nadie más tocando la defensa de Link mientras tanto.

## 7. Quién la usa en el juego

Nadie crea una `AccionProgramada` directamente: todos llaman `programar(ms, accion)`, que es `protected` en `EntidadAnimada`.

| Quién | Espera | Para qué | Código |
|---|---|---|---|
| `Link` | `DURACION_INVULNERABILIDAD` = 1000 ms | Termina la invulnerabilidad después de un golpe | `programar(DURACION_INVULNERABILIDAD, this::restaurarDefensa)` |
| `Link` | `DEMORA_ROTURA_SUELO` = 800 ms | El suelo quebradizo se rompe y deja una caída al vacío (cambio 33) | `programar(DEMORA_ROTURA_SUELO, () -> { ... crearCaidasAlVacio ... })` |
| `Enemigo` | `getDuracionMuerte()`: `DURACION_MUERTE` = 300 ms | Termina la animación de muerte: se elimina, suma los puntos y quizás suelta el drop o pasa de nivel (cambios 34 y 48) | `programar(getDuracionMuerte(), this::desaparecer)` |
| `Link` | `DURACION_PERDER_VIDA` = 1300 ms o `DURACION_MUERTE` = 2100 ms | Termina la animación: pierde la vida y sigue con los corazones llenos; si era la última, termina la partida (cambios 43 y 45) | `programar(vidas > 1 ? DURACION_PERDER_VIDA : DURACION_MUERTE, this::terminarMuerte)` |
| `Link` | `DURACION_CAIDA` = 400 ms | Termina la caída al vacío: pierde la vida y reinicia el nivel; si era la última, termina la partida (cambios 31 y 32) | `programar(DURACION_CAIDA, this::terminarCaida)` |
| `Wizzrobe` | `DURACION_INVULNERABILIDAD` = 1000 ms | **Defensa 7:** después de un golpe queda quieto, invulnerable y parpadeando; al vencer vuelve a teletransportarse | `programar(DURACION_INVULNERABILIDAD, () -> setMovimiento(new MovimientoTeletransporte(INTERVALO_TELETRANSPORTE)))` |
| `Wizzrobe` | `DURACION_APARECER` = 500 ms y `INTERVALO_TELETRANSPORTE - DURACION_DESAPARECER` = 2500 ms | **Cambio 30:** apaga el GIF de aparecer y prende el de desaparecer antes del próximo salto. Cada acción guarda el número de su salto (`teletransportes`) y no hace nada si ya hubo otro | `programar(DURACION_APARECER, () -> { if (numero == teletransportes) { apareciendo = false; notificarObservers(); } })` |
| `MoblinConEspadaYEscudo` | 300 a 2400 ms | Velocidades 1, 2 y 3 al salir, frenado a 2 y vuelta a caminar al azar | `programar(PREPARACION_ABALANZADA + ..., () -> setMovimiento(new MovimientoInducido(d, velocidad)))` y `programar(..., this::terminarAbalanzada)` |

**La abalanzada del Moblin con escudo, una sola vez (cambio 26).** `vigilarJugador()` corre en cada vuelta (cada 30 ms).
Antes, mientras Link estaba enfrente, en cada vuelta creaba otro `MovimientoInducido` y programaba otra vuelta al
azar: se juntaban hasta 27 acciones pendientes, la abalanzada no terminaba cuando debía y, cuando Link se corría, el
Moblin temblaba medio segundo porque cada acción creaba un `MovimientoAleatorio` nuevo que elegía otra dirección. Ahora
el atributo `# abalanzandose : boolean` evita empezar otra abalanzada mientras dura una:

```java
protected void vigilarJugador() {
    if (!abalanzandose && linkEstaEnfrente() && !hayObstaculoHastaJugador()) {
        abalanzandose = true;
        setMovimiento(new MovimientoInducido(getDireccion(), VELOCIDAD_ABALANZADA));
        programar(DURACION_ABALANZADA, this::terminarAbalanzada);
    }
}

private void terminarAbalanzada() {
    abalanzandose = false;
    setMovimiento(new MovimientoAleatorio(VELOCIDAD, INTERVALO_CAMBIO_DIRECCION));
}
```

Si al terminar Link sigue enfrente, en la vuelta siguiente empieza otra abalanzada de 1600 ms.

**Abalanzada más lenta (cambio 27).** `VELOCIDAD_ABALANZADA` pasa de 6 a 3 y `DURACION_ABALANZADA` de 800 a 1600 ms: va
a la mitad de velocidad (sigue siendo más rápido que caminar, que es 2) y recorre lo mismo que antes, unos 160 px.

**Abalanzada suave (cambio 28).** Para que no se vea tosca, `vigilarJugador()` arma toda la abalanzada con
`programar`: se queda quieto `PREPARACION_ABALANZADA` = 300 ms mirando a Link, sale a velocidad 1, 2 y 3 (cada
`DURACION_CAMBIO_VELOCIDAD` = 100 ms), va a 3 hasta completar `DURACION_ABALANZADA` y frena a su velocidad de caminar,
siguiendo derecho `DURACION_FRENADO` = 500 ms. Recién ahí `terminarAbalanzada()` vuelve a `MovimientoAleatorio`, así
no gira de golpe apenas termina. La dirección se guarda al empezar (`d`), así sale hacia donde estaba Link.

```java
protected void vigilarJugador() {
    if (!abalanzandose && linkEstaEnfrente() && !hayObstaculoHastaJugador()) {
        abalanzandose = true;
        Direccion d = getDireccion();
        setMovimiento(new MovimientoInducido((Direccion) null, 0));
        for (int v = 1; v <= VELOCIDAD_ABALANZADA; v++) {
            int velocidad = v;
            programar(PREPARACION_ABALANZADA + (v - 1) * DURACION_CAMBIO_VELOCIDAD,
                    () -> setMovimiento(new MovimientoInducido(d, velocidad)));
        }
        programar(PREPARACION_ABALANZADA + DURACION_ABALANZADA,
                () -> setMovimiento(new MovimientoInducido(d, VELOCIDAD)));
        programar(PREPARACION_ABALANZADA + DURACION_ABALANZADA + DURACION_FRENADO, this::terminarAbalanzada);
    }
}
```
| `MasterStalfos` | `DURACION_INVULNERABILIDAD` = 800 ms | Termina su invulnerabilidad | `programar(DURACION_INVULNERABILIDAD, () -> setDefensa(...SIN_LIMITE...))` |
| `MasterStalfos` | `DURACION_FASE` = 2000 ms | Cambia de fase, espada ↔ contacto | `programar(DURACION_FASE, this::faseContacto)` y `this::faseEspada` |
| `MasterStalfos` | `getDuracionMuerte()`: `DURACION_MUERTE` = 1530 ms | Termina la animación de muerte: se elimina y avisa `jefeDerrotado` (cambios 47 y 48) | La misma acción de `Enemigo`, con su duración |
| `StoneHinox` | 1000 a 3000 ms | Primer ataque, fin de la embestida, fin de la vulnerabilidad y siguiente ataque | `DEMORA_PRIMER_ATAQUE` (3000), `DURACION_EMBESTIDA` (1500), `DURACION_VULNERABILIDAD` (1000), `DURACION_LANZAMIENTO_ROCAS` (3000) |

**La trampa de cuchillas ya no programa nada (defensa 7).** En la defensa 6 volvía a su lugar con `programar(600, volver)`.
Ahora sale a 8 px por vuelta hasta **la posición que tenía Link** cuando la vio y, al llegar o al chocar con algo, vuelve
a 4 px por vuelta hasta su lugar. La vuelta depende de la distancia y no de un tiempo fijo.

**Acciones que se encadenan.** En `MasterStalfos`, `faseEspada()` programa `faseContacto()`, y `faseContacto()` programa `faseEspada()`. Así el jefe alterna de fase cada 2 segundos para siempre (mientras esté vivo), sin ningún hilo. Esto funciona porque la acción se ejecuta **fuera de la llave** (ver sección 8): puede llamar a `programar` sin trabarse.

```java
private void faseEspada() {
    setAtaque(espada);                              // Strategy en tiempo de ejecución
    programar(DURACION_FASE, this::faseContacto);
}

private void faseContacto() {
    setAtaque(contacto);
    programar(DURACION_FASE, this::faseEspada);
}
```

## 8. Hilos y sincronización

`AccionProgramada` **no tiene nada `synchronized`** y no lo necesita: una vez creada no cambia (nadie modifica `instante` ni `accion`). Lo que sí se comparte es la **lista** `pendientes` de la entidad, y de eso se encarga `EntidadAnimada`:

| Método de `EntidadAnimada` | ¿`synchronized`? | Por qué |
|---|---|---|
| `programar(ms, accion)` | Sí | Puede llamarlo otro hilo. Por ejemplo, `HiloMundo` hace que un Moblin toque a Link y eso termina en `Link.alSerGolpeado()`, que programa en la lista de Link. |
| `sacarVencidas(ahora)` | Sí | Recorre y modifica la lista. Si otro hilo agregara al mismo tiempo, saltaría `ConcurrentModificationException`. |
| `ejecutarPendientes()` | **No** | Ejecuta las acciones **fuera** de la llave. |

**Por qué ejecutar fuera de la llave.** Si `ejecutar()` corriera con la llave tomada:

- Una acción que vuelve a programar (como las fases de `MasterStalfos`) modificaría la lista mientras se la recorre.
- Una acción que toca otra entidad con métodos `synchronized` (por ejemplo, dañarla) podría causar un **abrazo mortal**: este hilo con la llave de A esperando la de B, y otro hilo con la de B esperando la de A.

Por eso el trabajo se divide en dos: primero `sacarVencidas` saca las vencidas con la llave tomada (rápido, solo mueve objetos de lista), y después `ejecutarPendientes` las ejecuta ya sin la llave.

**Pausa y transición.** Durante la transición de sector los hilos se pausan, así que nadie revisa los pendientes. Las acciones se cumplen un poco más tarde de lo pedido (en la primera vuelta después de la pausa). Para un juego no es un problema.

## 9. Paquete e imports

```java
package logica.hilos;
```

- Va en `logica.hilos`, junto con `HiloJuego*`, `HiloJugador`, `HiloMundo` y `Reloj` y `OyenteReloj`. **Defensa 7:** todos los paquetes van en minúscula.
- **No necesita imports.** `Runnable` es del paquete `java.lang`, que Java importa automáticamente (igual que `String` o `Math`). Escribir `import java.lang.Runnable;` compila, pero es redundante.
- No importa ninguna clase del proyecto: no conoce a `Entidad` ni a `EntidadAnimada`. La relación va en un solo sentido: `EntidadAnimada` conoce a `AccionProgramada`, no al revés. Por eso `EntidadAnimada` (en `logica.entidades`) sí necesita `import logica.hilos.AccionProgramada;`, además de `java.util.List` y `java.util.ArrayList`.
- Como `AccionProgramada` está en otro paquete que `EntidadAnimada`, la clase, el constructor y los dos métodos tienen que ser `public`, como dice el diagrama (`+`).

## 10. Cuidados y errores comunes

| Error | Qué pasa | Cómo se evita |
|---|---|---|
| Pasar la espera en vez del instante: `new AccionProgramada(1000, ...)` | Vence enseguida, porque 1000 ms ya pasó hace décadas en el reloj del sistema. | Solo `programar` crea acciones, y hace `System.currentTimeMillis() + ms`. |
| Escribir `new Thread(accion).start()` en `ejecutar()` | Vuelve el problema de la Defensa 4: un hilo nuevo y carreras. | `ejecutar()` es solo `accion.run()`. |
| Hacer que `AccionProgramada` implemente `Runnable` | No hace falta y confunde: parece un hilo. El diagrama no la muestra realizando `Runnable`. | La **tiene** como atributo, no la **es**. |
| Comparar con `==` en `estaVencida` | Casi nunca coincide el milisegundo exacto: la acción no se ejecutaría nunca. | Usar `>=`. |
| Ejecutar dentro de `sacarVencidas` | Abrazo mortal o `ConcurrentModificationException` si la acción programa otra. | Sacar con la llave, ejecutar sin ella. |
| Esperar que se ejecute aunque la entidad muera | No se ejecuta: `actualizarEstado` sale enseguida si está eliminada. Es lo correcto (un Moblin muerto no tiene que volver a caminar). | Si algo tiene que pasar al morir, va en `morir()`, no en una acción programada. |

## 11. En los diagramas

| Diagrama | Cómo aparece |
|---|---|
| **Reducido** | Clase `AccionProgramada` en blanco (no es parte de un patrón), a la derecha de `EntidadAnimada*`. Composición `EntidadAnimada* ◆ AccionProgramada` con rol `#pendientes 0..*`. |
| **Extendido** | Con sus dos atributos (`# instante : long`, `# accion : Runnable`), el constructor, `+ ejecutar()` y `+ estaVencida(ahora : long) : boolean`. No lleva el subtítulo "implementa Runnable". |

**Por qué composición (◆) y no agregación.** Cada acción la crea una entidad, pertenece solo a ella y desaparece con ella. Ninguna otra clase guarda referencias a una `AccionProgramada`.

**Por qué `0..*`.** Una entidad puede no tener ninguna espera (un Moblin común) o varias a la vez (StoneHinox después de embestir).

**Por qué no hay flecha a `Runnable`.** `Runnable` es una interfaz de Java y en el diagrama solo aparece porque la realizan `HiloJuego*` y `AnimadorTransicion`. `AccionProgramada` la usa solo como **tipo de un atributo**, que ya se lee en el extendido.

## 12. Preguntas que pueden hacer en la defensa

| Pregunta | Respuesta corta |
|---|---|
| ¿`AccionProgramada` es un hilo? | No. Guarda un `Runnable` como dato y lo ejecuta con un llamado normal, dentro de la vuelta de la entidad. |
| ¿Entonces cómo espera sin dormir? | No espera: el hilo de la entidad pregunta en cada vuelta `estaVencida(ahora)`. Cuando da `true`, la ejecuta. |
| ¿Por qué no usar un `Thread` con `sleep` como en la Defensa 4? | Sumaba hilos que no estaban en el diagrama, y la acción corría al mismo tiempo que la vuelta de la entidad, con riesgo de carreras. |
| ¿En qué hilo corre la acción? | En el mismo que actualiza a la entidad: `HiloJugador` para Link y `HiloMundo` para el resto. |
| ¿Qué pasa si la entidad muere antes de que venza? | No se ejecuta, porque `actualizarEstado` sale enseguida si está eliminada. |
| ¿Por qué `ejecutar` va fuera del `synchronized`? | Para que una acción pueda volver a programar otra (fases de MasterStalfos) y para evitar abrazos mortales con otras entidades. |
| ¿Qué tan exacta es la espera? | Se cumple en la primera vuelta después del instante: unos milisegundos más tarde (hasta un período del hilo), o más si hubo una pausa por transición. |
| ¿Por qué `Runnable` y no una interfaz propia? | `Runnable` ya existe en Java, no tiene parámetros ni devuelve nada, y acepta lambdas y referencias a métodos (`this::volver`). |

---

# Explicación de la clase HiloJuego (Defensa 7)

Basado en los diagramas extendido y reducido de la defensa 7 (estrategia `bloqueaPasoA`) y en el código de
`DEFENSA 7 FINAL/Codigo/src/logica/hilos/HiloJuego.java`.

**Lo que cambió en la defensa 7:** `HiloJuego` no cambió. Cambiaron sus subclases y quien las maneja:

- Los períodos son **constantes con nombre** en cada subclase (`PERIODO = 30` en `HiloJugador` y `HiloMundo`,
  `PERIODO = 1000` en `Reloj`), y cada una llama `super(PERIODO)`.
- El `Reloj` le avisa a un **`OyenteReloj`** (interfaz de un solo método) y ya no a `Juego`.
- `Juego.terminarPartida()` ya no pregunta `reloj.estaActivo()` para saber si la partida terminó: usa su propio atributo
  `partidaEnCurso`. El estado de un hilo no es el estado de la partida.


## 1. Qué es

`HiloJuego` es la **clase abstracta** base de los tres hilos de la lógica del juego: `HiloJugador`, `HiloMundo` y `Reloj`. Realiza la interfaz `Runnable` de Java.

Escribe **una sola vez** el ciclo que comparten todos:

> mientras esté activo → si no está en pausa, hacer una vuelta → dormir un rato → repetir

Cada subclase dice solo dos cosas:

| Qué | Cómo lo dice | Ejemplo |
|---|---|---|
| Qué es **una vuelta** | Redefine `ciclo()` | `HiloJugador`: actualizar a Link |
| **Cada cuánto** se repite | Le pasa el período al constructor | `super(PERIODO)`, con `PERIODO = 30` o `1000` |

**Ojo:** aunque a veces se la llama "interfaz", en los diagramas es una **clase abstracta** (`HiloJuego*`, con asterisco). No puede ser una interfaz porque tiene atributos (`hilo`, `activo`, `pausado`, `periodo`) y código en sus métodos.

## 2. Por qué existe

Antes de la Defensa 5, `Timer` tenía su propio `activo`, `iniciar()`, `detener()` y `run()`, y cada entidad animada tenía un hilo propio con el mismo ciclo copiado. El mismo código estaba repetido en varios lugares.

`HiloJuego` junta todo lo repetido:

| Antes | Ahora |
|---|---|
| Cada clase con hilo escribía su `while`, su `sleep` y su `try/catch` | Lo escribe `HiloJuego.run()` una vez |
| Pausar durante la transición había que hacerlo en cada clase | `pausar()` / `reanudar()` heredados |
| Un hilo por entidad animada | Tres hilos fijos: `HiloJugador`, `HiloMundo` y `Reloj` |

## 3. Miembros (según el extendido)

### Atributos

| Miembro | Tipo | Para qué |
|---|---|---|
| `# hilo` | `Thread` | El hilo de Java que ejecuta `run()`. Se crea en `iniciar()`. |
| `# activo` | `boolean` (`volatile`) | Mientras sea `true`, el ciclo sigue. `false` lo termina. |
| `# pausado` | `boolean` (`volatile`) | Si es `true`, el hilo sigue vivo pero saltea las vueltas. |
| `# periodo` | `long` | Milisegundos que duerme entre vueltas: 30 en los hilos de juego, 1000 en el reloj. |

### Constructor

| Constructor | Uso |
|---|---|
| `# HiloJuego(periodo : long)` | `protected`: solo lo llaman las subclases, con `super(PERIODO)`. No arranca el hilo. |

### Comandos

| Método | Qué hace | Quién lo llama |
|---|---|---|
| `+ iniciar()` | `activo = true`, `pausado = false`, crea el `Thread` y lo arranca | `Juego.iniciar` |
| `+ detener()` | `activo = false` | `Juego.terminarPartida` |
| `+ pausar()` | `pausado = true` | `Juego.cambiarDeSector`, `jugadorCayoAlVacio`, `jefeDerrotado` |
| `+ reanudar()` | `pausado = false` | `Juego.transicionTerminada`, `jugadorCayoAlVacio`, `jefeDerrotado` |
| `+ run()` | El ciclo (`final`) | Java, en el hilo nuevo, después de `start()` |
| `# ciclo()` | **Abstracto**: una vuelta | `run()` |

### Consultas

| Método | Qué devuelve |
|---|---|
| `+ estaActivo() : boolean` | Si el hilo se inició y no se detuvo. La usa `Juego.terminarPartida` con el reloj para no terminar dos veces. |
| `+ estaPausado() : boolean` | Si está en pausa. |

## 4. El código, método por método

```java
public abstract class HiloJuego implements Runnable {

    protected Thread hilo;
    protected volatile boolean activo;
    protected volatile boolean pausado;
    protected long periodo;

    protected HiloJuego(long periodo) {
        this.periodo = periodo;
    }

    public void iniciar() {
        activo = true;
        pausado = false;
        hilo = new Thread(this);
        hilo.start();
    }

    public void detener() { activo = false; }
    public void pausar() { pausado = true; }
    public void reanudar() { pausado = false; }

    @Override
    public final void run() {
        while (activo) {
            if (!pausado) {
                try {
                    ciclo();
                } catch (RuntimeException error) {
                    error.printStackTrace();
                }
            }
            try {
                Thread.sleep(periodo);
            } catch (InterruptedException interrupcion) {
                activo = false;
            }
        }
    }

    protected abstract void ciclo();

    public boolean estaActivo() { return activo; }
    public boolean estaPausado() { return pausado; }
}
```

(La versión del `.java` tiene además todo el javadoc.)

### El constructor

Solo guarda el período. **No arranca nada**: `Juego` crea los hilos primero, carga el nivel y recién después llama `iniciar()`. Así ningún hilo corre sobre un nivel a medio armar.

### `iniciar()`

1. `activo = true`: el `while` de `run()` va a entrar.
2. `pausado = false`: arranca haciendo vueltas.
3. `hilo = new Thread(this)`: crea el hilo de Java y le pasa **este objeto** como `Runnable`. Por eso `HiloJuego` implementa `Runnable`.
4. `hilo.start()`: Java crea el hilo y, **en ese hilo nuevo**, llama a `run()`. `iniciar()` termina enseguida; `run()` sigue corriendo en paralelo.

**Importante:** hay que llamar `start()`, no `run()`. Si se llamara `run()` directamente, el ciclo correría en el hilo de quien llamó (por ejemplo, el de Swing) y la ventana se congelaría para siempre.

### `detener()`

Pone `activo = false`. **No corta el hilo de golpe**: la vuelta en curso termina, el hilo duerme su período, el `while` vuelve a preguntar y sale. Como mucho tarda un período (30 ms o 1 s).

### `pausar()` y `reanudar()`

Solo cambian `pausado`. Durante la pausa el hilo sigue vivo dando vueltas vacías (duerme y pregunta). Se usan:

| Situación | Qué se pausa | Por qué |
|---|---|---|
| Cambio de sector | `HiloJugador` y `HiloMundo` | Mientras la pantalla se desliza, nadie se mueve |
| Link cae al vacío | `HiloMundo` | Se recarga el nivel sin que los enemigos se muevan sobre un sector a medio armar |
| Jefe derrotado (pasa de nivel) | `HiloMundo` | Igual: se carga el nivel siguiente |

El `Reloj` nunca se pausa: el tiempo de la partida sigue corriendo durante la transición.

### `ciclo()`

Es `abstract` y `protected`: cada subclase **tiene** que escribirlo, y nadie de afuera lo puede llamar. Lo llama solo `run()`.

### Consultas

Devuelven el atributo. Siguen la regla de un solo `return`.

## 5. El método run() en detalle

`run()` es el **ciclo de vida del hilo**: es todo lo que hace el hilo desde que nace hasta que muere. Nadie del proyecto lo llama: lo llama Java después de `hilo.start()`. Cuando `run()` termina, el hilo muere.

| Paso | Código | Qué hace |
|---|---|---|
| 1 | `while (activo)` | Repite mientras el hilo esté activo. Cuando `detener()` pone `false`, sale al terminar la vuelta. |
| 2 | `if (!pausado)` | Si está en pausa, saltea la vuelta pero no muere. |
| 3 | `ciclo();` | **Una vuelta**: lo que diga la subclase. |
| 4 | `catch (RuntimeException error)` | Si la vuelta falla, imprime el error y sigue. |
| 5 | `Thread.sleep(periodo)` | Duerme 30 ms (o 1000 ms) antes de la próxima vuelta. |
| 6 | `catch (InterruptedException ...)` | Si alguien interrumpe el hilo mientras duerme, `activo = false` y termina. |

**Por qué el `sleep`.** Sin él, el hilo daría millones de vueltas por segundo: el juego iría a una velocidad distinta en cada computadora y usaría el 100% del procesador. Con `sleep(30)` da unas 33 vueltas por segundo, una velocidad pareja.

**Por qué atrapar `RuntimeException`.** Si `ciclo()` lanza una excepción que nadie atrapa, `run()` termina y **el hilo muere**. El juego quedaría congelado sin ningún aviso. Con el `catch`, el error aparece en la consola (para poder arreglarlo) y el juego sigue.

**Por qué `InterruptedException` es obligatoria.** `Thread.sleep` la declara (es una excepción *chequeada*), así que Java obliga a atraparla. Nadie en el proyecto interrumpe los hilos, pero si pasara, lo correcto es terminar.

**Por qué es `final`.** Es la parte fija del Template Method: ninguna subclase puede cambiar el esquema, solo el paso `ciclo()`.

## 6. Template Method

`HiloJuego` es un ejemplo del patrón **Template Method**:

| Rol del patrón | En el proyecto |
|---|---|
| Clase abstracta | `HiloJuego*` |
| Método plantilla (esquema fijo) | `run()`, `final` |
| Paso variable (abstracto) | `ciclo()` |
| Clases concretas | `HiloJugador`, `HiloMundo`, `Reloj` |

```mermaid
classDiagram
    class Runnable {
        <<interface>>
        +run()
    }
    class HiloJuego {
        <<abstract>>
        #hilo : Thread
        #activo : boolean
        #pausado : boolean
        #periodo : long
        #HiloJuego(periodo : long)
        +iniciar()
        +detener()
        +pausar()
        +reanudar()
        +run()
        #ciclo()*
        +estaActivo() boolean
        +estaPausado() boolean
    }
    class HiloJugador {
        #ciclo()
    }
    class HiloMundo {
        #ciclo()
    }
    class Reloj {
        #ciclo()
    }
    Runnable <|.. HiloJuego
    HiloJuego <|-- HiloJugador
    HiloJuego <|-- HiloMundo
    HiloJuego <|-- Reloj
```

Lo que cambia en cada subclase:

| Clase | Período | `ciclo()` |
|---|---|---|
| `HiloJugador` | 30 ms | `jugador.actualizarEstado(colisiones)` |
| `HiloMundo` | 30 ms | `colisiones.getSector().actualizarEntidades(colisiones)` (si hay sector) |
| `Reloj` | 1000 ms | `segundos++` y `oyente.tic(segundos)` |

## 7. Ciclo de vida de un hilo

```mermaid
stateDiagram-v2
    [*] --> Creado: new HiloJugador(...)
    Creado --> Corriendo: iniciar()
    Corriendo --> Pausado: pausar()
    Pausado --> Corriendo: reanudar()
    Corriendo --> Terminado: detener()
    Pausado --> Terminado: detener()
    Terminado --> [*]
```

| Estado | `activo` | `pausado` | ¿Hace vueltas? |
|---|---|---|---|
| Creado | `false` | `false` | No: el `Thread` todavía no existe |
| Corriendo | `true` | `false` | Sí, una cada período |
| Pausado | `true` | `true` | No, pero el hilo sigue vivo |
| Terminado | `false` | — | No: `run()` terminó y el hilo murió |

**Un hilo terminado no se puede volver a usar.** Java no permite llamar `start()` dos veces sobre el mismo `Thread`. Por eso cada partida nueva crea objetos `HiloJugador`, `HiloMundo` y `Reloj` nuevos en `Juego.iniciar`.

## 8. Quién la usa

`Juego` es el único que maneja los hilos:

```java
public void iniciar(ModoJuego modo, FabricaSprites dominio) {
    ...
    reloj = new Reloj(this);       // this como OyenteReloj
    hiloJugador = new HiloJugador(jugador, colisiones);
    hiloMundo = new HiloMundo(colisiones);
    cargarNivel();                 // primero se arma el nivel
    partidaEnCurso = true;         // defensa 7
    reloj.iniciar();               // después arrancan los hilos
    hiloJugador.iniciar();
    hiloMundo.iniciar();
}

public void cambiarDeSector(Direccion d) {
    ...
    hiloJugador.pausar();
    hiloMundo.pausar();
    ...
    controladorGrafico.transicion(d);   // al terminar llama transicionTerminada()
}

public void transicionTerminada() {
    activarSector(colisiones.getSector());
    hiloJugador.reanudar();
    hiloMundo.reanudar();
}

public synchronized void terminarPartida() {
    if (partidaEnCurso) {               // defensa 7: el estado de la partida, no el del reloj
        partidaEnCurso = false;
        reloj.detener();
        hiloJugador.detener();
        hiloMundo.detener();
        controladorGrafico.terminarControl();   // cambio 51
        ...
    }
}
```

**Por qué `partidaEnCurso` (defensa 7).** En la defensa 6 `terminarPartida()` preguntaba `reloj.estaActivo()`. Funcionaba
porque `pausar()` cambia `pausado` y no `activo`, pero mezclaba el estado de un **hilo** con el de la **partida**: si
algún día se pausara o detuviera el reloj por otra razón, la partida "parecería" terminada. Además, antes de `iniciar()`
el `reloj` era `null`. Ahora `Juego` guarda su propio `boolean`, y como el método es `synchronized`, si dos avisos
llegan juntos solo el primero termina la partida.

## 9. volatile y sincronización

`activo` y `pausado` los **escribe un hilo** (el que ejecuta `Juego`: el de Swing, `AnimadorTransicion`, o el propio `HiloJugador` cuando Link cae) y los **lee otro** (el hilo de `run()`).

Sin `volatile`, Java permite que el hilo de `run()` guarde una copia del valor y no vea nunca el cambio: `detener()` no detendría nada. Con `volatile`, cada lectura ve el último valor escrito.

No hace falta `synchronized`: cada método escribe **un solo** `boolean`, y eso ya es atómico. No hay que proteger una secuencia de pasos.

| Atributo | ¿Lo comparten varios hilos? | Protección |
|---|---|---|
| `activo` | Sí | `volatile` |
| `pausado` | Sí | `volatile` |
| `periodo` | No: se asigna en el constructor y no cambia | Ninguna |
| `hilo` | No: solo lo usa `iniciar()` | Ninguna |

`volatile` y `synchronized` **no se dibujan** en los diagramas (son detalles de Java).

## 10. Paquete e imports

```java
package logica.hilos;
```

- Va en `logica.hilos`, con `HiloJugador`, `HiloMundo`, `Reloj`, `OyenteReloj` y `AccionProgramada`.
- **No necesita imports**: `Runnable`, `Thread`, `RuntimeException` e `InterruptedException` son de `java.lang`, que Java importa solo.
- No conoce ninguna clase del proyecto: no sabe nada de Link, sectores ni colisiones. Eso lo agregan las subclases.

## 11. Cuidados y errores comunes

| Error | Qué pasa | Cómo se evita |
|---|---|---|
| Llamar `run()` en vez de `iniciar()` | El ciclo corre en el hilo de quien llamó; si es Swing, la ventana se congela | Siempre `iniciar()`, que hace `start()` |
| Llamar `iniciar()` dos veces sobre el mismo objeto | Se crean dos `Thread` que ejecutan el mismo ciclo: todo va al doble de velocidad | `Juego` llama `iniciar()` una vez por partida |
| Olvidar `volatile` | `detener()` o `pausar()` pueden no tener efecto | Declarar `activo` y `pausado` `volatile` |
| Sacar el `sleep` | 100% de procesador y velocidad distinta en cada máquina | El `sleep(periodo)` va siempre, aunque esté pausado |
| Excepción en `ciclo()` sin atrapar | El hilo muere en silencio y el juego se congela | El `catch (RuntimeException)` de `run()` |
| Hacer `run()` `synchronized` | El hilo tendría la llave todo el tiempo: nadie podría llamar otros métodos `synchronized` del objeto | `run()` no es `synchronized` |

## 12. En los diagramas

| Diagrama | Cómo aparece |
|---|---|
| **Reducido** | `HiloJuego*` (abstracta) realiza `Runnable`. `HiloJugador`, `HiloMundo` y `Reloj` heredan de ella. Va coloreada como parte del Template Method. |
| **Extendido** | Con los cuatro atributos, el constructor `#`, los comandos, `+ run()`, `# ciclo()` abstracto y las dos consultas. |

## 13. Preguntas que pueden hacer en la defensa

| Pregunta | Respuesta corta |
|---|---|
| ¿Por qué es abstracta y no una interfaz? | Porque tiene atributos y código (el ciclo). Una interfaz no puede guardar estado. |
| ¿Qué patrón es? | Template Method: `run()` es el esquema fijo y `ciclo()` el paso que cambia. |
| ¿Quién llama a `run()`? | Java, en el hilo nuevo, después de `hilo.start()`. |
| ¿Por qué `run()` es `final`? | Para que ninguna subclase cambie el esquema; solo redefinen `ciclo()`. |
| ¿Cómo se detiene un hilo? | `detener()` pone `activo = false`; el hilo termina al final de la vuelta. |
| ¿Qué diferencia hay entre pausar y detener? | Pausado sigue vivo y puede reanudar. Detenido terminó y no se puede volver a arrancar. |
| ¿Por qué `volatile`? | Porque `activo` y `pausado` los escribe un hilo y los lee otro; sin `volatile` el cambio puede no verse. |
| ¿Usan timers? | No. `Reloj` es un `HiloJuego` con `sleep(1000)`, no `javax.swing.Timer` ni `java.util.Timer`. |
| ¿Qué cambió en la defensa 7? | Nada en `HiloJuego`. Los períodos son constantes `PERIODO` en cada subclase, el reloj avisa a un `OyenteReloj` y `Juego` ya no usa `reloj.estaActivo()` para saber si la partida terminó. |
| ¿Cuántos hilos tiene el juego? | Tres de lógica (`HiloJugador`, `HiloMundo`, `Reloj`), más `AnimadorTransicion` en la vista y el EDT de Swing. |

---

# Explicación de la clase HiloJugador (Defensa 7)

Basado en los diagramas extendido y reducido de la defensa 7 (estrategia `bloqueaPasoA`) y en el código de
`DEFENSA 7 FINAL/Codigo/src/logica/hilos/HiloJugador.java`. Conviene leer antes la sección de `HiloJuego`.

**Lo que cambió en la defensa 7:**

- El período es la constante `PERIODO = 30` y el constructor llama `super(PERIODO)`.
- Con el bloqueo `bloqueaPasoA`, Link y los enemigos **no se atraviesan**: si Link camina contra un enemigo, el choque
  lo detecta este hilo en `AdministradorColisiones.mover` y termina en la estrategia de ataque del enemigo (sección 7).
- La vuelta de Link termina con `avisarParpadeo()` y, si mostró un espadazo, cuenta las vueltas de esa imagen.


## 1. Qué es

`HiloJugador` es el hilo que **mueve solo a Link**. Hereda de `HiloJuego*` (patrón Template Method): hereda el ciclo `run()` y redefine el paso `ciclo()`.

Cada 30 ms (unas 33 veces por segundo) hace **una vuelta de Link**: `jugador.actualizarEstado(colisiones)`.

Es la clase más corta de los hilos: dos atributos, un constructor y un método. Todo el trabajo de verdad lo hace Link en `actualizarEstado`, y todo lo de "ser un hilo" lo hace `HiloJuego`.

## 2. Por qué existe

¿Por qué Link tiene un hilo para él solo, separado del resto del mundo?

| Razón | Explicación |
|---|---|
| **Respuesta inmediata al teclado** | Si Link se actualizara en el mismo hilo que todos los enemigos, con un sector lleno de entidades cada vuelta tardaría más y Link respondería con retraso. Con su propio hilo, Link se mueve siempre a la misma velocidad. |
| **Un dueño claro** | A Link lo mueve **solo** este hilo. `HiloMundo` lo saltea (`Link.actualizarPorMundo` está vacío). Así Link nunca se mueve dos veces en la misma vuelta. |
| **Choques de Link en un lugar** | Los choques en los que Link es el que se movió se detectan acá (ver sección 7). |

## 3. Miembros (según el extendido)

### Atributos

| Constante | Valor | Para qué |
|---|---|---|
| `- PERIODO` | `30` (`long`) | Milisegundos entre vueltas (defensa 7) |

| Miembro | Tipo | Para qué | Relación |
|---|---|---|---|
| `# jugador` | `Link` | El Link que actualiza | `HiloJugador → Link` (`#jugador 1`) |
| `# colisiones` | `AdministradorColisiones` | Se lo pasa a Link en cada vuelta para moverse y verificar choques | `HiloJugador → AdministradorColisiones` (`#colisiones 1`), desde las correcciones finales |

Además hereda de `HiloJuego*`: `hilo`, `activo`, `pausado` y `periodo`.

### Constructor

| Constructor | Qué hace |
|---|---|
| `+ HiloJugador(l : Link, c : AdministradorColisiones)` | `super(PERIODO)`, guarda `l` en `jugador` y `c` en `colisiones`. No arranca el hilo. |

### Comandos

| Método | Qué hace | Quién lo llama |
|---|---|---|
| `# ciclo()` | `jugador.actualizarEstado(colisiones)` | `HiloJuego.run()`, en cada vuelta que no está en pausa |

Heredados y usados por `Juego`: `iniciar()`, `pausar()`, `reanudar()`, `detener()`.

## 4. El código

```java
package logica.hilos;

import logica.entidades.AdministradorColisiones;
import logica.entidades.Link;

public class HiloJugador extends HiloJuego {

    private static final long PERIODO = 30;     // una vuelta cada 30 ms: unas 33 por segundo

    protected Link jugador;
    protected AdministradorColisiones colisiones;

    public HiloJugador(Link l, AdministradorColisiones c) {
        super(PERIODO);
        jugador = l;
        colisiones = c;
    }

    @Override
    protected void ciclo() {
        jugador.actualizarEstado(colisiones);
    }
}
```

- **`super(PERIODO)`** le pasa el período a `HiloJuego`. Tiene que ser la primera línea del constructor.
- **`ciclo()`** es `protected` como en la clase padre, y lleva `@Override` para que el compilador avise si el nombre o la firma no coinciden.
- No redefine `run()`: no podría, porque es `final` en `HiloJuego`.

## 5. Qué pasa en una vuelta

`ciclo()` solo llama a `jugador.actualizarEstado(colisiones)`. Ese método está en `EntidadAnimada*` y hace la vuelta completa:

```java
// EntidadAnimada
public void actualizarEstado(AdministradorColisiones c) {   // UNA vuelta
    if (!estaEliminada()) {
        vigilarJugador();              // gancho (vacío en Link)
        movimiento.mover(this, c);     // Strategy: MovimientoInducido con la dirección del teclado
        ataque.atacar(this, c);        // Strategy: AtaqueRecargado (espada)
        if (!estaEliminada())
            c.verificarColisiones(this);   // Visitor
        ejecutarPendientes();          // AccionProgramada vencidas
        avisarParpadeo();              // defensa 7: avisa a la vista si cambió el parpadeo
    }
}

// Link (defensa 7): además cuenta las vueltas de la imagen del espadazo
public void actualizarEstado(AdministradorColisiones c) {
    super.actualizarEstado(c);
    if (vueltasMostrandoGolpe > 0) {
        vueltasMostrandoGolpe--;
        if (vueltasMostrandoGolpe == 0)
            notificarObservers();
    }
}
```

| Paso | Qué hace con Link | Patrón |
|---|---|---|
| `vigilarJugador()` | Nada: el gancho está vacío en Link (lo usan algunos enemigos) | Gancho |
| `movimiento.mover(this, c)` | Si hay una flecha apretada, `MovimientoInducido` llama `c.mover(link, direccion, velocidad)`: avanza si nadie le bloquea el paso (`bloqueaPasoA(link)`), y si sale del borde cambia de sector. Si un enemigo lo bloquea, se dispara el Visitor con ese enemigo | Strategy + polimorfismo |
| `ataque.atacar(this, c)` | Si soltó la tecla de ataque, `AtaqueRecargado` golpea con `c.golpearEn(...)` | Strategy |
| `c.verificarColisiones(this)` | Busca con qué se superpone Link y resuelve cada choque con doble despacho | Visitor |
| `ejecutarPendientes()` | Ejecuta las esperas vencidas, por ejemplo el fin de la invulnerabilidad (1000 ms) o el suelo que se rompe (800 ms) | — |
| `avisarParpadeo()` | Si Link está parpadeando, avisa a la vista cuando cambia entre visible e invisible | Observer |

```mermaid
sequenceDiagram
    participant HJ as HiloJugador
    participant L as Link
    participant MI as MovimientoInducido
    participant AC as AdministradorColisiones
    participant P as PowerUP
    HJ->>HJ: run() → ciclo()
    HJ->>L: actualizarEstado(colisiones)
    L->>MI: mover(link, colisiones)
    MI->>AC: mover(link, DERECHA, velocidad)
    AC->>L: avanzar(DERECHA, velocidad)
    L->>AC: verificarColisiones(link)
    AC->>P: aceptarColision(link)
    P->>L: colisionarCon(powerUp)
    L->>L: ejecutarPendientes()
    HJ->>HJ: Thread.sleep(30)
```

## 6. Del teclado a la pantalla

El teclado **no** mueve a Link directamente. Lo hacen dos hilos que se pasan la información:

| Hilo | Qué hace | Cuándo |
|---|---|---|
| **EDT de Swing** | `GUI.procesarTecla` → `ControlJugador.mover(d)` / `atacar()` / `usarEscudo()`. Solo **anota la intención** en atributos `volatile` de Link (`atacando`, `soltoAtaque`, `escudoActivo`) y en `MovimientoInducido.direccion`. | Al apretar o soltar una tecla |
| **HiloJugador** | En la próxima vuelta lee esas intenciones y hace el trabajo: mover, atacar, chocar. | Cada 30 ms |

**Por qué así.** Los métodos que corren en el EDT tienen que ser cortos y **no** `synchronized`: si el EDT se queda esperando una llave, la ventana entera se congela. Anotar un `boolean` es instantáneo. El trabajo pesado (recorrer el sector, resolver choques) lo hace `HiloJugador`, que puede tardar sin trabar la ventana.

**Por qué `volatile`.** Las intenciones las escribe el EDT y las lee `HiloJugador`. Sin `volatile`, `HiloJugador` podría no ver nunca que se apretó una tecla.

## 7. La regla de colisiones (Defensa 7)

> **El daño entre Link y un enemigo lo pone siempre la estrategia de ataque del enemigo**, sin importar qué hilo detecta
> el choque. Los demás choques de Link (proyectiles, obstáculos, power-ups, objetos) los resuelve `HiloJugador`.

| Choque | Hilo que lo detecta | Cómo termina |
|---|---|---|
| Link con un PowerUP, Rupia, Corazón, Bellota… | `HiloJugador` (`verificarColisiones`) | `powerUp.aceptarColision(link)` → `link.colisionarCon(powerUp)` → Link lo recoge |
| Link con un proyectil | `HiloJugador` o `HiloMundo` | El proyectil le hace daño a Link y desaparece |
| Link con un obstáculo (pasto, suelo quebradizo, caída al vacío) | `HiloJugador` (`verificarColisiones`) | Link se ralentiza, rompe el suelo, cae… |
| Link camina contra una roca o el agua | `HiloJugador` (`mover`) | `roca.bloqueaPasoA(link)` es `true`: Link no avanza |
| **Link camina contra un enemigo** | **`HiloJugador`** (`mover`) | `enemigo.bloqueaPasoA(link)` es `true` → `enemigo.aceptarColision(link)` → `link.colisionarCon(enemigo)` → `enemigo.colisionarCon(link)` → ataque del enemigo |
| **Un enemigo camina contra Link** | **`HiloMundo`** (`mover`) | `link.bloqueaPasoA(enemigo)` es `true` → `link.aceptarColision(enemigo)` → `enemigo.colisionarCon(link)` → ataque del enemigo |

**Sin daño doble.** Aunque los dos hilos detecten el choque casi a la vez, el primer golpe deja a Link invulnerable 1 s
(`DefensaLimitada(0, SIEMPRE)`): el segundo aviso no saca vida. `recibirDanio` es `synchronized`, así que los dos avisos
pasan de a uno.

**¿Por qué cambió respecto de la defensa 6?** Antes Link y los enemigos se podían superponer, y el choque lo detectaba
`HiloMundo` en `verificarColisiones`. Con el bloqueo ya no se superponen: si Link empuja a un enemigo quieto, solo
`HiloJugador` se entera, y por eso `link.colisionarCon(enemigo)` le delega al enemigo en lugar de estar vacío.

## 8. Pausa, cambio de sector y fin de partida

`HiloJugador` no decide cuándo pausarse: lo decide `Juego`.

| Situación | Qué hace `Juego` con `HiloJugador` |
|---|---|
| Empieza la partida | `new HiloJugador(jugador, colisiones)` y, después de `cargarNivel()`, `iniciar()` |
| Link cruza el borde | `pausar()` en `cambiarDeSector(d)`: Link no se mueve mientras se desliza la pantalla |
| Termina la transición | `reanudar()` en `transicionTerminada()` |
| Link cae al vacío o pasa de nivel | No se pausa: solo se pausa `HiloMundo` mientras se recarga |
| Termina la partida | `detener()` en `terminarPartida()` |

**Un detalle del cambio de sector.** Quien llama a `cambiarDeSector` es el propio `HiloJugador` (Link sale del borde dentro de `c.mover`, que llama `link.alSalirDelSector(d)`). O sea, `HiloJugador` se pausa a sí mismo en medio de su vuelta. No hay problema: `pausar()` solo cambia un `boolean`, la vuelta termina normalmente y las siguientes se saltean hasta que `AnimadorTransicion` llame a `transicionTerminada()`.

**El sector nuevo.** `HiloJugador` no guarda el sector: lo guarda `AdministradorColisiones`. Cuando `Juego` hace `colisiones.setSector(nuevo)`, `HiloJugador` y `HiloMundo` ven el sector nuevo a la vez, sin que nadie les avise.

## 9. Sincronización

`HiloJugador` en sí no tiene nada `synchronized`. Lo que comparte con otros hilos ya está protegido en otras clases:

| Dato que toca | Quién más lo toca | Protección |
|---|---|---|
| Vida y defensa de Link | `HiloMundo` (enemigo que choca con Link, proyectil, espada de MasterStalfos) | `synchronized` en `recibirDanio` y `aplicarDanio` |
| `pendientes` de Link | `HiloMundo` (al dañar a Link se programa el fin de la invulnerabilidad) | `synchronized` en `programar` y `sacarVencidas` |
| Lista del sector | `HiloMundo`, `Juego` | `getEntidades()` devuelve una copia (`synchronized`) |
| Puntaje | `HiloMundo` (enemigo derrotado) | `synchronized` en los métodos de `Juego` |
| Intenciones del teclado | EDT | `volatile` |

**Por qué `ciclo()` no es `synchronized`.** Si `HiloJugador` tomara una llave durante toda la vuelta, podría armarse un **abrazo mortal** con `HiloMundo` (cada uno con una llave esperando la del otro). La regla de la guía es: orden de llaves **Entidad → Juego → Sector**, y nunca ejecutar código de entidades con la llave del sector tomada.

## 10. Paquete e imports

```java
package logica.hilos;

import logica.entidades.AdministradorColisiones;
import logica.entidades.Link;
```

- Va en `logica.hilos`, junto a `HiloJuego`.
- `HiloJuego` está en el mismo paquete: no hace falta importarlo.
- Importa `Link` y `AdministradorColisiones`, que están en `logica.entidades` (`AdministradorColisiones` va ahí porque llama a ganchos protegidos de `EntidadAnimada`).
- `actualizarEstado(c)` tiene que ser `public` en `EntidadAnimada`, porque `HiloJugador` está en otro paquete.

## 11. Cuidados y errores comunes

| Error | Qué pasa | Cómo se evita |
|---|---|---|
| Actualizar a Link también desde `HiloMundo` | Link se mueve dos veces por vuelta, más rápido que lo previsto | `Link.actualizarPorMundo(c)` vacío |
| Mover a Link desde `procesarTecla` | Trabajo pesado en el EDT: la ventana se traba | El EDT solo anota intenciones `volatile` |
| Iniciar antes de `cargarNivel()` | El hilo corre sin sector o con uno a medio armar | `Juego.iniciar`: crear, cargar, y recién después `iniciar()` |
| Poner el daño en `link.colisionarCon(enemigo)` | Habría dos lugares que deciden el daño | `link.colisionarCon(enemigo)` solo le delega al enemigo; el daño lo decide su estrategia |
| Reusar el mismo `HiloJugador` en una partida nueva | Excepción: un `Thread` terminado no se puede arrancar | Crear uno nuevo en cada `Juego.iniciar` |

## 12. En los diagramas

| Diagrama | Cómo aparece |
|---|---|
| **Reducido** | Hereda de `HiloJuego*`. `Juego ◆ HiloJugador` (`#hiloJugador 1`), `HiloJugador → Link` (`#jugador 1`), `HiloJugador → AdministradorColisiones` (`#colisiones 1`). |
| **Extendido** | `- PERIODO : long = 30` (subrayado, defensa 7), `# jugador : Link`, `# colisiones : AdministradorColisiones`, `+ HiloJugador(l : Link, c : AdministradorColisiones)` y `# ciclo()`. |

**Por qué composición con `Juego`.** `Juego` lo crea, es el único que lo usa y lo descarta al terminar la partida.

**Por qué asociación con Link y no composición.** `HiloJugador` usa a Link pero no es su dueño: Link lo crea la fábrica y lo guarda `Juego`.

## 13. Preguntas que pueden hacer en la defensa

| Pregunta | Respuesta corta |
|---|---|
| ¿Por qué Link tiene un hilo propio? | Para responder al teclado a velocidad pareja, sin depender de cuántos enemigos haya en el sector. |
| ¿Qué hace en cada vuelta? | `jugador.actualizarEstado(colisiones)`: mover, atacar, verificar choques y ejecutar esperas vencidas. |
| ¿Cómo llega una tecla a mover a Link? | El EDT anota la dirección (`volatile`) y `HiloJugador` la usa en su próxima vuelta. |
| ¿Quién resuelve el choque de Link con un enemigo? | La estrategia de ataque del enemigo. Si camina Link, lo detecta `HiloJugador` en `mover` y `link.colisionarCon(enemigo)` le delega al enemigo; si camina el enemigo, lo detecta `HiloMundo`. |
| ¿Por qué no lo mueve también `HiloMundo`? | Porque `Link.actualizarPorMundo` está vacío: Link tiene un solo dueño. |
| ¿Cada cuánto da una vuelta? | Cada 30 ms, unas 33 por segundo. |
| ¿Qué pasa en el cambio de sector? | `Juego` lo pausa mientras se desliza la pantalla y lo reanuda en `transicionTerminada()`. |
| ¿Qué patrón usa? | Template Method (hereda el ciclo de `HiloJuego`), y en la vuelta Strategy y Visitor. |

---

# Explicación de la clase HiloMundo (Defensa 7)

Basado en los diagramas extendido y reducido de la defensa 7 (estrategia `bloqueaPasoA`) y en el código de
`DEFENSA 7 FINAL/Codigo/src/logica/hilos/HiloMundo.java`. Conviene leer antes la sección de `HiloJuego`.

**Lo que cambió en la defensa 7:**

- El período es la constante `PERIODO = 30` y el constructor llama `super(PERIODO)`.
- Con `bloqueaPasoA`, los enemigos **no atraviesan** a Link ni a otros enemigos. Cuando un enemigo camina contra Link,
  el choque lo detecta este hilo en `AdministradorColisiones.mover`, y el daño lo pone la estrategia de ataque del
  enemigo (sección 6).
- Cada vuelta de una entidad termina con `avisarParpadeo()`, para que la vista sepa si tiene que dibujarla o no.


## 1. Qué es

`HiloMundo` es el hilo que actualiza a **todas las entidades del sector visible menos a Link**: enemigos, jefes y proyectiles. Hereda de `HiloJuego*` (patrón Template Method): hereda el ciclo `run()` y redefine el paso `ciclo()`.

Cada 30 ms hace una vuelta: le pide el sector visible a `AdministradorColisiones` y le dice que actualice a sus entidades.

## 2. Por qué existe y por qué es uno solo

| Pregunta | Respuesta |
|---|---|
| ¿Por qué un hilo aparte de `HiloJugador`? | Para que los enemigos se muevan solos, al mismo tiempo que Link, sin que Link tenga que esperarlos. |
| ¿Por qué **uno solo** y no un hilo por enemigo? | En la Defensa 4 cada entidad animada tenía su propio hilo. Con un sector lleno eran decenas de hilos tocando el sector a la vez, difíciles de sincronizar. Un solo hilo que recorre a todos en orden es más simple y seguro: dos enemigos nunca se mueven al mismo tiempo. |
| ¿Por qué solo el sector **visible**? | Lo que no se ve no necesita moverse. Los enemigos de los demás sectores quedan quietos hasta que Link entre. Además ahorra trabajo. |

## 3. Miembros (según el extendido)

### Atributos

| Constante | Valor | Para qué |
|---|---|---|
| `- PERIODO` | `30` (`long`) | Milisegundos entre vueltas, igual que `HiloJugador` (defensa 7) |

| Miembro | Tipo | Para qué | Relación |
|---|---|---|---|
| `# colisiones` | `AdministradorColisiones` | De él sale el sector visible, y se le pasa a cada entidad en su vuelta | `HiloMundo → AdministradorColisiones` (`#colisiones 1`) |

En las correcciones finales `# colisiones` **reemplazó** a `# sector : Sector` (y salió `setSector`). Ver sección 7.

Además hereda de `HiloJuego*`: `hilo`, `activo`, `pausado` y `periodo`.

### Constructor

| Constructor | Qué hace |
|---|---|
| `+ HiloMundo(c : AdministradorColisiones)` | `super(PERIODO)` y guarda `c` en `colisiones`. No arranca el hilo. |

### Comandos

| Método | Qué hace | Quién lo llama |
|---|---|---|
| `# ciclo()` | Toma el sector visible y, si existe, `sector.actualizarEntidades(colisiones)` | `HiloJuego.run()`, en cada vuelta que no está en pausa |

Heredados y usados por `Juego`: `iniciar()`, `pausar()`, `reanudar()`, `detener()`.

## 4. El código

```java
package logica.hilos;

import logica.entidades.AdministradorColisiones;
import logica.mapa.Sector;

public class HiloMundo extends HiloJuego {

    private static final long PERIODO = 30;     // igual que HiloJugador

    protected AdministradorColisiones colisiones;

    public HiloMundo(AdministradorColisiones c) {
        super(PERIODO);
        colisiones = c;
    }

    @Override
    protected void ciclo() {
        Sector sectorVisible = colisiones.getSector();   // se lee una sola vez
        if (sectorVisible != null)
            sectorVisible.actualizarEntidades(colisiones);
    }
}
```

**Por qué la variable `sectorVisible`.** `Juego` puede cambiar el sector (desde otro hilo) en cualquier momento. Si se llamara dos veces a `colisiones.getSector()` (una para preguntar si es `null` y otra para usarlo), entre las dos podría haber cambiado. Leyéndolo una vez, la vuelta entera trabaja sobre el mismo sector.

**Por qué el `if (sectorVisible != null)`.** Antes de que `Juego` active el primer sector, el administrador no tiene sector. Con el control, el hilo simplemente no hace nada en esas vueltas en vez de lanzar un `NullPointerException`. (Con el orden de `Juego.iniciar`, que carga el nivel antes de arrancar los hilos, no debería pasar, pero es barato protegerse.)

## 5. Qué pasa en una vuelta

`ciclo()` delega en `Sector.actualizarEntidades`:

```java
// En Sector
public void actualizarEntidades(AdministradorColisiones c) {    // SIN synchronized
    for (Entidad e : getEntidades())                             // copia de la lista
        if (!e.estaEliminada())
            e.actualizarPorMundo(c);
}
```

`actualizarPorMundo(c)` es un **gancho** de `Entidad*`. Cada tipo de entidad responde distinto, sin `instanceof`:

| Entidad | `actualizarPorMundo(c)` | Resultado |
|---|---|---|
| Fijas (roca, pasto, agua, power-ups…) | Vacío (el de `Entidad*`) | No hacen nada |
| Enemigos, jefes, proyectiles | `actualizarEstado(c)` (lo redefine `EntidadAnimada*`) | Dan su vuelta completa |
| `Link` | Vacío otra vez (lo redefine `Link`) | Nada: a Link lo mueve solo `HiloJugador` |

Y la vuelta de cada entidad animada es la misma que la de Link:

```java
public void actualizarEstado(AdministradorColisiones c) {
    if (!estaEliminada()) {
        vigilarJugador();              // gancho: algunos enemigos miran dónde está Link
        movimiento.mover(this, c);     // Strategy: aleatorio, inducido o teletransporte
        ataque.atacar(this, c);        // Strategy: contacto, espada, proyectil, avalancha…
        if (!estaEliminada())
            c.verificarColisiones(this);   // Visitor
        ejecutarPendientes();          // AccionProgramada vencidas
        avisarParpadeo();              // defensa 7
    }
}
```

```mermaid
sequenceDiagram
    participant HM as HiloMundo
    participant AC as AdministradorColisiones
    participant S as Sector
    participant R as Roca
    participant M as Moblin
    participant L as Link
    HM->>HM: run() → ciclo()
    HM->>AC: getSector()
    AC-->>HM: sector visible
    HM->>S: actualizarEntidades(colisiones)
    S->>S: getEntidades() (copia)
    S->>R: actualizarPorMundo(c)
    Note over R: vacío
    S->>M: actualizarPorMundo(c)
    M->>M: actualizarEstado(c)
    S->>L: actualizarPorMundo(c)
    Note over L: vacío (lo mueve HiloJugador)
    HM->>HM: Thread.sleep(30)
```

**Por qué recorre una copia.** Mientras `HiloMundo` recorre, pueden aparecer o desaparecer entidades: un enemigo muere, un Octorok dispara un proyectil, Link recoge una rupia (desde `HiloJugador`). Si se recorriera la lista original, Java lanzaría `ConcurrentModificationException`. `getEntidades()` devuelve una copia nueva, así que los cambios no afectan al recorrido. Las entidades eliminadas a mitad de camino se saltean con `!e.estaEliminada()`.

## 6. La regla de colisiones (Defensa 7)

> **El daño entre Link y un enemigo lo pone siempre la estrategia de ataque del enemigo.** Desde la defensa 7 Link y los
> enemigos se frenan entre sí (`bloqueaPasoA`), así que el choque aparece cuando uno **no puede dar el paso** contra el otro.

Cuando `HiloMundo` actualiza a un Moblin que camina hacia Link:

```mermaid
sequenceDiagram
    participant HM as HiloMundo
    participant M as Moblin
    participant AC as AdministradorColisiones
    participant L as Link
    participant APC as AtaquePorContacto
    HM->>M: actualizarEstado(c)
    M->>AC: mover(moblin, d, pasos)
    AC->>AC: buscarBloqueo(moblin, d, pasos)
    AC->>L: bloqueaPasoA(moblin)
    L->>M: esFrenadoPorPersonajes()
    M-->>L: true
    L-->>AC: true
    AC->>L: aceptarColision(moblin)
    L->>M: colisionarCon(link)
    M->>APC: ataqueAlContactar(moblin, link)
    APC->>L: recibirDanio(1, direccion)
    Note over L: synchronized
    AC->>M: alChocarConBloqueo()
```

| Paso | Qué pasa |
|---|---|
| 1 | `HiloMundo` actualiza al Moblin. Su movimiento llama `c.mover(moblin, d, pasos)`. |
| 2 | `buscarBloqueo` encuentra a Link en el lugar al que el Moblin quiere ir, y Link responde `bloqueaPasoA(moblin)` con `moblin.esFrenadoPorPersonajes()`: `true`. |
| 3 | El Moblin no avanza. `mover` dispara el Visitor con el que bloquea: `link.aceptarColision(moblin)` → `moblin.colisionarCon(link)`. |
| 4 | El Moblin le delega a su estrategia de ataque: `ataque.ataqueAlContactar(moblin, link)`, que hace `link.recibirDanio(...)`. |
| 5 | `moblin.alChocarConBloqueo()`: el Moblin elige otra dirección. |

**Un solo daño por choque.** Si al mismo tiempo Link camina contra el Moblin, `HiloJugador` también dispara el choque
(`link.colisionarCon(moblin)` → `moblin.colisionarCon(link)`). Pero el primer golpe deja a Link 1 s invulnerable, así que el
segundo aviso no saca vida.

**Si se superponen igual.** Los proyectiles no se frenan contra personajes.
Esas sí llegan a superponerse con Link, y el choque lo encuentra `verificarColisiones` al final de la vuelta, como antes.

**Quién lastima así:** Moblin, MoblinConEspadaYEscudo, ErizoDeMar y TrampaDeCuchillas (`AtaquePorContacto(1)`), StoneHinox al embestir (`AtaquePorContacto(2)`) y MasterStalfos en su fase de contacto.

## 7. Por qué no guarda el sector

Hasta la Defensa 5, `HiloMundo` tenía `# sector : Sector` y un `setSector(s)`. En las correcciones finales eso se cambió por `# colisiones : AdministradorColisiones`:

| Antes | Ahora |
|---|---|
| `HiloMundo → Sector` (`#sector 1`) | `HiloMundo → AdministradorColisiones` (`#colisiones 1`) |
| `Juego` tenía que avisarle a cada hilo el sector nuevo | `Juego` hace `colisiones.setSector(nuevo)` una vez |
| Riesgo de que `HiloJugador` y `HiloMundo` miren sectores distintos | Los dos le preguntan al mismo administrador: ven el sector nuevo a la vez |

El sector visible vive en **un solo lugar** (`AdministradorColisiones.sector`, que es `volatile`).

## 8. Pausa, cambio de sector y recarga del nivel

`HiloMundo` no decide cuándo pausarse: lo decide `Juego`.

| Situación | Qué hace `Juego` con `HiloMundo` |
|---|---|
| Empieza la partida | `new HiloMundo(colisiones)` y, después de `cargarNivel()`, `iniciar()` |
| Link cruza el borde | `pausar()` en `cambiarDeSector(d)`, junto con `HiloJugador` |
| Termina la transición | `reanudar()` en `transicionTerminada()` |
| Link cae al vacío | `pausar()`, `cargarNivel()`, `reanudar()` |
| Jefe derrotado (pasa de nivel) | `pausar()`, `cargarNivel()`, `reanudar()` |
| Termina la partida | `detener()` en `terminarPartida()` |

**Por qué se pausa al recargar el nivel.** Mientras `cargarNivel()` arma los sectores y cambia el sector visible, los enemigos no tienen que moverse sobre un nivel a medio armar.

**Acciones programadas durante la pausa.** Si un enemigo tenía una `AccionProgramada` (por ejemplo, el cambio de fase de MasterStalfos), no se ejecuta mientras el hilo está pausado. Se cumple en la primera vuelta después de reanudar, un poco más tarde de lo pedido. Para un juego no es un problema.

## 9. Sincronización y el abrazo mortal

`HiloMundo` no tiene nada `synchronized`, y **no tiene que tenerlo**. Tampoco `Sector.actualizarEntidades`.

**El abrazo mortal que se evita (guía, sección 22.4).** Si `actualizarEntidades` fuera `synchronized`:

1. `HiloMundo` entra a `actualizarEntidades` y **tiene la llave del sector**. Adentro, un enemigo toca a Link y llama `link.recibirDanio(...)`, que necesita **la llave de Link**.
2. Al mismo tiempo, `HiloJugador` está en `link.recibirDanio(...)` (**tiene la llave de Link**) y adentro Link recoge algo o muere, lo que termina en `sector.quitar(...)`, que necesita **la llave del sector**.
3. Cada hilo espera la llave que tiene el otro. El juego se congela para siempre.

**Las reglas que lo evitan:**

| Regla | Cómo se cumple en `HiloMundo` |
|---|---|
| Orden de llaves: Entidad → `Juego` → `Sector`, nunca al revés | `HiloMundo` no toma ninguna llave antes de llamar a las entidades |
| Nunca ejecutar código de entidades con la llave del sector tomada | `actualizarEntidades` recorre la copia de `getEntidades()` **sin** `synchronized` |
| `AdministradorColisiones` sin métodos `synchronized` | Se recorren copias de la lista |

**Qué sí está protegido** (en otras clases): la lista del sector (`agregar`, `quitar`, `retirar`, `getEntidades` son `synchronized`), la vida y la defensa (`recibirDanio`, `aplicarDanio`), las acciones programadas (`programar`, `sacarVencidas`) y el puntaje (métodos de `Juego`).

## 10. Paquete e imports

```java
package logica.hilos;

import logica.entidades.AdministradorColisiones;
import logica.mapa.Sector;
```

- Va en `logica.hilos`, junto a `HiloJuego` (mismo paquete: no se importa).
- Importa `AdministradorColisiones` (de `logica.entidades`) y `Sector` (de `logica.mapa`), que usa como tipo de la variable `sectorVisible`.
- `getSector()` de `AdministradorColisiones` y `actualizarEntidades(c)` de `Sector` tienen que ser `public`, porque están en otros paquetes.

## 11. Cuidados y errores comunes

| Error | Qué pasa | Cómo se evita |
|---|---|---|
| Hacer `actualizarEntidades` `synchronized` | Abrazo mortal con `HiloJugador` | Recorrer una copia, sin `synchronized` |
| Recorrer la lista original del sector | `ConcurrentModificationException` cuando muere o aparece una entidad | `getEntidades()` devuelve una copia |
| No redefinir `Link.actualizarPorMundo` como vacío | Link se mueve dos veces por vuelta | Gancho vacío en Link |
| Llamar dos veces a `colisiones.getSector()` en la vuelta | Puede devolver sectores distintos si `Juego` lo cambió en el medio | Leerlo una vez en `sectorVisible` |
| Poner el daño en `link.colisionarCon(enemigo)` | Dos lugares que deciden el daño | El daño lo pone solo la estrategia del enemigo; `link.colisionarCon(enemigo)` le delega |
| Un hilo por enemigo | Decenas de hilos, carreras, diagrama que no coincide | Un solo `HiloMundo` |

## 12. En los diagramas

| Diagrama | Cómo aparece |
|---|---|
| **Reducido** | Hereda de `HiloJuego*`. `Juego ◆ HiloMundo` (`#hiloMundo 1`), `HiloMundo → AdministradorColisiones` (`#colisiones 1`). |
| **Extendido** | `- PERIODO : long = 30` (subrayado, defensa 7), `# colisiones : AdministradorColisiones`, `+ HiloMundo(c : AdministradorColisiones)` y `# ciclo()`. |

**Por qué composición con `Juego`.** `Juego` lo crea, es el único que lo usa y lo descarta al terminar la partida.

**Por qué no hay flecha a `Sector`.** Desde las correcciones finales, `HiloMundo` llega al sector a través de `AdministradorColisiones` (que sí tiene `→ Sector`, `#sector 1`). Usar `Sector` como tipo de una variable local no se dibuja.

## 13. Preguntas que pueden hacer en la defensa

| Pregunta | Respuesta corta |
|---|---|
| ¿Qué actualiza `HiloMundo`? | Todas las entidades del sector visible menos Link. |
| ¿Por qué un solo hilo para todos los enemigos? | Menos hilos, ningún par de enemigos moviéndose a la vez, más fácil de sincronizar. |
| ¿Cómo sabe qué entidades se mueven, sin `instanceof`? | Con el gancho `actualizarPorMundo`: vacío en las fijas y en Link, `actualizarEstado` en las animadas. |
| ¿Quién resuelve el choque de Link con un enemigo? | La estrategia de ataque del enemigo (`ataqueAlContactar`). Si camina el enemigo, el choque lo detecta `HiloMundo` en `mover`, porque Link le bloquea el paso. |
| ¿Por qué no guarda el sector? | Lo guarda `AdministradorColisiones`, así los dos hilos ven el mismo sector sin avisarles a cada uno. |
| ¿Por qué `actualizarEntidades` no es `synchronized`? | Para no tener la llave del sector mientras las entidades piden otras llaves: evitaría un abrazo mortal. |
| ¿Qué pasa con los enemigos de otros sectores? | Quedan quietos hasta que Link entre. |
| ¿Cuándo se pausa? | En el cambio de sector, cuando Link cae al vacío y al pasar de nivel. |

---

# Explicación de la clase Reloj (Defensa 7)

Basado en los diagramas extendido y reducido de la defensa 7 (estrategia `bloqueaPasoA`), en el cambio 17 de
`Cambios-desde-defensa-6.md` y en el código de `DEFENSA 7 FINAL/Codigo/src/logica/hilos/Reloj.java` y `OyenteReloj.java`.
Conviene leer antes la sección de `HiloJuego`.

**Lo que cambió en la defensa 7 (devolución del ayudante):**

- El reloj **ya no conoce a `Juego`**. Guarda un `# oyente : OyenteReloj`, una interfaz nueva de **un solo método**,
  `tic(segundos : int)`, que `Juego` implementa. El constructor pasó a ser `Reloj(o : OyenteReloj)`.
- Se cortó la dependencia entre paquetes `logica.hilos` → `logica.juego`: `OyenteReloj` está en `logica.hilos`, junto
  al reloj.
- El período es la constante `PERIODO = 1000`.
- `Juego.terminarPartida()` ya no usa `reloj.estaActivo()` para saber si la partida terminó: usa `partidaEnCurso`.
- `Juego.getTiempo()` se borró (no lo usaba nadie).


## 1. Qué es

`Reloj` es el hilo que **cuenta el tiempo de la partida**. Hereda de `HiloJuego*` (patrón Template Method): hereda el ciclo `run()` y redefine el paso `ciclo()`.

Da **una vuelta por segundo** (`super(PERIODO)`, con `PERIODO = 1000`). En cada vuelta suma un segundo y le avisa a su oyente con `oyente.tic(segundos)`. El oyente es `Juego`, pero el reloj solo lo ve como `OyenteReloj`. Lo que pasa con ese aviso (mostrar el tiempo, descontar en Contrarreloj, terminar la partida) lo decide `Juego` y el modo de juego, no el reloj.

Es el tercer hilo de la lógica, junto a `HiloJugador` (Link) y `HiloMundo` (el resto de las entidades).

## 2. De Timer a Reloj

Hasta la Defensa 4 la clase se llamaba `Timer` y tenía su propio ciclo. En la Defensa 5 pasó a llamarse `Reloj` y a heredar de `HiloJuego*`.

| | `Timer` (Defensa 4) | `Reloj` (Defensa 5 y 6) | `Reloj` (Defensa 7) |
|---|---|---|---|
| Nombre | `Timer` | `Reloj` | `Reloj` |
| Herencia | Ninguna (implementaba `Runnable`) | Hereda de `HiloJuego*` | Hereda de `HiloJuego*` |
| `# activo`, `iniciar()`, `detener()`, `run()`, `estaActivo()` | Propios | **Heredados** de `HiloJuego*` | Heredados |
| A quién avisa | — | `# juego : Juego` | **`# oyente : OyenteReloj`** |
| Lo que queda propio | — | `# segundos`, `# juego`, el constructor, `reiniciar()`, `ciclo()` y `getSegundos()` | `PERIODO`, `# segundos`, `# oyente`, el constructor, `reiniciar()`, `ciclo()` y `getSegundos()` |

**Por qué el cambio de nombre.** El enunciado **prohíbe usar timers** para los movimientos. La clase nunca fue `javax.swing.Timer` ni `java.util.Timer` (siempre fue un `Thread` que duerme), pero el nombre invitaba a la pregunta en la defensa. `Reloj` dice lo mismo sin confusión.

**Por qué heredar de `HiloJuego`.** El ciclo "repetir, hacer una vuelta, dormir" era igual al de los otros hilos. Ahora está escrito una sola vez.

### Por qué `OyenteReloj` (defensa 7)

El ayudante preguntó **qué necesita el reloj de `Juego`**. La respuesta es: solo `tic(int)`. Pero con `# juego : Juego` el
reloj podía llamar a cualquier método público de `Juego` (`terminarPartida()`, `iniciar(...)`, …). Es el **principio de
segregación de interfaces**: un cliente no debería depender de métodos que no usa.

```java
package logica.hilos;

public interface OyenteReloj {
    public void tic(int segundos);
}
```

| Qué se gana | Por qué |
|---|---|
| El compilador impide el mal uso | El reloj solo ve `tic`; no puede terminar la partida ni tocar los hilos |
| Menos acoplamiento | Si cambia un método de `Juego` que no está en la interfaz, el reloj no se entera |
| Se corta un ciclo entre paquetes | Antes `hilos.Reloj` importaba `juego.Juego` y `Juego` importaba `Reloj`. Ahora el reloj no conoce el paquete `juego` |
| Reutilizable y fácil de probar | Sirve para cualquiera que quiera un aviso por segundo; se prueba sin armar un `Juego` |
| El diagrama muestra qué necesita | La flecha va a una interfaz de un método y no a la clase más grande del sistema |

Es la misma idea que ya usábamos con la vista, que ve `ControladorJuego` y no `Juego`. Con `OyenteReloj` se hace
con el **patrón Observer** de forma explícita: el reloj es el sujeto y `Juego` el oyente.

## 3. Miembros (según el extendido)

### Atributos

| Miembro | Tipo | Para qué | Relación |
|---|---|---|---|
| `- PERIODO` | `long` (constante, 1000) | Milisegundos entre vueltas (defensa 7) | — |
| `# segundos` | `int` (`volatile`) | Segundos transcurridos de la partida | — |
| `# oyente` | `OyenteReloj` | A quién avisarle cada segundo (defensa 7) | `Reloj → OyenteReloj` (`#oyente 1`) |

Además hereda de `HiloJuego*`: `hilo`, `activo`, `pausado` y `periodo` (que vale 1000).

### Constructor

| Constructor | Qué hace |
|---|---|
| `+ Reloj(o : OyenteReloj)` | `super(PERIODO)`, guarda `o` en `oyente` y empieza en 0 segundos. No arranca el hilo. |

### Comandos

| Método | Qué hace | Quién lo llama |
|---|---|---|
| `+ reiniciar()` | `segundos = 0`, sin detener el hilo | No está fijado en la guía (ver sección 10) |
| `# ciclo()` | `segundos++` y `oyente.tic(segundos)` | `HiloJuego.run()`, una vez por segundo |

Heredados y usados por `Juego`: `iniciar()` y `detener()`. Desde la defensa 7 `Juego` ya no usa `estaActivo()`.

### Consultas

| Método | Qué devuelve | Quién la usa |
|---|---|---|
| `+ getSegundos() : int` | Los segundos transcurridos | Nadie por ahora (`Juego.getTiempo()` se borró en la defensa 7). Queda en el extendido como consulta del reloj |

## 4. El código, método por método

```java
package logica.hilos;

public class Reloj extends HiloJuego {

    private static final long PERIODO = 1000;   // una vuelta por segundo

    protected volatile int segundos;
    protected OyenteReloj oyente;

    public Reloj(OyenteReloj o) {
        super(PERIODO);
        oyente = o;
        segundos = 0;
    }

    public void reiniciar() {
        segundos = 0;
    }

    @Override
    protected void ciclo() {
        segundos++;
        oyente.tic(segundos);
    }

    public int getSegundos() {
        return segundos;
    }
}
```

No tiene ningún `import`: `OyenteReloj` y `HiloJuego` están en el mismo paquete.

(La versión del `.java` tiene además todo el javadoc.)

### El constructor

- **`super(PERIODO)`** le pasa el período a `HiloJuego`: el hilo dormirá 1000 ms entre vueltas. Tiene que ser la primera línea.
- **`segundos = 0`**: Java ya lo inicializa en 0, pero escribirlo deja claro desde dónde cuenta.
- **No arranca el hilo.** `Juego` lo crea en `iniciar`, carga el nivel y recién después llama `reloj.iniciar()`.

### `ciclo()`

1. **`segundos++`**: pasó un segundo más.
2. **`oyente.tic(segundos)`**: le avisa al oyente (`Juego`) con el valor nuevo.

El orden importa: primero se suma y después se avisa, así el primer `tic` es `tic(1)` (pasó el primer segundo), no `tic(0)`.

El reloj **no sabe nada** de la vista ni de los modos de juego. Solo cuenta y avisa. Eso deja la lógica de qué hacer con el tiempo en un solo lugar (`Juego` y `ModoJuego`).

### `reiniciar()`

Vuelve la cuenta a 0 sin detener el hilo. El hilo sigue durmiendo y sumando: el próximo `tic` será `tic(1)`.

### `getSegundos()`

Devuelve los segundos transcurridos. En la defensa 6 la usaba `Juego.getTiempo()`, que se borró porque nadie la llamaba. La vista recibe el tiempo por `tic`, no preguntándolo.

**Sobre la precisión.** El reloj no es exacto al milisegundo: entre vuelta y vuelta pasan 1000 ms de `sleep` **más** lo que tarde `oyente.tic(...)`. En una partida de varios minutos el desvío es de unos pocos milisegundos por segundo, que para un juego no importa.

## 5. Qué pasa en cada segundo

```java
// En Juego (implementa OyenteReloj)
@Override
public synchronized void tic(int segundos) {
    controladorGrafico.actualizarTiempo(segundos);   // el HUD muestra el tiempo
    modoJuego.alPasarTiempo(this, segundos);          // this como ArbitroPartida
}

// En GUI (la vista)
public void actualizarTiempo(int segundos) {
    SwingUtilities.invokeLater(() -> panelNivel.actualizarTiempo(segundos));
}
```

Diagrama de secuencia de un segundo en Contrarreloj:

```mermaid
sequenceDiagram
    participant RL as Reloj
    participant J as Juego (OyenteReloj / ArbitroPartida)
    participant G as GUI
    participant CR as Contrarreloj
    RL->>RL: run() → ciclo()
    RL->>RL: segundos++
    RL->>J: tic(segundos)
    J->>G: actualizarTiempo(segundos)
    Note over G: invokeLater → el EDT actualiza el HUD
    J->>CR: alPasarTiempo(this, segundos)
    CR->>CR: tiempoRestante--
    alt tiempoRestante llega a 0
        CR->>J: terminarPartida()
        J->>J: partidaEnCurso = false
        J->>RL: detener()
    end
    RL->>RL: Thread.sleep(1000)
```

| Paso | Hilo | Qué pasa |
|---|---|---|
| 1 | `Reloj` | `ciclo()`: `segundos++` y `oyente.tic(segundos)` |
| 2 | `Reloj` | `Juego.tic` le pasa los segundos a la vista |
| 3 | EDT | `invokeLater` hace que el cambio del `JLabel` del HUD lo haga el hilo de Swing |
| 4 | `Reloj` | `Juego.tic` le avisa al modo con `alPasarTiempo` |
| 5 | `Reloj` | En Contrarreloj, si se acabó el tiempo, `terminarPartida()` (a través de `ArbitroPartida`) |

La secuencia completa, dibujada desde el diagrama, está en `imagenes-cambio-17/secuencia-contrarreloj.png`.

**Por qué `invokeLater`.** Swing solo se puede tocar desde su propio hilo (el EDT). `Reloj` no es el EDT, así que no puede cambiar el `JLabel` directamente: le deja el cambio anotado a Swing.

## 6. El reloj y los modos de juego

El reloj avisa **igual** en los tres modos. Cada modo decide qué hacer con el aviso, sin `instanceof` (es un gancho de `ModoJuego*`):

| Modo | `alPasarTiempo(a, segundos)` | Efecto del reloj |
|---|---|---|
| `Clasico` | Vacío (el de `ModoJuego*`) | Solo se muestra el tiempo |
| `NoHit` | Vacío | Solo se muestra el tiempo |
| `Contrarreloj` | `tiempoRestante--` y, si llega a 0, `a.terminarPartida()` | El tiempo puede terminar la partida |

```java
// En Contrarreloj
public void alIniciarNivel() { tiempoRestante = tiempoLimite; }

public void alPasarTiempo(ArbitroPartida a, int segundos) {   // defensa 7: ArbitroPartida, no Juego
    tiempoRestante--;
    if (tiempoRestante <= 0) {
        a.terminarPartida();
    }
}
```

**El reloj no cuenta hacia atrás.** Siempre cuenta segundos **transcurridos**. La cuenta regresiva de Contrarreloj la lleva el modo (`tiempoRestante`), y se reinicia al empezar cada nivel con `alIniciarNivel()`.

## 7. Ciclo de vida en la partida

| Momento | Qué hace `Juego` con el reloj |
|---|---|
| Empieza la partida | `reloj = new Reloj(this)` y, después de `cargarNivel()`, `reloj.iniciar()` |
| Cambio de sector | **Nada**: el reloj no se pausa, el tiempo sigue corriendo durante la transición |
| Link cae al vacío o pasa de nivel | Nada: solo se pausa `HiloMundo` |
| Termina la partida | `terminarPartida()` pregunta `partidaEnCurso` y llama `reloj.detener()` |
| Partida nueva | Se crea un `Reloj` nuevo (un `Thread` terminado no se puede volver a arrancar) |

```java
@Override
public synchronized void terminarPartida() {
    if (partidaEnCurso) {              // defensa 7: el estado de la partida, no el del reloj
        partidaEnCurso = false;
        reloj.detener();
        hiloJugador.detener();
        hiloMundo.detener();
        controladorGrafico.terminarControl();   // cambio 51
        ...
    }
}
```

**La partida tiene su propia bandera (defensa 7).** En la defensa 6 `terminarPartida()` usaba `reloj.estaActivo()` para
saber si la partida ya había terminado. El ayudante preguntó: ¿si se pausa el reloj, terminó la partida? Funcionaba de
casualidad, porque `pausar()` cambia `pausado` y no `activo`, pero dependía de un detalle de un **hilo** para responder
algo de la **partida**. Y si se llamaba antes de `iniciar()`, `reloj` era `null`.

Ahora `Juego` tiene `# partidaEnCurso : boolean`. Sigue cubriendo el caso de dos avisos casi a la vez (por ejemplo, en
Contrarreloj se acaba el tiempo en el mismo momento en que Link pierde la última vida): como el método es `synchronized`,
el primero pone `partidaEnCurso = false` y el segundo no hace nada. Así no se pide el nombre dos veces ni se guarda el
ranking dos veces (ver `imagenes-cambio-17/secuencia-dos-avisos.png`).

**Un detalle.** En Contrarreloj, `terminarPartida()` se llama **desde el propio hilo del reloj** (dentro de `ciclo()` → `tic` → `alPasarTiempo`). `reloj.detener()` pone `activo = false`, la vuelta termina normalmente, el reloj duerme su segundo y el `while` de `run()` sale. No hay problema en que un hilo se detenga a sí mismo así.

## 8. Hilos y sincronización

| Dato | Quién lo escribe | Quién lo lee | Protección |
|---|---|---|---|
| `segundos` | `Reloj` (`ciclo`), quien llame `reiniciar()` | `getSegundos()` desde otros hilos | `volatile` |
| `activo` (heredado) | `Juego.terminarPartida()` | `run()` del reloj | `volatile` (en `HiloJuego`) |
| `partidaEnCurso` (de `Juego`) | `Juego.iniciar` y `terminarPartida` | `terminarPartida` | `synchronized` en `terminarPartida` |
| Estado de la partida | `Reloj` vía `tic`, `HiloJugador` y `HiloMundo` vía otros avisos | — | `synchronized` en `Juego.tic`, `terminarPartida`, etc. |
| HUD | Solo el EDT | — | `SwingUtilities.invokeLater` |

**Por qué `segundos` es `volatile`.** Lo escribe el hilo del reloj y lo leen otros hilos con `getSegundos()`. Sin `volatile`, Java permite que el que lee vea un valor viejo.`volatile` no se dibuja en el diagrama.

**Por qué `segundos++` no necesita `synchronized`.** `++` no es atómico (lee, suma y escribe), pero **solo el hilo del reloj** lo hace. No hay dos hilos sumando a la vez.

**Por qué `Juego.tic` es `synchronized`.** Porque puede cambiar el estado de la partida (terminarla en Contrarreloj) al mismo tiempo que `HiloJugador` o `HiloMundo` avisan otras cosas (daño, enemigo derrotado). La llave de `Juego` los pone en fila. Respeta el orden de llaves de la guía (Entidad → `Juego` → `Sector`): el reloj no tiene ninguna llave cuando pide la de `Juego`.

## 9. Paquete e imports

```java
package logica.hilos;

```

- Va en `logica.hilos`, junto a `HiloJuego`, `OyenteReloj`, `HiloJugador`, `HiloMundo` y `AccionProgramada`.
- **Defensa 7: no importa nada.** Antes importaba `logica.juego.Juego`; ahora usa `OyenteReloj`, del mismo paquete.
- `Juego` importa `logica.hilos.OyenteReloj` para implementarla, y `tic(segundos)` es `public` porque es un método de interfaz.

## 10. Decisiones abiertas

La guía deja algunas cosas para que el equipo decida (sección 24):

| Tema | Opciones | Propuesta de la guía | Qué hace esta implementación |
|---|---|---|---|
| Reloj durante la transición | Corre o se pausa | Corre | Corre: `Juego` no lo pausa |
| Tiempo en Contrarreloj | Mostrar transcurrido o restante | Restante, con una consulta común en `ModoJuego` (hay que dibujarla) | El reloj manda transcurrido; el cambio iría en `ModoJuego`/`Juego`, no en `Reloj` |
| Quién llama `reiniciar()` | No está fijado | — | Queda disponible, sin uso inventado |
| Quién usa `getSegundos()` | `Juego.getTiempo()` se borró en la defensa 7 | — | Queda como consulta del reloj |

## 11. Cuidados y errores comunes

| Error | Qué pasa | Cómo se evita |
|---|---|---|
| Usar `javax.swing.Timer` o `java.util.Timer` | El enunciado lo prohíbe | `Reloj` es un `HiloJuego` con `sleep(1000)` |
| Avisar antes de sumar | El primer aviso sería `tic(0)` | `segundos++` y después `oyente.tic(segundos)` |
| Cambiar el HUD directamente desde el reloj | Swing desde otro hilo: errores raros al dibujar | `GUI.actualizarTiempo` usa `invokeLater` |
| Poner la lógica de Contrarreloj en el reloj | El reloj tendría que saber en qué modo está (`instanceof`) | El gancho `alPasarTiempo` de `ModoJuego` |
| Terminar la partida dos veces | Se pide el nombre o se guarda el ranking dos veces | `terminarPartida()` solo hace algo si `partidaEnCurso` (defensa 7) |
| Guardar `Juego` en el reloj | El reloj podría llamar cualquier método de `Juego` | Guardar un `OyenteReloj` (defensa 7) |
| Reusar el mismo `Reloj` en una partida nueva | Excepción al arrancar un `Thread` terminado | Crear uno nuevo en cada `Juego.iniciar` |

## 12. En los diagramas

| Diagrama | Cómo aparece |
|---|---|
| **Reducido** | `Reloj` hereda de `HiloJuego*`. `Juego ◆ Reloj` (`#reloj 1`) y, desde la defensa 7, `Reloj → OyenteReloj` (`#oyente 1`). `Juego` realiza `<<Interface>> OyenteReloj` (línea punteada). |
| **Extendido** | `- PERIODO : long = 1000` (subrayado), `# segundos : int`, `# oyente : OyenteReloj`, `+ Reloj(o : OyenteReloj)`, `+ reiniciar()`, `# ciclo()` y `+ getSegundos() : int`. La interfaz `OyenteReloj` aparece debajo de `Juego`, con `+ tic(segundos : int)`. |

**Por qué composición `Juego ◆ Reloj`.** `Juego` lo crea, es el único que lo maneja y lo descarta al terminar la partida.

**Por qué `Reloj → OyenteReloj` y no `Reloj → Juego`.** El reloj necesita a quién avisarle cada segundo, pero solo para llamar `tic`. La flecha va a la interfaz chica: el reloj **conoce** un oyente y no sabe que es `Juego`.

## 13. Preguntas que pueden hacer en la defensa

| Pregunta | Respuesta corta |
|---|---|
| ¿Usan timers? | No. `Reloj` es un hilo propio (hereda de `HiloJuego`) que duerme 1000 ms. Se renombró de `Timer` para evitar la confusión. |
| ¿Qué hace en cada vuelta? | `segundos++` y `oyente.tic(segundos)`. |
| ¿Cómo termina la partida en Contrarreloj? | `Juego.tic` llama `alPasarTiempo` del modo; Contrarreloj descuenta y, al llegar a 0, llama `terminarPartida()`. |
| ¿Por qué el reloj no sabe del modo? | Para no usar `instanceof`: el reloj avisa igual siempre y cada modo decide con su gancho. |
| ¿Se pausa en la transición? | No: el tiempo de la partida sigue corriendo. |
| ¿Cómo actualiza el HUD si no es el hilo de Swing? | `GUI.actualizarTiempo` usa `SwingUtilities.invokeLater`. |
| ¿Por qué `Juego.tic` es `synchronized`? | Porque puede terminar la partida al mismo tiempo que otros hilos avisan daño o puntos. |
| ¿Qué relación tiene con `Juego`? | Composición desde `Juego` (`#reloj 1`). Hacia el otro lado no ve a `Juego`: tiene un `OyenteReloj` (`#oyente 1`), que `Juego` implementa. |
| ¿Qué necesita el reloj de `Juego`? | Solo `tic(int)`. Por eso recibe un `OyenteReloj`, una interfaz de un método (segregación de interfaces). |
| ¿Cómo sabe `Juego` si la partida terminó? | Con su atributo `partidaEnCurso`, no con `reloj.estaActivo()`: pausar o detener el reloj no es terminar la partida. |
| ¿Qué patrón usa? | Template Method: hereda el ciclo de `HiloJuego` y solo redefine `ciclo()`. |

---

*Integrante 4 · logica.juego*

# Explicación de la clase Juego (Defensa 7)

Basado en los diagramas extendido y reducido de la defensa 7 (estrategia `bloqueaPasoA`), en el cambio 17 de
`Cambios-desde-defensa-6.md` y en el código de `DEFENSA 7 FINAL/Codigo/src/logica/juego/Juego.java`.

**Lo que cambió en la defensa 7 (devolución del ayudante):**

- `Juego` implementa **cuatro interfaces chicas nuevas**, una por cada tipo de colaborador:
  `OyenteReloj` (el reloj), `ArbitroPartida` y `TablaRankings` (los modos) y `EntornoJuego` (la fábrica y las
  entidades). **Ningún colaborador tiene una referencia de tipo `Juego`**: solo `Principal`, que lo crea.
- `getJugador()` devuelve **`Entidad`** y no `Link`: así nadie puede hacer `getJugador().sumarPuntos(...)` desde afuera.
- Se borraron `getNumeroNivel()` y `getTiempo()`, que no usaba nadie.
- `terminarPartida()` usa su propio atributo **`partidaEnCurso`** en lugar de `reloj.estaActivo()`.
- Los métodos que vienen de una interfaz llevan `@Override`, y el 4 de la bellota es la constante `RACHA_PARA_BELLOTA`.
- Cada ranking guarda **un solo puntaje por nombre** (`Ranking.insertar`, cambio 15.2).


## 1. Qué es

`Juego` es el **árbitro de la partida**. Realiza cinco interfaces, y cada colaborador lo ve solo a través de la suya:

```java
public class Juego implements ControladorJuego, OyenteReloj, ArbitroPartida, TablaRankings, EntornoJuego {
```

| Interfaz | Paquete | Métodos | Quién lo ve así |
|---|---|---|---|
| `ControladorJuego` | `logica` | `iniciar`, `registrarNombre`, `transicionTerminada`, `getRanking`, `getControlJugador` | La vista (`GUI`, `AnimadorTransicion`) |
| `OyenteReloj` | `logica.hilos` | `tic(segundos)` | `Reloj` |
| `ArbitroPartida` | `logica.juego` | `terminarPartida()` | Los modos, en `alRecibirDanio` y `alPasarTiempo` |
| `TablaRankings` | `logica.juego` | `agregarAlRankingClasico/Contrarreloj/NoHit(e)` y `getRankingClasico/Contrarreloj/NoHit()` | Los modos, en `registrarPuntaje` y `getRanking` |
| `EntornoJuego` | `logica.entidades` | `agregarEntidad`, `cambiarDeSector`, `enemigoDerrotado(e) : boolean`, `jefeDerrotado`, `powerUpRecogido`, `jugadorDaniado`, `jugadorSinVidas`, `jugadorCayoAlVacio`, `getFabricaEntidades()`, `getJugador() : Entidad` | `FabricaEntidades` y todas las entidades (`Entidad.miJuego`) |

**Por qué interfaces chicas (defensa 7).** Es el **principio de segregación de interfaces**: un cliente no debería
depender de métodos que no usa. Antes `new Reloj(this)`, `new FabricaEntidades(this, …)` o `modoJuego.alRecibirDanio(this)`
recibían el `Juego` entero y podían llamar a cualquier método público. Ahora:

- **El compilador impide el mal uso.** El reloj no puede llamar a `terminarPartida()`; un modo no puede tocar los hilos.
- **Menos acoplamiento.** Si cambia un método de `Juego` que no está en una interfaz, no afecta a ningún colaborador.
- **Se cortan dependencias entre paquetes.** `logica.hilos.Reloj` y `logica.entidades.Entidad` ya no importan
  `logica.juego.Juego`.
- **El diagrama muestra qué necesita cada uno**: las flechas van a interfaces chicas y no a la clase más grande.

| Responsabilidad | Métodos |
|---|---|
| Armar una partida | `iniciar` |
| Cargar niveles y activar sectores | `cargarNivel`, `activarSector`, `cambiarDeSector`, `transicionTerminada` |
| Recibir los avisos de las entidades | `enemigoDerrotado`, `jefeDerrotado`, `powerUpRecogido`, `jugadorDaniado`, `jugadorSinVidas`, `jugadorCayoAlVacio`, `agregarEntidad` |
| Manejar los hilos | Crea, arranca, pausa, reanuda y detiene `Reloj`, `HiloJugador` e `HiloMundo` |
| Contar el tiempo | `tic` (lo llama el reloj, como `OyenteReloj`) |
| Terminar la partida y guardar el ranking | `terminarPartida`, `registrarNombre`, `agregarAlRanking...` |

**Lo que Juego no hace** (desde las correcciones de la Defensa 4): no recibe las teclas. Las siete acciones del jugador (`mover`, `atacar`, `usarEscudo`…) son de Link, a través de `ControlJugador`. Juego solo devuelve a Link con `getControlJugador()`.

## 2. Relaciones

| Relación | Tipo | Rol | Por qué ese tipo |
|---|---|---|---|
| `Juego ··▷ ControladorJuego` | Realización | — | La vista solo conoce la interfaz |
| `Juego ··▷ OyenteReloj`, `ArbitroPartida`, `TablaRankings`, `EntornoJuego` | Realización | — | **Defensa 7.** Cada colaborador ve solo su interfaz. El `Reloj` apunta a `OyenteReloj` (`#oyente 1`), `Entidad*` a `EntornoJuego` (`#miJuego 1`) y `FabricaEntidades` a `EntornoJuego` (`#entorno 1`) |
| `Juego → ControladorGrafico` | Asociación | `#controladorGrafico 1` | La lógica le avisa a la vista sin conocer Swing |
| `Juego → Link` | Asociación | `#jugador 1` | Lo crea la fábrica. `Juego` sí lo guarda como `Link`, porque necesita `sumarPuntos`, `getRacha`, etc. |
| `Juego ◇ Nivel` | Agregación | `#nivel 1` | Se reemplaza en cada `cargarNivel` |
| `Juego ◇ ModoJuego` | Agregación | `#modoJuego 1` | Lo crea la vista y lo pasa en `iniciar` |
| `Juego ◆ Ranking` | Composición | `#rankings 3` | Los crea y es su único dueño |
| `Juego ◆ Reloj`, `◆ HiloJugador`, `◆ HiloMundo` | Composición | `#reloj 1`, `#hiloJugador 1`, `#hiloMundo 1` | Los crea en `iniciar` y los descarta al terminar |
| `Juego ◆ AdministradorColisiones` | Composición | `#colisiones 1` | Lo crea en el constructor y vive con él |
| `Juego → GeneradorNivel` | Asociación | `#generadorNivel 1` | Arma los niveles |
| `Juego → FabricaEntidades` | Asociación | `#fabricaEntidades 1` | Crea entidades con el dominio elegido |
| `Juego → PersistenciaRanking` | Asociación | `#persistencia 1` | Lee y guarda los rankings |

## 3. Atributos

| Atributo | Tipo | Se crea en | Para qué |
|---|---|---|---|
| `# controladorGrafico` | `ControladorGrafico` | Constructor (parámetro) | Avisarle a la vista |
| `# jugador` | `Link` | `iniciar` | El personaje |
| `# nivel` | `Nivel` | `cargarNivel` | El nivel que se juega |
| `# numeroNivel` | `int` | `iniciar` (1) | Qué nivel cargar |
| `# modoJuego` | `ModoJuego` | `iniciar` (parámetro) | Las reglas del modo |
| `# rankings` | `Ranking[3]` | Constructor | 0 Clásico, 1 Contrarreloj, 2 NoHit |
| `# reloj` | `Reloj` | `iniciar` | Cuenta los segundos |
| `# hiloJugador` | `HiloJugador` | `iniciar` | Mueve a Link |
| `# hiloMundo` | `HiloMundo` | `iniciar` | Mueve el resto del sector visible |
| `# colisiones` | `AdministradorColisiones` | Constructor | Guarda el sector visible; lo comparten los dos hilos |
| `# generadorNivel` | `GeneradorNivel` | Constructor | Lee los `nivel<n>.txt` |
| `# fabricaEntidades` | `FabricaEntidades` | `iniciar` | Crea entidades con los sprites del dominio |
| `# persistencia` | `PersistenciaRanking` | Constructor | Archivos `ranking0.txt`, `ranking1.txt`, `ranking2.txt` |
| `# partidaEnCurso` | `boolean` | `iniciar` (`true`) | **Defensa 7.** Si la partida sigue; lo apaga `terminarPartida` |
| `- RACHA_PARA_BELLOTA` | `int` (constante, 4) | — | **Defensa 7.** Enemigos seguidos sin daño para que aparezca la bellota |

**Qué vive siempre y qué vive por partida.** Lo del constructor (colisiones, generador, persistencia, rankings) dura toda la ejecución del programa. Lo de `iniciar` (Link, fábrica, hilos, modo) se crea de nuevo en cada partida.

## 4. Constructor

```java
public Juego(ControladorGrafico vista) {
    controladorGrafico = vista;
    colisiones = new AdministradorColisiones();
    generadorNivel = new GeneradorNivel("/Recursos/Niveles/");
    persistencia = new PersistenciaRanking();
    rankings = new Ranking[3];
    for (int indiceRanking = 0; indiceRanking < rankings.length; indiceRanking++)
        rankings[indiceRanking] = persistencia.cargar("ranking" + indiceRanking + ".txt");
}
```

- Lo crea `Principal` (el `main`), junto con la vista.
- **No arranca ninguna partida**: eso lo hace `iniciar`, cuando el jugador elige un modo en el menú.
- Carga los tres rankings desde sus archivos. Si un archivo no existe, `PersistenciaRanking.cargar` devuelve un ranking vacío.
- Los nombres de archivo salen del índice (`"ranking" + 0 + ".txt"`).

## 5. Lo que pide la vista (ControladorJuego)

| Método | Lo llama | Qué hace |
|---|---|---|
| `iniciar(modo, dominio)` | `GUI`, al elegir modo y dominio | Arma la partida (sección 6) |
| `registrarNombre(nombre)` | `GUI`, después de `pedirNombre` | Guarda el puntaje en el ranking del modo y lo muestra |
| `transicionTerminada()` | `AnimadorTransicion` | Termina el cambio de sector (sección 8) |
| `getRanking(m)` | `GUI` | El ranking del modo, sin `instanceof` |
| `getControlJugador()` | `GUI` | Link como `ControlJugador`, para las teclas |

```java
public void registrarNombre(String nombre) {
    EntradaRanking entradaNueva = new EntradaRanking(nombre, jugador.getPuntaje());
    modoJuego.registrarPuntaje(this, entradaNueva);          // this como TablaRankings
    controladorGrafico.mostrarRanking(getRanking(modoJuego), modoJuego.getNombre());
}
```

**Sin `instanceof`.** Juego no pregunta "¿el modo es Clásico?". Le pide al modo que registre el puntaje (`registrarPuntaje`), y cada modo llama al método de la `TablaRankings` que le corresponde (`agregarAlRankingClasico`, etc.). Lo mismo con `getRanking(m)`: le pregunta al modo cuál es su ranking. Es un doble despacho, y desde la defensa 7 el modo recibe `this` como `TablaRankings`, no como `Juego`:

```java
// NoHit
@Override
public void registrarPuntaje(TablaRankings t, EntradaRanking e) {
    t.agregarAlRankingNoHit(e);
}

@Override
public Ranking getRanking(TablaRankings t) {
    return t.getRankingNoHit();
}
```

La secuencia completa está en `imagenes-cambio-17/secuencia-ranking.png`.

## 6. Empezar una partida

```java
public void iniciar(ModoJuego modo, FabricaSprites dominio) {
    modoJuego = modo;
    numeroNivel = 1;
    fabricaEntidades = new FabricaEntidades(this, dominio);   // this como EntornoJuego
    jugador = fabricaEntidades.crearLink(0, 0);       // la posición real la pone cargarNivel
    reloj = new Reloj(this);                           // this como OyenteReloj
    hiloJugador = new HiloJugador(jugador, colisiones);
    hiloMundo = new HiloMundo(colisiones);
    cargarNivel();                                     // primero se arma el nivel
    partidaEnCurso = true;                             // defensa 7
    reloj.iniciar();                                   // después arrancan los hilos
    hiloJugador.iniciar();
    hiloMundo.iniciar();
}
```

```mermaid
sequenceDiagram
    participant G as GUI
    participant J as Juego
    participant F as FabricaEntidades
    participant GN as GeneradorNivel
    participant H as Hilos
    G->>J: iniciar(modo, dominio)
    J->>F: new FabricaEntidades(this como EntornoJuego, dominio)
    J->>F: crearLink(0, 0)
    J->>H: new Reloj, new HiloJugador, new HiloMundo
    J->>J: cargarNivel()
    J->>GN: generar(1, fabrica)
    GN-->>J: nivel
    J->>J: activarSector(sector inicial)
    J->>J: partidaEnCurso = true
    J->>H: iniciar() los tres
```

**El orden importa.** Los hilos arrancan **después** de `cargarNivel()`. Si arrancaran antes, `HiloMundo` podría recorrer un sector a medio armar o no encontrar sector.

**Hilos nuevos en cada partida.** Un `Thread` terminado no se puede volver a arrancar, por eso `iniciar` crea objetos nuevos cada vez.

**Lo que elige el jugador** es el **modo** (Clásico, Contrarreloj, NoHit) y el **dominio** de imágenes (original o alternativo). El nivel no se elige: siempre se empieza por el 1.

## 7. Niveles: cómo se cargan y cómo se pasa de uno a otro

### Cargar un nivel

```java
private void cargarNivel() {
    Sector sectorAnterior = jugador.getSector();          // Link sabe en qué sector está
    if (sectorAnterior != null)
        sectorAnterior.retirar(jugador);
    nivel = generadorNivel.generar(numeroNivel, fabricaEntidades);
    Sector sectorInicial = nivel.getSectorInicial();
    jugador.setPosicion(nivel.getPosicionInicial());
    sectorInicial.agregar(jugador);
    modoJuego.alIniciarNivel();
    controladorGrafico.actualizarNivel(numeroNivel);
    activarSector(sectorInicial);
}
```

| Paso | Qué hace |
|---|---|
| 1 | Saca a Link del sector donde estaba (si estaba en alguno: al empezar no está en ninguno) |
| 2 | `GeneradorNivel` lee `/Recursos/Niveles/nivel<numeroNivel>.txt` y arma el `Nivel` con todas sus entidades |
| 3 | Ubica a Link en el **sector inicial** y en la **posición inicial** que dice el archivo |
| 4 | Le avisa al modo (`alIniciarNivel`: en Contrarreloj reinicia el tiempo restante) |
| 5 | Le avisa a la vista el número de nivel (HUD) |
| 6 | Activa el sector inicial (sección 8) |

### La posición inicial de Link sale del archivo

En el `.txt` del nivel, la línea `INICIO <fila> <columna> <x> <y>` dice en qué sector empieza Link y en qué celda de ese sector. `GeneradorNivel` la convierte a píxeles con el lado de la celda que dice la línea `CELDAS` (desde la defensa 7, 24 px: `x * 24`, `y * 24`) y la guarda en el `Nivel`. `cargarNivel` la usa con `getSectorInicial()` y `getPosicionInicial()`. El `crearLink(0, 0)` de `iniciar` es provisorio: `cargarNivel` lo pisa antes de que arranquen los hilos.

### Cuándo se carga un nivel

| Situación | Método | `numeroNivel` | Qué se pausa |
|---|---|---|---|
| Empieza la partida | `iniciar` | 1 | Nada (los hilos todavía no corren) |
| Se derrotan todos los jefes y no era el último nivel | `jefeDerrotado` | `+1` | `HiloMundo` |
| Link cae al vacío y le quedan vidas | `jugadorCayoAlVacio` | Igual (se reinicia el mismo) | `HiloMundo` |

```java
public void jefeDerrotado(Jefe j) {
    jugador.sumarPuntos(j.getPuntos());
    if (nivel.jefesDerrotados()) {
        if (modoJuego.esUltimoNivel(numeroNivel)) {
            terminarPartida();
        } else {
            numeroNivel++;
            hiloMundo.pausar();
            cargarNivel();
            hiloMundo.reanudar();
        }
    }
}
```

**Cuántos niveles hay** lo decide el modo: `ModoJuego` tiene `cantidadNiveles` (la constante `CANTIDAD_NIVELES = 2` en los tres modos) y `esUltimoNivel(n)` devuelve `n == cantidadNiveles`.

**Por qué se pausa solo `HiloMundo`.** `jefeDerrotado` y `jugadorCayoAlVacio` los llama el propio `HiloJugador` (Link mata al jefe o pisa la caída). `HiloJugador` está ocupado ejecutando ese mismo código, así que no se va a mover mientras tanto. El que hay que frenar es `HiloMundo`, para que los enemigos no se muevan sobre un nivel a medio armar.

## 8. Activar un sector y cambiar de sector

### Activar un sector

```java
private void activarSector(Sector s) {
    colisiones.setSector(s);
    controladorGrafico.limpiarEscena();
    for (Entidad entidad : s.getEntidades())
        if (entidad != jugador)
            entidad.registrarObserver(controladorGrafico.mostrarEntidad(entidad));
    jugador.registrarObserver(controladorGrafico.mostrarJugador(jugador));
}
```

1. **`colisiones.setSector(s)`**: el sector visible vive en el administrador; los dos hilos lo ven a la vez.
2. **`limpiarEscena()`**: la vista borra las celdas del sector anterior.
3. **Una celda por entidad** (patrón Observer): `mostrarEntidad(e)` crea la `CeldaGrafica` y la entidad la registra como observadora. Cuando la entidad se mueve, `notificarObservers()` redibuja la celda.
4. **Link último**, con su celda especial (`CeldaJugador`, que además actualiza el HUD). Desde la defensa 7 el orden de dibujo no depende de esto: cada entidad dice su capa con `getCapa()` y Link está en `CAPA_JUGADOR`, la de más arriba.

`entidad != jugador` compara **referencias**, no tipos: no es `instanceof`.

### Cambiar de sector

```java
public void cambiarDeSector(Direccion d) {
    Sector sectorActual = colisiones.getSector();
    Sector sectorVecino = nivel.getMapa().getVecino(sectorActual, d);
    if (sectorVecino == null) {
        jugador.entrarPorBordeOpuesto(d.opuesta());      // no hay vecino: vuelve al mismo borde
    } else {
        hiloJugador.pausar();
        hiloMundo.pausar();
        sectorActual.retirar(jugador);
        jugador.entrarPorBordeOpuesto(d);
        sectorVecino.agregar(jugador);
        colisiones.setSector(sectorVecino);
        controladorGrafico.transicion(d);                // al terminar llama a transicionTerminada()
    }
}

public void transicionTerminada() {
    activarSector(colisiones.getSector());
    hiloJugador.reanudar();
    hiloMundo.reanudar();
}
```

```mermaid
sequenceDiagram
    participant HJ as HiloJugador
    participant L as Link
    participant J as Juego
    participant S as Sectores
    participant G as GUI
    participant AT as AnimadorTransicion
    HJ->>L: actualizarEstado(c)
    L->>J: cambiarDeSector(DERECHA)
    J->>J: pausar los dos hilos
    J->>S: actual.retirar(link) y vecino.agregar(link)
    J->>L: entrarPorBordeOpuesto(DERECHA)
    J->>G: transicion(DERECHA)
    G->>AT: new Thread(...).start()
    AT->>AT: desliza la pantalla
    AT->>J: transicionTerminada()
    J->>J: activarSector(vecino)
    J->>J: reanudar los dos hilos
```

| Caso | Qué pasa |
|---|---|
| Hay sector vecino | Pausa los hilos, pasa a Link al sector nuevo (en el borde por el que entra), cambia el sector visible y arranca la animación. Al terminar, `transicionTerminada` muestra el sector nuevo y reanuda. |
| No hay vecino (borde del mapa) | Link vuelve a entrar por el mismo borde. No hay transición ni pausa. |

El **reloj no se pausa** durante la transición: el tiempo de la partida sigue corriendo. Como desde la defensa 7 `terminarPartida()` ya no depende del estado del reloj, si algún día se decide pausarlo en la transición, no hay que tocar nada más.

## 9. Avisos de las entidades

Todos estos métodos, menos `tic`, están en la interfaz **`EntornoJuego`**: las entidades los ven a través de `miJuego`.

| Método | Lo llama | Hilo | `synchronized` | Qué hace |
|---|---|---|---|---|
| `enemigoDerrotado(e) : boolean` | `Enemigo.desaparecer()` y `EnemigoConDrop.desaparecer()` | `HiloMundo` (la acción programada al terminar la muerte) | Sí | Suma puntos y racha; cada 4, una bellota (y devuelve `true` para que el enemigo no suelte drop encima) |
| `jefeDerrotado(j)` | `Jefe.desaparecer()` | `HiloMundo` | No | Suma puntos; si no quedan jefes, pasa de nivel o termina |
| `powerUpRecogido(p)` | `Link.powerUpRecogido` | `HiloJugador` | Sí | Suma los puntos del power-up |
| `jugadorDaniado()` | `Link.recibirDanio` | `HiloJugador` o `HiloMundo` | Sí | `modoJuego.alRecibirDanio(this)` (`this` como `ArbitroPartida`): en NoHit termina la partida |
| `jugadorSinVidas()` | `Link.morir`, `Link.caerAlVacio` | Los dos | No | `terminarPartida()` (que sí es `synchronized`) |
| `jugadorCayoAlVacio()` | `Link.caerAlVacio` | `HiloJugador` | No | Reinicia el nivel actual |
| `cambiarDeSector(d)` | `Link.alSalirDelSector` | `HiloJugador` | No | Sección 8 |
| `agregarEntidad(e)` | Ataques, drops, suelo roto | Los dos | No (lo protege `Sector.agregar`) | Agrega la entidad al sector visible y la muestra |
| `tic(segundos)` | `Reloj.ciclo` (por `OyenteReloj`) | `Reloj` | Sí | Actualiza el tiempo y avisa al modo |

### La racha y la bellota

```java
public synchronized void enemigoDerrotado(Enemigo e) {
    jugador.sumarPuntos(e.getPuntos());
    jugador.incrementarRacha();
    if (jugador.getRacha() == RACHA_PARA_BELLOTA) {
        jugador.reiniciarRacha();
        aparecerBellota(e.getX(), e.getY());
    }
}
```

Cada enemigo derrotado suma uno a la racha. La racha vuelve a 0 cuando Link recibe daño o cae. Al llegar a 4, aparece una bellota donde murió el último enemigo, con `aparecerBellota`, que la crea con la fábrica y la agrega con `agregarEntidad`.

### Los modos reaccionan con ganchos

| Aviso | Gancho del modo | Clásico | Contrarreloj | NoHit |
|---|---|---|---|---|
| `cargarNivel` | `alIniciarNivel()` | Nada | Reinicia el tiempo restante | Nada |
| `jugadorDaniado` | `alRecibirDanio(a)` | Nada | Nada | `a.terminarPartida()` |
| `tic` | `alPasarTiempo(a, s)` | Nada | Descuenta; a 0, `a.terminarPartida()` | Nada |

Juego llama siempre al mismo gancho, y cada modo decide qué hacer. Sin `instanceof`. Desde la defensa 7 los ganchos reciben un `ArbitroPartida` (`a`), que solo deja terminar la partida.

## 10. Terminar la partida y los rankings

```java
@Override
public synchronized void terminarPartida() {
    if (partidaEnCurso) {                                   // defensa 7: todavía no había terminado
        partidaEnCurso = false;
        reloj.detener();
        hiloJugador.detener();
        hiloMundo.detener();
        controladorGrafico.terminarControl();                // cambio 51: la vista suelta a Link
        int puntajeFinal = jugador.getPuntaje();
        Ranking rankingDelModo = getRanking(modoJuego);
        if (rankingDelModo.entraEnTop5(puntajeFinal))
            controladorGrafico.pedirNombre(puntajeFinal);
        else
            controladorGrafico.mostrarRanking(rankingDelModo, modoJuego.getNombre());
    }
}
```

**Quién la llama:** `jugadorSinVidas`, `jefeDerrotado` (último jefe del último nivel), NoHit (primer daño) y Contrarreloj (se acabó el tiempo).

**Por qué el `if (partidaEnCurso)`.** Dos avisos pueden llegar casi juntos (por ejemplo, se acaba el tiempo en el mismo
momento en que Link pierde la última vida). Como el método es `synchronized`, el primero pone `partidaEnCurso = false` y
el segundo no hace nada. Así no se pide el nombre dos veces (ver `imagenes-cambio-17/secuencia-dos-avisos.png`).

**Por qué ya no `reloj.estaActivo()` (defensa 7).** El ayudante preguntó: ¿si se pausa el reloj, terminó la partida? En la
defensa 6 se usaba el estado de un **hilo** para responder algo de la **partida**. Funcionaba porque `pausar()` cambia
`pausado` y no `activo`, pero si mañana se pausa o detiene el reloj por otra razón, `terminarPartida()` quedaba atado a
ese detalle. Además, si se llamaba antes de `iniciar()`, `reloj` era `null`. Con `partidaEnCurso` (que arranca en `false`)
llamarlo antes de `iniciar()` no hace nada.

**El flujo del ranking:**

```mermaid
sequenceDiagram
    participant J as Juego
    participant G as GUI
    participant M as ModoJuego
    participant R as Ranking
    participant P as PersistenciaRanking
    J->>J: terminarPartida()
    J->>G: terminarControl()
    J->>R: entraEnTop5(puntaje)
    alt entra
        J->>G: pedirNombre(puntaje)
        G->>J: registrarNombre(nombre)
        J->>M: registrarPuntaje(this como TablaRankings, entrada)
        M->>J: agregarAlRankingClasico(entrada)
        J->>R: insertar(entrada)
        J->>P: guardar(ranking, ranking0.txt)
        J->>G: mostrarRanking(ranking, Clásico)
    else no entra
        J->>G: mostrarRanking(ranking, nombre del modo)
    end
```

```java
private void agregar(int i, EntradaRanking e) {
    Ranking ranking = rankings[i];
    boolean entro = ranking.insertar(e);
    if (entro)
        persistencia.guardar(ranking, "ranking" + i + ".txt");
}
```

Solo se guarda el archivo si `insertar` devuelve `true`.

**Un solo puntaje por nombre (defensa 7, cambio 15.2).** `Ranking.insertar(e)` ya no agrega siempre una fila nueva. Si
el nombre ya está en el ranking, se queda con **el mejor** de los dos puntajes: si el nuevo es mayor, reemplaza al viejo
y devuelve `true`; si no, no cambia nada y devuelve `false` (y no se reescribe el archivo). Si el nombre no está, se
inserta como antes y queda en el top 5 si le alcanza. Los tres métodos públicos (`agregarAlRankingClasico`, `...Contrarreloj`, `...NoHit`) existen para que cada modo llame al suyo sin que Juego tenga que preguntar de qué tipo es.

## 11. Consultas

| Consulta | Devuelve | La usa |
|---|---|---|
| `getRanking(m)` | El ranking de ese modo (le pregunta al modo) | Vista, `terminarPartida`, `registrarNombre` |
| `getControlJugador()` | Link como `ControlJugador` (`null` antes de `iniciar`) | `GUI`, para las teclas |
| `getRankingClasico()`, `getRankingContrarreloj()`, `getRankingNoHit()` | `rankings[0]`, `[1]`, `[2]` | Cada modo, desde su `getRanking(t)` (son de `TablaRankings`) |
| `getJugador()` | **Link como `Entidad`** (defensa 7) | Los enemigos, para saber dónde está (`getHitbox()`, `getCentro()`, `getPosicion()`). Es de `EntornoJuego` |
| `getFabricaEntidades()` | La fábrica de la partida | Las entidades que crean otras: `Link` (caída al vacío), `EnemigoConDrop` (drops), `Octorok` y `Wizzrobe` (proyectiles), `StoneHinox` (rocas). Es de `EntornoJuego` |

**Los getters que marcó el ayudante (defensa 7):**

| Método | Defensa 6 | Defensa 7 | Por qué |
|---|---|---|---|
| `getNumeroNivel() : int` | Público | **Se borró** | No lo usaba nadie: el HUD recibe el nivel por `actualizarNivel(n)` |
| `getTiempo() : int` | Público | **Se borró** | No lo usaba nadie: el HUD recibe el tiempo por `actualizarTiempo(s)` |
| `getJugador()` | `: Link` | `: Entidad`, en `EntornoJuego` | Devolver `Link` dejaba hacer `getJugador().sumarPuntos(...)` desde cualquier lado y deshacía el encapsulamiento de `getControlJugador()` |
| `getFabricaEntidades()` | Público | En `EntornoJuego` | Lo necesitan las entidades que crean otras |

## 12. Hilos y sincronización

Juego es la clase que **más hilos tocan**:

| Hilo | Qué le pide a Juego |
|---|---|
| EDT (Swing) | `iniciar`, `registrarNombre`, `getRanking`, `getControlJugador` |
| `HiloJugador` | Casi todos los avisos: enemigos, jefes, power-ups, caída, cambio de sector |
| `HiloMundo` | `jugadorDaniado` (un enemigo choca con Link), `agregarEntidad` (proyectiles) |
| `Reloj` | `tic` (como `OyenteReloj`) |
| `AnimadorTransicion` | `transicionTerminada` |

**Qué es `synchronized` y por qué:**

| Método | ¿`synchronized`? | Por qué |
|---|---|---|
| `enemigoDerrotado`, `powerUpRecogido` | Sí | Tocan el puntaje y la racha |
| `jugadorDaniado`, `tic`, `terminarPartida` | Sí | Pueden terminar la partida; la llave pone en fila a los hilos |
| `jefeDerrotado`, `jugadorCayoAlVacio`, `cambiarDeSector` | No | Recargan el nivel o cambian de sector: tocan la lista de los sectores, que se protege en `Sector` |
| `agregarEntidad` | No | Lo protege `Sector.agregar` |

**El orden de llaves: Entidad → Juego → Sector.** Un hilo puede pedir la llave de Juego teniendo la de una entidad (por ejemplo, `Link.recibirDanio` → `jugadorDaniado`), y la de un sector teniendo cualquiera, pero **nunca al revés**. Por eso, **desde un método `synchronized` de Juego nunca se llama a `recibirDanio`, `aplicarDanio` ni `programar` de una entidad**. Los métodos de Link que sí llama Juego (`sumarPuntos`, `incrementarRacha`, `reiniciarRacha`) no son `synchronized`.

| Cadena | ¿Respeta el orden? |
|---|---|
| `Link.recibirDanio` (Link) → `Juego.jugadorDaniado` (Juego) → NoHit → `terminarPartida` (Juego) | Sí |
| `Juego.enemigoDerrotado` (Juego) → `aparecerBellota` → `Sector.agregar` (Sector) | Sí |

**Llamadas reentrantes.** `jugadorDaniado` (synchronized) puede terminar llamando a `terminarPartida` (también synchronized). No se traba: en Java el mismo hilo puede volver a entrar a una llave que ya tiene.

## 13. Paquete e imports

```java
package logica.juego;

import logica.ControlJugador;
import logica.ControladorGrafico;
import logica.ControladorJuego;
import logica.entidades.AdministradorColisiones;
import logica.entidades.Entidad;
import logica.entidades.EntornoJuego;
import logica.entidades.Link;
import logica.entidades.enemigos.Enemigo;
import logica.entidades.enemigos.Jefe;
import logica.entidades.fijas.PowerUP;
import logica.fabricas.FabricaEntidades;
import logica.fabricas.FabricaSprites;
import logica.hilos.HiloJugador;
import logica.hilos.HiloMundo;
import logica.hilos.OyenteReloj;
import logica.hilos.Reloj;
import logica.mapa.GeneradorNivel;
import logica.mapa.Nivel;
import logica.mapa.Sector;
import logica.util.Direccion;
```

- Va en `logica.juego`, junto a `ModoJuego`, los modos, `Ranking`, `EntradaRanking`, `PersistenciaRanking`, `ArbitroPartida` y `TablaRankings` (por eso esos no se importan).
- Importa `OyenteReloj` (de `logica.hilos`) y `EntornoJuego` (de `logica.entidades`) para implementarlas. Cada interfaz vive en el paquete de **quien la usa**: así el reloj y las entidades no conocen el paquete `juego`.
- Las interfaces entre lógica y vista (`ControladorJuego`, `ControladorGrafico`, `ControlJugador`) están en el paquete `logica`.
- **No importa nada de Swing**: Juego no sabe que la vista usa Swing. Solo conoce la interfaz `ControladorGrafico`.
- **Defensa 7:** los paquetes van en minúscula.

## 14. Cuidados y detalles conocidos

| Tema | Detalle |
|---|---|
| **Celdas viejas** | Cada vez que se activa un sector se registra una celda nueva en cada entidad, y las del sector anterior siguen registradas (el extendido no tiene `quitarObserver`). `CeldaGrafica.actualizar()` ignora la actualización si ya no está en el panel. La lista de observadores de Link crece una celda por cambio de sector; para una partida es poco. |
| **`getControlJugador()` antes de `iniciar`** | Devuelve `null`, porque Link se crea en `iniciar`. La `GUI` lo pide después. |
| **Link durante la transición** | Ya está en el borde del sector nuevo, así que su celda salta en el panel viejo mientras se desliza. |
| **`pausar()` no espera** | `HiloMundo` puede estar terminando una vuelta en el sector viejo mientras Juego arma el nuevo. Lo peor que pasa es que un enemigo del sector viejo dé un paso más. |
| **Primer `tic` del reloj** | Con el `run()` actual de `HiloJuego`, el primer `tic(1)` llega apenas arranca la partida (la vuelta va antes del `sleep`). |
| **`terminarPartida()` antes de `iniciar()`** | No hace nada: `partidaEnCurso` arranca en `false` (en la defensa 6 daba `NullPointerException`). |
| **Orden de llaves** | No llamar desde un método `synchronized` de Juego a `recibirDanio`, `aplicarDanio` ni `programar` de una entidad. |

## 15. En los diagramas

| Diagrama | Cómo aparece |
|---|---|
| **Reducido** | `Juego` realiza `ControladorJuego` y, desde la defensa 7, `<<Interface>> OyenteReloj`, `ArbitroPartida`, `TablaRankings` y `EntornoJuego` (cuatro realizaciones punteadas nuevas). Composición con `Ranking` (3), `Reloj`, `HiloJugador`, `HiloMundo` y `AdministradorColisiones`; agregación con `Nivel` y `ModoJuego`; asociación con `ControladorGrafico`, `Link`, `GeneradorNivel`, `FabricaEntidades` y `PersistenciaRanking`. `Reloj → OyenteReloj` (`#oyente 1`), `Entidad* → EntornoJuego` (`#miJuego 1`) y `FabricaEntidades → EntornoJuego` (`#entorno 1`). Los modos reciben `ArbitroPartida` y `TablaRankings` solo como parámetros: es una dependencia y no se dibuja. Totales: 94 clases/interfaces y 131 relaciones (124 dibujadas). |
| **Extendido** | Subtítulo "implementa ControladorJuego, OyenteReloj, ArbitroPartida, TablaRankings, EntornoJuego". La constante `RACHA_PARA_BELLOTA`, 14 atributos (con `# partidaEnCurso : boolean`), el constructor `+ Juego(vista : ControladorGrafico)`, los comandos públicos, 4 privados (`cargarNivel`, `activarSector`, `aparecerBellota`, `agregar`) y las consultas, con `+ getJugador() : Entidad`. Ya no están `getNumeroNivel()` ni `getTiempo()`. Las cuatro interfaces nuevas aparecen con fondo amarillo. El código coincide uno a uno. |

## 16. Preguntas que pueden hacer en la defensa

| Pregunta | Respuesta corta |
|---|---|
| ¿Qué hace Juego? | Es el árbitro: arma la partida, carga niveles, recibe los avisos de las entidades, maneja los hilos y los rankings. |
| ¿Por qué ya no recibe las teclas? | Por las correcciones de la Defensa 4: las acciones del jugador son de Link (`ControlJugador`). Juego solo lo devuelve con `getControlJugador()`. |
| ¿Cómo se elige el nivel? | No se elige: se empieza en el 1 y se pasa al siguiente al derrotar a todos los jefes. Cuántos hay lo dice el modo. |
| ¿De dónde sale la posición inicial de Link? | Del archivo del nivel (línea `INICIO`), a través de `Nivel.getSectorInicial()` y `getPosicionInicial()`. |
| ¿Por qué los hilos arrancan después de `cargarNivel`? | Para que no corran sobre un nivel a medio armar. |
| ¿Cómo sabe qué ranking usar sin `instanceof`? | Le pregunta al modo (`m.getRanking(this)`), y el modo llama al método de la `TablaRankings` que le corresponde. |
| ¿Qué necesita el reloj de Juego? | Solo `tic(int)`. Por eso lo recibe como `OyenteReloj`. |
| ¿Por qué cuatro interfaces y no una? | Porque cada colaborador usa cosas distintas: el reloj solo `tic`, los modos terminar la partida y los rankings, las entidades los avisos. Cada uno ve solo lo suyo (segregación de interfaces). |
| ¿Para qué es público `getJugador()`? | Lo necesitan las entidades para ubicar a Link. Desde la defensa 7 está en `EntornoJuego` y devuelve `Entidad`, así que no se puede usar para sumarle puntos ni quitarle vidas. |
| ¿Qué pasa en el cambio de sector? | Pausa los dos hilos, pasa a Link al sector vecino, cambia el sector visible y arranca la animación; al terminar, muestra el sector y reanuda. |
| ¿Cómo evita terminar la partida dos veces? | `terminarPartida` es `synchronized` y solo hace algo si `partidaEnCurso` es `true`; lo primero que hace es ponerlo en `false`. |
| Si se pausa el reloj, ¿terminó la partida? | No. Desde la defensa 7 la partida tiene su propio estado (`partidaEnCurso`), separado del estado del hilo. |
| ¿Por qué `jefeDerrotado` no es `synchronized`? | Porque puede recargar el nivel, que toca la lista de los sectores; no se debe tener la llave de Juego mientras tanto. |
| ¿Por qué Juego no usa Swing? | Porque es lógica. Le habla a la vista a través de `ControladorGrafico`, y la vista usa `invokeLater` para tocar Swing. |

---

*Cambios generales*

# Cambios generales: cuerpos de colisión (Defensa 7)

En la defensa 6 esta sección era una **propuesta**: separar la imagen de una entidad de su cuerpo de colisión. En la
defensa 7 la propuesta está aplicada en todas las clases y cada una declara un cuerpo **ajustado a su dibujo**
(cambio 4 de `Cambios-desde-defensa-6.md`). Así Link, por ejemplo, ya no cae al vacío sin tocar el dibujo y pasa por
pasillos de una celda.

## Idea

Una entidad tiene dos rectángulos que no tienen por qué coincidir:

| Qué | Métodos | Lo usa |
|---|---|---|
| **Posición** (la esquina de la imagen) | `getX()`, `getY()`, `getPosicion()` | La vista, para dibujar |
| **Cuerpo** (un rectángulo con margen respecto de esa esquina) | `getHitbox()`, `getAncho()`, `getAlto()`, `getCentro()` | Todas las colisiones: `buscarBloqueo`, `verificarColisiones`, `golpearEn`, `estaFuera`, `caminoHasta` |

Por defecto el margen es 0 y el cuerpo mide 48 × 48 (`Entidad.LADO`), así que una entidad que no declara nada se
comporta como antes. El cuerpo es una **regla del juego** y se declara en la clase con constantes, no en
`FabricaSprites`: es el mismo en los dos dominios de imágenes.

## Hitbox.java

`posicion` es la esquina de la entidad (donde se dibuja). `getX()`/`getY()` devuelven la esquina del **cuerpo**, así que
`intersecta`, `adelante`, `estaDentroDe`, `estaEnLineaCon` y `caminoHasta` trabajan siempre con el cuerpo.

```java
public class Hitbox {

    protected Posicion posicion;   // esquina de la entidad (donde se dibuja)
    protected int margenX;         // del borde de la imagen al borde del cuerpo
    protected int margenY;
    protected int ancho;           // tamaño del cuerpo
    protected int alto;

    public Hitbox(int x, int y, int ancho, int alto) {
        this(x, y, 0, 0, ancho, alto);
    }

    public Hitbox(int x, int y, int margenX, int margenY, int ancho, int alto) { ... }

    public int getX() { return posicion.getX() + margenX; }      // esquina del cuerpo
    public int getY() { return posicion.getY() + margenY; }

    public Posicion getCentro() {
        return new Posicion(getX() + ancho / 2, getY() + alto / 2);
    }

    public Hitbox desplazada(Direccion d, int pasos) {            // conserva el margen
        Posicion desplazada = posicion.desplazada(d, pasos);
        return new Hitbox(desplazada.getX(), desplazada.getY(), margenX, margenY, ancho, alto);
    }

    public Posicion posicionParaCuerpoEn(int x, int y) {          // dónde poner la imagen para que
        return new Posicion(x - margenX, y - margenY);            // el cuerpo quede en (x, y)
    }

    public Hitbox caminoHasta(Hitbox otra) { ... }                // defensa 7: la franja entre dos cuerpos

    public boolean contiene(Posicion p) { ... }                   // cambio 31: si el punto cae dentro
}
```

**Defensa 7: `caminoHasta(otra)`.** Devuelve el rectángulo entre dos cuerpos que están en la misma fila o columna. Lo
usa `EntidadAnimada.hayObstaculoHastaJugador()` para que el Moblin con espada y la trampa no se abalancen a través de una
roca, el agua o un vacío (cambio 9).

## Entidad.java

El constructor crea el cuerpo de 48 × 48 sin margen. Cada clase que quiere otro cuerpo llama a `setCuerpo` en su
constructor.

```java
protected void setCuerpo(int margenX, int margenY, int ancho, int alto) {
    hitbox = new Hitbox(getX(), getY(), margenX, margenY, ancho, alto);
}

public void ubicarCuerpoEn(int x, int y) {                  // mueve la entidad para que su cuerpo quede en (x, y)
    setPosicion(hitbox.posicionParaCuerpoEn(x, y));
}

public Posicion getCentro() { return hitbox.getCentro(); }
```

## Cuerpo de cada clase (defensa 7)

Cada clase lo declara con cuatro constantes subrayadas en el extendido: `- CUERPO_MARGEN_X`, `- CUERPO_MARGEN_Y`,
`- CUERPO_ANCHO` y `- CUERPO_ALTO : int`.

| Clase | Imagen | margenX | margenY | ancho | alto |
|---|---|---|---|---|---|
| `Link` | 48 × 48 | 6 | 2 | 36 | 44 |
| `Moblin` | 48 × 48 | 4 | 4 | 40 | 40 |
| `Octorok` | 48 × 48 | 4 | 4 | 40 | 40 |
| `Wizzrobe` | 48 × 48 | 4 | 2 | 40 | 44 |
| `ErizoDeMar` | 48 × 48 | 8 | 8 | 32 | 32 |
| `TrampaDeCuchillas` | 48 × 48 | 8 | 8 | 32 | 32 |
| `CaidasAlVacio` | 48 × 48 | 8 | 8 | 32 | 32 |
| `Roca` | 48 × 48 | 4 | 4 | 42 | 42 |
| `Rupia` | 48 × 48 | 13 | 3 | 21 | 42 |
| `Corazon` | 48 × 48 | 3 | 6 | 42 | 36 |
| `Bellota` | 48 × 48 | 12 | 1 | 24 | 45 |
| `FragmentoDeCorazon` | 48 × 48 | 1 | 3 | 45 | 42 |
| `StoneHinox` | 96 × 96 | 6 | 4 | 84 | 88 |
| `MasterStalfos` | 171 × 216 | 13 | 12 | 117 | 120 |
| `Proyectil` | 48 × 48 | `(48 − lado) / 2` | `(48 − lado) / 2` | `lado` | `lado` |

El resto (`Agua`, `Pasto`, `SuelosQuebradizo`, `Espada`, `Escudo`) usa el cuerpo por defecto de
48 × 48. `MoblinConEspadaYEscudo` (cambios 19 y 35) tiene una imagen de 126 × 126 con la espada afuera y el cuerpo azul en el
centro: su cuerpo es el del `Moblin` (40 × 40) corrido `MARGEN_IMAGEN` = 39 px (`43, 43, 40, 40`). Era de 96 × 96 con 24 px, pero al animar la caminata la espada adelantada quedaba recortada. El constructor lo ubica en
`(x − MARGEN_IMAGEN, y − MARGEN_IMAGEN)` para que el cuerpo caiga en la celda del nivel. El proyectil recibe el lado de su cuerpo en el constructor y lo
centra en su imagen.

## Imágenes del StoneHinox (cambios 20, 48 y 50)

El StoneHinox tiene cinco GIF de 96 × 96 (cambio 50; en el cambio 20 eran tres PNG fijos) y elige uno en `getRutaImagen()`, en este orden:

| Situación | Atributo | Imagen | Cuándo avisa a la vista |
|---|---|---|---|
| Muriendo (cambio 48) | `muriendo = true` | `stonehinox-muerte.gif` (nube agrandada, 300 ms) | En `morir()` de `Enemigo` |
| Vulnerable 1 s después de la embestida | `vulnerable = true` | `stonehinox-vulnerable.gif` (naranja, 2 cuadros de 300 ms) | En `embestidaTerminada()` y cuando termina `DURACION_VULNERABILIDAD` |
| Llegó al centro y largó la avalancha | `golpeandoSuelo = true` | `stonehinox-avalancha.gif` (brazos arriba 150 ms y puño contra el suelo 450 ms, sin repetir) | En `ataqueTerminado()` y cuando termina `DURACION_GOLPE_AVALANCHA` (600 ms) |
| Embistiendo (cambio 50) | `embistiendo = true` | `stonehinox-embestida.gif` (pasos rápidos, 2 cuadros de 110 ms) | En `siguienteAtaque()` al elegir la embestida; `embestidaTerminada()` lo vuelve a `false` |
| Cualquier otro momento | todos en `false` | `stonehinox-normal.gif` (camina, 2 cuadros de 300 ms) | — |

El GIF de la avalancha no se repite: `CeldaGrafica` lo vuelve a cargar cada vez que cambia la ruta, así que arranca de cero en cada golpe y dura justo los 600 ms que el jefe se queda quieto.

La avalancha larga todas las rocas en una sola vuelta y avisa enseguida con `ataqueTerminado()`. Para que el golpe se vea, el jefe se queda quieto 600 ms (`MovimientoInducido(null, 0)`) con un ataque que no lastima (`AtaquePorContacto(0)`), y recién después elige el siguiente ataque. Los atributos son `volatile` porque los escribe el hilo del mundo y los lee la vista.

## Lugares que mezclan posición y cuerpo

| Lugar | Qué hace | Por qué |
|---|---|---|
| `Link.entrarPorBordeOpuesto(d)` | `ubicarCuerpoEn(...)` | `estaFuera` mira el cuerpo, así que la entrada también pega el cuerpo al borde |
| `AtaquePorProyectil` | Ubica el cuerpo del proyectil centrado en el **centro** del que dispara | El proyectil sale del medio del cuerpo, no de la esquina de la imagen |
| `AtaqueAvalancha` | Ubica el cuerpo de cada roca arriba de todo con `ubicarCuerpoEn(x, 0)`, y compara el centro del jefe con el del sector | La roca entra justo por el borde de arriba |
| `MovimientoTeletransporte` | `posicionLibreAlAzar(ancho, alto)` y `ubicarCuerpoEn(...)` | El lugar libre es para el cuerpo |
| `EntidadAnimada.direccionHaciaJugador()`, `StoneHinox` (embestida) | Comparan **centros** | Con cuerpos de distinto tamaño, comparar esquinas da direcciones raras |
| `TrampaDeCuchillas` | Guarda la posición de la **imagen** como `posicionOriginal` y vuelve a ella | Vuelve exacto a su lugar |
| `EnemigoConDrop.generarDrop()` (cambio 19) | Crea la rupia o el corazón en la esquina del **cuerpo** (`getHitbox().getX()`, `getY()`) | Con la imagen grande del `MoblinConEspadaYEscudo`, la esquina de la imagen queda 24 px afuera del cuerpo |

## Otros cambios generales de la defensa 7

| Cambio | Qué hace | Dónde está explicado |
|---|---|---|
| **Bloqueo con `bloqueaPasoA(quien)`** | La entidad de adelante decide si frena al que camina, preguntándole `esquivaVacios()` o `esFrenadoPorPersonajes()`. Sin `instanceof` | `AdministradorColisiones` y `Explicativo-bloqueaPasoA.md` |
| **Capas de dibujo** | Cada entidad dice su capa (`getCapa()`): suelo 0, objetos 1, obstáculos 2, personajes 3, jugador 4. La vista ordena las celdas con ese número | Integrante 3 (vista) y `EntidadAnimada` |
| **Parpadeo** | `aplicarDanio` hace parpadear 600 ms; Link, Wizzrobe y MasterStalfos lo estiran mientras dura su invulnerabilidad | `DefensaLimitada`, `EntidadAnimada` y `Link` |
| **Constantes con nombre** | No quedan números sueltos en la lógica | En cada clase |
| **Interfaces chicas para `Juego`** | `OyenteReloj`, `ArbitroPartida`, `TablaRankings`, `EntornoJuego` | `Juego` y `Reloj` |
| **Soltar el control al terminar (cambio 51)** | `Juego.terminarPartida()` llama `terminarControl()` y la `GUI` deja de mandarle teclas al Link muerto | `GUI` (integrante 3) y "Terminar la partida y los rankings" |

## Lo que no cambia

- La vista sigue dibujando en `getX()`/`getY()` (la esquina de la imagen) con el tamaño de la imagen.
- Las entidades que no declaran cuerpo se comportan igual que en la defensa 5.
- `intersecta`, `adelante` y `estaDentroDe` no cambiaron: ya trabajaban con `getX()`/`getY()` del hitbox.

---

*Diagramas de secuencia*

# Diagramas de secuencia (Defensa 7)

Los tres diagramas de la defensa 6, rehechos con el código de la defensa 7. Lo que cambió:

- **Secuencia 1:** antes de chocar con la rupia, Link avanza por `AdministradorColisiones.mover`, que busca bloqueos con
  `bloqueaPasoA`. La rupia no bloquea a nadie, así que Link avanza y el choque lo encuentra `verificarColisiones`.
- **Secuencia 2:** `cargarAtaque()` y `ataqueRealizado()` avisan a la vista para mostrar la imagen del espadazo; el
  Moblin golpeado parpadea.
- **Secuencia 3:** `puedeMoverA` ya no existe. `mover` usa `buscarBloqueo` y, si algo bloquea, dispara el Visitor con esa
  entidad. El reloj le avisa a un `OyenteReloj` y el modo recibe un `ArbitroPartida`.

Al final se suman los tres diagramas nuevos del cambio 17 (ranking, Contrarreloj y dos avisos de fin).

## Secuencia 1: Link colisiona con un PowerUP (Rupia)

```mermaid
sequenceDiagram
    autonumber
    participant HJ as :HiloJugador
    participant L as link : Link
    participant AC as :AdministradorColisiones
    participant R as rupia : Rupia
    participant J as :Juego
    participant S as :Sector
    participant CJ as :CeldaJugador
    participant CG as :CeldaGrafica
    HJ->>L: actualizarEstado(colisiones)
    L->>AC: mover(link, d, 4) (desde MovimientoInducido)
    AC->>R: bloqueaPasoA(link)
    R-->>AC: false (la rupia no frena a nadie)
    AC->>L: avanzar(d, 4)
    L->>CJ: actualizar()
    L->>AC: verificarColisiones(link)
    Note over AC: el cuerpo de link se superpone con el de la rupia
    AC->>R: aceptarColision(link)
    R->>L: colisionarCon(this)
    Note over L: Rupia es un PowerUP: Java elige colisionarCon(PowerUP)
    L->>R: serRecogidoPor(this)
    R->>L: sumarRupias(cantidad)
    L->>CJ: actualizar()
    R->>L: powerUpRecogido(this)
    L->>J: powerUpRecogido(rupia)
    J->>L: sumarPuntos(rupia.getPuntos())
    L->>CJ: actualizar()
    R->>S: quitar(this) (dentro de eliminar())
    R->>CG: actualizar()
    Note over CG: ve estaEliminada() y se saca del panel
```

| Paso | Qué pasa |
|---|---|
| 1 a 6 | `HiloJugador` da la vuelta de Link. `MovimientoInducido` pide `c.mover(...)`; `buscarBloqueo` le pregunta a la rupia `bloqueaPasoA(link)`, que devuelve `false` (el de `Entidad`), así que Link avanza y su celda se redibuja |
| 7 a 10 | `verificarColisiones` ve que los cuerpos se superponen y arranca el doble despacho: `rupia.aceptarColision(link)` → `link.colisionarCon(PowerUP)` |
| 11 a 17 | La rupia suma entre 1 y 5 rupias, avisa a Link y Link a Juego (`EntornoJuego.powerUpRecogido`), que suma 10 puntos por rupia. Cada cambio actualiza el HUD |
| 18 y 19 | `eliminar()` marca la rupia, la saca del sector y avisa a su celda, que se quita del panel |

## Secuencia 2: Link equipa su espada y realiza un ataque recargado

```mermaid
sequenceDiagram
    autonumber
    participant G as :GUI
    participant L as link : Link
    participant E as espada : Espada
    participant AR as :AtaqueRecargado
    participant HJ as :HiloJugador
    participant AC as :AdministradorColisiones
    participant M as moblin : Moblin
    participant CJ as :CeldaJugador
    G->>L: cambiarObjeto()
    Note over G,L: la GUI conoce a Link solo como ControlJugador
    L->>CJ: actualizar() (el HUD muestra la espada)
    G->>L: atacar()
    L->>E: atacarCon(this)
    E->>L: cargarAtaque()
    L->>AR: cargar()
    L->>CJ: actualizar() (imagen de ataque)
    Note over G: el jugador mantiene A apretada 3 s
    G->>L: soltarAtaque()
    L->>E: soltarAtaqueCon(this)
    E->>L: liberarAtaque()
    Note over G,E: hasta acá actúa el EDT: solo deja la intención
    HJ->>L: actualizarEstado(colisiones)
    L->>AR: atacar(this, colisiones)
    AR->>L: soltoElAtaque()
    L-->>AR: true
    Note over AR: estaCargado() es true: FACTOR_CARGA = 2
    AR->>AC: golpearAlrededor(link, 64, 2)
    AC->>M: recibirGolpeDeEspada(link, 2)
    Note over M: la defensa decide cuánto pasa. Si sigue vivo, parpadea 600 ms
    AR->>L: ataqueRealizado()
    L->>CJ: actualizar() (giro: 16 vueltas, una imagen por dirección)
```

| Paso | Qué pasa |
|---|---|
| 1 a 3 | La tecla D o Espacio equipa la espada y el HUD lo muestra |
| 4 a 8 | La tecla A llega por el EDT. Link le delega al objeto equipado, que es la espada: empieza la carga y se ve la imagen de ataque |
| 9 a 11 | Al soltar A solo se anota `soltoAtaque = true` |
| 12 a 18 | En la próxima vuelta, `AtaqueRecargado` ve que soltó y que pasaron 3 s (`TIEMPO_CARGA`): golpea con el doble de alcance y daño (64 px y 2). `golpearAlrededor` arma la zona alrededor del cuerpo de Link (cambio 38) |
| 19 y 20 | `ataqueRealizado()` termina el ataque y, como fue recargado, deja el giro `VUELTAS_IMAGEN_GIRO` = 16 vueltas: `direccionImagen()` recorre `ORDEN_GIRO` y termina en la dirección de Link |

## Secuencia 3: Un enemigo se desplaza solo y el reloj descuenta un segundo

Dos hilos en paralelo: `HiloMundo` mueve al Moblin y el `Reloj` avisa un segundo en Contrarreloj. Para que se lean,
cada hilo va en su propio diagrama (en el original era un solo diagrama con un bloque `par`).

**Hilo del mundo:**

```mermaid
sequenceDiagram
    autonumber
    participant HM as :HiloMundo
    participant S as :Sector
    participant M as moblin : Moblin
    participant MA as :MovimientoAleatorio
    participant AC as :AdministradorColisiones
    participant O as otra : Entidad
    participant CG as :CeldaGrafica
    HM->>S: actualizarEntidades(colisiones)
    S->>M: actualizarPorMundo(colisiones)
    Note over M: llama a actualizarEstado(c)
    M->>MA: mover(this, colisiones)
    MA->>AC: mover(moblin, d, velocidad)
    AC->>AC: buscarBloqueo(moblin, d, velocidad)
    AC->>O: bloqueaPasoA(moblin)
    alt nadie bloquea
        AC->>M: avanzar(d, velocidad)
        M->>CG: actualizar()
        Note over AC,M: si el cuerpo quedó fuera de 768 × 528,<br/>alSalirDelSector(d): retrocede y se da vuelta
    else otra bloquea (roca, agua, vacío, Link u otro enemigo)
        AC->>O: aceptarColision(moblin)
        Note over O: si otra es Link, termina en<br/>moblin.colisionarCon(link)
        AC->>M: alChocarConBloqueo()
        AC-->>MA: false
        MA->>M: setDireccion(al azar)
    end
```

**Hilo del tiempo (al mismo tiempo):**

```mermaid
sequenceDiagram
    autonumber
    participant RL as :Reloj
    participant J as :Juego
    participant CG as :ControladorGrafico
    participant CR as :Contrarreloj
    RL->>RL: segundos++
    RL->>J: tic(segundos) (como OyenteReloj)
    J->>CG: actualizarTiempo(segundos)
    Note over CG: el HUD muestra el tiempo (invokeLater)
    J->>CR: alPasarTiempo(this, segundos) (como ArbitroPartida)
    Note over CR: tiempoRestante-- y, si llega a 0,<br/>a.terminarPartida()
```

| Paso | Qué pasa |
|---|---|
| 1 a 3 | `HiloMundo` recorre una copia de las entidades del sector visible; el gancho `actualizarPorMundo` hace la vuelta del Moblin |
| 4 a 7 | `MovimientoAleatorio` pide moverse. `buscarBloqueo` arma el cuerpo en el lugar siguiente y le pregunta a cada entidad que lo toca `bloqueaPasoA(moblin)` |
| Sin bloqueo | El Moblin avanza y su celda se redibuja. Si se salió de la pantalla, retrocede y se da vuelta |
| Con bloqueo | No avanza. `mover` dispara el Visitor con la entidad que bloquea (si es Link, le pega) y avisa `alChocarConBloqueo()`; `MovimientoAleatorio` elige otra dirección |
| Reloj | En paralelo, el `Reloj` suma un segundo y avisa a su `OyenteReloj`. `Juego` muestra el tiempo y le pasa el aviso al modo; Contrarreloj descuenta y, si llega a 0, termina la partida |

## Secuencias nuevas del cambio 17

### Registrar el puntaje (`TablaRankings`)

![Secuencia: registrar el puntaje](imagenes-cambio-17/secuencia-ranking.png)

### El Contrarreloj se queda sin tiempo (`OyenteReloj` y `ArbitroPartida`)

![Secuencia: el Contrarreloj se queda sin tiempo](imagenes-cambio-17/secuencia-contrarreloj.png)

### Dos avisos de fin en el mismo momento (`partidaEnCurso`)

![Secuencia: dos avisos de fin en el mismo momento](imagenes-cambio-17/secuencia-dos-avisos.png)

---

*Niveles*

# Niveles: archivo nivel1.txt (Defensa 7)

**Lo que cambió en la defensa 7:** las celdas pasaron de 48 px a **24 px** (`CELDAS 32 22 24`) y cada nivel tiene
**cuatro sectores en fila** (`MAPA 1 4`), con un **solo jefe** en el último sector: MasterStalfos en el nivel 1 y
StoneHinox en el nivel 2 (cambios 1 y 2). El formato completo y la tabla de símbolos están en la sección del
Integrante 2. Está en `Codigo/src/Recursos/Niveles/nivel1.txt`.

**Cómo leerlo.** Las celdas sirven solo para **ubicar**: cada letra pone la esquina de una entidad en
`x = columna × 24`, `y = fila × 24`. Las entidades siguen midiendo 48 px (los jefes, más), así que cada una ocupa 2 × 2
celdas. Por eso las letras aparecen separadas por un punto: `R.R` son dos rocas pegadas.

| Sector | Enemigos | Obstáculos | Otros |
|---|---|---|---|
| 0 0 (inicio) | Octorok, Moblin con espada y escudo, Erizo, Wizzrobe y una trampa | 4 rocas, 3 aguas, 4 pastos, 3 vacíos, 2 suelos quebradizos | Rupia, corazón y la **espada** (`X`), cerca de donde arranca Link (`INICIO 0 0 4 10` = píxel (96, 240)) |
| 0 1 | Octorok, Moblin, Erizo, Wizzrobe y una trampa | Igual que el 0 0 | Rupia y corazón |
| 0 2 | Wizzrobe, Moblin con espada y escudo, Moblin, Octorok y una trampa | Igual que el 0 0 | Rupia y corazón |
| 0 3 | **MasterStalfos** (`S`), solo, en el centro | — | — |

Además, al cargar el nivel, `GeneradorNivel` reparte **4 fragmentos de corazón** en sectores al azar, en lugares libres.

```
MAPA 1 4
CELDAS 32 22 24
INICIO 0 0 4 10
SECTOR 0 0
..............................T.
................................
..............V.....O...........
................................
......R.R.............P.P.......
................................
............Q.........P.P.......
................................
......N.............C...........
................................
..........X.....................
................................
........$...............E.......
................................
............V.......Q...........
................................
......A.A.............R.R.......
................................
......A.....W...V...............
................................
................................
................................
SECTOR 0 1
T...............................
................................
..........O.....V...............
................................
......P.P.............R.R.......
................................
......P.P.........Q.............
................................
..........C.............M.......
................................
................................
................................
......E...............$.........
................................
..........Q.......V.............
................................
......R.R.............A.A.......
................................
..............V...W.....A.......
................................
................................
................................
SECTOR 0 2
................................
................................
......A.....W...V...............
................................
......A.A.............R.R.......
................................
............V.......Q...........
................................
........$...............N.......
................................
................................
................................
......M.............C...........
................................
............Q.........P.P.......
................................
......R.R.............P.P.......
................................
..............V.....O...........
................................
..............................T.
................................
SECTOR 0 3
................................
................................
................................
................................
................................
................................
................................
................................
.............S..................
................................
................................
................................
................................
................................
................................
................................
................................
................................
................................
................................
................................
................................
```

---

*Referencia*

# Miembros que no se explican en otras secciones (Defensa 7)

Esta sección completa las explicaciones: cada atributo, constructor y método del código que no aparece en las secciones anteriores está acá, agrupado por clase. Son en general consultas simples, constantes o métodos de fábrica que siguen la misma idea que los ya explicados.

## Comportamientos (`logica.comportamientos`)

| Clase | Miembro | Qué hace |
|---|---|---|
| `AtaquePorProyectil` | `# generadorProyectil : GeneradorProyectil` | Quién crea cada disparo (el Octorok, el Wizzrobe o el StoneHinox). El ataque no sabe qué proyectil se crea: se lo pide al generador |
| `AtaquePorProyectil` | `# ultimoAtaque : long` | Hora (en ms) del último disparo |
| `AtaquePorProyectil` | `# pasoElIntervalo() : boolean` | Verdadero si desde `ultimoAtaque` pasaron al menos `intervalo` ms. Lo usa `puedeAtacar` para no disparar seguido |
| `AtaqueRecargado` | `- inicioCarga : long = -1` | Hora en que se empezó a mantener A. `-1` quiere decir que nunca se cargó. `cargar()` la anota y `estaCargado()` mira si pasaron `TIEMPO_CARGA` ms |
| `DefensaPorEscudo` | `# soloDeFrente : boolean` | Si es verdadero, el escudo solo frena los golpes que vienen de frente; si es falso, frena todos |
| `DefensaPorEscudo` | `# sinEscudo : ComportamientoDefensa` | La defensa que se usa cuando el golpe no se frena: una `DefensaLimitada(SIN_LIMITE, SIEMPRE)`, que deja pasar todo el daño |
| `MovimientoAleatorio` | `# intervaloCambio : long` | Cada cuántos ms elige una dirección nueva al azar |
| `MovimientoAleatorio` | `# ultimoCambio : long` | Hora del último cambio de dirección |
| `MovimientoTeletransporte` | `# ultimo : long` | Hora del último teletransporte. Cuando pasan `intervalo` ms, vuelve a teletransportar |

## Enemigos (`logica.entidades.enemigos`)

| Clase | Miembro | Qué hace |
|---|---|---|
| `GeneradorProyectil` | `generarProyectil() : Proyectil` | Única operación de la interfaz: crea el proyectil que se dispara. La implementan `Octorok`, `Wizzrobe` y `StoneHinox`, y la llama `AtaquePorProyectil` |
| `Octorok` | `+ generarProyectil() : Proyectil` | Pide a la fábrica un proyectil hacia donde mira, con su `DANIO_DISPARO` |
| `Wizzrobe` | `+ generarProyectil() : Proyectil` | Pide a la fábrica un proyectil hacia Link (`direccionHaciaJugador()`), con su `DANIO_DISPARO` |
| `StoneHinox` | `+ generarProyectil() : Proyectil` | Pide a la fábrica una roca grande hacia Link, con su `DANIO_ROCA` |
| `Octorok`, `Wizzrobe` | `- CANTIDAD_DISPAROS : int = 1` | Cuántos proyectiles tira por vez. Se pasa al `AtaquePorProyectil` |
| `StoneHinox` | `- CANTIDAD_ROCAS : int = 3`, `- INTERVALO_ROCAS : long = 400` | Cuántas rocas tira en cada ráfaga y cuántos ms pasan entre una y otra. Se pasan al `AtaqueRafaga` de `lanzarRocas` |
| `StoneHinox` | `- lanzarRocas : AtaqueRafaga` | El ataque de tirar rocas. Es del tipo concreto porque el StoneHinox le llama `reiniciar()` antes de cada ráfaga. Alterna entre este ataque, la embestida y la avalancha con `setAtaque` |
| `MasterStalfos` | `- direccionGolpe : Direccion` | Hacia dónde miraba al empezar el golpe. `getRutaImagen()` la usa para el GIF `ataque-<dir>`, así no cambia si gira en medio del golpe (cambio 44) |
| `MasterStalfos` | `- MARGEN_IMAGEN_X : int = 12`, `- MARGEN_IMAGEN_Y : int = 36` | Cuánto sobra el GIF de 171 × 216 a la izquierda y arriba del lugar de la entidad, para la espada levantada y el arco (cambio 44) |
| `MasterStalfos` | `+ getXImagen() : int`, `+ getYImagen() : int` | `getX() - MARGEN_IMAGEN_X` y `getY() - MARGEN_IMAGEN_Y`: la vista dibuja el GIF corrido; el cuerpo no se mueve (cambio 44) |
| `Wizzrobe` | `# desapareciendo : boolean` | Verdadero mientras se ve el GIF de desaparecer antes del teletransporte (cambio 30). `getRutaImagen()` lo usa para elegir `desaparecer-<dir>` |
| `EnemigoConDrop` | `# getProbabilidadDrop() : double` (abstracto) | Probabilidad (de 0 a 1) de soltar un power-up al morir. La usa `soltarDrop` con `Math.random()` |
| `ErizoDeMar`, `Moblin` | `# getProbabilidadDrop() : double` | Devuelve `PROBABILIDAD_DROP` = 0.2 |
| `Octorok` | `# getProbabilidadDrop() : double` | Devuelve `PROBABILIDAD_DROP` = 0.4 |
| `MoblinConEspadaYEscudo` | `# getProbabilidadDrop() : double` | Devuelve `PROBABILIDAD_DROP` = 0.5 |
| `Wizzrobe` | `# getProbabilidadDrop() : double` | Devuelve `PROBABILIDAD_DROP` = 1.0: siempre suelta algo |

## Entidades fijas, Link y mapa

| Clase | Miembro | Qué hace |
|---|---|---|
| `Link` | `- girando() : boolean` | Verdadero durante el giro del ataque recargado (ver "El giro del ataque recargado" en la explicación de `Link`) |
| `EntidadAnimada` | `- PERIODO_PARPADEO : long = 100` | Cada cuántos ms se prende y se apaga durante el parpadeo |
| `Rupia` | `+ getCantidad() : int` | Devuelve cuántas rupias da (al azar entre `CANTIDAD_MINIMA` y `CANTIDAD_MAXIMA`). Es una consulta pública; el juego usa el atributo dentro de la clase |
| `SuelosQuebradizo` | `+ estaPisado() : boolean` | Indica si Link ya lo pisó y se está por romper. Es una consulta pública; la clase usa el atributo `pisado` |
| `Escena` | `+ getFilas() : int`, `+ getColumnas() : int` | Tamaño de la grilla de sectores. `GeneradorNivel` los usa para recorrer todos los sectores |
| `Sector` | `+ getFila() : int`, `+ getColumna() : int` | Dónde está el sector en la escena. `Escena` los usa para buscar el sector vecino y `GeneradorNivel` para agregarlo |

## Fábricas (`logica.fabricas`)

`FabricaEntidades` tiene un método `crear…` por cada entidad. Cada uno recibe la posición (y lo que haga falta), pide el sprite a la `FabricaSprites` y devuelve la entidad nueva. Los que no se nombran en otras secciones siguen todos la misma forma, por ejemplo:

```java
public Agua crearAgua(int x, int y) {
    return new Agua(fabricaSprites.crearSpritesAgua(), x, y);
}
```

Son `crearAgua`, `crearPasto`, `crearRoca`, `crearSuelosQuebradizo`, `crearTrampaDeCuchillas`, `crearErizoDeMar`, `crearOctorok`, `crearMoblinConEspadaYEscudo`, `crearWizzrobe`, `crearMasterStalfos`, `crearStoneHinox`, `crearRupia`, `crearCorazon`, `crearFragmentoDeCorazon`, `crearBellota` y `crearEspada`. Los llama `GeneradorNivel` al leer el archivo del nivel; además, `EnemigoConDrop` usa `crearRupia` y `crearCorazon` al soltar un power-up, y `Juego` usa `crearBellota` cuando la racha llega a `RACHA_PARA_BELLOTA`.

`FabricaSprites` tiene un método `crearSprites…` por cada entidad. Cada uno arma el `Sprite` con las rutas de sus imágenes, en la carpeta del modo gráfico elegido (`original` o `alternativa`), con `armar(prefijo, estados…)`, que carga `prefijo-estado.png`. Por ejemplo, `crearSpritesAgua()` hace `armar("agua", "normal")`. Los que no se nombran en otras secciones son `crearSpritesAgua`, `crearSpritesPasto`, `crearSpritesRocaGrande`, `crearSpritesSuelosQuebradizo`, `crearSpritesCaidasAlVacio`, `crearSpritesTrampaDeCuchillas`, `crearSpritesErizoDeMar`, `crearSpritesOctorok`, `crearSpritesProyectil`, `crearSpritesRupia`, `crearSpritesCorazon`, `crearSpritesFragmentoDeCorazon`, `crearSpritesBellota`, `crearSpritesEspada` y `crearSpritesEscudo`. Los llama `FabricaEntidades`.

## Vista (`vista`)

| Clase | Miembro | Qué hace |
|---|---|---|
| `GUI` | `# panelPrincipal : PanelPantallaPrincipal`, `# panelRanking : PanelPantallaRanking` | Los paneles de la pantalla de inicio y del ranking. `GUI` los muestra cuando hace falta |
| `GUI` | `# controladorJuego : ControladorJuego` | Lo que la vista le pide al juego (empezar partida, ranking, etc.). Es la interfaz que implementa `Juego` |
| `PanelPantallaNivel` | `- etiquetaNivel`, `- etiquetaTiempo`, `- etiquetaPuntaje`, `- etiquetaVidas`, `- etiquetaRupias`, `- etiquetaObjeto : JLabel` | Las seis etiquetas del HUD de arriba. Se crean en el constructor y se actualizan con `setText(etiqueta(titulo, valor))` cuando el juego avisa un cambio (vidas y corazones, puntos, rupias, objeto equipado, tiempo y número de nivel) |
